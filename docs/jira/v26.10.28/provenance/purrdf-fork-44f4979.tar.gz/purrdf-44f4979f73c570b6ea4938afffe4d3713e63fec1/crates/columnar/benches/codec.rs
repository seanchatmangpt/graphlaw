// SPDX-FileCopyrightText: 2026 Blackcat Informatics® Inc. <paudley@blackcatinformatics.ca>
// SPDX-License-Identifier: MIT OR Apache-2.0 OR MulanPSL-2.0

// Bench targets are not public API, so the workspace `missing_docs` lint is
// not asked of their items.
#![allow(missing_docs)]

//! Report-only end-to-end measurements for the five-table columnar codec,
//! at the 1k-quad and the 100k-quad scale.

use std::sync::Arc;

use purrdf_columnar::plain_bench::PlainInt64;
use purrdf_columnar::{Compression, read, write};
use purrdf_core::{BlankScope, ContentStore, RdfDataset, RdfDatasetBuilder, RdfLiteral};
use purrdf_testkit::bench::{BatchSize, Bench, BenchmarkId, Throughput, bench_group, bench_main};
use purrdf_testkit::rng::splitmix64_next as mix;

const ROWS: u32 = 500;

/// Quads per fixture row: a subject-side quad in the default graph and a
/// blank-node quad in the named graph, so the fixed five-table schema sees
/// both shapes at every scale.
const QUADS_PER_ROW: u64 = 2;

/// Rows in the 100k-quad fixture: memory-bounded at 100k quads, not the
/// 1M-100M egress scales; the step from 1k shows how the codec's cost moves
/// with scale.
const ROWS_100K: u32 = 50_000;

fn fixture(rows: u32) -> (Arc<RdfDataset>, ContentStore) {
    let mut builder = RdfDatasetBuilder::new();
    let predicate = builder.intern_iri("https://example.org/p").unwrap();
    let graph = builder.intern_iri("https://example.org/g").unwrap();
    for row in 0..rows {
        let subject = builder
            .intern_iri(&format!("https://example.org/s{row}"))
            .unwrap();
        let blank = builder
            .intern_blank(&format!("b{row}"), BlankScope(row % 8))
            .unwrap();
        let literal = builder
            .intern_literal(RdfLiteral::typed(
                row.to_string(),
                "http://www.w3.org/2001/XMLSchema#integer",
            ))
            .unwrap();
        builder.push_quad(subject, predicate, blank, None).unwrap();
        builder
            .push_quad(blank, predicate, literal, Some(graph))
            .unwrap();
    }
    let mut blobs = ContentStore::new();
    for row in 0..16 {
        blobs.insert(format!("payload-{row:04}").into_bytes());
    }
    (
        builder.freeze().expect("benchmark fixture is valid RDF"),
        blobs,
    )
}

fn bench_codec(c: &mut Bench) {
    bench_codec_at(c, ROWS);
}

/// The same write/read rows at the 100k-quad scale.
fn bench_codec_100k(c: &mut Bench) {
    bench_codec_at(c, ROWS_100K);
}

fn bench_codec_at(c: &mut Bench, rows: u32) {
    let (dataset, blobs) = fixture(rows);
    let quads = u64::from(rows) * QUADS_PER_ROW;
    let encoded = write(&*dataset, &blobs, Compression::Zstd)
        .expect("benchmark fixture encodes as ZSTD Parquet");
    let mut group = c.benchmark_group(format!("columnar_codec_{quads}_quads"));
    group.throughput(Throughput::Elements(quads));
    group.bench_function("write_uncompressed", |bencher| {
        bencher.iter(|| {
            std::hint::black_box(
                write(&*dataset, &blobs, Compression::Uncompressed)
                    .expect("benchmark fixture encodes"),
            )
        });
    });
    group.bench_function("write_zstd", |bencher| {
        bencher.iter(|| {
            std::hint::black_box(
                write(&*dataset, &blobs, Compression::Zstd).expect("benchmark fixture encodes"),
            )
        });
    });
    // read_zstd runs ~450ms/iter at 100k quads; cap samples to keep the suite bounded.
    group.sample_size(50);
    group.bench_function("read_zstd", |bencher| {
        bencher.iter(|| {
            std::hint::black_box(read(&encoded.files).expect("benchmark fixture decodes"))
        });
    });
    group.finish();
}

/// Rows per PLAIN `INT64` column: many chunk multiples, and past any small-size
/// special case.
const PLAIN_ROWS: usize = 65_536;

/// A column with `nulls_per_ten` rows in ten null, at seeded positions.
fn plain_column(nulls_per_ten: u64) -> PlainInt64 {
    let mut state = 0xC0DE_u64 ^ nulls_per_ten;
    PlainInt64::from_rows((0..PLAIN_ROWS).map(|_| {
        let null = mix(&mut state) % 10 < nulls_per_ten;
        let value = mix(&mut state).cast_signed();
        (!null).then_some(value)
    }))
}

/// The PLAIN `INT64` value codec on its own (the `columnar.plain-codec` site):
/// encode is the copy of the dense present values into the body, decode the
/// length check and the copy back, each at 0%, 10% and 90% nulls. The decode's
/// definition levels are cloned outside the timed region.
fn bench_plain_int64(c: &mut Bench) {
    let mut group = c.benchmark_group("columnar_plain_int64_65536_rows");
    group.throughput(Throughput::Elements(PLAIN_ROWS as u64));
    for (label, nulls_per_ten) in [("nulls_0pct", 0), ("nulls_10pct", 1), ("nulls_90pct", 9)] {
        let column = plain_column(nulls_per_ten);
        let body = column.encode();
        let decoded = PlainInt64::decode(&body, column.presence()).expect("the body decodes");
        assert_eq!(decoded, column, "the bench column round-trips");
        group.bench_with_input(
            BenchmarkId::new("encode", label),
            &column,
            |bencher, column| {
                bencher.iter(|| std::hint::black_box(column.encode()));
            },
        );
        group.bench_with_input(BenchmarkId::new("decode", label), &body, |bencher, body| {
            bencher.iter_batched(
                || column.presence(),
                |presence| {
                    std::hint::black_box(
                        PlainInt64::decode(body, presence).expect("the body decodes"),
                    )
                },
                BatchSize::SmallInput,
            );
        });
    }
    group.finish();
}

bench_group!(benches, bench_codec, bench_codec_100k, bench_plain_int64);
bench_main!(benches);
