// SPDX-FileCopyrightText: 2026 Blackcat Informatics® Inc. <paudley@blackcatinformatics.ca>
// SPDX-License-Identifier: MIT OR Apache-2.0 OR MulanPSL-2.0

//! The two orders this crate defines over composite values, and why there are two.
//!
//! # 1. The SEP-0009 value relations — partial, and they raise
//!
//! [`list_equal`] / [`map_equal`] / [`list_less_than`] / [`map_less_than`] are the
//! spec's own operators. They are `Result<bool, CdtTypeError>` because SPARQL
//! comparison has three outcomes, not two: a positional pair that cannot be compared
//! at all is a **type error** that propagates out of the whole expression, and must
//! never be silently read as "not equal". `Err` here is that outcome.
//!
//! ## The three ways a comparison has no answer are kept apart
//!
//! Every refusal carries a [`crate::CdtTypeErrorKind`]. A query cannot tell them
//! apart — SPARQL propagates all three identically — but a validator must, because
//! only one of them is a defect:
//!
//! * an **ill-typed** operand claims a datatype PurRDF models and then carries a
//!   lexical form outside its lexical space, so it denotes nothing in any host;
//! * an **unmodelled** operand is well-formed RDF whose datatype PurRDF has nothing
//!   to say about, so the comparison is undecided rather than wrong;
//! * an **undefined** pair is two terms that both denote perfectly well, with no
//!   relation between them — two IRIs under `<`, a blank node, a `null`.
//!
//! Every literal in this module is resolved through [`crate::parse_literal`], which
//! is the crate's single lexical-to-value choke point and the only thing that knows
//! how to tell those apart. Calling `purrdf_xsd::parse_by_iri` here directly and
//! writing `.ok().flatten()` would collapse the first two into one `None`, which is
//! precisely the distinction [`crate::LiteralValue`] exists to preserve.
//!
//! # 2. The syntactic total order — total, and it never raises
//!
//! [`total_term_cmp`] / [`total_key_cmp`] / [`total_value_cmp`] give every pair of
//! elements an answer. `ORDER BY` needs one (a sort cannot raise per-comparison and
//! still terminate with an order), and so do this crate's map key order and render
//! order, which is what makes [`crate::canonical_lexical`] byte-deterministic.
//!
//! ## Why it is syntactic, and not "value order with a structural tie-break"
//!
//! The obvious composite — compare by value first, fall back to a structural
//! tie-break when the values are incomparable — is **not transitive**, so it is not
//! a total order at all, and Rust's sort is entitled to panic when handed it. A
//! three-element counterexample, all of them literals:
//!
//! * `A = "9"^^xsd:double`, `B = "P1D"^^xsd:duration`, `C = "8"^^xsd:float`.
//! * `A` and `B` are value-incomparable (a number against a duration), so the
//!   tie-break decides: `xsd:double` sorts before `xsd:duration`, so `A < B`.
//! * `B` and `C` are value-incomparable too, and `xsd:duration` sorts before
//!   `xsd:float`, so `B < C`.
//! * `A` and `C` **are** value-comparable, and `9 > 8`, so `C < A`.
//!
//! That is a cycle: `A < B < C < A`. The failure is structural, not a quirk of these
//! three constants — any value-incomparable element can be slotted between two
//! comparable ones whose value order and syntactic order disagree. The order this
//! module exports is therefore purely syntactic: a category rank, then a
//! lexicographic walk of the element's own syntactic components. That is provably
//! transitive (it is a lexicographic product of total orders), allocation-free, and
//! identical on every host — the three properties a sort comparator and a canonical
//! renderer both need. Value semantics stay where they belong: in the partial,
//! raising relations above.
//!
//! # Everything here is iterative, and the walk owns what it parses
//!
//! Composite values are trees over attacker-controlled lexical input, and a stack
//! overflow in Rust is an `abort`, not a catchable panic. Every function in this
//! module walks the tree with an explicit heap worklist; none of them recurses.
//!
//! The one place a walk meets a value that is not in the input is a `cdt:`-typed
//! literal: the value relations see through it to the composite its lexical form
//! denotes (see `composite_reach`), and that composite has to be parsed into a value
//! nobody else owns. The walk **owns** it: the parsed value goes onto the same work
//! list as the borrowed input, as an owned item beside the borrowed ones, and is
//! taken apart there position by position exactly as a nested composite written with
//! brackets is. A literal inside a literal inside a literal therefore costs one
//! parse and a few work-list entries per level, and never a native frame — there is
//! no re-entry into the comparator, and nothing for a depth budget to bound.

use alloc::vec::Vec;
use core::cmp::Ordering;
use core::mem;

use purrdf_xsd::XsdValue;

use crate::error::CdtTypeError;
use crate::literal::{NativeLiteralValue, release_xsd_with_memory};
use crate::memory::CdtMemory;
use crate::memory::{Memory, Resident, Storage, StorageError};
use crate::term::{CdtEntry, CdtKey, CdtLiteral, CdtTerm};
use crate::value::{CdtContents, CdtParts, CdtValue};
use core::alloc::Layout;

// ── 1. The syntactic total order ────────────────────────────────────────────────

/// One step of the iterative total-order comparison.
enum CmpJob<'a> {
    /// Compare two terms.
    Pair(&'a CdtTerm, &'a CdtTerm),
    /// Compare two map keys (always leaves).
    KeyPair(&'a CdtKey, &'a CdtKey),
    /// A comparison already decided by the enclosing structure (a length tie-break,
    /// or a composite-kind mismatch).
    Decided(Ordering),
}

/// The crate's syntactic total order over two literals: datatype IRI, then lexical
/// form, then language tag, then base direction — each by Unicode scalar order, with
/// `None` before `Some`.
///
/// # The component order is pinned by the corpus, not chosen for looks
///
/// This order is what a map's entries are held and compared in, so SEP-0009's own
/// map-ordering tests decide it. `map-functions/map-less-than-18.rq` requires
/// `{'1'@sv: 41} < {'2'@en: 41}` to be `true`: both keys are `rdf:langString`, so the
/// datatype component ties, and only a **lexical form before language tag** order
/// answers `true` — comparing the tags first would put `sv` after `en` and answer
/// `false`. `map-less-than-19.rq` is the other half: `{'1'@sv: 41} < {'1'@en: 41}` is
/// `false`, which is the language tag deciding once the lexical forms tie.
/// `map-less-than-15.rq` (`'001'` before `'01'`, same datatype) and
/// `map-less-than-17.rq` (`xsd:integer` before `xsd:string`) pin the other two
/// components.
fn literal_cmp(a: &CdtLiteral, b: &CdtLiteral) -> Ordering {
    a.datatype
        .cmp(&b.datatype)
        .then_with(|| a.lexical.cmp(&b.lexical))
        .then_with(|| a.language.cmp(&b.language))
        .then_with(|| a.direction.cmp(&b.direction))
}

/// The crate's syntactic total order over two map keys.
///
/// Strict on distinct keys: two keys compare `Equal` only when they are the same
/// term. That is what lets a map hold its entries as a sorted sequence with exactly
/// one admissible arrangement per value.
///
/// # Examples
///
/// ```rust
/// use core::cmp::Ordering;
///
/// use purrdf_cdt::{CdtKey, CdtLiteral, total_key_cmp};
///
/// let iri = CdtKey::Iri("http://example.org/a".into());
/// let lit = CdtKey::Literal(CdtLiteral::plain("a"));
/// // IRIs sort before literals.
/// assert_eq!(total_key_cmp(&iri, &lit), Ordering::Less);
/// // Distinct lexical forms of one value stay distinct.
/// let one = CdtKey::Literal(CdtLiteral::typed("1", "http://www.w3.org/2001/XMLSchema#integer"));
/// let oh_one = CdtKey::Literal(CdtLiteral::typed("01", "http://www.w3.org/2001/XMLSchema#integer"));
/// assert_ne!(total_key_cmp(&one, &oh_one), Ordering::Equal);
/// ```
#[must_use]
pub fn total_key_cmp(a: &CdtKey, b: &CdtKey) -> Ordering {
    a.rank().cmp(&b.rank()).then_with(|| match (a, b) {
        (CdtKey::Iri(x), CdtKey::Iri(y)) => x.cmp(y),
        (CdtKey::Literal(x), CdtKey::Literal(y)) => literal_cmp(x, y),
        // Equal ranks imply the same variant, so this arm is unreachable; answering
        // `Equal` keeps the function total rather than panicking on an impossible
        // input.
        _ => Ordering::Equal,
    })
}

/// The crate's syntactic total order over two elements.
///
/// Category rank first — `null` < blank node < IRI < literal < triple term <
/// composite — then the category's own order. Composites compare element-wise and
/// then by length; a list sorts before a map.
///
/// Walks the two trees with an explicit heap worklist; it never recurses.
///
/// # Examples
///
/// ```rust
/// use core::cmp::Ordering;
///
/// use purrdf_cdt::{CdtLiteral, CdtTerm, total_term_cmp};
///
/// assert_eq!(
///     total_term_cmp(&CdtTerm::Null, &CdtTerm::Iri("http://example.org/a".into())),
///     Ordering::Less
/// );
/// // Within literals the order is syntactic, so it is defined even for pairs the
/// // value order calls incomparable.
/// let nan = CdtTerm::Literal(CdtLiteral::typed("NaN", "http://www.w3.org/2001/XMLSchema#double"));
/// let one = CdtTerm::Literal(CdtLiteral::typed("1", "http://www.w3.org/2001/XMLSchema#double"));
/// assert_ne!(total_term_cmp(&nan, &one), Ordering::Equal);
/// ```
#[must_use]
pub fn total_term_cmp(a: &CdtTerm, b: &CdtTerm) -> Ordering {
    try_total_term_cmp(a, b, &mut Resident).expect("resident composite comparison capacity")
}

/// Native syntactic term ordering through the caller's physical storage owner.
/// # Errors
/// Checked layout, admission or allocator refusal, separate from comparability.
pub fn try_total_term_cmp(
    a: &CdtTerm,
    b: &CdtTerm,
    storage: &mut impl Storage,
) -> Result<Ordering, StorageError> {
    let mut memory = Memory::new(storage);
    let mut jobs = Vec::new();
    memory.push(&mut jobs, CmpJob::Pair(a, b))?;
    run_cmp(jobs, &mut memory)
}

/// The crate's syntactic total order over two composite values.
///
/// This is the order [`CdtValue::map`](crate::CdtValue::map) sorts entries with and
/// the order [`crate::canonical_lexical`] writes a map in.
#[must_use]
pub fn total_value_cmp(a: &CdtValue, b: &CdtValue) -> Ordering {
    try_total_value_cmp(a, b, &mut Resident).expect("resident composite comparison capacity")
}

/// Native syntactic composite ordering through the same existing relation.
/// # Errors
/// Checked layout, admission or allocator refusal, separate from comparability.
pub fn try_total_value_cmp(
    a: &CdtValue,
    b: &CdtValue,
    storage: &mut impl Storage,
) -> Result<Ordering, StorageError> {
    let mut memory = Memory::new(storage);
    let mut jobs = Vec::new();
    push_value_cmp(&mut jobs, a, b, &mut memory)?;
    run_cmp(jobs, &mut memory)
}

/// Drive the comparison worklist to a verdict.
fn run_cmp(mut jobs: Vec<CmpJob<'_>>, memory: &mut Memory<'_>) -> Result<Ordering, StorageError> {
    while let Some(job) = jobs.pop() {
        let decided = match job {
            CmpJob::Decided(ordering) => ordering,
            CmpJob::KeyPair(x, y) => total_key_cmp(x, y),
            CmpJob::Pair(x, y) => {
                let by_rank = x.rank().cmp(&y.rank());
                if by_rank != Ordering::Equal {
                    memory.release_vec(jobs)?;
                    return Ok(by_rank);
                }
                match (x, y) {
                    (CdtTerm::Null, CdtTerm::Null) => Ordering::Equal,
                    (CdtTerm::Blank(p), CdtTerm::Blank(q)) => p.cmp(q),
                    (CdtTerm::Iri(p), CdtTerm::Iri(q)) => p.cmp(q),
                    (CdtTerm::Literal(p), CdtTerm::Literal(q)) => literal_cmp(p, q),
                    (CdtTerm::TripleTerm(p), CdtTerm::TripleTerm(q)) => {
                        memory.push(&mut jobs, CmpJob::Pair(&p.object, &q.object))?;
                        memory.push(&mut jobs, CmpJob::Pair(&p.predicate, &q.predicate))?;
                        memory.push(&mut jobs, CmpJob::Pair(&p.subject, &q.subject))?;
                        continue;
                    }
                    (CdtTerm::Composite(p), CdtTerm::Composite(q)) => {
                        push_value_cmp(&mut jobs, p.as_ref(), q.as_ref(), memory)?;
                        continue;
                    }
                    // Equal ranks imply the same variant; answering `Equal` keeps the
                    // function total rather than panicking on an impossible input.
                    _ => Ordering::Equal,
                }
            }
        };
        if decided != Ordering::Equal {
            memory.release_vec(jobs)?;
            return Ok(decided);
        }
    }
    memory.release_vec(jobs)?;
    Ok(Ordering::Equal)
}

/// Push the jobs comparing two composites, in reverse evaluation order (the
/// worklist pops LIFO, so the length tie-break goes on first and is consulted last).
fn push_value_cmp<'a>(
    jobs: &mut Vec<CmpJob<'a>>,
    a: &'a CdtValue,
    b: &'a CdtValue,
    memory: &mut Memory<'_>,
) -> Result<(), StorageError> {
    match (a.contents(), b.contents()) {
        (CdtContents::List(_), CdtContents::Map(_)) => {
            memory.push(jobs, CmpJob::Decided(Ordering::Less))?;
        }
        (CdtContents::Map(_), CdtContents::List(_)) => {
            memory.push(jobs, CmpJob::Decided(Ordering::Greater))?;
        }
        (CdtContents::List(left), CdtContents::List(right)) => {
            memory.push(jobs, CmpJob::Decided(left.len().cmp(&right.len())))?;
            for (p, q) in left.iter().zip(right.iter()).rev() {
                memory.push(jobs, CmpJob::Pair(p, q))?;
            }
        }
        (CdtContents::Map(left), CdtContents::Map(right)) => {
            memory.push(jobs, CmpJob::Decided(left.len().cmp(&right.len())))?;
            for (p, q) in left.iter().zip(right.iter()).rev() {
                memory.push(jobs, CmpJob::Pair(&p.value, &q.value))?;
                memory.push(jobs, CmpJob::KeyPair(&p.key, &q.key))?;
            }
        }
    }
    Ok(())
}

// ── 2. The SEP-0009 value relations ─────────────────────────────────────────────

/// What a composite element's literal denotes.
///
/// Produced by [`denotation`], which is a thin wrapper over [`crate::parse_literal`] —
/// the crate's single lexical-to-value choke point. The four cases are exactly
/// [`crate::LiteralValue`]'s, plus the one this layer has to add: a language-tagged
/// string, whose "value" is the term itself.
///
/// # Why [`Denotation::IllTyped`] and [`Denotation::Unmodelled`] are not one case
///
/// They look alike to a caller that only asks "did it parse?", and collapsing them is
/// the bug this enum exists to prevent. An **unmodelled** literal is well-formed RDF
/// whose datatype PurRDF has nothing to say about, so a comparison with it has no
/// answer — and might have had one, in a host that knows that datatype. An
/// **ill-typed** literal is a defect: it claims a datatype PurRDF *does* model and
/// then carries a lexical form outside that datatype's lexical space, so it denotes
/// nothing anywhere, in any host. Both refuse the comparison, but only the second is
/// something a validator must report, and the refusals therefore carry different
/// [`crate::CdtTypeErrorKind`]s.
enum Denotation {
    /// A `cdt:List` / `cdt:Map` literal whose lexical form parses.
    Composite(CdtValue),
    /// An XSD literal whose lexical form parses.
    Xsd(XsdValue),
    /// A language-tagged string (`rdf:langString`, or RDF 1.2's `rdf:dirLangString`).
    /// Its value space is term identity: two of them are the same value exactly when
    /// they are the same term.
    LanguageTagged,
    /// A datatype PurRDF models, with a lexical form that is not in its lexical space.
    IllTyped,
    /// A datatype outside every value space PurRDF models.
    Unmodelled,
}

/// Resolve a literal through [`crate::parse_literal`].
///
/// This is the **only** place in the crate that turns a `(lexical form, datatype IRI)`
/// pair inside a composite into a value; `parse_literal` in turn is the only place
/// that decides between the XSD and composite value spaces. Reaching for
/// `purrdf_xsd::parse_by_iri` directly here would reintroduce the collapse this
/// module documents against, because that function's `Err` (ill-typed) and `Ok(None)`
/// (unmodelled) are one `None` the moment anyone writes `.ok().flatten()`.
///
/// The language check comes first and is not redundant: the invariant on
/// [`CdtLiteral`] says a language tag implies `rdf:langString` / `rdf:dirLangString`,
/// but this function is total over the type, and a hand-built literal carrying both a
/// language tag and, say, `xsd:integer` is a language-tagged string with a confused
/// datatype rather than an ill-typed integer.
fn denotation(literal: &CdtLiteral, memory: &mut Memory<'_>) -> Result<Denotation, StorageError> {
    if literal.language.is_some() {
        return Ok(Denotation::LanguageTagged);
    }
    Ok(
        match crate::literal::resolve_literal_with_memory(
            &literal.lexical,
            &literal.datatype,
            memory,
        )? {
            NativeLiteralValue::Cdt(value) => Denotation::Composite(value),
            NativeLiteralValue::Xsd(value) => Denotation::Xsd(value),
            NativeLiteralValue::IllTyped => Denotation::IllTyped,
            NativeLiteralValue::Opaque => Denotation::Unmodelled,
        },
    )
}

impl Denotation {
    fn release(self, memory: &mut Memory<'_>) -> Result<(), StorageError> {
        match self {
            Self::Composite(value) => value.release_with_memory(memory),
            Self::Xsd(value) => release_xsd_with_memory(value, memory),
            Self::LanguageTagged | Self::IllTyped | Self::Unmodelled => Ok(()),
        }
    }
}

/// Numeric scratch is admitted from the native operation certificate before the
/// original kernel runs; it dies inside the kernel before this scope releases it.
fn xsd_relation(
    a: &XsdValue,
    b: &XsdValue,
    equal: bool,
    memory: &mut Memory<'_>,
) -> Result<Option<bool>, StorageError> {
    memory.scope(|memory| {
        let baseline = memory.admitted_bytes();
        let mut original_failure = None;
        let mut admit = |layout: purrdf_xsd::exact::cost::NumericOperationLayout| {
            let next = baseline
                .checked_add(layout.required_bytes())
                .ok_or(purrdf_xsd::bigint::LimbScratchError::SizeOverflow)?;
            let required = next.saturating_sub(memory.admitted_bytes());
            if let Err(error) = memory.add_bytes(required) {
                original_failure.get_or_insert(error);
                return Err(purrdf_xsd::bigint::LimbScratchError::AllocationFailed);
            }
            Ok(())
        };
        let answer = if equal {
            purrdf_xsd::ops::value_equal_admitted(a, b, &mut admit)
        } else {
            purrdf_xsd::ops::value_cmp_admitted(a, b, &mut admit)
                .map(|order| order.map(|order| order == Ordering::Less))
        };
        // Native scratch has already died. Select its original failure before any
        // refund callback; the common scope preserves it if that callback refuses.
        if let Some(error) = original_failure {
            return Err(error);
        }
        let answer = answer.map_err(|error| match error {
            purrdf_xsd::bigint::LimbScratchError::SizeOverflow => StorageError::SizeOverflow,
            purrdf_xsd::bigint::LimbScratchError::Storage(error) => error,
            purrdf_xsd::bigint::LimbScratchError::AllocationFailed
            | purrdf_xsd::bigint::LimbScratchError::Destinations { .. }
            | purrdf_xsd::bigint::LimbScratchError::Capacity { .. }
            | purrdf_xsd::bigint::LimbScratchError::Exhausted { .. }
            | purrdf_xsd::bigint::LimbScratchError::Retained { .. } => {
                StorageError::AllocationFailed
            }
        })?;
        let scratch = memory
            .admitted_bytes()
            .checked_sub(baseline)
            .ok_or(StorageError::SizeOverflow)?;
        memory.release_bytes(scratch)?;
        Ok(answer)
    })
}

/// The error an ill-typed operand raises, whichever relation asked.
fn ill_typed() -> CdtTypeError {
    CdtTypeError::ill_typed(
        "a literal whose datatype PurRDF models and whose lexical form is not in that \
         datatype's lexical space denotes nothing, so no comparison with it has an answer",
    )
}

/// The error an unmodelled operand raises, whichever relation asked.
fn unmodelled() -> CdtTypeError {
    CdtTypeError::unmodelled(
        "a literal whose datatype is outside every value space PurRDF models may or may \
         not denote the same value as this one, so the comparison has no answer",
    )
}

/// The error `<` raises between a list and a map, wherever in a walk the pair meets.
fn list_against_map() -> CdtTypeError {
    CdtTypeError::undefined("SPARQL `<` is not defined between a cdt:List and a cdt:Map")
}

/// How an element reaches the composite it denotes.
///
/// # Why an element that *is* a literal can still be a composite
///
/// SEP-0009 admits one and the same composite element written two ways inside a
/// lexical form: as the grammar's own nested `List` / `Map` production, or as an
/// ordinary `RDFLiteral` carrying the composite datatype. The corpus writes the same
/// test both ways and demands the same answer — `list-functions/contains-07.rq` nests
/// `[2]` while `contains-08.rq` writes `'[2]'^^cdt:List`, and both must find it;
/// `contains-09.rq` and `contains-10.rq` do the same for a map. So the two spellings
/// denote the same **value**, and the value relations have to see through the literal
/// one.
///
/// Term identity does not, and must not: `list-functions/sameterm-03.rq` requires two
/// spellings of one value to be different *terms*. That is exactly why the literal
/// keeps its lexical form ([`CdtLiteral`] is verbatim), why map keys are still
/// distinguished lexically, and why this resolution lives here in the value relations
/// and nowhere else.
enum Reach {
    /// The element is a [`CdtTerm::Composite`]: the value is right there, borrowed.
    Syntactic,
    /// The element is a `cdt:`-typed literal whose lexical form parses: the value was
    /// parsed out of it and belongs to the walk that asked.
    Parsed(CdtValue),
}

/// The composite an element denotes, in either of its two spellings, or `None` when it
/// denotes no composite at all.
///
/// An **ill-typed** `cdt:`-typed literal answers `None` here on purpose: it denotes no
/// composite, and the leaf rules then raise
/// [`CdtTypeErrorKind::IllTyped`](crate::CdtTypeErrorKind::IllTyped) for it rather than
/// reporting an inequality.
fn composite_reach(term: &CdtTerm, memory: &mut Memory<'_>) -> Result<Option<Reach>, StorageError> {
    match term {
        CdtTerm::Composite(_) => Ok(Some(Reach::Syntactic)),
        CdtTerm::Literal(literal) => match denotation(literal, memory)? {
            Denotation::Composite(value) => Ok(Some(Reach::Parsed(value))),
            other => {
                other.release(memory)?;
                Ok(None)
            }
        },
        _ => Ok(None),
    }
}
impl Reach {
    fn release(self, memory: &mut Memory<'_>) -> Result<(), StorageError> {
        match self {
            Self::Syntactic => Ok(()),
            Self::Parsed(value) => value.release_with_memory(memory),
        }
    }
}

/// What a leaf comparison under `=` found.
enum LeafEq {
    /// The pair has its answer, or its refusal.
    Answer(Result<bool, CdtTypeError>),
    /// Both sides denote composites, at least one of them spelled as a literal. Each
    /// `Some` is the value parsed out of that side's literal; a `None` side is already
    /// a [`CdtTerm::Composite`] and is used as it stands. The walk continues into the
    /// pair as it would into two nested composites.
    Composites(Option<CdtValue>, Option<CdtValue>),
}

/// SPARQL `=` over two literals.
///
/// Same term is always `true`; after that the answer is a function of what the two
/// literals **denote**, which is what [`denotation`] reports:
///
/// * either side ill-typed — a type error, whatever the other side is. An ill-typed
///   literal denotes nothing, so there is no value to be equal or unequal to.
///   `list-functions/list-less-than-error-03.rq` pins the analogous outcome for `<`
///   on a whole `"1"^^cdt:List` operand.
/// * both composites — compared as composites (`list-functions/contains-08.rq`), by
///   the walk that asked, which takes over both parsed values.
/// * a composite against an XSD value or a language-tagged string — `false`. Those
///   are three value spaces PurRDF models in full and they are pairwise disjoint, so
///   this is SPARQL's "known to be different" rather than a refusal.
///   `list-functions/contains-07.rq` requires `cdt:contains("[1,[2]]", 2)` to be
///   `false`, which is exactly this pair.
/// * anything against an **unmodelled** datatype — a type error. This is the case the
///   tri-state exists for: PurRDF cannot know whether that datatype's value space
///   overlaps this one, so `false` would be a claim it has no grounds for.
/// * a language-tagged string against an XSD value, or against another
///   language-tagged string that is not the same term — `false`.
///   `list-functions/contains-03.rq` requires a list holding `'b'@en` to answer
///   `false`, not an error, when asked for the plain string `'b'`.
/// * two XSD values — `purrdf_xsd::value_eq`, which is definite in both directions.
fn literal_equal(
    a: &CdtLiteral,
    b: &CdtLiteral,
    memory: &mut Memory<'_>,
) -> Result<LeafEq, StorageError> {
    if a == b {
        return Ok(LeafEq::Answer(Ok(true)));
    }
    let left = denotation(a, memory)?;
    let right = denotation(b, memory)?;
    if matches!(
        (&left, &right),
        (Denotation::Composite(_), Denotation::Composite(_))
    ) {
        if let (Denotation::Composite(left), Denotation::Composite(right)) = (left, right) {
            return Ok(LeafEq::Composites(Some(left), Some(right)));
        }
        unreachable!("composite denotations established");
    }
    let answer = match (&left, &right) {
        (Denotation::IllTyped, _) | (_, Denotation::IllTyped) => Err(ill_typed()),
        (Denotation::Unmodelled, _) | (_, Denotation::Unmodelled) => Err(unmodelled()),
        (Denotation::Composite(_), _) | (_, Denotation::Composite(_)) => Ok(false),
        (Denotation::LanguageTagged, _) | (_, Denotation::LanguageTagged) => Ok(false),
        (Denotation::Xsd(x), Denotation::Xsd(y)) => {
            Ok(xsd_relation(x, y, true, memory)?.unwrap_or(false))
        }
    };
    left.release(memory)?;
    right.release(memory)?;
    Ok(LeafEq::Answer(answer))
}

/// A nested composite against a literal: the pair is two composites when the literal
/// denotes one, and otherwise has the leaf answer for a composite against a
/// non-composite.
fn composite_against_literal(
    literal: &CdtLiteral,
    memory: &mut Memory<'_>,
) -> Result<Result<Option<CdtValue>, CdtTypeError>, StorageError> {
    let denotation = denotation(literal, memory)?;
    let answer = match denotation {
        Denotation::Composite(value) => return Ok(Ok(Some(value))),
        Denotation::IllTyped => Err(ill_typed()),
        Denotation::Unmodelled => Err(unmodelled()),
        _ => Ok(None),
    };
    denotation.release(memory)?;
    Ok(answer)
}

/// SPARQL `=` over two elements that are not both composites and not both triple
/// terms (those two cases are driven by the iterative walker instead).
///
/// # Two blank nodes are equal when they are the same node, and undecidable otherwise
///
/// `list-functions/list-equals-07.rq` compares `"[   _:b   ]"^^cdt:List` with
/// `"[_:b]"^^cdt:List` and requires `true`, and `list-equals-09.rq` requires the same
/// of one `BNODE()` compared with itself — so the same blank node is the same value.
/// But `list-equals-06.rq` compares `_:b1` with `_:b2` and `list-equals-08.rq`
/// compares two distinct `BNODE()`s, and **both require the result to be unbound**,
/// not `false`. SEP-0009 therefore treats two distinct blank nodes the way it treats
/// two unknowns: they might denote the same resource, so equality has no answer. This
/// is narrower than SPARQL's own `RDFterm-equal`, which answers `false` for any two
/// terms that are not both literals, and the corpus is the reason for the narrowing.
///
/// [`membership_equal`] is where the distinction stops applying — see there.
fn leaf_equal(a: &CdtTerm, b: &CdtTerm, memory: &mut Memory<'_>) -> Result<LeafEq, StorageError> {
    Ok(LeafEq::Answer(match (a, b) {
        (CdtTerm::Iri(p), CdtTerm::Iri(q)) => Ok(p == q),
        (CdtTerm::Blank(p), CdtTerm::Blank(q)) => {
            if p == q {
                Ok(true)
            } else {
                Err(CdtTypeError::undefined(
                    "two distinct blank nodes may or may not denote the same resource, so \
                     SEP-0009 equality has no answer for them",
                ))
            }
        }
        (CdtTerm::Literal(p), CdtTerm::Literal(q)) => return literal_equal(p, q, memory),
        (CdtTerm::Null, CdtTerm::Null) => Ok(true),
        // A nested composite and a composite-typed literal are two spellings of one
        // value; see `composite_reach`. The parsed value takes the literal's side.
        (CdtTerm::Composite(_), CdtTerm::Literal(q)) => match composite_against_literal(q, memory)?
        {
            Ok(Some(value)) => return Ok(LeafEq::Composites(None, Some(value))),
            Ok(None) => Ok(false),
            Err(error) => Err(error),
        },
        (CdtTerm::Literal(p), CdtTerm::Composite(_)) => match composite_against_literal(p, memory)?
        {
            Ok(Some(value)) => return Ok(LeafEq::Composites(Some(value), None)),
            Ok(None) => Ok(false),
            Err(error) => Err(error),
        },
        // Nulls are indistinguishable from each other and distinguishable from
        // everything else; different term categories are simply not equal, which is
        // `false` and not a type error.
        _ => Ok(false),
    }))
}

/// SPARQL `<` over two elements that are not both composites.
///
/// The refusal is typed, so a consumer can tell "this data is broken" from "this
/// relation has nothing to say": an ill-typed operand is
/// [`CdtTypeErrorKind::IllTyped`](crate::CdtTypeErrorKind::IllTyped), an unmodelled
/// datatype is [`CdtTypeErrorKind::Unmodelled`](crate::CdtTypeErrorKind::Unmodelled),
/// and a pair that simply has no order — two IRIs, a `null`, a blank node, a `NaN`
/// against a number — is
/// [`CdtTypeErrorKind::Undefined`](crate::CdtTypeErrorKind::Undefined).
/// `map-functions/map-less-than-error-01.rq` pins the IRI case and
/// `map-less-than-null-01.rq` the `null` case: both require the whole comparison to be
/// unbound.
fn leaf_less_than(
    a: &CdtTerm,
    b: &CdtTerm,
    memory: &mut Memory<'_>,
) -> Result<Result<bool, CdtTypeError>, StorageError> {
    let unordered =
        || CdtTypeError::undefined("SPARQL `<` is not defined for this pair of elements");
    let (CdtTerm::Literal(p), CdtTerm::Literal(q)) = (a, b) else {
        return Ok(Err(unordered()));
    };
    let left = denotation(p, memory)?;
    let right = denotation(q, memory)?;
    let answer = match (&left, &right) {
        (Denotation::IllTyped, _) | (_, Denotation::IllTyped) => Err(ill_typed()),
        (Denotation::Unmodelled, _) | (_, Denotation::Unmodelled) => Err(unmodelled()),
        (Denotation::Xsd(x), Denotation::Xsd(y)) => {
            xsd_relation(x, y, false, memory)?.ok_or_else(unordered)
        }
        _ => Err(unordered()),
    };
    left.release(memory)?;
    right.release(memory)?;
    Ok(answer)
}

// ── Equality ────────────────────────────────────────────────────────────────────

/// One side of an equality pair: an element of the input, borrowed, or an element the
/// walk parsed out of a composite-typed literal and owns.
enum Side<'a> {
    Borrowed(&'a CdtTerm),
    Owned(CdtTerm),
}

impl<'a> Side<'a> {
    fn term(&self) -> &CdtTerm {
        match self {
            Self::Borrowed(term) => term,
            Self::Owned(term) => term,
        }
    }

    /// This side with the composite its literal denotes standing in for the literal,
    /// or this side as it is when it was a composite already.
    fn resolved(
        self,
        parsed: Option<CdtValue>,
        memory: &mut Memory<'_>,
    ) -> Result<Self, StorageError> {
        match parsed {
            Some(value) => {
                self.release(memory)?;
                Ok(Self::Owned(CdtTerm::Composite(memory.boxed_value(value)?)))
            }
            None => Ok(self),
        }
    }
    fn release(self, memory: &mut Memory<'_>) -> Result<(), StorageError> {
        match self {
            Self::Borrowed(_) => Ok(()),
            Self::Owned(term) => term.release_with_memory(memory),
        }
    }

    /// The three components of this side, which the caller has established is a
    /// triple term, each as a side of its own.
    fn components(self, memory: &mut Memory<'_>) -> Result<[Self; 3], StorageError> {
        Ok(match self {
            Self::Borrowed(CdtTerm::TripleTerm(triple)) => [
                Self::Borrowed(&triple.subject),
                Self::Borrowed(&triple.predicate),
                Self::Borrowed(&triple.object),
            ],
            Self::Owned(CdtTerm::TripleTerm(mut triple)) => {
                let result = [
                    Self::Owned(mem::replace(&mut triple.subject, CdtTerm::Null)),
                    Self::Owned(mem::replace(&mut triple.predicate, CdtTerm::Null)),
                    Self::Owned(mem::replace(&mut triple.object, CdtTerm::Null)),
                ];
                drop(triple);
                memory.release_bytes(Layout::new::<crate::CdtTripleTerm>().size())?;
                result
            }
            _ => unreachable!("components are taken of a triple term"),
        })
    }

    /// The contents of this side, which the caller has established is a composite.
    fn children(self, memory: &mut Memory<'_>) -> Result<Kids<'a>, StorageError> {
        Ok(match self {
            Self::Borrowed(CdtTerm::Composite(value)) => match value.contents() {
                CdtContents::List(items) => Kids::BorrowedList(items),
                CdtContents::Map(entries) => Kids::BorrowedMap(entries),
            },
            Self::Owned(CdtTerm::Composite(mut value)) => {
                let inner = mem::replace(&mut *value, CdtValue::empty_list());
                drop(value);
                memory.release_bytes(Layout::new::<CdtValue>().size())?;
                match inner.into_parts() {
                    CdtParts::List(items) => Kids::OwnedList(items),
                    CdtParts::Map(entries) => Kids::OwnedMap(entries),
                }
            }
            _ => unreachable!("children are taken of a composite"),
        })
    }
}

/// The contents of one side of a composite pair, borrowed from the input or owned by
/// the walk.
enum Kids<'a> {
    BorrowedList(&'a [CdtTerm]),
    BorrowedMap(&'a [CdtEntry]),
    OwnedList(Vec<CdtTerm>),
    OwnedMap(Vec<CdtEntry>),
}

impl<'a> Kids<'a> {
    const fn is_map(&self) -> bool {
        matches!(self, Self::BorrowedMap(_) | Self::OwnedMap(_))
    }

    fn len(&self) -> usize {
        match self {
            Self::BorrowedList(items) => items.len(),
            Self::BorrowedMap(entries) => entries.len(),
            Self::OwnedList(items) => items.len(),
            Self::OwnedMap(entries) => entries.len(),
        }
    }

    /// The key at `index`, of a side the caller has established is a map.
    fn key(&self, index: usize) -> &CdtKey {
        match self {
            Self::BorrowedMap(entries) => &entries[index].key,
            Self::OwnedMap(entries) => &entries[index].key,
            Self::BorrowedList(_) | Self::OwnedList(_) => unreachable!("a list has no keys"),
        }
    }

    /// The elements — list items, or map values — in order, each as a side.
    fn take(&mut self, index: usize) -> Side<'a> {
        match self {
            Self::BorrowedList(items) => Side::Borrowed(&items[index]),
            Self::BorrowedMap(entries) => Side::Borrowed(&entries[index].value),
            Self::OwnedList(items) => Side::Owned(mem::replace(&mut items[index], CdtTerm::Null)),
            Self::OwnedMap(entries) => {
                Side::Owned(mem::replace(&mut entries[index].value, CdtTerm::Null))
            }
        }
    }
    fn release(self, memory: &mut Memory<'_>) -> Result<(), StorageError> {
        match self {
            Self::BorrowedList(_) | Self::BorrowedMap(_) => Ok(()),
            Self::OwnedList(mut items) => {
                for item in &mut items {
                    mem::replace(item, CdtTerm::Null).release_with_memory(memory)?;
                }
                memory.release_vec(items)
            }
            Self::OwnedMap(mut entries) => {
                for entry in &mut entries {
                    mem::replace(&mut entry.value, CdtTerm::Null).release_with_memory(memory)?;
                    // Move the original key into its destruction-only release home.
                    mem::replace(&mut entry.key, CdtKey::Iri(alloc::string::String::new()))
                        .release_with_memory(memory)?;
                }
                memory.release_vec(entries)
            }
        }
    }
}

/// What a pair on the equality work list is made of.
enum Shape {
    /// Two triple terms: compare component by component.
    Triples,
    /// Two nested composites: compare the contents.
    Composites,
    /// Anything else: a leaf rule decides, or finds two composites after all.
    Leaves,
}

fn shape(x: &CdtTerm, y: &CdtTerm) -> Shape {
    match (x, y) {
        (CdtTerm::TripleTerm(_), CdtTerm::TripleTerm(_)) => Shape::Triples,
        (CdtTerm::Composite(_), CdtTerm::Composite(_)) => Shape::Composites,
        _ => Shape::Leaves,
    }
}

/// SPARQL `=` over two elements, walking nested composites and triple terms with an
/// explicit worklist.
///
/// A pair that raises does **not** immediately abandon the walk: a definite `false`
/// found anywhere dominates a type error, exactly as SPARQL's `=` over a sequence
/// does, so the error is only reported if no pair is definitely unequal.
///
/// # Examples
///
/// ```rust
/// use purrdf_cdt::{CdtTerm, term_equal};
///
/// // Nulls are mutually indistinguishable.
/// assert_eq!(term_equal(&CdtTerm::Null, &CdtTerm::Null), Ok(true));
/// // …and distinguishable from everything else.
/// assert_eq!(
///     term_equal(&CdtTerm::Null, &CdtTerm::Iri("http://example.org/a".into())),
///     Ok(false)
/// );
/// ```
pub fn term_equal(a: &CdtTerm, b: &CdtTerm) -> Result<bool, CdtTypeError> {
    try_term_equal(a, b, &mut Resident).expect("resident composite equality storage")
}
/// The same SEP equality with original native storage admission.
/// # Errors
/// Physical refusal is separate from a semantic type error.
pub fn try_term_equal(
    a: &CdtTerm,
    b: &CdtTerm,
    storage: &mut impl Storage,
) -> Result<Result<bool, CdtTypeError>, StorageError> {
    let mut memory = Memory::new(storage);
    term_equal_with_memory(a, b, &mut memory)
}
fn term_equal_with_memory(
    a: &CdtTerm,
    b: &CdtTerm,
    memory: &mut Memory<'_>,
) -> Result<Result<bool, CdtTypeError>, StorageError> {
    memory.scope(|memory| term_equal_kernel(a, b, memory))
}
fn term_equal_kernel(
    a: &CdtTerm,
    b: &CdtTerm,
    memory: &mut Memory<'_>,
) -> Result<Result<bool, CdtTypeError>, StorageError> {
    let mut work = Vec::new();
    memory.push(&mut work, (Side::Borrowed(a), Side::Borrowed(b)))?;
    equal_worklist(work, memory)
}

/// `cdt:contains`'s membership test: [`term_equal`], except that two blank nodes are
/// compared by **identity** and therefore always have an answer.
///
/// `list-functions/contains-05.rq` searches `"[_:b,null,'_:b']"^^cdt:List` for a fresh
/// `BNODE()` and requires the result to be **bound** and `false` — so an unrelated
/// blank node in the list is a definite miss, not the undecidable comparison
/// [`leaf_equal`] reports for `=`. `contains-06.rq` is the other half: the very term
/// `cdt:head` just returned from that list **is** found. Membership asks "is this term
/// in the list?", which for a blank node is a question about the term; `=` asks "are
/// these the same value?", which for two unknowns has no answer.
///
/// The distinction applies to the top-level pair only. A blank node buried inside two
/// nested composites is compared by [`term_equal`]'s rule, because at that depth the
/// question is again one of value equality; no corpus test reaches that case.
pub(crate) fn membership_equal_with_memory(
    item: &CdtTerm,
    term: &CdtTerm,
    memory: &mut Memory<'_>,
) -> Result<Result<bool, CdtTypeError>, StorageError> {
    if let (CdtTerm::Blank(p), CdtTerm::Blank(q)) = (item, term) {
        return Ok(Ok(p == q));
    }
    term_equal_with_memory(item, term, memory)
}

/// Drive an equality worklist to a verdict. Every pair on the list must be equal for
/// the answer to be `true`.
///
/// A pair of composites is compared by putting its element pairs on the list, whether
/// the composites are borrowed from the input or were parsed out of literals during
/// the walk: an owned composite hands its elements over to the pairs, so ownership
/// travels down the list and no walk ever re-enters this function.
fn equal_worklist(
    mut work: Vec<(Side<'_>, Side<'_>)>,
    memory: &mut Memory<'_>,
) -> Result<Result<bool, CdtTypeError>, StorageError> {
    let result = (|| {
        let mut withheld = None;
        while let Some((x, y)) = work.pop() {
            match shape(x.term(), y.term()) {
                Shape::Triples => {
                    let [ls, lp, lo] = x.components(memory)?;
                    let [rs, rp, ro] = y.components(memory)?;
                    memory.push(&mut work, (lo, ro))?;
                    memory.push(&mut work, (lp, rp))?;
                    memory.push(&mut work, (ls, rs))?;
                }
                Shape::Composites => {
                    let (mut left, mut right) = (x.children(memory)?, y.children(memory)?);
                    let unequal = left.is_map() != right.is_map()
                        || left.len() != right.len()
                        || (left.is_map()
                            && (0..left.len()).any(|index| left.key(index) != right.key(index)));
                    if !unequal {
                        for index in 0..left.len() {
                            memory.push(&mut work, (left.take(index), right.take(index)))?;
                        }
                    }
                    left.release(memory)?;
                    right.release(memory)?;
                    if unequal {
                        return Ok(Ok(false));
                    }
                }
                Shape::Leaves => {
                    let verdict = leaf_equal(x.term(), y.term(), memory)?;
                    match verdict {
                        LeafEq::Composites(left, right) => {
                            let left = x.resolved(left, memory)?;
                            let right = y.resolved(right, memory)?;
                            memory.push(&mut work, (left, right))?;
                        }
                        LeafEq::Answer(answer) => {
                            x.release(memory)?;
                            y.release(memory)?;
                            match answer {
                                Ok(true) => {}
                                Ok(false) => return Ok(Ok(false)),
                                Err(error) => {
                                    if withheld.is_none() {
                                        withheld = Some(error);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        Ok(match withheld {
            Some(error) => Err(error),
            None => Ok(true),
        })
    })();
    // An early semantic verdict still destroys every originally owned sibling.
    if result.is_ok() {
        while let Some((left, right)) = work.pop() {
            left.release(memory)?;
            right.release(memory)?;
        }
    }
    memory.release_vec_after(work, result)
}

/// SEP-0009 `cdt:list-equal` over two lists' elements.
///
/// # Examples
///
/// ```rust
/// use purrdf_cdt::{CdtTerm, list_equal};
///
/// // Nulls are mutually indistinguishable, so `[null]` equals `[null]`.
/// assert_eq!(list_equal(&[CdtTerm::Null], &[CdtTerm::Null]), Ok(true));
/// // Different lengths are unequal, never an error.
/// assert_eq!(list_equal(&[CdtTerm::Null], &[]), Ok(false));
/// ```
pub fn list_equal(a: &[CdtTerm], b: &[CdtTerm]) -> Result<bool, CdtTypeError> {
    let mut storage = Resident;
    let mut memory = Memory::new(&mut storage);
    list_equal_with_memory(a, b, &mut memory).expect("resident list equality storage")
}
fn list_equal_with_memory(
    a: &[CdtTerm],
    b: &[CdtTerm],
    memory: &mut Memory<'_>,
) -> Result<Result<bool, CdtTypeError>, StorageError> {
    if a.len() != b.len() {
        return Ok(Ok(false));
    }
    let mut work = Vec::new();
    for (p, q) in a.iter().zip(b) {
        memory.push(&mut work, (Side::Borrowed(p), Side::Borrowed(q)))?;
    }
    equal_worklist(work, memory)
}

/// SEP-0009 `cdt:map-equal` over two maps' entries.
///
/// The entry sequences must already be in [`total_key_cmp`] order — the invariant
/// [`crate::parse_map`] and [`CdtValue::map`](crate::CdtValue::map) establish. Two
/// maps are equal when their key sets are identical and every shared key's values
/// are equal.
pub fn map_equal(a: &[CdtEntry], b: &[CdtEntry]) -> Result<bool, CdtTypeError> {
    let mut storage = Resident;
    let mut memory = Memory::new(&mut storage);
    map_equal_with_memory(a, b, &mut memory).expect("resident map equality storage")
}
fn map_equal_with_memory(
    a: &[CdtEntry],
    b: &[CdtEntry],
    memory: &mut Memory<'_>,
) -> Result<Result<bool, CdtTypeError>, StorageError> {
    if a.len() != b.len() || a.iter().zip(b).any(|(p, q)| p.key != q.key) {
        return Ok(Ok(false));
    }
    let mut work = Vec::new();
    for (p, q) in a.iter().zip(b) {
        memory.push(
            &mut work,
            (Side::Borrowed(&p.value), Side::Borrowed(&q.value)),
        )?;
    }
    equal_worklist(work, memory)
}

/// SEP-0009 `=` over two composite values, dispatching on their datatypes. A list is
/// never equal to a map.
pub fn value_equal(a: &CdtValue, b: &CdtValue) -> Result<bool, CdtTypeError> {
    match (a.contents(), b.contents()) {
        (CdtContents::List(left), CdtContents::List(right)) => list_equal(left, right),
        (CdtContents::Map(left), CdtContents::Map(right)) => map_equal(left, right),
        (CdtContents::List(_), CdtContents::Map(_))
        | (CdtContents::Map(_), CdtContents::List(_)) => Ok(false),
    }
}

// ── Ordering ────────────────────────────────────────────────────────────────────

/// SPARQL `<` over two elements, seeing through both spellings of a composite.
///
/// The pair is walked as a one-position sequence on each side, so a composite pair
/// descends exactly as it does at any position of a list, and a leaf pair is decided
/// by the leaf rules.
pub fn term_less_than(a: &CdtTerm, b: &CdtTerm) -> Result<bool, CdtTypeError> {
    try_term_less_than(a, b, &mut Resident).expect("resident composite order storage")
}
/// The same SEP partial order with original native storage admission.
/// # Errors
/// Physical refusal is separate from a semantic type error.
pub fn try_term_less_than(
    a: &CdtTerm,
    b: &CdtTerm,
    storage: &mut impl Storage,
) -> Result<Result<bool, CdtTypeError>, StorageError> {
    let mut memory = Memory::new(storage);
    sequence_less_than(
        Owner::Borrowed(Seq::List(core::slice::from_ref(a))),
        Owner::Borrowed(Seq::List(core::slice::from_ref(b))),
        &mut memory,
    )
    .map(|answer| answer.map(|verdict| verdict == Verdict::Less))
}

/// The three outcomes one position of a lexicographic walk can produce.
#[derive(Clone, Copy, PartialEq, Eq)]
enum Verdict {
    /// The left side is strictly smaller; the whole comparison is `true`.
    Less,
    /// This position is equal; keep walking.
    Equal,
    /// The left side is not smaller; the whole comparison is `false`.
    NotLess,
}

/// One side of a lexicographic walk, borrowed from the input.
#[derive(Clone, Copy)]
enum Seq<'a> {
    List(&'a [CdtTerm]),
    Map(&'a [CdtEntry]),
}

impl<'a> Seq<'a> {
    const fn len(self) -> usize {
        match self {
            Self::List(items) => items.len(),
            Self::Map(entries) => entries.len(),
        }
    }

    const fn value(self, index: usize) -> &'a CdtTerm {
        match self {
            Self::List(items) => &items[index],
            Self::Map(entries) => &entries[index].value,
        }
    }

    const fn key(self, index: usize) -> Option<&'a CdtKey> {
        match self {
            Self::List(_) => None,
            Self::Map(entries) => Some(&entries[index].key),
        }
    }

    fn of(value: &'a CdtValue) -> Self {
        match value.contents() {
            CdtContents::List(items) => Self::List(items),
            CdtContents::Map(entries) => Self::Map(entries),
        }
    }

    const fn is_map(self) -> bool {
        matches!(self, Self::Map(_))
    }
}

/// One side of a lexicographic walk: a sequence of the input, borrowed, or one the
/// walk parsed out of a composite-typed literal and owns.
enum Owner<'a> {
    Borrowed(Seq<'a>),
    List(Vec<CdtTerm>),
    Map(Vec<CdtEntry>),
}

impl Owner<'_> {
    /// A value the walk owns, taken apart into the sequence it walks.
    fn parsed(value: CdtValue) -> Self {
        match value.into_parts() {
            CdtParts::List(items) => Self::List(items),
            CdtParts::Map(entries) => Self::Map(entries),
        }
    }

    fn release(self, memory: &mut Memory<'_>) -> Result<(), StorageError> {
        match self {
            Self::Borrowed(_) => Ok(()),
            Self::List(items) => Kids::OwnedList(items).release(memory),
            Self::Map(entries) => Kids::OwnedMap(entries).release(memory),
        }
    }

    fn len(&self) -> usize {
        match self {
            Self::Borrowed(seq) => seq.len(),
            Self::List(items) => items.len(),
            Self::Map(entries) => entries.len(),
        }
    }

    const fn is_map(&self) -> bool {
        match self {
            Self::Borrowed(seq) => seq.is_map(),
            Self::List(_) => false,
            Self::Map(_) => true,
        }
    }

    fn value(&self, index: usize) -> &CdtTerm {
        match self {
            Self::Borrowed(seq) => seq.value(index),
            Self::List(items) => &items[index],
            Self::Map(entries) => &entries[index].value,
        }
    }

    fn key(&self, index: usize) -> Option<&CdtKey> {
        match self {
            Self::Borrowed(seq) => seq.key(index),
            Self::List(_) => None,
            Self::Map(entries) => Some(&entries[index].key),
        }
    }

    /// The composite at `index`, which the caller has established is one, as an owner
    /// of its own: borrowed from the input when this side is, and otherwise moved out
    /// of this side. Position `index` is settled once the walk descends into it — the
    /// walk either returns from inside it or moves on to `index + 1` — so nothing
    /// reads the null left behind.
    fn descend(&mut self, index: usize, memory: &mut Memory<'_>) -> Result<Self, StorageError> {
        let taken = match self {
            Self::Borrowed(seq) => match seq.value(index) {
                CdtTerm::Composite(inner) => return Ok(Self::Borrowed(Seq::of(inner))),
                _ => unreachable!("the walk descends into a composite"),
            },
            Self::List(items) => mem::replace(&mut items[index], CdtTerm::Null),
            Self::Map(entries) => mem::replace(&mut entries[index].value, CdtTerm::Null),
        };
        match taken {
            CdtTerm::Composite(mut value) => {
                let inner = mem::replace(&mut *value, CdtValue::empty_list());
                drop(value);
                memory.release_bytes(Layout::new::<CdtValue>().size())?;
                Ok(Self::parsed(inner))
            }
            _ => unreachable!("the walk descends into a composite"),
        }
    }

    /// The composite at `index` as the walk reaches it: the syntactic one this side
    /// holds, or the one parsed out of the literal at that position.
    fn reached(
        &mut self,
        index: usize,
        reach: Reach,
        memory: &mut Memory<'_>,
    ) -> Result<Self, StorageError> {
        match reach {
            Reach::Syntactic => self.descend(index, memory),
            Reach::Parsed(value) => Ok(Self::parsed(value)),
        }
    }
}

/// A frame of the iterative lexicographic walk: two sequences and how far we are.
struct Frame<'a> {
    left: Owner<'a>,
    right: Owner<'a>,
    index: usize,
}

/// The lexicographic `<` walk shared by lists, maps and single elements.
///
/// The rules, stated once so every entry point reads the same, each with the corpus
/// test that pins it:
///
/// * Positions are visited in order, and the walk stops at the first position that is
///   not equal — `list-functions/list-less-than-07.rq` (`[1,2] < [1,3]` is `true`) and
///   `list-less-than-11.rq` (`[1,1,2] < [1,2,3]`, where position 1 decides).
/// * Two nulls are equal, so the walk **continues** past them:
///   `list-less-than-null-03.rq` (`[null] < [null]` is `false`, so the walk reached the
///   length tie-break) and `list-less-than-null-05.rq` (`[1,null] < [2,null]`).
/// * When one sequence is a prefix of the other the shorter one is smaller —
///   `list-less-than-09.rq` and `map-less-than-12.rq` — and this tie-break is reached
///   **before** any element of the longer sequence is examined, which is why
///   `list-less-than-26.rq` can answer `[] < [_:b]` with a clean `true` even though a
///   blank node has no order.
/// * A **blank node** at a visited position has no answer, even against itself:
///   `list-less-than-27.rq` (two distinct `BNODE()`s), `list-less-than-28.rq`
///   (`[_:b] < [_:b]`, the same label on both sides) and `list-less-than-29.rq` (one
///   `BNODE()` compared with itself) all require the result to be unbound. Note the
///   contrast with `list-less-than-31.rq`, where two *equal IRIs* are simply equal and
///   the walk carries on to a clean `false`: an IRI is a term you can know, and a blank
///   node is not.
/// * At the first unequal position the whole comparison is `<` for that pair, **and
///   that pair's error propagates**: `map-functions/map-less-than-error-01.rq` (two
///   different IRIs as map values), `map-less-than-error-02.rq` (an IRI against a
///   number) and `map-less-than-null-01.rq` (`{1:null} < {1:42}`) each require the
///   result to be unbound rather than `false`. That is the one place where `<` and `=`
///   disagree about the very same pair: `map-equals-null-02.rq` requires
///   `{1:null} = {1:44}` to be a bound `false` while `map-less-than-null-01.rq`
///   requires `{1:null} < {1:42}` to be unbound.
/// * If `=` itself raises at a position, that error propagates too.
/// * For maps the walk is in key order and the key is compared **syntactically**, with
///   [`total_key_cmp`], not with SPARQL `<`. `map-less-than-15.rq` is the test that
///   forces this: `{'001'^^xsd:integer: 41} < {'01'^^xsd:integer: 41}` must be `true`,
///   and those two keys are the *same integer value*, so a value comparison could only
///   have answered `false`. `map-less-than-17.rq` (an `xsd:integer` key against an
///   `xsd:string` key), `map-less-than-20.rq` (a literal key against an IRI key) and
///   `map-less-than-21.rq` (two IRI keys) each demand an answer where SPARQL `<` has
///   none, and each agrees with [`total_key_cmp`].
/// * Two composites at a position — nested with brackets, or spelled as
///   `cdt:`-typed literals, in any mix — open a frame of their own and the walk
///   continues inside them; a list against a map there raises. A composite parsed
///   out of a literal belongs to its frame, so the depth of literals inside literals
///   costs frames on the heap and nothing else.
///
/// # `<=` is not `<` or `=`
///
/// A consumer must compute `a <= b` as "if `<` raised, raise; else if `<` was `true`,
/// `true`; else `a = b`" — **not** as `(a < b) || (a = b)`. `list-less-equal-28.rq`
/// requires `"[_:b]"^^cdt:List <= "[_:b]"^^cdt:List` to be unbound while
/// `list-equals-07.rq` requires the same two operands to be `=`-equal, so SPARQL's
/// `||`, under which `error || true` is `true`, would give the wrong answer.
/// `list-greater-equal-28.rq` says the same for `>=`.
fn sequence_less_than(
    left: Owner<'_>,
    right: Owner<'_>,
    memory: &mut Memory<'_>,
) -> Result<Result<Verdict, CdtTypeError>, StorageError> {
    memory.scope(|memory| sequence_less_than_kernel(left, right, memory))
}
fn sequence_less_than_kernel(
    left: Owner<'_>,
    right: Owner<'_>,
    memory: &mut Memory<'_>,
) -> Result<Result<Verdict, CdtTypeError>, StorageError> {
    let mut stack = Vec::new();
    memory.push(
        &mut stack,
        Frame {
            left,
            right,
            index: 0,
        },
    )?;
    let result = (|| {
        loop {
            let Some(top) = stack.last_mut() else {
                return Ok(Ok(Verdict::Equal));
            };
            let index = top.index;
            let shortest = top.left.len().min(top.right.len());
            if index == shortest {
                match top.left.len().cmp(&top.right.len()) {
                    Ordering::Less => return Ok(Ok(Verdict::Less)),
                    Ordering::Greater => return Ok(Ok(Verdict::NotLess)),
                    Ordering::Equal => {}
                }
                let frame = stack.pop().expect("original active frame");
                frame.left.release(memory)?;
                frame.right.release(memory)?;
                match stack.last_mut() {
                    None => return Ok(Ok(Verdict::Equal)),
                    Some(parent) => {
                        parent.index += 1;
                        continue;
                    }
                }
            }
            if let (Some(left), Some(right)) = (top.left.key(index), top.right.key(index)) {
                match total_key_cmp(left, right) {
                    Ordering::Less => return Ok(Ok(Verdict::Less)),
                    Ordering::Greater => return Ok(Ok(Verdict::NotLess)),
                    Ordering::Equal => {}
                }
            }
            let (x, y) = (top.left.value(index), top.right.value(index));
            if matches!(x, CdtTerm::Blank(_)) || matches!(y, CdtTerm::Blank(_)) {
                return Ok(Err(CdtTypeError::undefined(
                    "SPARQL `<` has no answer where a blank node stands, not even against the very same blank node",
                )));
            }
            let reaches = (composite_reach(x, memory)?, composite_reach(y, memory)?);
            match reaches {
                (Some(left), Some(right)) => {
                    let left = top.left.reached(index, left, memory)?;
                    let right = top.right.reached(index, right, memory)?;
                    if left.is_map() != right.is_map() {
                        left.release(memory)?;
                        right.release(memory)?;
                        return Ok(Err(list_against_map()));
                    }
                    memory.push(
                        &mut stack,
                        Frame {
                            left,
                            right,
                            index: 0,
                        },
                    )?;
                }
                (left, right) => {
                    if let Some(reach) = left {
                        reach.release(memory)?;
                    }
                    if let Some(reach) = right {
                        reach.release(memory)?;
                    }
                    match term_equal_with_memory(x, y, memory)? {
                        Err(error) => return Ok(Err(error)),
                        Ok(true) => {
                            top.index += 1;
                        }
                        Ok(false) => match leaf_less_than(x, y, memory)? {
                            Err(error) => return Ok(Err(error)),
                            Ok(true) => return Ok(Ok(Verdict::Less)),
                            Ok(false) => return Ok(Ok(Verdict::NotLess)),
                        },
                    }
                }
            }
        }
    })();
    if result.is_ok() {
        while let Some(frame) = stack.pop() {
            frame.left.release(memory)?;
            frame.right.release(memory)?;
        }
    }
    memory.release_vec_after(stack, result)
}

/// SEP-0009 `cdt:list-less-than` over two lists' elements.
///
/// See `sequence_less_than` for the exact rules, each with the corpus test that
/// pins it, including what happens when `<` raises at the first unequal position.
///
/// # Examples
///
/// ```rust
/// use purrdf_cdt::{CdtDatatype, CdtValue, list_less_than, parse_list};
///
/// let items = |lexical: &str| {
///     parse_list(lexical)
///         .unwrap()
///         .into_list()
///         .expect("parse_list yields a list")
/// };
/// assert_eq!(list_less_than(&items("[1,2]"), &items("[1,3]")), Ok(true));
/// // A shorter list is smaller than any list it is a prefix of.
/// assert_eq!(list_less_than(&items("[1]"), &items("[1,2]")), Ok(true));
/// // Two nulls do not stop the walk.
/// assert_eq!(list_less_than(&items("[null,1]"), &items("[null,2]")), Ok(true));
/// # let _ = CdtDatatype::List;
/// ```
pub fn list_less_than(a: &[CdtTerm], b: &[CdtTerm]) -> Result<bool, CdtTypeError> {
    sequence_less_than(
        Owner::Borrowed(Seq::List(a)),
        Owner::Borrowed(Seq::List(b)),
        &mut Memory::new(&mut Resident),
    )
    .expect("resident list order storage")
    .map(|verdict| verdict == Verdict::Less)
}

/// SEP-0009 `cdt:map-less-than` over two maps' entries, walking in key order.
pub fn map_less_than(a: &[CdtEntry], b: &[CdtEntry]) -> Result<bool, CdtTypeError> {
    sequence_less_than(
        Owner::Borrowed(Seq::Map(a)),
        Owner::Borrowed(Seq::Map(b)),
        &mut Memory::new(&mut Resident),
    )
    .expect("resident map order storage")
    .map(|verdict| verdict == Verdict::Less)
}

/// SEP-0009 `<` over two composite values, dispatching on their datatypes.
///
/// A `cdt:List` and a `cdt:Map` are two disjoint value spaces with no order between
/// them, so this **raises** rather than answering `false`. **The corpus does not
/// exercise the mixed pair**; the choice follows the pairs it does exercise, where
/// every genuinely unordered pair at a compared position — two IRIs
/// (`map-functions/map-less-than-error-01.rq`), an IRI against a number
/// (`map-less-than-error-02.rq`), a `null` against a term (`map-less-than-null-01.rq`)
/// — is required to be unbound rather than `false`. Answering `false` here would also
/// make `<` and `>` both `false` for a pair that is not equal either, which is a claim
/// about an order that does not exist.
pub fn value_less_than(a: &CdtValue, b: &CdtValue) -> Result<bool, CdtTypeError> {
    let (left, right) = (Seq::of(a), Seq::of(b));
    if left.is_map() != right.is_map() {
        return Err(list_against_map());
    }
    sequence_less_than(
        Owner::Borrowed(left),
        Owner::Borrowed(right),
        &mut Memory::new(&mut Resident),
    )
    .expect("resident value order storage")
    .map(|verdict| verdict == Verdict::Less)
}
