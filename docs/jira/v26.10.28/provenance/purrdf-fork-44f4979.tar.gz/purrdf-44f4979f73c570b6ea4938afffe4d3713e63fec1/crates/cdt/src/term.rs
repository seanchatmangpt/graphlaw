// SPDX-FileCopyrightText: 2026 Blackcat Informatics® Inc. <paudley@blackcatinformatics.ca>
// SPDX-License-Identifier: MIT OR Apache-2.0 OR MulanPSL-2.0

//! The crate's **own** closed element type.
//!
//! `purrdf-cdt` is a closed leaf: it does not depend on `purrdf-core` in either
//! direction, so it cannot name the kernel's term type and does not try to. It owns
//! [`CdtTerm`], which is exactly the set of things the SEP-0009 grammar (plus this
//! crate's two documented supersets) admits as a list element or a map value —
//! nothing wider, nothing narrower. Converting between [`CdtTerm`] and a host's own
//! term representation is the *consumer's* job, and happens above this crate.
//!
//! # Literals are kept lexical-verbatim
//!
//! [`CdtLiteral`] stores the lexical form byte-for-byte as authored. That is not an
//! accident of implementation: SEP-0009 distinguishes map keys **by lexical form
//! rather than by value**, deliberately, so `"1"^^xsd:integer` and
//! `"01"^^xsd:integer` are two different keys. Canonicalizing the value at parse
//! time would silently merge them. It also matches the PurRDF kernel's own rule
//! that the IR keeps literals lexical-verbatim.

use alloc::boxed::Box;
use alloc::string::String;

use crate::datatype::{RDF_DIR_LANG_STRING, RDF_LANG_STRING};
use crate::error::CdtError;
use crate::memory::{CdtMemory as _, Memory, ReadError, Resident, Storage, StorageError};
use crate::value::CdtValue;

/// The RDF 1.2 base direction of a directional language-tagged string: the
/// stack's one direction type, carried exactly as the workspace's concrete
/// syntaxes write it (the `--ltr` / `--rtl` suffix after a language tag).
pub use purrdf_events::TextDirection;

/// An RDF literal appearing inside a composite lexical form.
///
/// # Invariants
///
/// Every literal this crate constructs satisfies all of:
///
/// * `language.is_some()` **iff** `datatype` is [`RDF_LANG_STRING`] or
///   [`RDF_DIR_LANG_STRING`];
/// * `direction.is_some()` **iff** `datatype` is [`RDF_DIR_LANG_STRING`] (and then
///   `language.is_some()` too);
/// * `datatype` is a syntactically valid absolute IRI.
///
/// [`CdtLiteral::plain`], [`CdtLiteral::typed`], [`CdtLiteral::lang`] and
/// [`CdtLiteral::dir_lang`] establish them; the scanner establishes them too.
#[derive(Debug, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub struct CdtLiteral {
    /// The lexical form, byte-for-byte as authored (escapes already decoded).
    pub lexical: String,
    /// The datatype IRI. Always explicit — a bare `"abc"` carries
    /// `http://www.w3.org/2001/XMLSchema#string`, a `"abc"@en` carries
    /// `rdf:langString`, and a `"abc"@en--rtl` carries `rdf:dirLangString`.
    pub datatype: String,
    /// The language tag, for language-tagged strings.
    pub language: Option<String>,
    /// The RDF 1.2 base direction, for directional language-tagged strings.
    pub direction: Option<TextDirection>,
}

impl CdtLiteral {
    /// A plain `xsd:string` literal.
    #[must_use]
    pub fn plain(lexical: impl Into<String>) -> Self {
        Self::typed(lexical, crate::datatype::XSD_STRING)
    }

    /// A datatyped literal.
    #[must_use]
    pub fn typed(lexical: impl Into<String>, datatype: impl Into<String>) -> Self {
        Self {
            lexical: lexical.into(),
            datatype: datatype.into(),
            language: None,
            direction: None,
        }
    }

    /// A language-tagged string with no base direction (`rdf:langString`).
    #[must_use]
    pub fn lang(lexical: impl Into<String>, language: impl Into<String>) -> Self {
        Self {
            lexical: lexical.into(),
            datatype: String::from(RDF_LANG_STRING),
            language: Some(language.into()),
            direction: None,
        }
    }

    /// A **directional** language-tagged string (`rdf:dirLangString`) — the RDF 1.2
    /// term type this crate's second lexical superset exists to carry.
    #[must_use]
    pub fn dir_lang(
        lexical: impl Into<String>,
        language: impl Into<String>,
        direction: TextDirection,
    ) -> Self {
        Self {
            lexical: lexical.into(),
            datatype: String::from(RDF_DIR_LANG_STRING),
            language: Some(language.into()),
            direction: Some(direction),
        }
    }
}

/// An RDF 1.2 **triple term** appearing as a composite element.
///
/// This is the payload of this crate's first documented superset of the SEP-0009
/// lexical space. The three components are unrestricted [`CdtTerm`]s because the
/// superset production spells them as `Element`; whether the resulting triple is
/// well-formed RDF is the consumer's question, not this lexical layer's.
///
/// The components may nest triple terms and composites without bound, so this type
/// implements allocation-free iterative `Drop` ([`crate::tree`]); the fields are public to read and
/// assign, and are moved out with `core::mem::replace` / `take` rather than by
/// destructuring the struct by value, which a type with a `Drop` does not allow.
#[derive(Debug)]
pub struct CdtTripleTerm {
    /// The subject component.
    pub subject: CdtTerm,
    /// The predicate component.
    pub predicate: CdtTerm,
    /// The object component.
    pub object: CdtTerm,
}

/// An element of a `cdt:List`, or the value of a `cdt:Map` entry.
///
/// # The tree is walked iteratively, however deep
///
/// This is an owning tree with no depth bound of its own: a level is one element of
/// [`crate::MAX_ELEMENTS`] and a few bytes of [`crate::MAX_LEXICAL_BYTES`], and those
/// two are the only bounds. Its `Drop`, `Clone` and `Debug` are therefore not the
/// compiler's recursive glue but the loops in [`crate::tree`], each over an explicit
/// work lists for copying/debugging and existing evacuated slots for destruction;
/// equality and ordering are the loops in [`crate::ops`]. The
/// variants below are free to be public: an element assembled by hand nests as deep
/// as its author likes, costs heap for every level and stack for none, and is
/// measured against the two bounds the moment it is offered to [`CdtValue::list`] /
/// [`CdtValue::map`] — or here, at [`CdtTerm::composite`], which measures it earlier.
pub enum CdtTerm {
    /// `IRIREF` — always absolute (CDT lexical forms carry no base).
    Iri(String),
    /// `BLANK_NODE_LABEL` — the label **without** the `_:` prefix.
    Blank(String),
    /// `RDFLiteral`, `NumericLiteral` or `BooleanLiteral`. The two shorthands are
    /// resolved to their explicit datatype at parse time; the lexical form is kept
    /// verbatim.
    Literal(CdtLiteral),
    /// `<<( s p o )>>` — an RDF 1.2 triple term. **PurRDF superset** of SEP-0009.
    TripleTerm(Box<CdtTripleTerm>),
    /// A nested `List` or `Map`.
    Composite(Box<CdtValue>),
    /// `null` — the SEP-0009 null element. Nulls are mutually **indistinguishable**:
    /// `"[null]"` equals `"[null]"`.
    Null,
}

impl CdtTerm {
    /// A nested composite element.
    ///
    /// An element can only ever appear inside a composite that is one element larger
    /// and two bytes longer than it, so the bounds are checked here against that
    /// smallest container, at the point the element is made, rather than leaving the
    /// caller to discover a refusal only when the element is finally placed. The
    /// measure reads the value's own carried extent, so it costs the same whatever the
    /// value's depth.
    ///
    /// # Errors
    ///
    /// [`CdtError::TooManyElements`] or [`CdtError::InputTooLarge`], whichever bound
    /// the element crosses first.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use purrdf_cdt::{CdtTerm, CdtValue, parse_list};
    ///
    /// let nested = CdtTerm::composite(parse_list("[1]")?)?;
    /// assert_eq!(
    ///     CdtValue::list(vec![nested])?.canonical_lexical(),
    ///     "[[\"1\"^^<http://www.w3.org/2001/XMLSchema#integer>]]"
    /// );
    /// # Ok::<(), purrdf_cdt::CdtError>(())
    /// ```
    pub fn composite(value: CdtValue) -> Result<Self, CdtError> {
        Self::composite_admitted(value, &mut Resident)
            .map(|(value, _)| value)
            .map_err(resident_error)
    }

    /// A triple-term element.
    ///
    /// A triple term *combines* three elements' element counts and canonical lengths
    /// into one, so both bounds are checked against the combined term.
    ///
    /// # Errors
    ///
    /// [`CdtError::TooManyElements`] or [`CdtError::InputTooLarge`], whichever bound
    /// the combined term crosses first.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use purrdf_cdt::{CdtTerm, CdtValue};
    ///
    /// let triple = CdtTerm::triple(
    ///     CdtTerm::Iri("http://example.org/s".into()),
    ///     CdtTerm::Iri("http://example.org/p".into()),
    ///     CdtTerm::Null,
    /// )?;
    /// assert_eq!(
    ///     CdtValue::list(vec![triple])?.canonical_lexical(),
    ///     "[<<( <http://example.org/s> <http://example.org/p> null )>>]"
    /// );
    /// # Ok::<(), purrdf_cdt::CdtError>(())
    /// ```
    pub fn triple(subject: Self, predicate: Self, object: Self) -> Result<Self, CdtError> {
        Self::triple_admitted(subject, predicate, object, &mut Resident)
            .map(|(value, _)| value)
            .map_err(resident_error)
    }

    /// `true` for [`CdtTerm::Null`].
    #[must_use]
    pub const fn is_null(&self) -> bool {
        matches!(self, Self::Null)
    }

    /// The ordering rank of this term's category in the crate's syntactic total
    /// order (see [`crate::total_term_cmp`]).
    pub(crate) const fn rank(&self) -> u8 {
        match self {
            Self::Null => 0,
            Self::Blank(_) => 1,
            Self::Iri(_) => 2,
            Self::Literal(_) => 3,
            Self::TripleTerm(_) => 4,
            Self::Composite(_) => 5,
        }
    }
}

/// A `cdt:Map` key.
///
/// Production `[7] MapKey ::= IRIREF | RDFLiteral | NumericLiteral | BooleanLiteral`
/// — narrower than [`CdtTerm`]: a key is never a blank node, never `null`, never a
/// nested composite and never a triple term. Modelling that as its own closed enum
/// makes the restriction unrepresentable rather than merely checked.
#[derive(Debug, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub enum CdtKey {
    /// `IRIREF` — always absolute.
    Iri(String),
    /// `RDFLiteral`, `NumericLiteral` or `BooleanLiteral`.
    Literal(CdtLiteral),
}

impl CdtKey {
    /// The key seen as a [`CdtTerm`] (an owning conversion; keys are always leaves,
    /// so this allocates at most the key's own strings and never recurses).
    #[must_use]
    pub fn to_term(&self) -> CdtTerm {
        self.to_term_admitted(&mut Resident)
            .expect("resident CDT key capacity")
            .0
    }

    /// The key a term denotes, or `None` when the term is **not admissible as a map
    /// key** at all.
    ///
    /// The inverse of [`CdtKey::to_term`], and total in the only way it can be:
    /// production `[7] MapKey` admits an `IRIREF` and a literal and nothing else, so
    /// a blank node, a `null`, a nested composite and a triple term each have no key
    /// to denote. That is a real distinction with observable consequences in
    /// [`crate::functions`] — `cdt:put` with a blank-node key raises, while
    /// `cdt:remove` with one leaves the map alone — so it is answered here once,
    /// rather than re-derived at each call site.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use purrdf_cdt::{CdtKey, CdtLiteral, CdtTerm};
    ///
    /// let literal = CdtTerm::Literal(CdtLiteral::plain("a"));
    /// assert_eq!(CdtKey::from_term(&literal), Some(CdtKey::Literal(CdtLiteral::plain("a"))));
    /// // A blank node can never be a map key.
    /// assert_eq!(CdtKey::from_term(&CdtTerm::Blank("b0".into())), None);
    /// assert_eq!(CdtKey::from_term(&CdtTerm::Null), None);
    /// ```
    #[must_use]
    pub fn from_term(term: &CdtTerm) -> Option<Self> {
        Self::from_term_admitted(term, &mut Resident)
            .expect("resident CDT key capacity")
            .0
    }

    /// The ordering rank of this key's category, aligned with [`CdtTerm::rank`] so
    /// key order and term order agree.
    pub(crate) const fn rank(&self) -> u8 {
        match self {
            Self::Iri(_) => 2,
            Self::Literal(_) => 3,
        }
    }
}

/// One `cdt:Map` entry: `MapKey ':' MapValue`.
#[derive(Debug)]
pub struct CdtEntry {
    /// The entry's key.
    pub key: CdtKey,
    /// The entry's value.
    pub value: CdtTerm,
}

fn resident_error(error: ReadError) -> CdtError {
    match error {
        ReadError::Lexical(error) => error,
        ReadError::Storage(error) => panic!("resident CDT construction capacity: {error}"),
    }
}

impl CdtLiteral {
    fn fields_with_memory(
        lexical: &str,
        datatype: &str,
        language: Option<&str>,
        direction: Option<TextDirection>,
        memory: &mut Memory<'_>,
    ) -> Result<Self, StorageError> {
        Ok(Self {
            lexical: memory.string(lexical)?,
            datatype: memory.string(datatype)?,
            language: language.map(|value| memory.string(value)).transpose()?,
            direction,
        })
    }

    pub(crate) fn clone_with_memory(&self, memory: &mut Memory<'_>) -> Result<Self, StorageError> {
        Self::fields_with_memory(
            &self.lexical,
            &self.datatype,
            self.language.as_deref(),
            self.direction,
            memory,
        )
    }
    /// Construct from borrowed plain spelling, before admitting each destination.
    ///
    /// # Errors
    /// Returns checked physical layout, allocator or original admission refusal.
    pub fn plain_admitted(
        lexical: &str,
        storage: &mut dyn Storage,
    ) -> Result<(Self, usize), StorageError> {
        Self::typed_admitted(lexical, crate::datatype::XSD_STRING, storage)
    }
    /// Construct a typed literal from borrowed verbatim spelling.
    ///
    /// # Errors
    /// Returns checked physical layout, allocator or original admission refusal.
    pub fn typed_admitted(
        lexical: &str,
        datatype: &str,
        storage: &mut dyn Storage,
    ) -> Result<(Self, usize), StorageError> {
        let mut memory = Memory::new(storage);
        let value = memory
            .scope(|memory| Self::fields_with_memory(lexical, datatype, None, None, memory))?;
        Ok((value, memory.admitted_bytes()))
    }
    /// Construct a language-tagged literal from borrowed verbatim spelling.
    ///
    /// # Errors
    /// Returns checked physical layout, allocator or original admission refusal.
    pub fn lang_admitted(
        lexical: &str,
        language: &str,
        storage: &mut dyn Storage,
    ) -> Result<(Self, usize), StorageError> {
        let mut memory = Memory::new(storage);
        let value = memory.scope(|memory| {
            Self::fields_with_memory(lexical, RDF_LANG_STRING, Some(language), None, memory)
        })?;
        Ok((value, memory.admitted_bytes()))
    }
    /// Construct a directional language literal from borrowed verbatim spelling.
    ///
    /// # Errors
    /// Returns checked physical layout, allocator or original admission refusal.
    pub fn dir_lang_admitted(
        lexical: &str,
        language: &str,
        direction: TextDirection,
        storage: &mut dyn Storage,
    ) -> Result<(Self, usize), StorageError> {
        let mut memory = Memory::new(storage);
        let value = memory.scope(|memory| {
            Self::fields_with_memory(
                lexical,
                RDF_DIR_LANG_STRING,
                Some(language),
                Some(direction),
                memory,
            )
        })?;
        Ok((value, memory.admitted_bytes()))
    }
    pub(crate) fn owned_bytes(&self) -> Result<usize, StorageError> {
        self.lexical
            .capacity()
            .checked_add(self.datatype.capacity())
            .and_then(|bytes| bytes.checked_add(self.language.as_ref().map_or(0, String::capacity)))
            .ok_or(StorageError::SizeOverflow)
    }
    crate::memory::release_entry!();
}
crate::tree::clone_entry! {
    /// Copy verbatim fields under original native storage.
    ///
    /// # Errors
    /// Returns checked physical layout, allocator or original admission refusal.
    CdtLiteral, "resident CDT literal capacity"
}

impl CdtKey {
    pub(crate) fn clone_with_memory(&self, memory: &mut Memory<'_>) -> Result<Self, StorageError> {
        Ok(match self {
            Self::Iri(iri) => Self::Iri(memory.string(iri)?),
            Self::Literal(value) => Self::Literal(value.clone_with_memory(memory)?),
        })
    }
    /// Copy a lexical key as its corresponding term.
    ///
    /// # Errors
    /// Returns checked physical layout, allocator or original admission refusal.
    pub fn to_term_admitted(
        &self,
        storage: &mut dyn Storage,
    ) -> Result<(CdtTerm, usize), StorageError> {
        let mut memory = Memory::new(storage);
        let value = memory.scope(|memory| self.to_term_with_memory(memory))?;
        Ok((value, memory.admitted_bytes()))
    }
    pub(crate) fn to_term_with_memory(
        &self,
        memory: &mut Memory<'_>,
    ) -> Result<CdtTerm, StorageError> {
        Ok(match self {
            Self::Iri(iri) => CdtTerm::Iri(memory.string(iri)?),
            Self::Literal(value) => CdtTerm::Literal(value.clone_with_memory(memory)?),
        })
    }
    /// Copy only the key admitted by the grammar; invalid categories allocate nothing.
    ///
    /// # Errors
    /// Returns checked physical layout, allocator or original admission refusal.
    pub fn from_term_admitted(
        term: &CdtTerm,
        storage: &mut dyn Storage,
    ) -> Result<(Option<Self>, usize), StorageError> {
        let mut memory = Memory::new(storage);
        let value = memory.scope(|memory| Self::from_term_with_memory(term, memory))?;
        Ok((value, memory.admitted_bytes()))
    }
    pub(crate) fn from_term_with_memory(
        term: &CdtTerm,
        memory: &mut Memory<'_>,
    ) -> Result<Option<Self>, StorageError> {
        Ok(match term {
            CdtTerm::Iri(iri) => Some(Self::Iri(memory.string(iri)?)),
            CdtTerm::Literal(value) => Some(Self::Literal(value.clone_with_memory(memory)?)),
            CdtTerm::Blank(_) | CdtTerm::Null | CdtTerm::TripleTerm(_) | CdtTerm::Composite(_) => {
                None
            }
        })
    }
    pub(crate) fn owned_bytes(&self) -> Result<usize, StorageError> {
        match self {
            Self::Iri(value) => Ok(value.capacity()),
            Self::Literal(value) => value.owned_bytes(),
        }
    }
    crate::memory::release_entry!();
}
crate::tree::clone_entry! {
    /// Copy this lexical key without changing its identity.
    ///
    /// # Errors
    /// Returns checked physical layout, allocator or original admission refusal.
    CdtKey, "resident CDT key capacity"
}

impl CdtEntry {
    pub(crate) fn clone_with_memory(&self, memory: &mut Memory<'_>) -> Result<Self, StorageError> {
        Ok(Self {
            key: self.key.clone_with_memory(memory)?,
            value: self.value.clone_with_memory(memory)?,
        })
    }
}
impl Clone for CdtEntry {
    fn clone(&self) -> Self {
        self.clone_with_memory(&mut Memory::new(&mut Resident))
            .expect("resident CDT entry capacity")
    }
}
impl CdtTripleTerm {
    pub(crate) fn clone_with_memory(&self, memory: &mut Memory<'_>) -> Result<Self, StorageError> {
        Ok(Self {
            subject: self.subject.clone_with_memory(memory)?,
            predicate: self.predicate.clone_with_memory(memory)?,
            object: self.object.clone_with_memory(memory)?,
        })
    }
}
impl Clone for CdtTripleTerm {
    fn clone(&self) -> Self {
        self.clone_with_memory(&mut Memory::new(&mut Resident))
            .expect("resident CDT triple capacity")
    }
}

impl CdtTerm {
    /// Move an original composite into its before-admitted box.
    /// The caller keeps the input payload's original account; the live byte
    /// result is additional surviving constructor storage.
    ///
    /// # Errors
    /// Keeps existing canonical/element bounds separate from physical failures.
    pub fn composite_admitted(
        value: CdtValue,
        storage: &mut dyn Storage,
    ) -> Result<(Self, usize), ReadError> {
        let mut memory = Memory::new(storage);
        let term = memory.scope(|memory| Self::composite_with_memory(value, memory))??;
        Ok((term, memory.admitted_bytes()))
    }
    pub(crate) fn composite_with_memory(
        value: CdtValue,
        memory: &mut Memory<'_>,
    ) -> Result<Result<Self, CdtError>, StorageError> {
        let extent = value.extent();
        if let Err(error) = crate::limits::check_extent(&crate::limits::Extent {
            elements: extent.elements.saturating_add(1),
            bytes: extent.bytes.saturating_add(2),
        }) {
            return Ok(Err(error));
        }
        Ok(Ok(Self::Composite(memory.boxed_value(value)?)))
    }

    /// Move original components into a box only after their original bound checks.
    /// Input payload accounts remain with the caller until the result dies.
    ///
    /// # Errors
    /// Keeps existing canonical/element bounds separate from physical failures.
    pub fn triple_admitted(
        subject: Self,
        predicate: Self,
        object: Self,
        storage: &mut dyn Storage,
    ) -> Result<(Self, usize), ReadError> {
        let mut memory = Memory::new(storage);
        let term = memory
            .scope(|memory| Self::triple_with_memory(subject, predicate, object, memory))??;
        Ok((term, memory.admitted_bytes()))
    }
    pub(crate) fn triple_with_memory(
        subject: Self,
        predicate: Self,
        object: Self,
        memory: &mut Memory<'_>,
    ) -> Result<Result<Self, CdtError>, StorageError> {
        let triple = CdtTripleTerm {
            subject,
            predicate,
            object,
        };
        let mut elements = 1usize;
        for term in [&triple.subject, &triple.predicate, &triple.object] {
            elements = elements.saturating_add(crate::limits::try_term_elements(term, memory)?);
        }
        let bytes = crate::render::try_triple_lexical_len(&triple, memory)?.saturating_add(2);
        if let Err(error) = crate::limits::check_extent(&crate::limits::Extent { elements, bytes })
        {
            return Ok(Err(error));
        }
        Ok(Ok(Self::TripleTerm(memory.boxed_triple(triple)?)))
    }
}
