// SPDX-FileCopyrightText: 2026 Blackcat Informatics® Inc. <paudley@blackcatinformatics.ca>
// SPDX-License-Identifier: MIT OR Apache-2.0 OR MulanPSL-2.0

//! The SEP-0009 equality and ordering relations, and the syntactic total order.

mod support;

use core::cmp::Ordering;
use support::{composite, triple};

use purrdf_cdt::{
    CdtEntry, CdtKey, CdtLiteral, CdtTerm, CdtTypeErrorKind, CdtValue, list_equal, list_less_than,
    map_equal, map_less_than, parse_list, parse_map, term_equal, term_less_than, total_term_cmp,
    total_value_cmp,
};

const XSD: &str = "http://www.w3.org/2001/XMLSchema#";

fn typed(lexical: &str, local: &str) -> CdtTerm {
    CdtTerm::Literal(CdtLiteral::typed(lexical, format!("{XSD}{local}")))
}

fn items(lexical: &str) -> Vec<CdtTerm> {
    parse_list(lexical)
        .expect("the lexical form is well formed")
        .into_list()
        .expect("parse_list yields a list")
}

fn entries(lexical: &str) -> Vec<CdtEntry> {
    parse_map(lexical)
        .expect("the lexical form is well formed")
        .into_map()
        .expect("parse_map yields a map")
}

// ── list-equal ────────────────────────────────────────────────────────────────

#[test]
fn list_equal_treats_nulls_as_mutually_indistinguishable() {
    assert_eq!(list_equal(&items("[null]"), &items("[null]")), Ok(true));
    assert_eq!(
        list_equal(&items("[1,null,2]"), &items("[1,null,2]")),
        Ok(true)
    );
    // A null is distinguishable from everything that is not a null.
    assert_eq!(list_equal(&items("[null]"), &items("[1]")), Ok(false));
}

#[test]
fn list_equal_compares_by_value_not_by_lexical_form() {
    // One value, two datatypes, two lexical forms.
    assert_eq!(list_equal(&items("[1]"), &items("[1.0]")), Ok(true));
    assert_eq!(
        list_equal(
            &items("[1]"),
            &items("[\"01\"^^<http://www.w3.org/2001/XMLSchema#integer>]")
        ),
        Ok(true)
    );
    assert_eq!(list_equal(&items("[1]"), &items("[2]")), Ok(false));
}

#[test]
fn list_equal_is_false_on_a_length_mismatch_and_never_an_error() {
    // The right-hand element would raise if it were ever compared; the length check
    // reaches its verdict first, so the answer is a clean `false`.
    let unknown = items("[\"x\"^^<http://example.org/unmodelled>]");
    assert_eq!(list_equal(&items("[]"), &unknown), Ok(false));
    assert_eq!(list_equal(&unknown, &items("[1,2]")), Ok(false));
}

#[test]
fn list_equal_propagates_a_type_error_but_a_definite_false_dominates_it() {
    let raising = items("[\"x\"^^<http://example.org/unmodelled>]");
    let other = items("[\"y\"^^<http://example.org/unmodelled>]");
    // Nothing is definitely unequal, so the type error is the answer.
    assert!(list_equal(&raising, &other).is_err());
    // Here position 0 is definitely unequal, so `false` dominates the raise at
    // position 1.
    let left = items("[1,\"x\"^^<http://example.org/unmodelled>]");
    let right = items("[2,\"y\"^^<http://example.org/unmodelled>]");
    assert_eq!(list_equal(&left, &right), Ok(false));
}

#[test]
fn list_equal_walks_nested_composites() {
    assert_eq!(
        list_equal(&items("[[1,[2]]]"), &items("[[1.0,[2.0]]]")),
        Ok(true)
    );
    assert_eq!(
        list_equal(&items("[[1,[2]]]"), &items("[[1,[3]]]")),
        Ok(false)
    );
    // A list is never equal to a map.
    assert_eq!(
        list_equal(&items("[[1]]"), &items("[{1: 1}]")),
        Ok(false),
        "a nested list is never equal to a nested map"
    );
}

// ── map-equal ─────────────────────────────────────────────────────────────────

#[test]
fn map_equal_requires_identical_key_sets() {
    assert_eq!(
        map_equal(&entries("{\"a\":1,\"b\":2}"), &entries("{\"b\":2,\"a\":1}")),
        Ok(true)
    );
    // Same values, different keys.
    assert_eq!(
        map_equal(&entries("{\"a\":1}"), &entries("{\"b\":1}")),
        Ok(false)
    );
    // Keys are distinguished by LEXICAL form, so these key sets differ even though
    // the two keys denote one value.
    assert_eq!(
        map_equal(
            &entries("{1:\"v\"}"),
            &entries("{\"01\"^^<http://www.w3.org/2001/XMLSchema#integer>:\"v\"}")
        ),
        Ok(false)
    );
    // Values, however, are compared by value.
    assert_eq!(
        map_equal(&entries("{\"a\":1}"), &entries("{\"a\":1.0}")),
        Ok(true)
    );
}

// ── list-less-than ────────────────────────────────────────────────────────────

#[test]
fn list_less_than_stops_at_the_first_unequal_position() {
    assert_eq!(list_less_than(&items("[1,2]"), &items("[1,3]")), Ok(true));
    assert_eq!(list_less_than(&items("[1,3]"), &items("[1,2]")), Ok(false));
    // The first position decides; later positions are never consulted.
    assert_eq!(list_less_than(&items("[1,9]"), &items("[2,0]")), Ok(true));
}

#[test]
fn list_less_than_continues_past_two_nulls() {
    assert_eq!(
        list_less_than(&items("[null,1]"), &items("[null,2]")),
        Ok(true)
    );
    assert_eq!(
        list_less_than(&items("[null,2]"), &items("[null,1]")),
        Ok(false)
    );
}

/// `map-functions/map-less-than-error-01.rq` and `map-less-than-error-02.rq`.
///
/// Two IRIs are definitely unequal and SPARQL `<` has no answer for them. The corpus
/// requires the whole comparison to be **unbound**, not `false`: the first unequal
/// position decides the comparison, and if `<` has no answer there then neither does
/// the comparison.
#[test]
fn list_less_than_propagates_the_operators_error_at_the_first_unequal_position() {
    let left = items("[<http://example.org/a>]");
    let right = items("[<http://example.org/b>]");
    assert_eq!(term_equal(&left[0], &right[0]), Ok(false));
    assert!(term_less_than(&left[0], &right[0]).is_err());
    assert!(list_less_than(&left, &right).is_err());
    assert!(list_less_than(&right, &left).is_err());

    // The map form the corpus actually writes: `{1: <ex:b>} < {1: <ex:a>}`.
    let map_left = entries("{1: <http://example.org/b>}");
    let map_right = entries("{1: <http://example.org/a>}");
    assert!(map_less_than(&map_left, &map_right).is_err());
    // …and `map-less-than-error-02.rq`: an IRI value against a numeric one.
    assert!(map_less_than(&map_left, &entries("{1: 42}")).is_err());

    // `map-functions/map-less-than-null-01.rq`: a stored null against a term.
    assert!(map_less_than(&entries("{1: null}"), &entries("{1: 42}")).is_err());
    // …while `map-equals-null-02.rq` requires `=` on that same pair to be a bound
    // `false`. The two relations genuinely disagree here, and both are pinned.
    assert_eq!(
        map_equal(&entries("{1: null}"), &entries("{1: 44}")),
        Ok(false)
    );

    // Equal IRIs, by contrast, are simply equal, and the walk carries on to a clean
    // `false` — `list-functions/list-less-than-31.rq`.
    let same = items("[<http://example.org/a>]");
    assert_eq!(
        list_less_than(&same, &items("[<http://example.org/a>]")),
        Ok(false)
    );
}

/// `list-functions/list-less-than-27.rq`, `-28.rq` and `-29.rq`.
///
/// A blank node at a compared position has no order — not even against the very same
/// blank node — while the length tie-break is reached first and is unaffected
/// (`list-less-than-25.rq`, `-26.rq`).
#[test]
fn a_blank_node_at_a_compared_position_has_no_order() {
    assert!(list_less_than(&items("[_:b]"), &items("[_:b]")).is_err());
    assert!(list_less_than(&items("[_:b1]"), &items("[_:b2]")).is_err());
    // `list-less-than-null-06.rq`: a null on one side does not rescue it either.
    assert!(list_less_than(&items("[null]"), &items("[_:b]")).is_err());

    // The length tie-break never looks at the element.
    assert_eq!(list_less_than(&items("[_:b]"), &items("[]")), Ok(false));
    assert_eq!(list_less_than(&items("[]"), &items("[_:b]")), Ok(true));
}

/// `list-functions/list-equals-06.rq` … `-09.rq`.
///
/// `=` on two blank nodes is `true` for the same node and **unbound** for two distinct
/// ones — SEP-0009 treats distinct blank nodes as two unknowns rather than as two known
/// different terms.
#[test]
fn equality_of_two_distinct_blank_nodes_has_no_answer() {
    assert_eq!(list_equal(&items("[   _:b   ]"), &items("[_:b]")), Ok(true));
    assert!(list_equal(&items("[_:b1]"), &items("[_:b2]")).is_err());
    // A blank node against anything that is not a blank node is a clean `false`.
    assert_eq!(list_equal(&items("[_:b]"), &items("[1]")), Ok(false));
    assert_eq!(list_equal(&items("[_:b]"), &items("[null]")), Ok(false));
}

#[test]
fn list_less_than_propagates_an_equality_error() {
    let left = items("[\"x\"^^<http://example.org/unmodelled>]");
    let right = items("[\"y\"^^<http://example.org/unmodelled>]");
    assert!(list_less_than(&left, &right).is_err());
}

/// The tri-state `purrdf_xsd::parse_by_iri` reports is preserved all the way to the
/// comparison's diagnostic: an ill-typed operand is a **defect** and says so, while an
/// unmodelled datatype is well-formed RDF the relation simply cannot decide.
#[test]
fn an_ill_typed_operand_is_distinguishable_from_an_unmodelled_one() {
    let ill = typed("abc", "integer");
    let one = typed("1", "integer");
    let unmodelled = CdtTerm::Literal(CdtLiteral::typed("x", "http://example.org/unmodelled"));

    let ill_error = term_equal(&ill, &one).expect_err("an ill-typed literal denotes nothing");
    assert_eq!(ill_error.kind, CdtTypeErrorKind::IllTyped);
    assert!(ill_error.is_ill_typed());

    let unmodelled_error =
        term_equal(&unmodelled, &one).expect_err("an unmodelled datatype cannot be decided");
    assert_eq!(unmodelled_error.kind, CdtTypeErrorKind::Unmodelled);
    assert!(!unmodelled_error.is_ill_typed());

    // Two IRIs denote perfectly well; `<` simply has nothing to say about them.
    let iri = CdtTerm::Iri("http://example.org/a".into());
    let other = CdtTerm::Iri("http://example.org/b".into());
    assert_eq!(
        term_less_than(&iri, &other)
            .expect_err("IRIs have no order")
            .kind,
        CdtTypeErrorKind::Undefined
    );

    // `<` carries the same distinction.
    assert_eq!(
        term_less_than(&ill, &one).expect_err("ill-typed").kind,
        CdtTypeErrorKind::IllTyped
    );
    assert_eq!(
        term_less_than(&unmodelled, &one)
            .expect_err("unmodelled")
            .kind,
        CdtTypeErrorKind::Unmodelled
    );

    // An ill-typed `cdt:List` literal is ill-typed for the same reason, and is NOT
    // merely "not a composite" — `list-functions/list-less-than-error-03.rq`.
    let bad_list = CdtTerm::Literal(CdtLiteral::typed(
        "1",
        "http://w3id.org/awslabs/neptune/SPARQL-CDTs/List",
    ));
    let good_list = &items("[[2]]")[0];
    assert_eq!(
        term_equal(&bad_list, good_list)
            .expect_err("ill-typed")
            .kind,
        CdtTypeErrorKind::IllTyped
    );
    // A well-formed composite against an XSD value is a clean `false`, though: the two
    // value spaces are disjoint and PurRDF models both — `contains-07.rq`.
    assert_eq!(term_equal(good_list, &one), Ok(false));
    // Against an unmodelled datatype it is not, because PurRDF cannot know.
    assert!(term_equal(good_list, &unmodelled).is_err());
}

#[test]
fn a_shorter_list_is_smaller_than_a_list_it_prefixes() {
    assert_eq!(list_less_than(&items("[1]"), &items("[1,2]")), Ok(true));
    assert_eq!(list_less_than(&items("[1,2]"), &items("[1]")), Ok(false));
    assert_eq!(list_less_than(&items("[]"), &items("[1]")), Ok(true));
    // Equal lists are not less than each other.
    assert_eq!(list_less_than(&items("[1]"), &items("[1]")), Ok(false));
}

#[test]
fn list_less_than_descends_into_nested_lists() {
    assert_eq!(
        list_less_than(&items("[[1,2]]"), &items("[[1,3]]")),
        Ok(true)
    );
    assert_eq!(
        list_less_than(&items("[[1,3]]"), &items("[[1,2]]")),
        Ok(false)
    );
    assert_eq!(list_less_than(&items("[[1]]"), &items("[[1,0]]")), Ok(true));
}

// ── map-less-than ─────────────────────────────────────────────────────────────

#[test]
fn map_less_than_walks_in_key_order() {
    // Same key set: the values at the first differing key decide.
    assert_eq!(
        map_less_than(&entries("{\"a\":1,\"b\":2}"), &entries("{\"b\":2,\"a\":9}")),
        Ok(true)
    );
    // Authoring order is irrelevant on both sides.
    assert_eq!(
        map_less_than(&entries("{\"b\":2,\"a\":1}"), &entries("{\"a\":9,\"b\":2}")),
        Ok(true)
    );
    // Different key sets: the smaller first key wins, in the SYNTACTIC key order.
    assert_eq!(
        map_less_than(&entries("{1:\"x\"}"), &entries("{2:\"x\"}")),
        Ok(true)
    );
    assert_eq!(
        map_less_than(&entries("{2:\"x\"}"), &entries("{1:\"x\"}")),
        Ok(false)
    );
    // A shorter map is smaller than a map it prefixes in key order.
    assert_eq!(
        map_less_than(&entries("{1:\"x\"}"), &entries("{1:\"x\",2:\"y\"}")),
        Ok(true)
    );
}

/// The map `<` walk compares keys **syntactically**, and the corpus is what forces it.
///
/// `map-functions/map-less-than-15.rq` is the load-bearing case: the two keys are the
/// same integer *value* written two ways, so a value comparison could only ever have
/// answered `false`, and the corpus requires `true`.
#[test]
fn map_less_than_compares_keys_in_the_syntactic_order() {
    const INT: &str = "<http://www.w3.org/2001/XMLSchema#integer>";
    const STR: &str = "<http://www.w3.org/2001/XMLSchema#string>";

    // map-less-than-15: two spellings of the integer 1, and `'001'` sorts first.
    assert_eq!(
        map_less_than(
            &entries(&format!("{{'001'^^{INT}: 41}}")),
            &entries(&format!("{{'01'^^{INT}: 41}}"))
        ),
        Ok(true)
    );
    // map-less-than-16: the same two spellings as VALUES compare by value, so the
    // maps are equal and `<` is `false`. The two components use different orders.
    assert_eq!(
        map_less_than(
            &entries(&format!("{{1: '001'^^{INT}}}")),
            &entries(&format!("{{1: '01'^^{INT}}}"))
        ),
        Ok(false)
    );
    // map-less-than-17: the datatype IRI is the first key component, and
    // `xsd:integer` sorts before `xsd:string`.
    assert_eq!(
        map_less_than(
            &entries(&format!("{{'2'^^{INT}: 41}}")),
            &entries(&format!("{{'1'^^{STR}: 41}}"))
        ),
        Ok(true)
    );
    // map-less-than-18 and -19: the lexical form is compared BEFORE the language tag.
    assert_eq!(
        map_less_than(&entries("{'1'@sv: 41}"), &entries("{'2'@en: 41}")),
        Ok(true)
    );
    assert_eq!(
        map_less_than(&entries("{'1'@sv: 41}"), &entries("{'1'@en: 41}")),
        Ok(false)
    );
    // map-less-than-20 and -21: an IRI key sorts before any literal key, and two IRI
    // keys compare by their IRI text.
    assert_eq!(
        map_less_than(&entries("{1: 41}"), &entries("{<http://example.org>: 41}")),
        Ok(false)
    );
    assert_eq!(
        map_less_than(
            &entries("{<http://example.org/b>: 41}"),
            &entries("{<http://example.org/a>: 41}")
        ),
        Ok(false)
    );
}

// ── The syntactic total order ─────────────────────────────────────────────────

#[test]
fn the_total_order_is_defined_where_the_operator_raises() {
    let iri_a = CdtTerm::Iri("http://example.org/a".into());
    let iri_b = CdtTerm::Iri("http://example.org/b".into());
    assert!(term_less_than(&iri_a, &iri_b).is_err());
    assert_eq!(total_term_cmp(&iri_a, &iri_b), Ordering::Less);

    // NaN is incomparable to every number, and still totally ordered here.
    let nan = typed("NaN", "double");
    let one = typed("1", "double");
    assert!(term_less_than(&nan, &one).is_err());
    assert_ne!(total_term_cmp(&nan, &one), Ordering::Equal);

    // Category ranks: null < blank node < IRI < literal < triple term < composite.
    let triple = triple(iri_a.clone(), iri_b, one.clone());
    let ranked = [
        CdtTerm::Null,
        CdtTerm::Blank("b".into()),
        iri_a,
        one,
        triple,
        composite(CdtValue::empty_list()),
    ];
    for window in ranked.windows(2) {
        assert_eq!(
            total_term_cmp(&window[0], &window[1]),
            Ordering::Less,
            "{:?} should sort before {:?}",
            window[0],
            window[1]
        );
    }
    // …and a list sorts before a map.
    assert_eq!(
        total_value_cmp(&CdtValue::empty_list(), &CdtValue::empty_map()),
        Ordering::Less
    );
}

/// The counterexample the crate docs cite, run as code.
///
/// The tempting comparator — SPARQL `<` first, syntactic tie-break when it raises —
/// is **not transitive**, so it is not a total order and is unsafe to sort with.
/// This test builds it and exhibits the cycle, then shows the order the crate
/// actually exports has no cycle on the same three elements.
#[test]
fn value_order_with_a_syntactic_tiebreak_is_intransitive_but_the_exported_order_is_not() {
    fn naive(a: &CdtTerm, b: &CdtTerm) -> Ordering {
        if term_equal(a, b) == Ok(true) {
            return Ordering::Equal;
        }
        match term_less_than(a, b) {
            Ok(true) => Ordering::Less,
            Ok(false) => Ordering::Greater,
            // No value order for this pair — fall back to the syntactic one.
            Err(_) => total_term_cmp(a, b),
        }
    }

    let a = typed("9", "double");
    let b = typed("P1D", "duration");
    let c = typed("8", "float");

    // The cycle: a < b < c < a.
    assert_eq!(naive(&a, &b), Ordering::Less, "double vs duration");
    assert_eq!(naive(&b, &c), Ordering::Less, "duration vs float");
    assert_eq!(
        naive(&c, &a),
        Ordering::Less,
        "float 8 vs double 9 by value"
    );

    // The exported order is transitive on the very same three elements.
    assert_eq!(total_term_cmp(&a, &b), Ordering::Less);
    assert_eq!(total_term_cmp(&b, &c), Ordering::Less);
    assert_eq!(total_term_cmp(&a, &c), Ordering::Less);
}

#[test]
fn the_total_order_sorts_and_is_strict_on_distinct_keys() {
    let key = |lexical: &str, local: &str| {
        CdtKey::Literal(CdtLiteral::typed(lexical, format!("{XSD}{local}")))
    };
    // Distinct lexical forms of one value are distinct keys, so the order separates
    // them rather than calling them equal.
    let one = key("1", "integer");
    let oh_one = key("01", "integer");
    assert_ne!(
        purrdf_cdt::total_key_cmp(&one, &oh_one),
        Ordering::Equal,
        "distinct key terms must never compare Equal, or a map could hold both"
    );

    // Sorting a heterogeneous vector terminates with a deterministic arrangement.
    let mut terms = [
        composite(CdtValue::empty_map()),
        typed("NaN", "double"),
        CdtTerm::Null,
        CdtTerm::Iri("http://example.org/z".into()),
        CdtTerm::Blank("b".into()),
        typed("P1D", "duration"),
        typed("8", "float"),
        typed("9", "double"),
    ];
    terms.sort_by(total_term_cmp);

    let sorted_once: Vec<String> = terms
        .iter()
        .map(|term| {
            CdtValue::list(vec![term.clone()])
                .expect("a one-element list is within every bound")
                .canonical_lexical()
        })
        .collect();
    terms.reverse();
    terms.sort_by(total_term_cmp);
    let sorted_twice: Vec<String> = terms
        .iter()
        .map(|term| {
            CdtValue::list(vec![term.clone()])
                .expect("a one-element list is within every bound")
                .canonical_lexical()
        })
        .collect();
    assert_eq!(sorted_once, sorted_twice);
    assert_eq!(sorted_once[0], "[null]");
}

// ── elements past machine words ───────────────────────────────────────────────

#[test]
fn elements_of_any_size_compare_by_every_digit() {
    let big = |last: char| format!("[1{}{last}]", "0".repeat(58));
    // Two sixty-digit integers one apart: a value each, distinct and ordered.
    assert_eq!(list_equal(&items(&big('1')), &items(&big('2'))), Ok(false));
    assert_eq!(
        list_less_than(&items(&big('1')), &items(&big('2'))),
        Ok(true)
    );
    assert_eq!(
        list_less_than(&items(&big('2')), &items(&big('1'))),
        Ok(false)
    );
    // The same value spelled with a leading zero is equal.
    let padded = format!(
        "[\"01{}1\"^^<http://www.w3.org/2001/XMLSchema#integer>]",
        "0".repeat(58)
    );
    assert_eq!(list_equal(&items(&big('1')), &items(&padded)), Ok(true));
    // Decimals past eighteen fractional digits keep every digit too.
    let fine = |last: char| format!("[0.{}{last}]", "0".repeat(40));
    assert_eq!(
        list_equal(&items(&fine('1')), &items(&fine('2'))),
        Ok(false)
    );
    assert_eq!(
        list_less_than(&items(&fine('1')), &items(&fine('2'))),
        Ok(true)
    );
    // An integer past i128 against a decimal of the same value.
    assert_eq!(
        list_equal(
            &items("[170141183460469231731687303715884105728]"),
            &items("[170141183460469231731687303715884105728.0]")
        ),
        Ok(true)
    );
    // Map keys of any size stay distinct.
    assert_eq!(
        map_equal(
            &entries(&format!("{{1{z}1 : 1, 1{z}2 : 2}}", z = "0".repeat(58))),
            &entries(&format!("{{1{z}2 : 2, 1{z}1 : 1}}", z = "0".repeat(58)))
        ),
        Ok(true)
    );
}

// Original native storage receipts are measured against the real allocator.
use purrdf_alloc_probe::{CountingAllocator, CurrentThreadWindow};
use purrdf_cdt::CdtTripleTerm;
use purrdf_cdt::memory::{Admission, Storage, StorageError};

#[global_allocator]
static NATIVE_ALLOCATOR: CountingAllocator = CountingAllocator;

struct NativeGrant {
    live: usize,
    peak: usize,
    calls: usize,
    refuse_growth: Option<usize>,
    refuse_box: bool,
}

impl NativeGrant {
    const fn new() -> Self {
        Self {
            live: 0,
            peak: 0,
            calls: 0,
            refuse_growth: None,
            refuse_box: false,
        }
    }
    fn boxed<T>(&self, value: T) -> Result<Box<T>, StorageError> {
        if self.refuse_box {
            return Err(StorageError::AllocationFailed);
        }
        purrdf_lex::allocation::try_boxed(value).map_err(|_| StorageError::AllocationFailed)
    }
}
impl Admission for NativeGrant {
    fn resize(&mut self, next: usize) -> Result<(), StorageError> {
        if next > self.live {
            self.calls += 1;
            if self.refuse_growth == Some(self.calls) {
                return Err(StorageError::AdmissionFailed);
            }
        }
        self.live = next;
        self.peak = self.peak.max(next);
        Ok(())
    }
}
impl Storage for NativeGrant {
    fn boxed_value(&mut self, value: CdtValue) -> Result<Box<CdtValue>, StorageError> {
        self.boxed(value)
    }
    fn boxed_triple(&mut self, value: CdtTripleTerm) -> Result<Box<CdtTripleTerm>, StorageError> {
        self.boxed(value)
    }
}

fn literal_composite(lexical: &str) -> CdtTerm {
    CdtTerm::Literal(CdtLiteral::typed(lexical, purrdf_cdt::CDT_LIST))
}

#[test]
fn native_relations_preserve_original_answers_and_price_actual_peak() {
    let cases = [
        (
            literal_composite("[[1],{'a':[2,null]}]"),
            literal_composite("[[1.0],{'a':[2.0,null]}]"),
        ),
        (
            literal_composite("[[1,2],3]"),
            literal_composite("[[1,2],4]"),
        ),
        (
            literal_composite("[1,'x'^^<http://example.org/unknown>]"),
            literal_composite("[2,'y'^^<http://example.org/unknown>]"),
        ),
        (literal_composite("[_:a]"), literal_composite("[ _:a ]")),
        (literal_composite("[]"), literal_composite("[_:a]")),
        (literal_composite("[{'a':1}]"), literal_composite("[[1]]")),
        (
            typed("170141183460469231731687303715884105728", "integer"),
            typed("170141183460469231731687303715884105728.0", "decimal"),
        ),
        (
            typed("9007199254740993", "integer"),
            typed("9007199254740992", "double"),
        ),
        (typed("abc", "integer"), typed("1", "integer")),
        (typed("NaN", "double"), typed("1", "double")),
    ];
    for (left, right) in &cases {
        let expected_equal = term_equal(left, right);
        let expected_less = term_less_than(left, right);
        for less in [false, true] {
            let mut grant = NativeGrant::new();
            let window = CurrentThreadWindow::open();
            let answer = if less {
                purrdf_cdt::ops::try_term_less_than(left, right, &mut grant)
            } else {
                purrdf_cdt::ops::try_term_equal(left, right, &mut grant)
            }
            .expect("native physical storage");
            let measured = window.close();
            assert_eq!(
                answer,
                if less {
                    expected_less.clone()
                } else {
                    expected_equal.clone()
                }
            );
            assert_eq!(
                grant.live, 0,
                "every original comparison allocation has died"
            );
            assert_eq!(measured.retained_bytes, 0);
            assert!(
                measured.peak_working_bytes <= i64::try_from(grant.peak).unwrap(),
                "actual peak exceeded original before-birth admission"
            );
        }
    }
}

#[test]
fn native_relations_refuse_each_original_growth_without_retained_scratch() {
    let left = literal_composite("[[1],{'a':[2,null]}]");
    let right = literal_composite("[[1.0],{'a':[2.0,null]}]");
    for less in [false, true] {
        let call = |grant: &mut NativeGrant| {
            if less {
                purrdf_cdt::ops::try_term_less_than(&left, &right, grant)
            } else {
                purrdf_cdt::ops::try_term_equal(&left, &right, grant)
            }
        };
        let mut healthy = NativeGrant::new();
        let _ = call(&mut healthy).unwrap();
        assert!(
            healthy.calls > 1,
            "exercise nested native parser and walk growth"
        );
        for refusal in 1..=healthy.calls {
            let mut grant = NativeGrant::new();
            grant.refuse_growth = Some(refusal);
            let window = CurrentThreadWindow::open();
            let answer = call(&mut grant);
            let measured = window.close();
            assert_eq!(answer, Err(StorageError::AdmissionFailed));
            assert_eq!(grant.live, 0);
            assert_eq!(measured.retained_bytes, 0);
            if refusal == 1 {
                assert_eq!(
                    measured.allocations, 0,
                    "first refusal precedes original worklist birth"
                );
            }
        }
    }
    let mut grant = NativeGrant::new();
    grant.refuse_box = true;
    let window = CurrentThreadWindow::open();
    let answer = purrdf_cdt::ops::try_term_equal(&left, &right, &mut grant);
    let measured = window.close();
    assert_eq!(answer, Err(StorageError::AllocationFailed));
    assert_eq!(grant.live, 0);
    assert_eq!(measured.retained_bytes, 0);
}

#[test]
fn native_canonical_render_retains_the_original_output_and_releases_scratch() {
    let value = parse_list("[[1],{'a':[2,null]},'é'@fr--rtl]").unwrap();
    let expected = value.canonical_lexical();
    let mut grant = NativeGrant::new();
    let window = CurrentThreadWindow::open();
    let (output, retained) = purrdf_cdt::render::try_canonical_lexical(&value, &mut grant).unwrap();
    let measured = window.close();
    assert_eq!(output, expected);
    assert_eq!(retained, output.capacity());
    assert_eq!(grant.live, retained);
    assert_eq!(measured.retained_bytes, i64::try_from(retained).unwrap());
    assert!(measured.peak_working_bytes <= i64::try_from(grant.peak).unwrap());
    drop(output);
    grant.resize(0).unwrap();
    assert_eq!(grant.live, 0);
    let mut grant = NativeGrant::new();
    grant.refuse_growth = Some(1);
    let window = CurrentThreadWindow::open();
    let answer = purrdf_cdt::render::try_canonical_lexical(&value, &mut grant);
    let measured = window.close();
    assert_eq!(answer, Err(StorageError::AdmissionFailed));
    assert_eq!(measured.allocations, 0);
    assert_eq!(grant.live, 0);
}

// Native primitive ownership uses the same original grant/allocator fixture above.
#[test]
fn native_clone_retains_only_original_payload_and_refuses_every_growth() {
    let source = parse_list("[[1],{'a':[2,null]},<<( <urn:s> 'é'@fr--rtl [3] )>>]").unwrap();
    let mut healthy = NativeGrant::new();
    let window = CurrentThreadWindow::open();
    let (copy, live) = source.clone_admitted(&mut healthy).unwrap();
    let measured = window.close();
    assert_eq!(copy, source);
    assert_eq!(healthy.live, live);
    assert_eq!(measured.retained_bytes, i64::try_from(live).unwrap());
    assert!(measured.peak_working_bytes <= i64::try_from(healthy.peak).unwrap());
    let calls = healthy.calls;
    drop(copy);
    healthy.resize(0).unwrap();
    assert!(calls > 1);
    for refusal in 1..=calls {
        let mut grant = NativeGrant::new();
        grant.refuse_growth = Some(refusal);
        let window = CurrentThreadWindow::open();
        let answer = source.clone_admitted(&mut grant);
        let measured = window.close();
        assert!(matches!(answer, Err(StorageError::AdmissionFailed)));
        assert_eq!(
            grant.live, 0,
            "original failed-prefix payload dies before release"
        );
        assert_eq!(measured.retained_bytes, 0);
        if refusal == 1 {
            assert_eq!(measured.allocations, 0);
        }
    }
    let mut grant = NativeGrant::new();
    grant.refuse_box = true;
    let window = CurrentThreadWindow::open();
    let answer = source.clone_admitted(&mut grant);
    let measured = window.close();
    assert!(matches!(answer, Err(StorageError::AllocationFailed)));
    assert_eq!(grant.live, 0);
    assert_eq!(measured.retained_bytes, 0);

    let mut grant = NativeGrant::new();
    grant.refuse_growth = Some(1);
    let window = CurrentThreadWindow::open();
    let (null, live) = CdtTerm::Null.clone_admitted(&mut grant).unwrap();
    let measured = window.close();
    assert!(matches!(null, CdtTerm::Null));
    assert_eq!(live, 0);
    assert_eq!(measured.allocations, 0);
    assert_eq!(
        grant.calls, 0,
        "inline leaves require no artificial reservation"
    );
}

#[test]
fn native_map_constructor_keeps_last_binding_and_releases_discarded_keys() {
    let pairs = vec![
        (
            CdtTerm::Iri("urn:k".into()),
            CdtTerm::Iri("urn:left".into()),
        ),
        (CdtTerm::Null, CdtTerm::Iri("urn:discarded".into())),
        (CdtTerm::Iri("urn:z".into()), CdtTerm::Null),
        (
            CdtTerm::Iri("urn:k".into()),
            CdtTerm::Iri("urn:right".into()),
        ),
    ];
    let mut grant = NativeGrant::new();
    let window = CurrentThreadWindow::open();
    let (answer, live) =
        purrdf_cdt::functions::map_constructor_admitted(&pairs, &mut grant).unwrap();
    let measured = window.close();
    let purrdf_cdt::CdtOutcome::Value(value) = answer else {
        panic!("native constructed map");
    };
    assert_eq!(
        value,
        parse_map("{<urn:k>:<urn:right>,<urn:z>:null}").unwrap()
    );
    assert_eq!(grant.live, live);
    assert_eq!(measured.retained_bytes, i64::try_from(live).unwrap());
    assert!(measured.peak_working_bytes <= i64::try_from(grant.peak).unwrap());
    drop(value);
    grant.resize(0).unwrap();
}

#[test]
fn native_merge_keeps_first_map_and_releases_selection_metadata() {
    let maps = vec![
        parse_map("{<urn:k>:<urn:first>,<urn:z>:null}").unwrap(),
        parse_map("{<urn:k>:<urn:second>,<urn:a>:<urn:other>}").unwrap(),
    ];
    let mut grant = NativeGrant::new();
    let window = CurrentThreadWindow::open();
    let (answer, live) = purrdf_cdt::functions::merge_admitted(&maps, &mut grant).unwrap();
    let measured = window.close();
    let purrdf_cdt::CdtOutcome::Value(value) = answer else {
        panic!("native merged map");
    };
    assert_eq!(
        value,
        parse_map("{<urn:a>:<urn:other>,<urn:k>:<urn:first>,<urn:z>:null}").unwrap()
    );
    assert_eq!(grant.live, live);
    assert_eq!(measured.retained_bytes, i64::try_from(live).unwrap());
    assert!(measured.peak_working_bytes <= i64::try_from(grant.peak).unwrap());
    drop(value);
    grant.resize(0).unwrap();
}

#[test]
fn native_duplicate_diagnostic_preserves_stable_original_value_order() {
    let entries = vec![
        CdtEntry {
            key: CdtKey::Iri("urn:z".into()),
            value: CdtTerm::Null,
        },
        CdtEntry {
            key: CdtKey::Iri("urn:k".into()),
            value: CdtTerm::Iri("urn:one".into()),
        },
        CdtEntry {
            key: CdtKey::Iri("urn:k".into()),
            value: CdtTerm::Iri("urn:second-very-long".into()),
        },
    ];
    let mut grant = NativeGrant::new();
    let error = CdtValue::map_admitted(entries, &mut grant).unwrap_err();
    let purrdf_cdt::memory::ReadError::Lexical(purrdf_cdt::CdtError::DuplicateMapKey {
        offset,
        key,
    }) = error
    else {
        panic!("original duplicate-key diagnostic");
    };
    // "{<urn:k>:<urn:one>," occupies nineteen bytes before the duplicate.
    assert_eq!(offset, 19);
    assert_eq!(key, "<urn:k>");
    assert_eq!(
        grant.live,
        key.capacity(),
        "only the owned diagnostic survives the native constructor"
    );
    drop(key);
    grant.resize(0).unwrap();
}

#[test]
fn native_large_index_parse_stays_expression_error_while_physical_refusal_is_hard() {
    let index = CdtTerm::Literal(CdtLiteral::typed(
        "1".repeat(2_000),
        purrdf_cdt::XSD_INTEGER,
    ));
    let mut grant = NativeGrant::new();
    let window = CurrentThreadWindow::open();
    let (answer, live) = purrdf_cdt::functions::list_get_admitted(&[], &index, &mut grant).unwrap();
    let measured = window.close();
    assert!(
        answer.is_error(),
        "a non-inline integer remains an invalid list index"
    );
    assert_eq!(live, 0);
    assert_eq!(grant.live, 0);
    assert_eq!(measured.retained_bytes, 0);
    assert!(measured.peak_working_bytes > 0);
    assert!(measured.peak_working_bytes <= i64::try_from(grant.peak).unwrap());

    let mut grant = NativeGrant::new();
    grant.refuse_growth = Some(1);
    let window = CurrentThreadWindow::open();
    let answer = purrdf_cdt::functions::list_get_admitted(&[], &index, &mut grant);
    let measured = window.close();
    assert!(matches!(answer, Err(StorageError::AdmissionFailed)));
    assert_eq!(grant.live, 0);
    assert_eq!(
        measured.allocations, 0,
        "native parsing refuses before magnitude birth"
    );
}

#[test]
fn native_clone_and_release_do_not_recurse_on_a_small_stack() {
    purrdf_stack::on_stack(128 * 1024, || {
        let mut source = CdtTerm::Null;
        for _ in 0..10_000 {
            source = CdtTerm::TripleTerm(Box::new(CdtTripleTerm {
                subject: source,
                predicate: CdtTerm::Null,
                object: CdtTerm::Null,
            }));
        }
        let mut grant = NativeGrant::new();
        let window = CurrentThreadWindow::open();
        let (copy, live) = source.clone_admitted(&mut grant).unwrap();
        let measured = window.close();
        assert_eq!(copy, source);
        assert_eq!(measured.retained_bytes, i64::try_from(live).unwrap());
        assert!(measured.peak_working_bytes <= i64::try_from(grant.peak).unwrap());
        let window = CurrentThreadWindow::open();
        drop(copy);
        let measured = window.close();
        assert_eq!(
            measured.allocations, 0,
            "cleanup uses original native slots"
        );
        grant.resize(0).unwrap();
        drop(source);
    })
    .unwrap();
}

// A concrete native box refusal remains the first error when refund refuses too.
struct RefuseBoxAndShrink(NativeGrant, bool);
impl Admission for RefuseBoxAndShrink {
    fn resize(&mut self, next: usize) -> Result<(), StorageError> {
        if self.1 && next < self.0.live {
            return Err(StorageError::AdmissionFailed);
        }
        self.0.resize(next)
    }
}
impl Storage for RefuseBoxAndShrink {
    fn boxed_value(&mut self, _value: CdtValue) -> Result<Box<CdtValue>, StorageError> {
        self.1 = true;
        Err(StorageError::AllocationFailed)
    }
    fn boxed_triple(&mut self, _value: CdtTripleTerm) -> Result<Box<CdtTripleTerm>, StorageError> {
        self.1 = true;
        Err(StorageError::AllocationFailed)
    }
}
#[test]
fn native_box_failure_stays_primary_when_original_refund_also_refuses() {
    let source = parse_list("[[1],{'a':[2]}]").unwrap();
    let mut grant = RefuseBoxAndShrink(NativeGrant::new(), false);
    let window = CurrentThreadWindow::open();
    let answer = source.clone_admitted(&mut grant);
    let measured = window.close();
    assert!(
        matches!(answer, Err(StorageError::AllocationFailed)),
        "actual native factory refusal remains primary"
    );
    assert_eq!(
        measured.retained_bytes, 0,
        "all failed clone payloads die even when logical refund refuses"
    );
    assert!(
        grant.0.live > 0,
        "the failed shrink kept the original grant until owner destruction"
    );
}

#[test]
fn native_literal_parser_keeps_original_box_failure_through_child_refund() {
    let left = literal_composite("[[1],{'a':[2]}]");
    let right = literal_composite("[[1], {'a': [2]}]");
    // Distinct lexical terms denote the same nested value. Identical terms can
    // answer by term identity without entering the native denotation producer.
    assert_eq!(term_equal(&left, &right), Ok(true));
    let mut grant = RefuseBoxAndShrink(NativeGrant::new(), false);
    let window = CurrentThreadWindow::open();
    let answer = purrdf_cdt::ops::try_term_equal(&left, &right, &mut grant);
    let measured = window.close();
    assert!(
        grant.1,
        "exercise the actual nested native parser box factory"
    );
    assert!(
        matches!(answer, Err(StorageError::AllocationFailed)),
        "child refund cannot turn physical parser failure into another cause"
    );
    assert_eq!(measured.retained_bytes, 0);
    assert!(
        grant.0.live > 0,
        "original admission remains held after failed shrink"
    );
}
