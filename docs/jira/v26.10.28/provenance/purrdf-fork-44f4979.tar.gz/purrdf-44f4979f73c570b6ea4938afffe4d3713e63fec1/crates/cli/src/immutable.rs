// SPDX-FileCopyrightText: 2026 Blackcat Informatics® Inc. <paudley@blackcatinformatics.ca>
// SPDX-License-Identifier: MIT OR Apache-2.0 OR MulanPSL-2.0

//! The immutable-input authority: a byte buffer guaranteed **stable and
//! un-truncatable** for its whole lifetime.
//!
//! A pack on disk is read by memory-mapping it and handing the mapped bytes to
//! [`PackView`](purrdf_core::PackView) zero-copy. A bare `mmap` of a file this
//! process does not own is memory-**unsafe**: a hostile concurrent writer can
//! `ftruncate` the backing inode, and a later access to a now-missing page faults
//! the process with **SIGBUS** — an uncatchable crash. [`ImmutableInput`] closes
//! that hole by only ever handing out bytes whose backing object cannot shrink or
//! be mutated for the lifetime of the value.
//!
//! ## One open, one identity
//!
//! A path is opened **exactly once**; every subsequent decision — the `fstat` for
//! length, the Tier-1 snapshot copy, and the Tier-2 fallback read — is made against
//! that single file descriptor, never by re-resolving the path. Re-opening the path
//! would let a hostile pathname writer swap the file (or substitute a special file)
//! *between* the opens, so the object we inspected, the object we copied, and the
//! object we returned could diverge. Binding everything to one descriptor makes the
//! acquired bytes tied to the file that existed at open time.
//!
//! ## Tiered acquisition
//!
//! From that one descriptor, the cheapest sound option is taken, degrading — never
//! silently, always to something equally safe:
//!
//! * **Tier 0 — direct `mmap`, truly zero-copy (no byte copy).** Taken only when
//!   the descriptor already carries a *testable, kernel-enforced* invariant that
//!   prevents shrink/grow/mutation for the mapping's lifetime: it reports
//!   `F_SEAL_SHRINK | F_SEAL_GROW | F_SEAL_WRITE` via `fcntl(F_GET_SEALS)`. A regular
//!   disk file never carries seals, so this fires only for a pre-sealed `memfd`; a
//!   read-only mount or a bare `O_TMPFILE` is deliberately **not** accepted (a mount
//!   can be remounted read-write; an unsealed tmpfile can still be truncated).
//! * **Tier 1 — sealed `memfd` snapshot (one copy).** The common case for a regular
//!   file: snapshot the bytes (via offset-independent `pread`, so the descriptor's
//!   offset is never disturbed) into an anonymous `memfd` **we own**, seal it
//!   (`SHRINK | GROW | WRITE | SEAL`), *verify the complete seal set took*, and map
//!   the sealed fd. No external pathname writer can touch our memfd, so access can
//!   never SIGBUS.
//! * **Tier 2 — owned buffer (fail closed, portable).** stdin, a non-Linux target,
//!   a kernel without `memfd`/sealing, a non-regular file, or an **empty** input
//!   (a zero-length mapping is invalid): read the descriptor (rewound to offset 0)
//!   whole into a `Vec<u8>` we own — no external process can truncate our heap.
//!
//! ## Memory ceiling per tier
//!
//! The tiers trade zero-copy for safety, and that trade has a *peak-memory* cost
//! worth stating plainly — it is the ceiling a large pack has to fit under:
//!
//! * **Tier 0** adds nothing. The mapping aliases the already-immutable backing
//!   pages, so resident growth is only the pages actually touched (paged in on
//!   demand, shared with the backing object) — no second copy of the input exists.
//! * **Tier 1 holds one full copy of the input for the value's whole lifetime.** The
//!   sealed `memfd` *is* the bytes: a snapshot the size of the source. So a
//!   `PackView` over a Tier-1 acquisition has a resident ceiling of about the source
//!   size (the memfd) plus a small fixed transient — the reused 64 KiB `pread` chunk
//!   in `tier1_sealed_snapshot`, released the moment the snapshot completes. The
//!   copy is O(n) in the input's *byte* length and does **not** grow per term or per
//!   quad: there is no allocation that scales with the pack's *logical* size layered
//!   on top of its byte size. Because the snapshot lives in a `memfd`, this copy
//!   counts toward the process RSS but **not** toward the global allocator's byte
//!   accounting (it is not a heap `Vec`) — which is exactly why the `pack_input_alloc`
//!   bench reports peak *allocated bytes* and *RSS delta* as two separate figures.
//! * **Tier 2** is the same one-copy ceiling as Tier 1, but on the heap: the owned
//!   `Vec<u8>` is a full copy of the input and *does* count toward allocated bytes.
//!
//! In every tier the ceiling is **at most one copy** of the input — never a
//! per-element blow-up — so a pack costs resident memory proportional to its size,
//! not a multiple of it. That bound is what the large-pack coverage
//! (`memory_ceiling_of_a_large_pack_acquisition_is_about_one_copy` in
//! `crate::immutable`'s tests) pins.
//!
//! Integrity (`verify_pack`) is checked by the caller **after** acquisition, over
//! the already-immutable [`as_bytes`](ImmutableInput::as_bytes), closing the
//! time-of-check/time-of-use gap. Acquisition never trusts the input's *contents*; a
//! zero-length or otherwise invalid pack is rejected by that later `verify_pack`.

use std::fs::File;
use std::io::{Read as _, Seek as _};

use crate::error::CliError;
#[cfg(target_os = "linux")]
use crate::mmap::Mmap;

/// Which acquisition tier produced an [`ImmutableInput`]'s bytes.
///
/// Reported for the CLI pack benchmark (so acquisition cost can be attributed to a
/// tier) and for diagnostics; it carries no correctness obligation — every tier is
/// memory-safe.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum InputTier {
    /// Tier 0: a direct mapping of a descriptor whose verified
    /// `SHRINK | GROW | WRITE` seals make it immutable for the mapping's lifetime.
    SealedDirectMmap,
    /// Tier 1: a mapping of an anonymous, sealed `memfd` snapshot we own (one copy).
    SealedSnapshotMmap,
    /// Tier 2: an owned in-memory buffer.
    Owned,
}

/// An owner of immutable bytes, stable and un-truncatable for its lifetime.
///
/// Obtain one with [`from_disk_path`](Self::from_disk_path),
/// [`from_stdin`](Self::from_stdin), or [`from_owned`](Self::from_owned), then read
/// the bytes with [`as_bytes`](Self::as_bytes). The value must be held alive for as
/// long as the bytes are used (a [`PackView`](purrdf_core::PackView) borrows them).
#[derive(Debug)]
pub enum ImmutableInput {
    /// A memory mapping whose backing object cannot shrink, grow, or be written for
    /// the mapping's lifetime — a descriptor with verified seals (Tier 0) or our own
    /// sealed `memfd` snapshot (Tier 1). Linux only: elsewhere every input is owned.
    #[cfg(target_os = "linux")]
    Mapped {
        /// The read-only mapping. Held alive for the value's lifetime.
        mmap: Mmap,
        /// Which tier produced this mapping.
        tier: InputTier,
    },
    /// An owned buffer (Tier 2).
    Owned(Vec<u8>),
}

impl ImmutableInput {
    /// The immutable bytes. Stable for the lifetime of `self`.
    pub fn as_bytes(&self) -> &[u8] {
        match self {
            #[cfg(target_os = "linux")]
            Self::Mapped { mmap, .. } => &mmap[..],
            Self::Owned(buffer) => &buffer[..],
        }
    }

    /// The acquisition tier that produced these bytes.
    pub fn tier(&self) -> InputTier {
        match self {
            #[cfg(target_os = "linux")]
            Self::Mapped { tier, .. } => *tier,
            Self::Owned(_) => InputTier::Owned,
        }
    }

    /// Acquire immutable bytes from a disk `path`, tiered (Tier 0 → 1 → 2).
    ///
    /// The path is opened **exactly once**; the acquisition is then performed by
    /// the private `from_opened_file` against that single descriptor,
    /// which has no path to re-resolve — so a hostile pathname swap cannot divert it.
    ///
    /// # Errors
    ///
    /// Returns a `CliError` if the path cannot be opened or read. A tier that is
    /// *unavailable* (no seals, no `memfd`, an empty or non-regular file) is not an
    /// error — it degrades to the next tier; only an actual I/O failure surfaces.
    pub fn from_disk_path(path: &str) -> Result<Self, CliError> {
        Self::from_opened_file(File::open(path)?, false)
    }

    /// The post-open acquisition seam: tiered acquisition off an ALREADY-OPEN
    /// descriptor.
    ///
    /// This function has no `path` and therefore CANNOT re-resolve one — the acquired
    /// bytes are structurally bound to `file`, the descriptor the caller opened. That
    /// is what makes a hostile pathname swap unable to divert acquisition (a re-open
    /// per tier is not even expressible here), and it is what the
    /// `acquired_bytes_are_tied_to_the_opened_descriptor` regression exercises: it
    /// swaps the path *before* calling this, so a re-opening implementation would
    /// return the replacement bytes and fail the test.
    ///
    /// `force_tier1_failure` (only ever `true` in this module's tests) makes Tier 1
    /// perform its snapshot `pread` and then bail as if sealing failed, so a test can
    /// deterministically exercise the Tier-2 fallback *after* Tier 1 ran and prove
    /// the full input still reaches the owned buffer.
    #[cfg_attr(not(target_os = "linux"), allow(unused_variables))]
    fn from_opened_file(mut file: File, force_tier1_failure: bool) -> Result<Self, CliError> {
        let meta = file.metadata()?;

        if meta.is_file() {
            // A zero-length mapping is invalid; own it (the later `verify_pack`
            // rejects an empty pack — a content decision after a safe acquisition).
            if meta.len() == 0 {
                return Ok(Self::Owned(Vec::new()));
            }

            #[cfg(target_os = "linux")]
            {
                if let Some(mapped) = tier0_sealed_direct(&file)? {
                    return Ok(mapped);
                }
                if let Some(mapped) = tier1_sealed_snapshot(&file, meta.len(), force_tier1_failure)?
                {
                    return Ok(mapped);
                }
            }

            // Tier 2 for a regular file: rewind the SAME descriptor and read it
            // whole. `pread`/`mmap` above never moved the offset, but rewind is
            // explicit so the read is unambiguously from byte zero of this fd.
            file.rewind()?;
            let mut buffer = Vec::with_capacity(usize::try_from(meta.len()).unwrap_or(0));
            file.read_to_end(&mut buffer)?;
            return Ok(Self::Owned(buffer));
        }

        // Non-regular (a FIFO/socket the path resolved to): not seekable and not
        // mappable — stream the SAME descriptor to own its bytes.
        let mut buffer = Vec::new();
        file.read_to_end(&mut buffer)?;
        Ok(Self::Owned(buffer))
    }

    /// Acquire immutable bytes from standard input (Tier 2 only — there is no file
    /// descriptor to seal or map).
    ///
    /// # Errors
    ///
    /// Returns a `CliError` if stdin cannot be read.
    pub fn from_stdin() -> Result<Self, CliError> {
        let mut buffer = Vec::new();
        std::io::stdin().read_to_end(&mut buffer)?;
        Ok(Self::Owned(buffer))
    }

    /// Wrap bytes already owned in memory (Tier 2).
    pub fn from_owned(bytes: Vec<u8>) -> Self {
        Self::Owned(bytes)
    }
}

/// The seal set that makes a backing object immutable for a mapping's lifetime:
/// it can neither shrink, grow, nor be written.
#[cfg(target_os = "linux")]
const IMMUTABLE_SEALS: libc::c_int = libc::F_SEAL_SHRINK | libc::F_SEAL_GROW | libc::F_SEAL_WRITE;

/// Tier 0: if `file`'s descriptor already carries the verified complete invariant
/// `SHRINK | GROW | WRITE`, a direct read-only mapping is sound with **no copy** —
/// the kernel guarantees the backing object cannot shrink, grow, or be written for
/// the mapping's lifetime.
///
/// Returns `Ok(None)` (degrade) when the fd carries no such seals — the ordinary
/// case for a regular disk file, whose `fcntl(F_GET_SEALS)` fails or lacks the
/// required bits.
#[cfg(target_os = "linux")]
fn tier0_sealed_direct(file: &File) -> Result<Option<ImmutableInput>, CliError> {
    // A descriptor that does not support sealing (a regular disk file) errors here;
    // that is not a failure, it just means Tier 0 does not apply.
    let Ok(seals) = crate::mmap::get_seals(file) else {
        return Ok(None);
    };
    // The COMPLETE invariant: shrink AND grow AND write are all sealed. Anything
    // less does not prove the backing object is immutable for the mapping lifetime.
    if seals & IMMUTABLE_SEALS != IMMUTABLE_SEALS {
        return Ok(None);
    }
    // SAFETY: the descriptor carries the verified complete seal set
    // (`SHRINK | GROW | WRITE`), so its backing object's size and contents are
    // immutable for the whole lifetime of the mapping. No external truncation,
    // growth, or write can fault the mapping — exactly the invariant `Mmap::map`'s
    // safety contract requires. (The caller has already excluded zero length.)
    let mmap = unsafe { Mmap::map(file)? };
    Ok(Some(ImmutableInput::Mapped {
        mmap,
        tier: InputTier::SealedDirectMmap,
    }))
}

/// Tier 1: snapshot `file`'s bytes into an anonymous `memfd` we own, seal it against
/// shrink/grow/write, verify the complete seal set took, and map the sealed fd.
///
/// The copy uses offset-independent `pread` on the SAME descriptor the caller
/// opened — it neither re-opens the path nor disturbs the descriptor's offset, so
/// the Tier-2 fallback can still read the identical fd from byte zero. Returns
/// `Ok(None)` (degrade) when `memfd`/sealing is unavailable, when the snapshot turns
/// out empty (the file was truncated under us), or — for the test seam — when
/// `force_failure` is set.
#[cfg(target_os = "linux")]
fn tier1_sealed_snapshot(
    file: &File,
    len: u64,
    force_failure: bool,
) -> Result<Option<ImmutableInput>, CliError> {
    use std::io::Write as _;
    use std::os::unix::fs::FileExt as _;

    // An anonymous, sealable, close-on-exec memory file. If the kernel has no
    // `memfd_create`, degrade to the owned tier.
    let Ok(mut sink) =
        crate::mmap::memfd_create(c"purrdf-pack", libc::MFD_ALLOW_SEALING | libc::MFD_CLOEXEC)
    else {
        return Ok(None);
    };

    // One O(n) snapshot copy, via `pread` on the caller's descriptor (no offset
    // change, no re-open). If the file shrank under us, we copy only what is there;
    // the sealed snapshot is internally consistent and the later `verify_pack`
    // rejects a short/invalid pack.
    let mut offset: u64 = 0;
    // Heap buffer (not a stack array): reused across the copy loop, one allocation.
    let mut chunk = vec![0u8; 64 * 1024];
    while offset < len {
        let read = file.read_at(&mut chunk, offset)?;
        if read == 0 {
            break;
        }
        sink.write_all(&chunk[..read])?;
        offset += read as u64;
    }

    // A zero-length memfd cannot be mapped; degrade so the owned tier handles it.
    if offset == 0 {
        return Ok(None);
    }
    // Test seam: model a post-copy seal failure so the caller falls through to the
    // owned tier with the snapshot `pread` already having run.
    if force_failure {
        return Ok(None);
    }

    // Seal the memfd shut: no shrink, no grow, no write, and no further sealing.
    if crate::mmap::add_seals(&sink, IMMUTABLE_SEALS | libc::F_SEAL_SEAL).is_err() {
        // The seal could not be applied (should not happen for a fresh
        // ALLOW_SEALING memfd, but never map an unsealed object): degrade.
        return Ok(None);
    }
    // Verify the COMPLETE invariant actually holds before we rely on it for memory
    // safety.
    let Ok(applied) = crate::mmap::get_seals(&sink) else {
        return Ok(None);
    };
    if applied & IMMUTABLE_SEALS != IMMUTABLE_SEALS {
        return Ok(None);
    }

    // SAFETY: `sink` is our own anonymous `memfd`, now carrying the verified
    // complete seal set `SHRINK | GROW | WRITE` (confirmed just above) and non-empty
    // (`offset > 0`). No other process holds it, and its size and contents can no
    // longer change, so the read-only mapping cannot be faulted by truncation,
    // growth, or mutation for its whole lifetime.
    let mmap = unsafe { Mmap::map(&sink)? };
    Ok(Some(ImmutableInput::Mapped {
        mmap,
        tier: InputTier::SealedSnapshotMmap,
    }))
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write as _;

    fn temp_with(payload: &[u8]) -> purrdf_testkit::NamedTempFile {
        let mut file = purrdf_testkit::NamedTempFile::for_unit_test().expect("temp file");
        file.write_all(payload).expect("write payload");
        file.flush().expect("flush");
        file
    }

    fn path_of(file: &purrdf_testkit::NamedTempFile) -> &str {
        file.path().to_str().expect("utf-8 path")
    }

    #[test]
    fn owned_from_bytes_round_trips() {
        let input = ImmutableInput::from_owned(vec![1, 2, 3, 4]);
        assert_eq!(input.as_bytes(), &[1, 2, 3, 4]);
        assert_eq!(input.tier(), InputTier::Owned);
    }

    #[test]
    fn disk_path_bytes_match_file_contents() {
        let payload: Vec<u8> = (0u8..=255).cycle().take(8192).collect();
        let file = temp_with(&payload);

        let input = ImmutableInput::from_disk_path(path_of(&file)).expect("acquire");
        assert_eq!(input.as_bytes(), payload.as_slice());
        // On Linux a regular disk file is not sealable, so Tier 0 is skipped and the
        // sealed-memfd snapshot (Tier 1) is taken; elsewhere the owned tier is used.
        #[cfg(target_os = "linux")]
        assert_eq!(input.tier(), InputTier::SealedSnapshotMmap);
        #[cfg(not(target_os = "linux"))]
        assert_eq!(input.tier(), InputTier::Owned);
    }

    #[test]
    fn empty_disk_file_is_acquired_as_owned_empty() {
        let file = temp_with(&[]);
        let input = ImmutableInput::from_disk_path(path_of(&file)).expect("acquire");
        assert_eq!(input.as_bytes(), [] as [u8; 0]);
        assert_eq!(input.tier(), InputTier::Owned);
    }

    #[test]
    fn tier1_failure_falls_back_to_full_owned_bytes() {
        // Larger than a page so a truncated/short read would be obvious.
        let payload: Vec<u8> = (0u8..=255).cycle().take(64 * 1024).collect();
        let file = temp_with(&payload);

        // Force Tier 1 to run its snapshot `pread` and then fail; the Tier-2
        // fallback must still deliver every byte from the SAME descriptor.
        let handle = File::open(path_of(&file)).expect("open");
        let input = ImmutableInput::from_opened_file(handle, true).expect("acquire");
        assert_eq!(input.as_bytes(), payload.as_slice());
        assert_eq!(input.tier(), InputTier::Owned);
    }

    #[test]
    fn acquired_bytes_are_tied_to_the_opened_descriptor() {
        // Falsifies any reopen-per-tier implementation: open the ORIGINAL file, then
        // atomically replace its pathname with DIFFERENT bytes, and only then acquire
        // through the already-open descriptor. Acquisition has no path to re-resolve,
        // so it must return the original bytes; an implementation that reopened the
        // path would return the replacement bytes and fail here.
        let original: Vec<u8> = (0u8..=255).cycle().take(32 * 1024).collect();
        let original_file = temp_with(&original);
        let handle = File::open(path_of(&original_file)).expect("open original");

        // Atomically replace the pathname with a different file (a hostile writer)
        // BEFORE acquisition runs.
        let replacement: Vec<u8> = vec![0xAB; 48 * 1024];
        let replacement_file = temp_with(&replacement);
        std::fs::rename(replacement_file.path(), original_file.path()).expect("replace path");

        // Acquire through the already-open descriptor: the bytes are the original's,
        // never the replacement now living at the path.
        let input = ImmutableInput::from_opened_file(handle, false).expect("acquire");
        assert_eq!(input.as_bytes(), original.as_slice());
        assert_ne!(input.as_bytes(), replacement.as_slice());
    }

    #[test]
    fn acquired_bytes_survive_truncation_of_the_source_file() {
        // Multi-page payload so any mapping spans several pages.
        let payload: Vec<u8> = (0u8..=255).cycle().take(256 * 1024).collect();
        let file = temp_with(&payload);

        let input = ImmutableInput::from_disk_path(path_of(&file)).expect("acquire");

        // A hostile writer truncates the SOURCE file to zero AFTER acquisition
        // (deterministically ordered: acquisition has fully returned). A naive `mmap`
        // of the source would fault the process with SIGBUS on the next access; the
        // sealed-`memfd` snapshot (Tier 1) or owned buffer (Tier 2) is independent of
        // the source file, so the mapping cannot be shrunk under us.
        std::fs::OpenOptions::new()
            .write(true)
            .truncate(true)
            .open(file.path())
            .expect("truncate source");

        // Touch EVERY byte of the acquired mapping: this both reads the whole span
        // (where a truncated mapping would fault) and confirms the bytes are the
        // originals, unaffected by the truncation. Reaching the assertions at all is
        // the proof that no SIGBUS occurred.
        let bytes = input.as_bytes();
        assert_eq!(bytes.len(), payload.len());
        assert_eq!(bytes, payload.as_slice());
        assert_eq!(
            bytes.iter().map(|&b| u64::from(b)).sum::<u64>(),
            payload.iter().map(|&b| u64::from(b)).sum::<u64>()
        );
    }

    #[test]
    fn memory_ceiling_of_a_large_pack_acquisition_is_about_one_copy() {
        // A representatively large input — 4 MiB, far beyond a page and beyond the
        // 64 KiB snapshot chunk, so any per-element or per-chunk blow-up would show. The
        // module docs promise the acquired handle holds AT MOST ONE copy of the input,
        // so its byte footprint must equal the source exactly, whichever tier is
        // reached — a large pack costs resident memory proportional to its size, not a
        // multiple of it.
        let payload: Vec<u8> = (0u8..=255).cycle().take(4 * 1024 * 1024).collect();
        let file = temp_with(&payload);

        let input = ImmutableInput::from_disk_path(path_of(&file)).expect("acquire large input");

        // Exactly the source bytes: one copy, no duplication and no expansion that
        // scales with the element count.
        assert_eq!(input.as_bytes().len(), payload.len());
        assert_eq!(input.as_bytes(), payload.as_slice());

        // On Linux that one copy lives in a sealed `memfd` (it counts toward RSS, not
        // the heap allocator's byte accounting — see the `pack_input_alloc` bench);
        // elsewhere it is the owned heap buffer. Either way it is a single copy.
        #[cfg(target_os = "linux")]
        assert_eq!(input.tier(), InputTier::SealedSnapshotMmap);
        #[cfg(not(target_os = "linux"))]
        assert_eq!(input.tier(), InputTier::Owned);
    }
}
