// SPDX-FileCopyrightText: 2026 Blackcat Informatics® Inc. <paudley@blackcatinformatics.ca>
// SPDX-License-Identifier: MIT OR Apache-2.0 OR MulanPSL-2.0

//! End-to-end coverage of the three shapes-graph tools beside `validate` — `rules`,
//! `node-expr` and `shapes lint` — driving the BUILT `purrdf` binary.
//!
//! Every shapes graph carries the W3C SHACL 1.2 declaration of `sh:SPARQLExprExpression`
//! verbatim — a built-in declared as a `sh:NamedParameterExpressionFunction` with no
//! `sh:bodyExpression`, which is not a bodiless custom function — beside shapes that
//! call `sh:sparqlExpr` with `sh:prefixes`, so each command is exercised over a
//! shapes graph that carries the vocabulary's own declaration.

mod support;
use support::{code, run, stderr, stdout, write_file};

use std::path::Path;

/// The W3C SHACL 1.2 declaration of `sh:SPARQLExprExpression`, verbatim.
const SPARQL_EXPR_DECLARATION: &str = r#"
sh:SPARQLExprExpression a sh:NamedParameterExpressionFunction ;
  rdfs:label "SPARQL expr expression"@en ;
  rdfs:comment "The class of node expressions based on SPARQL expressions (sh:sparqlExpr)."@en ;
  rdfs:isDefinedBy sh: ;
  rdfs:subClassOf sh:NamedParameterExpression,
  sh:SPARQLExecutable ;
  sh:parameter sh:SPARQLExprExpression-prefixes,
  sh:SPARQLExprExpression-sparqlExpr .

sh:SPARQLExprExpression-prefixes a sh:Parameter ;
  rdfs:isDefinedBy sh: ;
  sh:description "The prefixes that shall be applied before parsing the SPARQL query that gets derived from the sh:sparqlExpr expression. The object should define those prefixes using sh:declare."@en ;
  sh:name "prefixes"@en ;
  sh:nodeKind sh:BlankNodeOrIRI ;
  sh:path sh:prefixes .

sh:SPARQLExprExpression-sparqlExpr a sh:Parameter ;
  rdfs:isDefinedBy sh: ;
  sh:datatype xsd:string ;
  sh:description "The SPARQL expression that is executed during evaluation of this node expression."@en ;
  sh:keyParameter true ;
  sh:name "SPARQL expr"@en ;
  sh:path sh:sparqlExpr .
"#;

const PREFIXES: &str = r"
@prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#> .
@prefix sh: <http://www.w3.org/ns/shacl#> .
@prefix shnex: <http://www.w3.org/ns/shacl-node-expr#> .
@prefix xsd: <http://www.w3.org/2001/XMLSchema#> .
@prefix ex: <http://example.org/ns#> .
";

/// A `sh:sparqlExpr` expression node naming `ex:yes` through `sh:prefixes` (`ex:Tag`), a
/// labelled `shnex:var` expression (`_:suffix`), a rule tagging every `ex:Item` through
/// the same expression, and a counter rule that steps `ex:n` to 5 — exactly four
/// term-generating rounds.
const TOOLS: &str = r#"
ex:Prefixes sh:declare [ sh:prefix "ex" ; sh:namespace "http://example.org/ns#"^^xsd:anyURI ] .
ex:Tag sh:sparqlExpr "ex:yes" ; sh:prefixes ex:Prefixes .
_:suffix shnex:var "suffix" .

ex:Tagger a sh:NodeShape ;
  sh:targetClass ex:Item ;
  sh:rule [ a sh:TripleRule ; sh:subject sh:this ; sh:predicate ex:tagged ;
            sh:object [ sh:sparqlExpr "ex:yes" ; sh:prefixes ex:Prefixes ] ] .

ex:Counter a sh:NodeShape ;
  sh:targetSubjectsOf ex:n ;
  sh:rule [ a sh:SPARQLRule ; sh:construct """PREFIX ex: <http://example.org/ns#>
CONSTRUCT { $this ex:n ?m } WHERE { $this ex:n ?k . FILTER(?k < 5) BIND(?k + 1 AS ?m) }""" ] .
"#;

const DATA: &str = "@prefix ex: <http://example.org/ns#> .\nex:a a ex:Item ; ex:n 1 .\n";

const INTEGER: &str = "<http://www.w3.org/2001/XMLSchema#integer>";

/// The shapes graph: prefixes, the `sh:SPARQLExprExpression` declaration, then `body`.
fn shapes_file(dir: &Path, body: &str) -> String {
    write_file(
        dir,
        "shapes.ttl",
        &format!("{PREFIXES}{SPARQL_EXPR_DECLARATION}{body}"),
    )
}

/// The inference graph the fixture's rules produce, in canonical order.
fn expected_inference() -> String {
    let mut out = String::new();
    for n in 2..=5 {
        out.push_str("<http://example.org/ns#a> <http://example.org/ns#n> \"");
        out.push_str(&n.to_string());
        out.push_str("\"^^");
        out.push_str(INTEGER);
        out.push_str(" .\n");
    }
    out.push_str(
        "<http://example.org/ns#a> <http://example.org/ns#tagged> <http://example.org/ns#yes> .\n",
    );
    out
}

/// `rules --shapes-graph` exposes the shapes graph to a `sh:SPARQLRule` under the named
/// IRI, as `validate --shapes-graph` does: `$shapesGraph` is pre-bound to it, so the rule
/// infers the IRI and reads the shapes graph through `GRAPH $shapesGraph`. Without the flag
/// `$shapesGraph` is an ordinary, unbound variable: the rule infers `ex:none` and reads
/// nothing. A relative value resolves against `--shapes-base`. Beside `--srl`, which has no
/// shapes graph, the flag is a usage error, and the same rule set without it runs.
#[test]
fn cli_rules_shapes_graph() {
    let dir = purrdf_testkit::temp_dir!().expect("tempdir");
    let shapes = write_file(
        dir.path(),
        "graph-rules.ttl",
        &format!(
            "{PREFIXES}ex:S a sh:NodeShape ; sh:targetClass ex:Person ; ex:marker ex:secret ;
  sh:rule [ a sh:SPARQLRule ; sh:construct \"\"\"
    CONSTRUCT {{ $this <http://example.org/ns#shapesGraph> ?g }}
    WHERE {{ BIND (COALESCE($shapesGraph, <http://example.org/ns#none>) AS ?g) }}\"\"\" ] ;
  sh:rule [ a sh:SPARQLRule ; sh:construct \"\"\"
    CONSTRUCT {{ $this <http://example.org/ns#marked> ?m }}
    WHERE {{ GRAPH $shapesGraph {{ $currentShape <http://example.org/ns#marker> ?m }} }}\"\"\" ] .
"
        ),
    );
    let data = write_file(
        dir.path(),
        "person.nt",
        "<http://example.org/ns#alice> <http://www.w3.org/1999/02/22-rdf-syntax-ns#type> \
         <http://example.org/ns#Person> .\n",
    );
    let named = "<http://example.org/ns#alice> <http://example.org/ns#shapesGraph> \
                 <http://example.org/shapes-graph> .";
    let marked = "<http://example.org/ns#alice> <http://example.org/ns#marked> \
                  <http://example.org/ns#secret> .";
    let unnamed = "<http://example.org/ns#alice> <http://example.org/ns#shapesGraph> \
                   <http://example.org/ns#none> .";

    let with = run(&[
        "rules",
        "--shapes",
        &shapes,
        "--shapes-graph",
        "http://example.org/shapes-graph",
        "--to",
        "ntriples",
        &data,
    ]);
    assert_eq!(code(&with), 0, "{}", stderr(&with));
    assert!(stdout(&with).contains(named), "{}", stdout(&with));
    assert!(stdout(&with).contains(marked), "{}", stdout(&with));

    let without = run(&["rules", "--shapes", &shapes, "--to", "ntriples", &data]);
    assert_eq!(code(&without), 0, "{}", stderr(&without));
    assert!(stdout(&without).contains(unnamed), "{}", stdout(&without));
    assert!(!stdout(&without).contains(marked), "{}", stdout(&without));

    let relative = run(&[
        "rules",
        "--shapes",
        &shapes,
        "--shapes-base",
        "http://example.org/doc",
        "--shapes-graph",
        "shapes-graph",
        "--to",
        "ntriples",
        &data,
    ]);
    assert_eq!(code(&relative), 0, "{}", stderr(&relative));
    assert!(stdout(&relative).contains(named), "{}", stdout(&relative));

    let srl = write_file(
        dir.path(),
        "tag.srl",
        "PREFIX ex: <http://example.org/ns#>\nRULE { ?x ex:tagged true } WHERE { ?x a ex:Person }\n",
    );
    let refused = run(&[
        "rules",
        "--srl",
        &srl,
        "--shapes-graph",
        "http://example.org/shapes-graph",
        "--to",
        "ntriples",
        &data,
    ]);
    assert_eq!(code(&refused), 2, "{}", stderr(&refused));
    assert!(
        stderr(&refused).contains("--shapes-graph"),
        "{}",
        stderr(&refused)
    );
    let checked = run(&[
        "rules",
        "--srl",
        &srl,
        "--check",
        "--shapes-graph",
        "http://example.org/shapes-graph",
    ]);
    assert_eq!(code(&checked), 2, "{}", stderr(&checked));
    let ran = run(&["rules", "--srl", &srl, "--to", "ntriples", &data]);
    assert_eq!(code(&ran), 0, "{}", stderr(&ran));
    assert!(stdout(&ran).contains("<http://example.org/ns#tagged>"));
}

/// `rules` writes the inference graph — the base triples excluded — deterministically,
/// with the proof under `--explain` (bare to stderr, `=PATH` to a file); the round limit
/// refuses at 3 and completes at 4 and at the default; and a SPARQL 1.2 RL rule set runs
/// through the same command, its imports resolved from `--import`.
#[test]
fn cli_rules() {
    let dir = purrdf_testkit::temp_dir!().expect("tempdir");
    let shapes = shapes_file(dir.path(), TOOLS);
    let data = write_file(dir.path(), "data.ttl", DATA);

    let out = run(&["rules", "--shapes", &shapes, "--to", "ntriples", &data]);
    assert_eq!(code(&out), 0, "{}", stderr(&out));
    assert_eq!(stdout(&out), expected_inference());
    assert!(
        stderr(&out).contains("rules inferred 5\n"),
        "{}",
        stderr(&out)
    );
    let again = run(&["rules", "--shapes", &shapes, "--to", "ntriples", &data]);
    assert_eq!(stdout(&again), stdout(&out), "byte-stable across runs");

    let explained = run(&[
        "rules",
        "--shapes",
        &shapes,
        "--explain",
        "--to",
        "ntriples",
        &data,
    ]);
    assert_eq!(code(&explained), 0, "{}", stderr(&explained));
    assert_eq!(
        stdout(&explained),
        expected_inference(),
        "the graph is unchanged"
    );
    let proof = stderr(&explained);
    assert!(
        proof.contains(
            "derived <http://example.org/ns#a> <http://example.org/ns#tagged> \
             <http://example.org/ns#yes> .\n  rule _:"
        ),
        "{proof}"
    );
    assert_eq!(proof.matches("derived ").count(), 5, "{proof}");
    let proof_path = dir.path().join("proof.txt");
    let to_file = run(&[
        "rules",
        "--shapes",
        &shapes,
        &format!("--explain={}", proof_path.display()),
        "--to",
        "ntriples",
        &data,
    ]);
    assert_eq!(code(&to_file), 0, "{}", stderr(&to_file));
    let written = std::fs::read_to_string(&proof_path).expect("proof written");
    assert!(
        written.starts_with("derived <http://example.org/ns#a> <http://example.org/ns#n> \"2\""),
        "{written}"
    );
    assert!(
        !stderr(&to_file).contains("derived "),
        "the proof went to the file only"
    );

    // The round limit: four term-generating rounds are needed.
    let refused = run(&[
        "rules",
        "--shapes",
        &shapes,
        "--max-term-generating-rounds",
        "3",
        "--to",
        "ntriples",
        &data,
    ]);
    assert_eq!(code(&refused), 1, "{}", stderr(&refused));
    assert!(
        stderr(&refused).contains("past the limit of 3 (the caller's limit)"),
        "{}",
        stderr(&refused)
    );
    assert!(
        stderr(&refused)
            .trim_end()
            .ends_with("raise the limit with --max-term-generating-rounds"),
        "the refusal names this command's flag: {}",
        stderr(&refused)
    );
    assert!(stdout(&refused).is_empty(), "a refused run writes no graph");
    // The generated-term budget: the rule set adds six terms.
    let budget = |terms: &str| {
        run(&[
            "rules",
            "--shapes",
            &shapes,
            "--max-generated-terms",
            terms,
            "--to",
            "ntriples",
            &data,
        ])
    };
    let tight = budget("5");
    assert_eq!(code(&tight), 1, "{}", stderr(&tight));
    assert!(
        stderr(&tight).contains("past the budget of 5 (the caller's budget)"),
        "{}",
        stderr(&tight)
    );
    assert!(
        stderr(&tight)
            .trim_end()
            .ends_with("raise the budget with --max-generated-terms"),
        "{}",
        stderr(&tight)
    );
    let roomy = budget("6");
    assert_eq!(code(&roomy), 0, "{}", stderr(&roomy));
    assert_eq!(stdout(&roomy), expected_inference());
    let enough = run(&[
        "rules",
        "--shapes",
        &shapes,
        "--max-term-generating-rounds",
        "4",
        "--to",
        "ntriples",
        &data,
    ]);
    assert_eq!(code(&enough), 0, "{}", stderr(&enough));
    assert_eq!(stdout(&enough), expected_inference());

    // SPARQL 1.2 RL text, importing a second rule set through `--import`.
    let imported = write_file(
        dir.path(),
        "more.srl",
        "PREFIX ex: <http://example.org/ns#>\nRULE { ?x ex:counted true } WHERE { ?x ex:q ?y }\n",
    );
    let srl = write_file(
        dir.path(),
        "rules.srl",
        "PREFIX ex: <http://example.org/ns#>\nIMPORTS <http://example.org/more>\n\
         RULE { ?x ex:q ?y } WHERE { ?x ex:n ?y }\nDATA { ex:d ex:q 2 }\n",
    );
    let pair = format!("http://example.org/more={imported}");
    let srl_run = run(&[
        "rules",
        "--srl",
        &srl,
        "--import",
        &pair,
        "--explain",
        "--to",
        "ntriples",
        &data,
    ]);
    assert_eq!(code(&srl_run), 0, "{}", stderr(&srl_run));
    let graph = stdout(&srl_run);
    for line in [
        format!("<http://example.org/ns#a> <http://example.org/ns#q> \"1\"^^{INTEGER} .\n"),
        format!("<http://example.org/ns#d> <http://example.org/ns#q> \"2\"^^{INTEGER} .\n"),
        "<http://example.org/ns#a> <http://example.org/ns#counted> \"true\"^^<http://www.w3.org/2001/XMLSchema#boolean> .\n".to_owned(),
    ] {
        assert!(graph.contains(&line), "{line} missing from:\n{graph}");
    }
    let proof = stderr(&srl_run);
    assert!(proof.contains("  data-block\n"), "{proof}");
    assert!(
        proof.contains(&format!(
            "  premise <http://example.org/ns#a> <http://example.org/ns#n> \"1\"^^{INTEGER} .\n"
        )),
        "{proof}"
    );
    // The same rule set without the pair names the missing import; a pair nothing
    // imports is refused as unused.
    let missing = run(&["rules", "--srl", &srl, "--to", "ntriples", &data]);
    assert_eq!(code(&missing), 1, "{}", stderr(&missing));
    assert!(
        stderr(&missing).contains("--import http://example.org/more=FILE"),
        "{}",
        stderr(&missing)
    );
    let lone = write_file(
        dir.path(),
        "lone.srl",
        "PREFIX ex: <http://example.org/ns#>\nRULE { ?x ex:q ?y } WHERE { ?x ex:n ?y }\n",
    );
    let unused = run(&[
        "rules", "--srl", &lone, "--import", &pair, "--to", "ntriples", &data,
    ]);
    assert_eq!(code(&unused), 2, "{}", stderr(&unused));

    // The knob reaches the SPARQL 1.2 RL route too, and the route is stricter than the
    // knob: a rule whose head templates a triple term containing a variable is a
    // run-once rule, and a run-once rule that depends on its own output is a cycle
    // through a closed dependency, which stratification refuses before any round runs.
    // The refusal names the stratification, not the round limit.
    let nesting = write_file(
        dir.path(),
        "nesting.srl",
        "PREFIX ex: <http://example.org/ns#>\nRULE { ?x ex:n <<( ?x ex:n ?y )>> } WHERE { ?x ex:n ?y }\n",
    );
    let refused = run(&[
        "rules",
        "--srl",
        &nesting,
        "--max-term-generating-rounds",
        "3",
        "--to",
        "ntriples",
        &data,
    ]);
    assert_eq!(code(&refused), 1, "{}", stderr(&refused));
    assert!(
        stderr(&refused).contains("not stratifiable"),
        "{}",
        stderr(&refused)
    );
    // Its neighbour: the same head over a body that does not read the head's predicate
    // has no cycle, so it is accepted and evaluated under the same limit.
    let acyclic = write_file(
        dir.path(),
        "acyclic.srl",
        "PREFIX ex: <http://example.org/ns#>\nRULE { ?x ex:m <<( ?x ex:n ?y )>> } WHERE { ?x ex:n ?y }\n",
    );
    let accepted = run(&[
        "rules",
        "--srl",
        &acyclic,
        "--max-term-generating-rounds",
        "3",
        "--to",
        "ntriples",
        &data,
    ]);
    assert_eq!(code(&accepted), 0, "{}", stderr(&accepted));
    // The flag still reaches the RL route and changes the outcome: the neighbour infers a
    // term the graph did not hold, which is one term-generating round, so a limit of 0
    // stops it by name and a limit of 1 lets it finish.
    let stopped = run(&[
        "rules",
        "--srl",
        &acyclic,
        "--max-term-generating-rounds",
        "0",
        "--to",
        "ntriples",
        &data,
    ]);
    assert_eq!(code(&stopped), 1, "{}", stderr(&stopped));
    assert!(
        stderr(&stopped).contains("past the limit of 0"),
        "{}",
        stderr(&stopped)
    );
    let one = run(&[
        "rules",
        "--srl",
        &acyclic,
        "--max-term-generating-rounds",
        "1",
        "--to",
        "ntriples",
        &data,
    ]);
    assert_eq!(code(&one), 0, "{}", stderr(&one));

    // Exactly one rule source.
    let both = run(&[
        "rules", "--shapes", &shapes, "--srl", &lone, "--to", "ntriples", &data,
    ]);
    assert_eq!(code(&both), 2, "{}", stderr(&both));
    let neither = run(&["rules", "--to", "ntriples", &data]);
    assert_eq!(code(&neither), 2, "{}", stderr(&neither));
}

/// `rules --srl FILE --check[=LEVEL]` checks a rule set without evaluating it: one summary
/// line on stdout and exit 0 for a rule set that passes; exit 1 naming the stage for one a
/// check refuses; exit 2 for an unused `--import` pair and for the evaluation flags a
/// check never consumes. Each refusal sits beside the neighbour that passes.
#[test]
fn cli_rules_check() {
    let dir = purrdf_testkit::temp_dir!().expect("tempdir");
    let data = write_file(dir.path(), "data.ttl", DATA);
    let imported = write_file(
        dir.path(),
        "more.srl",
        "PREFIX ex: <http://example.org/ns#>\nRULE { ?x ex:counted true } WHERE { ?x ex:q ?y }\n",
    );
    let srl = write_file(
        dir.path(),
        "rules.srl",
        "PREFIX ex: <http://example.org/ns#>\nVERSION \"1.2\"\nIMPORTS <http://example.org/more>\n\
         RULE { ?x ex:q ?y } WHERE { ?x ex:n ?y }\nDATA { ex:d ex:q 2 }\n",
    );
    let pair = format!("http://example.org/more={imported}");

    let ok = run(&["rules", "--srl", &srl, "--import", &pair, "--check"]);
    assert_eq!(code(&ok), 0, "{}", stderr(&ok));
    assert_eq!(
        stdout(&ok),
        format!(
            "--srl {srl}: SPARQL 1.2 RL rule set is well formed and stratified (level \
             stratified): 2 rules, 1 data triple, 1 imported rule set, 1 stratum, \
             VERSION \"1.2\"\n"
        )
    );
    // No evaluation ran: nothing inferred is reported.
    assert!(!stderr(&ok).contains("rules inferred"), "{}", stderr(&ok));

    // The same rule set without the pair: the import is unresolved, exit 1, by name.
    let missing = run(&["rules", "--srl", &srl, "--check"]);
    assert_eq!(code(&missing), 1, "{}", stderr(&missing));
    assert!(
        stderr(&missing).contains("--import http://example.org/more=FILE"),
        "{}",
        stderr(&missing)
    );
    assert_eq!(stdout(&missing), "");
    // A pair the closure never reaches is refused as unused, exit 2.
    let lone = write_file(
        dir.path(),
        "lone.srl",
        "PREFIX ex: <http://example.org/ns#>\nRULE { ?x ex:q ?y } WHERE { ?x ex:n ?y }\n",
    );
    let unused = run(&["rules", "--srl", &lone, "--import", &pair, "--check"]);
    assert_eq!(code(&unused), 2, "{}", stderr(&unused));
    let lone_ok = run(&["rules", "--srl", &lone, "--check"]);
    assert_eq!(code(&lone_ok), 0, "{}", stderr(&lone_ok));

    // A self-negating rule: syntactically valid and well formed, not stratifiable. Each
    // level answers its own question; its stratifiable neighbour passes all three.
    let cyclic = write_file(
        dir.path(),
        "cyclic.srl",
        "PREFIX ex: <http://example.org/ns#>\nRULE { ?x ex:p ex:z } WHERE { ?x ex:q ex:o NOT { ?x ex:p ex:z } }\n",
    );
    let acyclic = write_file(
        dir.path(),
        "acyclic.srl",
        "PREFIX ex: <http://example.org/ns#>\nRULE { ?x ex:p ex:z } WHERE { ?x ex:q ex:o NOT { ?x ex:r ex:z } }\n",
    );
    for level in ["--check=syntax", "--check=well-formed"] {
        let out = run(&["rules", "--srl", &cyclic, level]);
        assert_eq!(code(&out), 0, "{level}: {}", stderr(&out));
    }
    let strat = run(&["rules", "--srl", &cyclic, "--check=stratified"]);
    assert_eq!(code(&strat), 1, "{}", stderr(&strat));
    assert!(
        stderr(&strat).contains("is not stratifiable"),
        "{}",
        stderr(&strat)
    );
    for level in ["--check=syntax", "--check=well-formed", "--check"] {
        let out = run(&["rules", "--srl", &acyclic, level]);
        assert_eq!(code(&out), 0, "{level}: {}", stderr(&out));
    }
    // An ill-formed rule: the grammar accepts it, `well-formed` refuses it by that stage.
    let ill = write_file(
        dir.path(),
        "ill.srl",
        "PREFIX ex: <http://example.org/ns#>\nRULE { ?s ex:p ?o } WHERE { FILTER(?o < 50) ?s ex:p ?o }\n",
    );
    assert_eq!(code(&run(&["rules", "--srl", &ill, "--check=syntax"])), 0);
    let wf = run(&["rules", "--srl", &ill, "--check=well-formed"]);
    assert_eq!(code(&wf), 1, "{}", stderr(&wf));
    assert!(
        stderr(&wf).contains("is not well formed"),
        "{}",
        stderr(&wf)
    );
    // Not SPARQL 1.2 RL at all: refused by the grammar at every level.
    let broken = write_file(dir.path(), "broken.srl", "RULE {\n");
    let syntax = run(&["rules", "--srl", &broken, "--check=syntax"]);
    assert_eq!(code(&syntax), 1, "{}", stderr(&syntax));
    assert!(
        stderr(&syntax).contains("SPARQL 1.2 RL syntax error"),
        "{}",
        stderr(&syntax)
    );

    // A check evaluates nothing, so the flags that configure an evaluation are refused
    // beside it (exit 2), as are an unknown level and a SHACL rule source.
    for extra in [
        vec![data.as_str()],
        vec!["--to", "ntriples"],
        vec!["--explain"],
        vec!["--max-join-steps", "10"],
        vec!["--base", "http://example.org/"],
    ] {
        let mut args = vec!["rules", "--srl", lone.as_str(), "--check"];
        args.extend(extra.iter().copied());
        let out = run(&args);
        assert_eq!(code(&out), 2, "{args:?}: {}", stderr(&out));
    }
    let unknown = run(&["rules", "--srl", &lone, "--check=stratify"]);
    assert_eq!(code(&unknown), 2, "{}", stderr(&unknown));
    let shapes = shapes_file(dir.path(), TOOLS);
    let on_shapes = run(&["rules", "--shapes", &shapes, "--check"]);
    assert_eq!(code(&on_shapes), 2, "{}", stderr(&on_shapes));
    // The global document flags configure a serializer a check never runs.
    let ledger = run(&["--loss-ledger", "rules", "--srl", &lone, "--check"]);
    assert_eq!(code(&ledger), 2, "{}", stderr(&ledger));
}

/// `node-expr` reports the shapes graph's mandatory diagnostic on stderr — a `shacl
/// diagnostic RULE SHAPE` line, as `validate` and `rules` print it — when a shape carries an
/// empty `sh:in` list, and prints none for the neighbour whose list has a member. The output
/// is the expression's either way: a diagnostic changes nothing it evaluates.
#[test]
fn cli_node_expr_reports_the_mandatory_diagnostic() {
    let dir = purrdf_testkit::temp_dir!().expect("tempdir");
    let data = write_file(dir.path(), "data.ttl", DATA);
    let with_list = |members: &str| {
        write_file(
            dir.path(),
            &format!("shapes-{}.ttl", members.len()),
            &format!(
                "@prefix sh: <http://www.w3.org/ns/shacl#> .\n\
                 @prefix ex: <http://example.org/ns#> .\n\
                 ex:Listed a sh:NodeShape ; sh:in ( {members} ) .\n"
            ),
        )
    };
    let run_on = |shapes: &str| {
        run(&[
            "node-expr",
            "--shapes",
            shapes,
            "--expr",
            "http://example.org/ns#Constant",
            "--focus",
            "http://example.org/ns#a",
            &data,
        ])
    };
    let empty = run_on(&with_list(""));
    assert_eq!(code(&empty), 0, "{}", stderr(&empty));
    assert_eq!(stdout(&empty), "<http://example.org/ns#Constant>\n");
    assert!(
        stderr(&empty)
            .contains("shacl diagnostic in-minListLength <http://example.org/ns#Listed>\n"),
        "{}",
        stderr(&empty)
    );
    let member = run_on(&with_list("ex:one"));
    assert_eq!(code(&member), 0, "{}", stderr(&member));
    assert_eq!(stdout(&member), "<http://example.org/ns#Constant>\n");
    assert!(
        !stderr(&member).contains("shacl diagnostic"),
        "{}",
        stderr(&member)
    );
}

/// `node-expr` evaluates one expression node of the shapes graph: a `sh:sparqlExpr` node
/// natively, with its `sh:prefixes`; a labelled blank node reading `--scope`; a literal
/// focus. A label the document never wrote, and a scope binding that could never be read,
/// are refused beside the valid neighbour.
#[test]
fn cli_node_expr() {
    let dir = purrdf_testkit::temp_dir!().expect("tempdir");
    let shapes = shapes_file(dir.path(), TOOLS);
    let data = write_file(dir.path(), "data.ttl", DATA);

    let tag = run(&[
        "node-expr",
        "--shapes",
        &shapes,
        "--expr",
        "http://example.org/ns#Tag",
        "--focus",
        "http://example.org/ns#a",
        &data,
    ]);
    assert_eq!(code(&tag), 0, "{}", stderr(&tag));
    assert_eq!(stdout(&tag), "<http://example.org/ns#yes>\n");
    assert!(stderr(&tag).contains("node-expr outputs 1\n"));

    let scoped = run(&[
        "node-expr",
        "--shapes",
        &shapes,
        "--expr",
        "_:suffix",
        "--focus",
        &format!("\"-3\"^^{INTEGER}"),
        "--scope",
        "suffix=\"!\"@en",
        &data,
    ]);
    assert_eq!(code(&scoped), 0, "{}", stderr(&scoped));
    assert_eq!(stdout(&scoped), "\"!\"@en\n");

    let unknown = run(&[
        "node-expr",
        "--shapes",
        &shapes,
        "--expr",
        "_:nosuch",
        "--focus",
        "http://example.org/ns#a",
        &data,
    ]);
    assert_eq!(code(&unknown), 1, "{}", stderr(&unknown));
    assert!(stderr(&unknown).contains("mentions no blank node _:nosuch"));

    let unreadable = run(&[
        "node-expr",
        "--shapes",
        &shapes,
        "--expr",
        "_:suffix",
        "--focus",
        "http://example.org/ns#a",
        "--scope",
        "focusNode=\"!\"",
        &data,
    ]);
    assert_eq!(code(&unreadable), 1, "{}", stderr(&unreadable));
    assert!(stderr(&unreadable).contains("can never be read"));

    let relative = run(&[
        "node-expr",
        "--shapes",
        &shapes,
        "--expr",
        "Tag",
        "--focus",
        "http://example.org/ns#a",
        &data,
    ]);
    assert_eq!(
        code(&relative),
        2,
        "an argv term is decided before any document"
    );
    let no_equals = run(&[
        "node-expr",
        "--shapes",
        &shapes,
        "--expr",
        "_:suffix",
        "--focus",
        "http://example.org/ns#a",
        "--scope",
        "suffix",
        &data,
    ]);
    assert_eq!(code(&no_equals), 2, "{}", stderr(&no_equals));
}

/// `node-expr` names an ANONYMOUS expression two ways: by a walk from a named node (the
/// rule's `sh:object` expression, reached from `ex:Tagger`), and inline as Turtle (whose
/// `sh:prefixes ex:Prefixes` resolves in the shapes graph). Each refusal sits beside a
/// valid neighbour: a walk step reaching two values beside one reaching one, an inline
/// document with two roots beside one with one, and the selector flags' usage errors
/// beside the spelling that runs.
#[test]
fn cli_node_expr_selectors() {
    let dir = purrdf_testkit::temp_dir!().expect("tempdir");
    let shapes = shapes_file(dir.path(), TOOLS);
    let data = write_file(dir.path(), "data.ttl", DATA);
    let node_expr = |selector: &[&str]| {
        let mut args = vec!["node-expr", "--shapes", &shapes];
        args.extend_from_slice(selector);
        args.extend_from_slice(&["--focus", "http://example.org/ns#a", &data]);
        run(&args)
    };
    const SH: &str = "http://www.w3.org/ns/shacl#";

    let walked = node_expr(&[
        "--expr-at",
        "http://example.org/ns#Tagger",
        "--expr-via",
        &format!("{SH}rule"),
        "--expr-via",
        &format!("{SH}object"),
    ]);
    assert_eq!(code(&walked), 0, "{}", stderr(&walked));
    assert_eq!(stdout(&walked), "<http://example.org/ns#yes>\n");

    let one = node_expr(&[
        "--expr-at",
        &format!("{SH}SPARQLExprExpression"),
        "--expr-via",
        "http://www.w3.org/2000/01/rdf-schema#isDefinedBy",
    ]);
    assert_eq!(code(&one), 0, "{}", stderr(&one));
    assert_eq!(stdout(&one), format!("<{SH}>\n"));
    let two = node_expr(&[
        "--expr-at",
        &format!("{SH}SPARQLExprExpression"),
        "--expr-via",
        &format!("{SH}parameter"),
    ]);
    assert_eq!(code(&two), 1, "{}", stderr(&two));
    assert!(
        stderr(&two).contains("reaches 2 values"),
        "{}",
        stderr(&two)
    );

    let inline = node_expr(&[
        "--expr-turtle",
        "[ sh:sparqlExpr \"ex:yes\" ; sh:prefixes ex:Prefixes ] .",
    ]);
    assert_eq!(code(&inline), 0, "{}", stderr(&inline));
    assert_eq!(stdout(&inline), "<http://example.org/ns#yes>\n");
    let file = write_file(
        dir.path(),
        "expr.ttl",
        "[ sh:sparqlExpr \"ex:yes\" ; sh:prefixes ex:Prefixes ] .\n",
    );
    let from_file = node_expr(&["--expr-turtle-file", &file]);
    assert_eq!(code(&from_file), 0, "{}", stderr(&from_file));
    assert_eq!(stdout(&from_file), "<http://example.org/ns#yes>\n");
    let roots = node_expr(&[
        "--expr-turtle",
        "[ shnex:var \"a\" ] . [ shnex:var \"b\" ] .",
    ]);
    assert_eq!(code(&roots), 1, "{}", stderr(&roots));
    assert!(
        stderr(&roots).contains("has 2 root blank nodes"),
        "{}",
        stderr(&roots)
    );

    // Usage: two selectors, none, a walk with no predicate, a predicate with no walk,
    // a relative walk start, and the inline file on stdin.
    for selector in [
        &[
            "--expr",
            "http://example.org/ns#Tag",
            "--expr-turtle",
            "[ shnex:var \"a\" ] .",
        ][..],
        &[][..],
        &["--expr-at", "http://example.org/ns#Tagger"][..],
        &["--expr-via", &format!("{SH}rule")][..],
        &["--expr-at", "Tagger", "--expr-via", &format!("{SH}rule")][..],
        &["--expr-turtle-file", "-"][..],
    ] {
        let out = node_expr(selector);
        assert_eq!(code(&out), 2, "{selector:?}: {}", stderr(&out));
    }
}

/// `shapes lint` certifies the declaration-bearing graph clean (exit 0), naming `sh:sparqlExpr`'s
/// function as bound natively; a malformed neighbour is reported with findings (exit 1,
/// the report still written); a graph `shacl-shacl.ttl` flags but SHACL 1.2 Core makes
/// well-formed stays clean.
#[test]
fn cli_shapes_lint() {
    let dir = purrdf_testkit::temp_dir!().expect("tempdir");
    let clean = shapes_file(dir.path(), TOOLS);
    let out = run(&["shapes", "lint", &clean]);
    assert_eq!(code(&out), 0, "{}", stderr(&out));
    let report = stdout(&out);
    assert!(
        report.starts_with("load accepted\nshacl-shacl 0\n"),
        "{report}"
    );
    assert!(
        report.contains(
            "call native <http://www.w3.org/ns/shacl#SPARQLExprExpression> in sh:rule on <http://example.org/ns#Tagger>\n"
        ),
        "{report}"
    );
    assert!(
        report.ends_with(
            "validators 0\nunexecuted 0\ndiagnostics 0\nunanchored-imports 0\nfindings 0\nclean true\n"
        ),
        "{report}"
    );
    assert!(stderr(&out).contains("shapes lint clean true\n"));
    assert_eq!(
        stdout(&run(&["shapes", "lint", &clean])),
        report,
        "deterministic"
    );

    // An owl:imports on a node that is no anchor is data: listed, never a finding.
    let unanchored = write_file(
        dir.path(),
        "unanchored.ttl",
        &format!(
            "{PREFIXES}{SPARQL_EXPR_DECLARATION}{TOOLS}<http://example.org/ns#Other> <http://www.w3.org/2002/07/owl#imports> \
             <http://example.org/ns#Target> .\n"
        ),
    );
    let listed = run(&["shapes", "lint", &unanchored]);
    assert_eq!(code(&listed), 0, "{}", stderr(&listed));
    assert!(
        stdout(&listed).contains(
            "unanchored-imports 1\nunanchored <http://example.org/ns#Other> \
             <http://example.org/ns#Target> document -\nfindings 0\nclean true\n"
        ),
        "{}",
        stdout(&listed)
    );

    let malformed = write_file(
        dir.path(),
        "malformed.ttl",
        &format!(
            "{PREFIXES}{SPARQL_EXPR_DECLARATION}ex:S a sh:NodeShape ; sh:property [ sh:path ex:p ; sh:minCount \"one\" ] .\n"
        ),
    );
    let bad = run(&["shapes", "lint", &malformed]);
    assert_eq!(code(&bad), 1, "{}", stderr(&bad));
    let report = stdout(&bad);
    assert!(report.starts_with("load refused\n  error "), "{report}");
    assert!(
        report.contains("path <http://www.w3.org/ns/shacl#minCount>"),
        "{report}"
    );
    assert!(report.contains("functions unavailable\n"), "{report}");
    assert!(
        report.contains("validators unavailable\nunexecuted unavailable\n"),
        "{report}"
    );
    assert!(report.ends_with("clean false\n"), "{report}");
    assert!(stderr(&bad).contains("shapes lint clean false\n"));

    let list_kind = write_file(
        dir.path(),
        "list-kind.ttl",
        &format!(
            "{PREFIXES}{SPARQL_EXPR_DECLARATION}ex:S a sh:NodeShape ; \
             sh:nodeKind ( sh:IRI sh:Literal ) .\n"
        ),
    );
    let superseded = run(&["shapes", "lint", &list_kind]);
    assert_eq!(code(&superseded), 0, "{}", stderr(&superseded));
    assert!(stdout(&superseded).contains(" superseded list-valued-node-kind\n"));

    // An empty sh:xone list is a mandatory diagnostic named by rule id: the load is
    // accepted, the line is a finding, and the verb exits 1. The clean fixture above is
    // its neighbour and reported `diagnostics 0`.
    let empty_xone = write_file(
        dir.path(),
        "empty-xone.ttl",
        &format!("{PREFIXES}{SPARQL_EXPR_DECLARATION}ex:S a sh:NodeShape ; sh:xone () .\n"),
    );
    let diagnosed = run(&["shapes", "lint", &empty_xone]);
    assert_eq!(code(&diagnosed), 1, "{}", stderr(&diagnosed));
    let report = stdout(&diagnosed);
    assert!(report.starts_with("load accepted\n"), "{report}");
    assert!(
        report.contains("diagnostics 1\ndiagnostic xone-minListLength <http://example.org/ns#S>\n"),
        "{report}"
    );
    assert!(stderr(&diagnosed).contains("shapes lint findings 1\n"));

    let ledger = run(&["--loss-ledger", "shapes", "lint", &clean]);
    assert_eq!(code(&ledger), 2, "a text report has no loss ledger");
}

// ── One shapes graph, one owl:imports verdict, on every lane ────────────────────

/// The importing shapes graph: an ontology header and its import, and no shape of its own.
const IMPORTER: &str = "@prefix owl: <http://www.w3.org/2002/07/owl#> .\n\
    <http://example.org/shapes> a owl:Ontology ;\n\
      owl:imports <http://example.org/lib> .\n";

/// The imported document: a shape needing `ex:name`, a rule tagging every `ex:Person`
/// `ex:checked ex:yes`, and a node expression `ex:Who` reading the scope variable `who`.
const IMPORTED: &str = "@prefix sh: <http://www.w3.org/ns/shacl#> .\n\
    @prefix shnex: <http://www.w3.org/ns/shacl-node-expr#> .\n\
    @prefix ex: <http://example.org/> .\n\
    ex:NameShape a sh:NodeShape ;\n\
      sh:targetClass ex:Person ;\n\
      sh:property [ sh:path ex:name ; sh:minCount 1 ] ;\n\
      sh:rule [ a sh:TripleRule ; sh:subject sh:this ; sh:predicate ex:checked ; \
                sh:object ex:yes ] .\n\
    ex:Who shnex:var \"who\" .\n";

/// One `ex:Person` with no `ex:name`.
const PERSON: &str = "<http://example.org/alice> \
    <http://www.w3.org/1999/02/22-rdf-syntax-ns#type> <http://example.org/Person> .\n";

/// Every shapes-graph lane of the command line refuses the importing shapes graph with the
/// same `unresolved-import` refusal when no `--import` names the imported document, and —
/// with the pair — applies the imported document: the shape reports, the rule infers, the
/// expression reads its scope, the lint certifies, and the product carries the shape.
#[test]
fn every_shapes_lane_gives_the_same_owl_imports_verdict() {
    let dir = purrdf_testkit::temp_dir!().expect("tempdir");
    let shapes = write_file(dir.path(), "importer.ttl", IMPORTER);
    let lib = write_file(dir.path(), "lib.ttl", IMPORTED);
    let data = write_file(dir.path(), "data.nt", PERSON);
    let pair = format!("http://example.org/lib={lib}");
    let product = dir.path().join("closure.purrshp");
    let product = product.to_str().expect("utf-8 path").to_owned();

    let validate = |import: Option<&str>| {
        let mut args = vec!["validate", "--shapes", &shapes];
        args.extend(import.map(|pair| ["--import", pair]).into_iter().flatten());
        args.push(&data);
        run(&args)
    };
    let rules = |import: Option<&str>| {
        let mut args = vec!["rules", "--shapes", &shapes, "--to", "ntriples"];
        args.extend(import.map(|pair| ["--import", pair]).into_iter().flatten());
        args.push(&data);
        run(&args)
    };
    let node_expr = |import: Option<&str>| {
        let mut args = vec![
            "node-expr",
            "--shapes",
            &shapes,
            "--expr",
            "http://example.org/Who",
            "--focus",
            "http://example.org/alice",
            "--scope",
            "who=http://example.org/bob",
        ];
        args.extend(import.map(|pair| ["--import", pair]).into_iter().flatten());
        args.push(&data);
        run(&args)
    };
    let lint = |import: Option<&str>| {
        let mut args = vec!["shapes", "lint"];
        args.extend(import.map(|pair| ["--import", pair]).into_iter().flatten());
        args.push(&shapes);
        run(&args)
    };
    let pack = |import: Option<&str>| {
        let mut args = vec!["shacl", "pack", "--shapes", &shapes, "--out", &product];
        args.extend(import.map(|pair| ["--import", pair]).into_iter().flatten());
        run(&args)
    };

    for (lane, out) in [
        ("validate", validate(None)),
        ("rules", rules(None)),
        ("node-expr", node_expr(None)),
        ("shapes lint", lint(None)),
        ("shacl pack", pack(None)),
    ] {
        let err = stderr(&out);
        assert_eq!(code(&out), 1, "{lane}: a runtime refusal: {err}");
        assert!(
            err.contains("unresolved-import")
                && err.contains("<http://example.org/lib>")
                && err.contains("--import http://example.org/lib=FILE"),
            "{lane}: the one refusal, naming the import and its pair: {err}"
        );
        assert!(stdout(&out).is_empty(), "{lane}: nothing is written");
    }

    let validated = validate(Some(&pair));
    assert_eq!(code(&validated), 0, "{}", stderr(&validated));
    assert!(
        stderr(&validated).contains("shacl conforms false\n")
            && stdout(&validated).contains("MinCountConstraintComponent"),
        "the imported shape reports: {}",
        stdout(&validated)
    );

    let inferred = rules(Some(&pair));
    assert_eq!(code(&inferred), 0, "{}", stderr(&inferred));
    assert_eq!(
        stdout(&inferred),
        "<http://example.org/alice> <http://example.org/checked> <http://example.org/yes> .\n",
        "the imported rule infers"
    );

    let evaluated = node_expr(Some(&pair));
    assert_eq!(code(&evaluated), 0, "{}", stderr(&evaluated));
    assert_eq!(
        stdout(&evaluated),
        "<http://example.org/bob>\n",
        "the imported expression reads its scope"
    );

    let linted = lint(Some(&pair));
    assert_eq!(code(&linted), 0, "{}", stderr(&linted));
    assert!(
        stdout(&linted).ends_with("clean true\n"),
        "{}",
        stdout(&linted)
    );

    let packed = pack(Some(&pair));
    assert_eq!(code(&packed), 0, "{}", stderr(&packed));
    let restored = run(&["validate", "--shapes-product", &product, &data]);
    assert_eq!(code(&restored), 0, "{}", stderr(&restored));
    assert!(
        stdout(&restored).contains("MinCountConstraintComponent"),
        "the product carries the imported shape: {}",
        stdout(&restored)
    );
}

/// SHACL's prefix idiom (the W3C `sparql/node/prefixes-001` shape on `example.org`): the
/// `owl:imports` sits on `ex:TestPrefixes`, which is neither the shapes document's IRI nor
/// an ontology header, so it is a prefix edge and not an import. The command line validates
/// it with no `--import`, and the prefixes declared along
/// `sh:prefixes/owl:imports*/sh:declare` — `imp:` on the target, `test:` on the importing
/// node, neither a Turtle `@prefix` — reach the query, which reports `ex:Invalid`. The
/// neighbour types `ex:TestPrefixes` `owl:Ontology`: its `owl:imports` is then an import of
/// a document nothing in hand declares, and it is refused by name.
#[test]
fn the_shacl_prefix_idiom_validates_without_an_import_and_a_header_import_is_refused() {
    let idiom = |importer_type: &str| {
        format!(
            "@prefix ex: <http://example.org/ns#> .\n\
             @prefix owl: <http://www.w3.org/2002/07/owl#> .\n\
             @prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#> .\n\
             @prefix sh: <http://www.w3.org/ns/shacl#> .\n\
             @prefix xsd: <http://www.w3.org/2001/XMLSchema#> .\n\
             <http://example.org/ns#> sh:declare [ sh:prefix \"imp\" ; \
               sh:namespace \"http://example.org/ns#\"^^xsd:anyURI ] .\n\
             ex:TestPrefixes {importer_type} owl:imports <http://example.org/ns#> ;\n\
               sh:declare [ sh:prefix \"test\" ; \
                            sh:namespace \"http://example.org/test#\"^^xsd:anyURI ] .\n\
             ex:TestSPARQL sh:prefixes ex:TestPrefixes ;\n\
               sh:select \"SELECT $this ?value WHERE {{ $this imp:property ?value . \
                            FILTER (?value = test:Value) }}\" .\n\
             ex:TestShape a sh:NodeShape ; sh:sparql ex:TestSPARQL ;\n\
               sh:targetNode ex:Invalid , ex:Valid .\n"
        )
    };
    let dir = purrdf_testkit::temp_dir!().expect("tempdir");
    let declared = write_file(dir.path(), "declared.ttl", &idiom(""));
    let header = write_file(dir.path(), "header.ttl", &idiom("a owl:Ontology ;"));
    let data = write_file(
        dir.path(),
        "data.nt",
        "<http://example.org/ns#Invalid> <http://example.org/ns#property> \
         <http://example.org/test#Value> .\n\
         <http://example.org/ns#Valid> <http://example.org/ns#property> \
         <http://example.org/test#Other> .\n",
    );

    let out = run(&["validate", "--shapes", &declared, &data]);
    let err = stderr(&out);
    assert_eq!(code(&out), 0, "the idiom is in hand: {err}");
    assert!(
        err.contains("shacl conforms false\n") && err.contains("shacl results 1\n"),
        "one result: {err}"
    );
    let report = stdout(&out);
    assert!(
        report.contains("<http://www.w3.org/ns/shacl#focusNode> <http://example.org/ns#Invalid>")
            && report
                .contains("<http://www.w3.org/ns/shacl#value> <http://example.org/test#Value>"),
        "the query ran with both declared prefixes: {report}"
    );

    let out = run(&["validate", "--shapes", &header, &data]);
    let err = stderr(&out);
    assert_eq!(code(&out), 1, "a runtime refusal: {err}");
    assert!(
        err.contains("unresolved-import") && err.contains("<http://example.org/ns#>"),
        "the refusal names the header's import: {err}"
    );
    assert!(stdout(&out).is_empty(), "no report is written");
}

/// `shapes lint` names each validator a shapes graph declares for a built-in component
/// — here an ASK validator on `sh:MinCountConstraintComponent` that would pass
/// nothing — as an alternative the native implementation supersedes, and counts it as
/// no finding: exit 0, clean, the same findings as the graph without it. `validate`
/// over the same graph reports the NATIVE verdict, so the alternative did not run.
#[test]
fn cli_shapes_lint_reports_superseded_builtin_validators() {
    let dir = purrdf_testkit::temp_dir!().expect("tempdir");
    let shapes = write_file(
        dir.path(),
        "alternatives.ttl",
        &format!(
            r#"{PREFIXES}
sh:MinCountConstraintComponent a sh:ConstraintComponent ;
  sh:validator ex:neverValid .
ex:neverValid a sh:SPARQLAskValidator ; sh:ask "ASK {{ FILTER (false) }}" .
ex:S a sh:NodeShape ; sh:targetNode ex:a ; sh:property [ sh:path ex:n ; sh:minCount 1 ] .
"#
        ),
    );
    let out = run(&["shapes", "lint", &shapes]);
    assert_eq!(code(&out), 0, "{}", stderr(&out));
    let report = stdout(&out);
    assert!(
        report.contains(
            "validators 1\nalternative <http://www.w3.org/ns/shacl#MinCountConstraintComponent> \
             <http://www.w3.org/ns/shacl#validator> <http://example.org/ns#neverValid> \
             sparql-ask superseded-by-native\n"
        ),
        "{report}"
    );
    assert!(report.ends_with("findings 0\nclean true\n"), "{report}");

    let data = write_file(dir.path(), "data.ttl", DATA);
    let validated = run(&["validate", "--shapes", &shapes, &data]);
    assert_eq!(code(&validated), 0, "{}", stderr(&validated));
}

/// The stored-fact number a `--max-stored-facts` refusal observed.
fn observed_facts(refusal: &str) -> u64 {
    let (_, tail) = refusal
        .split_once("the rules exceeded the stored-fact limit: ")
        .unwrap_or_else(|| panic!("not a stored-fact refusal: {refusal}"));
    tail.split(' ')
        .next()
        .and_then(|count| count.parse().ok())
        .unwrap_or_else(|| panic!("no observed count: {refusal}"))
}

/// `rules --max-stored-facts` and `--max-join-steps` refuse naming the numbers and this
/// command's own flag, and write no graph; a limit of exactly the store the run needs
/// completes with the same inference graph as the default, and one fact fewer refuses.
#[test]
fn cli_rules_capacity_limits() {
    let dir = purrdf_testkit::temp_dir!().expect("tempdir");
    let shapes = shapes_file(dir.path(), TOOLS);
    let data = write_file(dir.path(), "data.ttl", DATA);
    let with = |flag: &str, value: &str| {
        run(&[
            "rules", "--shapes", &shapes, flag, value, "--to", "ntriples", &data,
        ])
    };

    // Find the store the run needs by raising the limit to each refusal's observation.
    let mut limit = 1_u64;
    let admitted = loop {
        let out = with("--max-stored-facts", &limit.to_string());
        if code(&out) == 0 {
            break out;
        }
        assert_eq!(code(&out), 1, "{}", stderr(&out));
        let refusal = stderr(&out);
        assert!(
            refusal.contains(&format!("{limit} permitted (the caller's limit)"))
                && refusal
                    .trim_end()
                    .ends_with("raise it with --max-stored-facts"),
            "the refusal names the numbers and this command's flag: {refusal}"
        );
        assert!(stdout(&out).is_empty(), "a refused run writes no graph");
        let observed = observed_facts(&refusal);
        assert!(observed > limit, "{refusal}");
        limit = observed;
    };
    assert_eq!(stdout(&admitted), expected_inference());
    let short = with("--max-stored-facts", &(limit - 1).to_string());
    assert_eq!(code(&short), 1, "{}", stderr(&short));
    assert!(
        stderr(&short).contains(&format!("{limit} facts observed, {} permitted", limit - 1)),
        "{}",
        stderr(&short)
    );

    let steps = with("--max-join-steps", "1");
    assert_eq!(code(&steps), 1, "{}", stderr(&steps));
    assert!(
        stderr(&steps).contains("the rules exceeded the join-step limit: ")
            && stderr(&steps)
                .trim_end()
                .ends_with("raise it with --max-join-steps"),
        "{}",
        stderr(&steps)
    );
    let roomy = with("--max-join-steps", "1000000");
    assert_eq!(code(&roomy), 0, "{}", stderr(&roomy));
    assert_eq!(stdout(&roomy), expected_inference());
}

/// Nonlinear recursive closure refuses an explicit small work budget without writing
/// a partial graph. Raising the budget completes the same closure as the default
/// and the linear rule. The test does not depend on an optimizer's historical step
/// count or require the default budget to reject a workload it can now complete.
#[test]
fn cli_rules_nonlinear_closure_needs_a_raised_join_step_limit() {
    use std::fmt::Write as _;
    const EDGES: usize = 32;
    let dir = purrdf_testkit::temp_dir!().expect("tempdir");
    let chain_of = |edges: usize| {
        let mut chain = String::from("@prefix ex: <http://example.org/ns#> .\n");
        for index in 0..edges {
            writeln!(chain, "ex:n{index} ex:link ex:n{} .", index + 1).expect("write to String");
        }
        chain
    };
    let data = write_file(dir.path(), "chain.ttl", &chain_of(EDGES));
    let rules = |recursive_atom: &str| {
        format!(
            "PREFIX ex: <http://example.org/ns#>\n\
             RULE {{ ?x ex:connected ?y }} WHERE {{ ?x ex:link ?y }}\n\
             RULE {{ ?x ex:connected ?z }} WHERE {{ ?x ex:connected ?y . ?y {recursive_atom} ?z }}\n"
        )
    };
    let nonlinear = write_file(dir.path(), "nonlinear.srl", &rules("ex:connected"));
    let linear = write_file(dir.path(), "linear.srl", &rules("ex:link"));

    let refused = run(&[
        "rules",
        "--srl",
        &nonlinear,
        "--max-join-steps",
        "64",
        "--to",
        "ntriples",
        &data,
    ]);
    assert_eq!(code(&refused), 1, "{}", stderr(&refused));
    assert!(
        stderr(&refused).contains("the rules exceeded the join-step limit: ")
            && stderr(&refused).contains("64 permitted (the caller's limit)")
            && stderr(&refused)
                .trim_end()
                .ends_with("raise it with --max-join-steps"),
        "{}",
        stderr(&refused)
    );
    assert!(stdout(&refused).is_empty(), "a refused run writes no graph");

    let fits = run(&["rules", "--srl", &nonlinear, "--to", "ntriples", &data]);
    assert_eq!(code(&fits), 0, "{}", stderr(&fits));
    assert_eq!(stdout(&fits).lines().count(), EDGES * (EDGES + 1) / 2);

    let raised = run(&[
        "rules",
        "--srl",
        &nonlinear,
        "--max-join-steps",
        "2097152",
        "--to",
        "ntriples",
        &data,
    ]);
    assert_eq!(code(&raised), 0, "{}", stderr(&raised));
    assert_eq!(stdout(&raised), stdout(&fits));

    let linear_run = run(&["rules", "--srl", &linear, "--to", "ntriples", &data]);
    assert_eq!(code(&linear_run), 0, "{}", stderr(&linear_run));
    assert_eq!(
        stdout(&linear_run),
        stdout(&raised),
        "the same closure either way"
    );
}

/// Maintainer decision, "Every run reports it": the approved W3C test `core/node/in-002`'s
/// shapes graph (an empty `sh:in` list), with a rule. `validate` writes the verdict and the
/// result count the specification gives and then `shacl diagnostic in-minListLength
/// <shape>`; `rules` writes the same line after its inference count; SARIF carries it as a
/// note-level tool-execution notification. The neighbour whose list has a member writes
/// no diagnostic line and no notification, and its verdict is the conforming one.
#[test]
fn every_run_reports_an_empty_in_list() {
    let dir = purrdf_testkit::temp_dir!().expect("tempdir");
    let shapes = |members: &str| {
        format!(
            "@prefix ex: <http://example.com/ns#> .\n\
             @prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> .\n\
             @prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#> .\n\
             @prefix sh: <http://www.w3.org/ns/shacl#> .\n\
             ex:TestShape rdf:type rdfs:Class , sh:NodeShape ; sh:in {members} ;\n\
               sh:rule [ a sh:TripleRule ; sh:subject sh:this ; sh:predicate ex:seen ; \
               sh:object ex:yes ] .\n"
        )
    };
    let data = write_file(
        dir.path(),
        "data.nt",
        "<http://example.com/ns#Instance> <http://www.w3.org/1999/02/22-rdf-syntax-ns#type> \
         <http://example.com/ns#TestShape> .\n",
    );
    let line = "shacl diagnostic in-minListLength <http://example.com/ns#TestShape>\n";
    for (name, members, conforms, results) in [
        ("empty.ttl", "()", "false", "1"),
        (
            "filled.ttl",
            "( <http://example.com/ns#Instance> )",
            "true",
            "0",
        ),
    ] {
        let flagged = members == "()";
        let path = write_file(dir.path(), name, &shapes(members));
        let validated = run(&["validate", "--shapes", &path, &data]);
        let err = stderr(&validated);
        assert_eq!(code(&validated), 0, "{err}");
        assert!(
            err.contains(&format!(
                "shacl conforms {conforms}\nshacl results {results}\n"
            )),
            "{err}"
        );
        assert_eq!(err.contains(line), flagged, "{name}: {err}");

        let sarif = run(&["validate", "--shapes", &path, "--format", "sarif", &data]);
        let log: purrdf_lex::json::Value = purrdf_lex::json::read(&stdout(&sarif))
            .unwrap_or_else(|error| panic!("{name}: SARIF on stdout: {error}: {}", stderr(&sarif)));
        let notified = log["runs"][0]["invocations"][0]["toolExecutionNotifications"][0]["descriptor"]
            ["id"]
            == "in-minListLength";
        assert_eq!(notified, flagged, "{name}: {log:#}");

        let rules = run(&["rules", "--shapes", &path, "--to", "ntriples", &data]);
        let err = stderr(&rules);
        assert_eq!(code(&rules), 0, "{err}");
        assert!(err.contains("rules inferred 1\n"), "{err}");
        assert_eq!(err.contains(line), flagged, "{name}: {err}");
    }
}

/// A shape rule minting one new focus node every iteration — the per-focus divergence
/// the join-step limit used to stop after re-executing the rule for every earlier focus
/// node each time — is refused by `rules` naming the TERM-GENERATING ROUND limit, with
/// `--max-join-steps` at its default and raised 256-fold out of the way, and writes no
/// graph. The corpus's rule minting a one-character-longer IRI every iteration is refused
/// by an explicit term-generating round ceiling, with join capacity unstated and raised. The
/// counter's neighbour bounded at 1,000 counters completes under the defaults.
#[test]
fn cli_rules_per_focus_divergence_is_refused_by_a_term_limit() {
    let dir = purrdf_testkit::temp_dir!().expect("tempdir");
    let counter = |bound: &str| {
        format!(
            r#"@prefix ex: <http://example.org/ns#> .
@prefix sh: <http://www.w3.org/ns/shacl#> .
ex:c1 a ex:C ; ex:n 1 .
ex:Counter a sh:NodeShape ; sh:targetClass ex:C ;
  sh:rule [ a sh:SPARQLRule ; sh:construct """PREFIX ex: <http://example.org/ns#>
CONSTRUCT {{ ?next a ex:C ; ex:n ?m . $this ex:next ?next . }}
WHERE {{ $this ex:n ?n . {bound} BIND (?n + 1 AS ?m)
        BIND (IRI(CONCAT("http://example.org/ns#c", STR(?m))) AS ?next) }}""" ] .
"#
        )
    };
    let divergent = write_file(dir.path(), "divergent.ttl", &counter(""));
    let bounded = write_file(dir.path(), "bounded.ttl", &counter("FILTER (?n < 1000)"));
    let longer = write_file(
        dir.path(),
        "longer.ttl",
        include_str!("../../../vectors/shacl/af/rules/err-diverging-fresh-term/input.ttl"),
    );
    let rules = |document: &str, extra: &[&str]| {
        let mut args = vec!["rules", "--shapes", document];
        args.extend_from_slice(extra);
        args.extend_from_slice(&["--to", "ntriples", document]);
        run(&args)
    };
    for extra in [&[][..], &["--max-join-steps", "268435456"][..]] {
        let refused = rules(&divergent, extra);
        assert_eq!(code(&refused), 1, "{}", stderr(&refused));
        assert!(
            stderr(&refused).contains(
                "the rules exceeded the term-generating round limit: 16385 rounds inferred a \
                 term the evaluation graph did not hold, past the limit of 16384 (the default)"
            ) && stderr(&refused)
                .trim_end()
                .ends_with("raise the limit with --max-term-generating-rounds"),
            "{}",
            stderr(&refused)
        );
        assert!(
            !stderr(&refused).contains("join-step"),
            "{}",
            stderr(&refused)
        );
        assert!(stdout(&refused).is_empty(), "a refused run writes no graph");

        let mut round_options = extra.to_vec();
        round_options.extend(["--max-term-generating-rounds", "8"]);
        let ceiling = rules(&longer, &round_options);
        assert_eq!(code(&ceiling), 1, "{}", stderr(&ceiling));
        assert!(
            stderr(&ceiling)
                .contains("the rules exceeded the term-generating round limit: 9 rounds"),
            "{}",
            stderr(&ceiling)
        );
        assert!(
            stderr(&ceiling)
                .trim_end()
                .ends_with("raise the limit with --max-term-generating-rounds")
        );
        assert!(
            !stderr(&ceiling).contains("join-step"),
            "{}",
            stderr(&ceiling)
        );
        assert!(stdout(&ceiling).is_empty(), "a refused run writes no graph");
    }
    let completes = rules(&bounded, &[]);
    assert_eq!(code(&completes), 0, "{}", stderr(&completes));
    assert_eq!(stdout(&completes).lines().count(), 3 * 999);
}
