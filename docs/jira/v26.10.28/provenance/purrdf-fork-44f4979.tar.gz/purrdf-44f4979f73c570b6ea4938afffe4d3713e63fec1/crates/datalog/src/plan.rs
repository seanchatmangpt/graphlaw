// SPDX-FileCopyrightText: 2026 Blackcat Informatics® Inc. <paudley@blackcatinformatics.ca>
// SPDX-License-Identifier: MIT OR Apache-2.0 OR MulanPSL-2.0

//! Index selection and plan construction: the consuming type-state pipeline
//! `Parsed → Stratified → Planned → Executable`.
//!
//! The program this pipeline consumes is a [`DlClause`] slice —
//! the crate's one rule representation. Atomic and unquantified conjunctive heads
//! are Datalog; [`Parsed::new`] refuses forms requiring another calculus by name.
//!
//! # Why a type-state pipeline
//!
//! A semi-naive executor may run ONLY a program that has been (a) proven to consist of
//! Datalog clauses, (b) proven stratifiable and (c) join-planned. Encoding that as a doc
//! contract ("call `stratify` first") is fragile: a caller can forget it, or redo it on
//! every call. This module makes an unchecked / unstratified / unplanned program
//! **unrepresentable at the executor boundary** — the executor's only input is an
//! [`Executable`], whose sole constructor chain is
//! `Parsed::new(..)?.stratify()?.plan().into_executable()`. There is no other way to
//! obtain one, so the compiler — not a comment — enforces "check the head form, stratify,
//! plan, then execute".
//!
//! # Consuming transitions, not marker generics
//!
//! Each stage is a DISTINCT type and each transition takes `self` by value, returning
//! the next stage. A `PhantomData<State>` marker bolted onto one shared struct would let
//! a caller name the wrong state or convert between them; distinct types cannot be
//! confused, and a consumed stage is moved-from and unusable, so a stale earlier-stage
//! value can never be fed to a later step.
//!
//! # What each stage memoizes
//!
//! - [`Stratified`] owns the [`stratify`] result lowered into the per-stratum rule
//!   grouping (`strata[k]` = the program-order rule indices of stratum `k`).
//! - [`Planned`] owns a [`RulePlan`] per rule: the positive/negated body partition, the
//!   flat variable slots, the binding-aware sideways-information-passing order, the
//!   guaranteed index shape, the variable/constant kernel shape, the certified cyclic
//!   subplans, and the swap programs that restore authored order. All are static
//!   functions of the rule, hoisted out of every semi-naive round.
//! - [`Executable`] additionally memoizes the head-predicate set (the IDB-derivable
//!   predicates) a completion frontier reads.
//!
//! Term and partition resolution is deliberately NOT hoisted here: a
//! [`TermId`](crate::id::TermId) and a [`PartitionId`](crate::id::PartitionId) are per-store handles minted
//! at load/derivation time in insertion order, so they are meaningless against a store
//! that does not yet exist at plan time. That is why a constant position lowers to its
//! lexical SURFACE and not to an id. The plan is store-independent; resolving ids here
//! would be unsound, not an optimisation.
//!
//! # Determinism
//!
//! Every associative structure on this path is a `BTreeMap`/`BTreeSet`, and every
//! remaining choice is broken by an explicit total order (authored position, then
//! lexical name). No hash map participates, so a plan is a pure function of the rule
//! program and, when supplied explicitly, immutable snapshot statistics. The same
//! rules and statistical inputs compile to the same plan on every target.

use purrdf_lex::allocation::{Admission, Memory, OrderedTable, Resident, StorageError};
use std::collections::{BTreeMap, BTreeSet};
use std::sync::Arc;

use crate::binding_pattern::BindingPattern;
use crate::clause::{ClauseAtom, ClauseTerm, DlClause, NonDatalogClause};
use crate::dictionary::TermIdentity;
use crate::guard::Negation;
#[cfg(test)]
use crate::id::TermId;
use crate::paths::relax_strata;
use crate::seminaive::RuleRuntime;
use crate::store::{Arity, Bound, StoreShape};

// ── Stratification ──────────────────────────────────────────────────────────────

/// The stratification symbol standing for a VARIABLE predicate position.
///
/// A predicate is data ([`ClauseAtom`]), so an atom may quantify over it — and then the
/// atom names no single relation: it reads, or derives into, every one of them. Such a
/// position is keyed by this symbol. `*` is not a term surface (an IRI renders as `<…>`
/// and a literal as `"…"`), so it cannot collide with a constant predicate's key.
pub const ANY_PREDICATE: &str = "*";

/// The stratification symbol of `atom`'s predicate position.
///
/// A constant predicate is keyed by its LEXICAL SURFACE — the same bytes the store keys
/// its partitions by, so a stratum key and a relation key are the same string. A variable
/// predicate is keyed by [`ANY_PREDICATE`].
pub fn predicate_symbol<const N: usize>(atom: &ClauseAtom<N>) -> String {
    atom.predicate()
        .surface()
        .unwrap_or_else(|| ANY_PREDICATE.to_owned())
}

/// Assign every predicate of `rules` a stratum, or report the program non-stratifiable.
///
/// A clause's head predicate must sit at or above the stratum of every predicate its body
/// reads, and STRICTLY above every predicate it reads NEGATIVELY. That is what makes
/// negation-as-failure well defined: a negated atom is only ever evaluated against a
/// relation that has already reached its fixpoint.
///
/// This is total over the whole [`DlClause`] IR, not just over its Datalog fragment: a
/// clause contributes one dependency edge per head ATOM — over every conjunct of every
/// disjunct — because a disjunctive head may derive any of its disjuncts and deriving one
/// derives every conjunct in it. An inconsistency clause (whose head is `false`) has no
/// head atom, derives nothing, and so contributes no edge at all. For the atomic form —
/// the only one this crate evaluates — that is exactly the one head predicate, so the edge
/// set is unchanged by the head's nesting.
///
/// # A variable predicate is a wildcard, and it is coupled conservatively
///
/// A predicate position may be a variable, and then the atom names no relation in
/// particular: it is keyed by [`ANY_PREDICATE`] and coupled to every concrete predicate by
/// edges added ONCE rather than by expanding the wildcard into every symbol:
///
/// * a variable predicate in a BODY reads every relation, so the wildcard is pushed to or
///   above every concrete predicate (`* ← p` for each `p`);
/// * a variable predicate in a HEAD derives into every relation, so every concrete
///   predicate is pushed to or above the wildcard (`p ← *` for each `p`).
///
/// A program with both — OWL 2 RL is exactly that shape — therefore collapses every
/// predicate into one stratum, which is sound: it is a single positive stratum for a
/// positive program, and it refuses any program that also negates, because a negated read
/// of a relation something else might derive into has no stratification. Refusing there is
/// the conservative answer, and it is a refusal by the same rule as any other negative
/// edge in a cycle, not a special case.
///
/// The assignment is a Bellman-Ford-style relaxation over the dependency edges: `n`
/// passes suffice for a stratifiable program over `n` predicates, and one further pass
/// that still relaxes proves a negative edge sits inside a cycle. `None` means exactly
/// that — a declared gap, not a failure to try harder.
///
/// The predicate set is gathered through a `BTreeSet` and the edges are a `Vec` in
/// program order, so the relaxation sequence — and therefore the result — is a pure
/// function of the rule program.
pub fn stratify<const N: usize>(rules: &[DlClause<N>]) -> Option<BTreeMap<String, usize>> {
    let graph = DependencyGraph::new_in(rules, &mut Memory::new(&mut Resident))
        .expect("resident dependency construction requires physical storage");
    stratify_dependencies(&graph)
}

fn stratify_dependencies(graph: &DependencyGraph) -> Option<BTreeMap<String, usize>> {
    let mut stratum: BTreeMap<String, usize> = graph
        .predicates
        .iter()
        .map(|p| (p.clone(), 0usize))
        .collect();

    // Still relaxing after n + 1 passes ⇒ a negative edge sits in a cycle.
    let settled = relax_strata(
        &mut stratum,
        || {
            graph.edges.iter().map(|edge| {
                (
                    graph.predicates[edge.head].as_str(),
                    graph.predicates[edge.body].as_str(),
                    edge.negative,
                )
            })
        },
        |levels, predicate| levels[*predicate],
        |levels, predicate, level| {
            *levels
                .get_mut(*predicate)
                .expect("an original dependency predicate") = level;
        },
        Some(graph.predicates.len()),
    );
    settled.then_some(stratum)
}

/// The predicate symbols of `rules` and the dependency edges
/// `(head symbol, body symbol, negative?)` over them, in program order.
///
/// [`stratify`] relaxes over these edges and
/// [`negative_cycle`](crate::seminaive::compile) searches the same graph for the cycle it
/// names, so both are derived from ONE function: a diagnostic that searched a smaller
/// graph than the decision was taken over could fail to find the cycle it was told exists.
/// That includes the wildcard coupling edges a variable predicate position adds.
pub(crate) fn dependency_edges<const N: usize>(
    rules: &[DlClause<N>],
) -> (BTreeSet<String>, Vec<(String, String, bool)>) {
    dependency_edges_with(rules, |_, head, body, negative| (head, body, negative))
}

/// The original dependency walk, with each authored edge's producing rule.
/// Wildcard coupling is graph structure rather than an authored rule and has no index.
pub(crate) fn dependency_edges_with<T, const N: usize>(
    rules: &[DlClause<N>],
    mut edge: impl FnMut(Option<usize>, String, String, bool) -> T,
) -> (BTreeSet<String>, Vec<T>) {
    let graph = DependencyGraph::new_in(rules, &mut Memory::new(&mut Resident))
        .expect("resident dependency construction requires physical storage");
    let edges = graph
        .edges
        .into_iter()
        .map(|dependency| {
            edge(
                dependency.rule,
                graph.predicates[dependency.head].clone(),
                graph.predicates[dependency.body].clone(),
                dependency.negative,
            )
        })
        .collect();
    (graph.predicates.into_iter().collect(), edges)
}

/// Original authored dependency coordinates, including explicit wildcard coupling.
#[derive(Debug)]
pub(crate) struct DependencyEdge {
    pub(crate) rule: Option<usize>,
    pub(crate) head: usize,
    pub(crate) body: usize,
    pub(crate) negative: bool,
}

/// One dependency walk shared by stratification, diagnostics and maintenance.
#[derive(Debug)]
pub(crate) struct DependencyGraph {
    pub(crate) predicates: Vec<String>,
    pub(crate) edges: Vec<DependencyEdge>,
}

fn predicate_surface_in<A: Admission + ?Sized, const N: usize>(
    atom: &ClauseAtom<N>,
    memory: &mut Memory<'_, A>,
) -> Result<String, StorageError> {
    if let Some(surface) = atom.predicate().surface_in(memory)? {
        return Ok(surface);
    }
    memory.scope(|memory| {
        let mut surface = String::new();
        memory.push_str(&mut surface, ANY_PREDICATE)?;
        Ok(surface)
    })
}

fn retain_predicate<A: Admission + ?Sized, const N: usize>(
    atom: &ClauseAtom<N>,
    predicates: &mut OrderedTable<String, ()>,
    memory: &mut Memory<'_, A>,
) -> Result<bool, StorageError> {
    let symbol = predicate_surface_in(atom, memory)?;
    let wildcard = symbol == ANY_PREDICATE;
    if predicates.get(&symbol).is_some() {
        memory.release_string(symbol)?;
    } else {
        predicates.insert(symbol, (), memory)?;
    }
    Ok(wildcard)
}

fn predicate_index<A: Admission + ?Sized, const N: usize>(
    atom: &ClauseAtom<N>,
    predicates: &[String],
    memory: &mut Memory<'_, A>,
) -> Result<usize, StorageError> {
    let symbol = predicate_surface_in(atom, memory)?;
    let index = predicates
        .binary_search(&symbol)
        .expect("an authored predicate was gathered");
    memory.release_string(symbol)?;
    Ok(index)
}

impl DependencyGraph {
    pub(crate) fn new_in<A: Admission + ?Sized, const N: usize>(
        rules: &[DlClause<N>],
        memory: &mut Memory<'_, A>,
    ) -> Result<Self, StorageError> {
        memory.scope(|memory| {
            let mut names = OrderedTable::default();
            let mut wildcard_head = false;
            let mut wildcard_body = false;
            for rule in rules {
                for atom in rule.head_atoms() {
                    wildcard_head |= retain_predicate(atom, &mut names, memory)?;
                }
                for atom in rule
                    .body()
                    .iter()
                    .chain(rule.negations().iter().flat_map(Negation::atoms))
                {
                    wildcard_body |= retain_predicate(atom, &mut names, memory)?;
                }
            }
            let mut predicates = Vec::new();
            memory.reserve(&mut predicates, names.len())?;
            while let Some((symbol, ())) = names.pop_first() {
                predicates.push(symbol);
            }
            names.release(memory)?;
            let mut edges = Vec::new();
            for (rule_index, rule) in rules.iter().enumerate() {
                for atom in rule.head_atoms() {
                    let head = predicate_index(atom, &predicates, memory)?;
                    for body in rule.body() {
                        let body_index = predicate_index(body, &predicates, memory)?;
                        memory.push(
                            &mut edges,
                            DependencyEdge {
                                rule: Some(rule_index),
                                head,
                                body: body_index,
                                negative: body.is_negated(),
                            },
                        )?;
                    }
                    // A negated conjunction reads every member negatively.
                    for body in rule.negations().iter().flat_map(Negation::atoms) {
                        let body = predicate_index(body, &predicates, memory)?;
                        memory.push(
                            &mut edges,
                            DependencyEdge {
                                rule: Some(rule_index),
                                head,
                                body,
                                negative: true,
                            },
                        )?;
                    }
                }
            }
            if wildcard_body || wildcard_head {
                let wildcard = predicates
                    .iter()
                    .position(|symbol| symbol == ANY_PREDICATE)
                    .expect("an authored wildcard was gathered");
                for symbol in 0..predicates.len() {
                    if symbol == wildcard {
                        continue;
                    }
                    if wildcard_body {
                        memory.push(
                            &mut edges,
                            DependencyEdge {
                                rule: None,
                                head: wildcard,
                                body: symbol,
                                negative: false,
                            },
                        )?;
                    }
                    if wildcard_head {
                        memory.push(
                            &mut edges,
                            DependencyEdge {
                                rule: None,
                                head: symbol,
                                body: wildcard,
                                negative: false,
                            },
                        )?;
                    }
                }
            }
            Ok(Self { predicates, edges })
        })
    }
}

// ── Index selection ─────────────────────────────────────────────────────────────

/// The guaranteed index shape at one point in the planned execution order.
///
/// Runtime values are resolved to store-local term ids only when the atom is scanned,
/// but WHICH columns are bound is a plan-time property: by the time this atom runs, the
/// sideways-information-passing order has already bound the named positions.
///
/// This is the arity-2 face of the crate's adornment lattice — see
/// [`pattern`](Self::pattern) — specialised to the store's `(subject, object)` columns,
/// so the index choice is a single `Copy` tag on the hot path rather than a bitset
/// re-derived per tuple.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub enum IndexChoice {
    /// Neither column bound: a full scan of the relation.
    Any,
    /// Subject bound: gallop the sorted subject column.
    Subject,
    /// Object bound: walk the lazily-built `(object, subject)` permutation.
    Object,
    /// Both columns bound: at most one row, since the key is unique.
    Both,
}

impl IndexChoice {
    /// This index shape as an arity-2 [`BindingPattern`]: position 0 is the subject,
    /// position 1 the object.
    ///
    /// The adornment codes are `"ff"`, `"bf"`, `"fb"` and `"bb"` respectively — the same
    /// lattice a backward magic-sets demand is keyed by, so an index shape and a demand
    /// adornment are comparable values rather than two vocabularies kept in sync by
    /// hand.
    pub fn pattern(self) -> BindingPattern {
        let bound: &[usize] = match self {
            Self::Any => &[],
            Self::Subject => &[0],
            Self::Object => &[1],
            Self::Both => &[0, 1],
        };
        BindingPattern::from_bound_positions(2, bound.iter().copied())
    }

    /// The index shape an arity-2 adornment describes.
    ///
    /// # Panics
    ///
    /// Panics unless `pattern` has arity 2: a binary relation's index shape is not
    /// defined for any other arity, and silently truncating a wider adornment would
    /// select the wrong access path.
    pub fn from_pattern(pattern: BindingPattern) -> Self {
        assert_eq!(
            pattern.arity(),
            2,
            "an index choice is an arity-2 adornment over (subject, object)"
        );
        match (pattern.is_bound(0), pattern.is_bound(1)) {
            (false, false) => Self::Any,
            (true, false) => Self::Subject,
            (false, true) => Self::Object,
            (true, true) => Self::Both,
        }
    }

    /// Lower this plan-time shape to a runtime store [`Bound`], given the interned ids of
    /// whichever positions the shape says are bound.
    ///
    /// `None` means a bound position's term is NOT interned in the store being probed,
    /// so nothing can match it and the caller short-circuits to the empty selection.
    /// That is the same probe-miss semantics
    /// [`RelationStore::term_id`](crate::store::RelationStore::term_id) defines,
    /// expressed once here rather than at every call site.
    pub fn bound<I: TermIdentity>(self, subject: Option<I>, object: Option<I>) -> Option<Bound<I>> {
        match self {
            Self::Any => Some(Bound::Any),
            Self::Subject => subject.map(Bound::Subject),
            Self::Object => object.map(Bound::Object),
            Self::Both => match (subject, object) {
                (Some(s), Some(o)) => Some(Bound::Both(s, o)),
                _ => None,
            },
        }
    }
}

/// Whether a term's value is already known at this point in the execution order: a
/// constant always is, a variable only once something has bound it.
fn term_is_known(term: &ClauseTerm, bound: &BTreeSet<String>) -> bool {
    match term {
        ClauseTerm::Var(variable) => bound.contains(variable),
        ClauseTerm::Iri(_) | ClauseTerm::Literal(_) | ClauseTerm::DefaultGraph => true,
    }
}

/// Record every variable of `atom` as bound: the atom has been scanned, so ALL of its
/// positions carry values from here on — including a variable predicate, which the
/// partition key binds, and a variable graph.
fn bind_atom_variables<const N: usize>(atom: &ClauseAtom<N>, bound: &mut BTreeSet<String>) {
    for term in atom.terms() {
        if let ClauseTerm::Var(variable) = term {
            bound.insert(variable.clone());
        }
    }
}

/// Whether two of `atom`'s positions hold the SAME variable — an equality filter the atom
/// carries on its own, over any pair of its stored positions.
fn atom_has_repeated_variable<const N: usize>(atom: &ClauseAtom<N>) -> bool {
    let terms = atom.terms();
    (0..terms.len()).any(|left| {
        ((left + 1)..terms.len()).any(|right| match (terms[left], terms[right]) {
            (ClauseTerm::Var(left), ClauseTerm::Var(right)) => left == right,
            _ => false,
        })
    })
}

/// Static selectivity of one atom at the current binding frontier.
///
/// A shared bound VARIABLE connects the atom to the current join; a shared constant
/// does not. Connectivity takes precedence over known-position, constant and repeated-
/// variable counts, so a selective disconnected atom cannot force a cross product while
/// a connected atom remains. All stored positions participate, including predicate and, for quads, graph.
fn atom_priority<const N: usize>(
    atom: &ClauseAtom<N>,
    bound: &BTreeSet<String>,
    estimate: &impl Fn(&ClauseAtom<N>) -> Option<purrdf_core::StatisticCount>,
) -> (bool, usize, usize, usize, u64) {
    let connected = atom
        .terms()
        .into_iter()
        .any(|term| matches!(term, ClauseTerm::Var(variable) if bound.contains(variable)));
    let known = atom
        .terms()
        .into_iter()
        .filter(|term| term_is_known(term, bound))
        .count();
    let constants = atom
        .terms()
        .into_iter()
        .filter(|term| !term.is_var())
        .count();
    (
        connected,
        known,
        constants,
        usize::from(atom_has_repeated_variable(atom)),
        estimate(atom).map_or(0, |count| u64::MAX - count.value),
    )
}

/// The one binding-aware selection loop for ordinary atoms and certified join groups.
///
/// The priority includes a unique authored coordinate as its last component. Each choice
/// extends the binding frontier before the next choice; no store history participates.
fn binding_aware_order<T, P: Ord>(
    mut remaining: Vec<T>,
    mut bound: BTreeSet<String>,
    priority: impl Fn(&T, &BTreeSet<String>) -> P,
    bind: impl Fn(&T, &mut BTreeSet<String>),
) -> Vec<T> {
    let mut order = Vec::with_capacity(remaining.len());
    while !remaining.is_empty() {
        let slot = remaining
            .iter()
            .enumerate()
            .max_by_key(|&(_, item)| priority(item, &bound))
            .expect("a non-empty remaining set has a best item")
            .0;
        let item = remaining.remove(slot);
        bind(&item, &mut bound);
        order.push(item);
    }
    order
}

/// Guard-produced variables cannot occur before their producer: scoping would reject
/// the overwrite. They can therefore be marked known for planning when barriers keep
/// every atom in its authored stage. Execution still checks the actual bound value.
fn guard_bound_variables<const N: usize>(rule: &DlClause<N>) -> BTreeSet<String> {
    if rule.guard_positions().is_some() {
        rule.guards()
            .iter()
            .flat_map(crate::guard::Guard::outputs)
            .cloned()
            .collect()
    } else {
        BTreeSet::new()
    }
}

/// The stage containing an authored atom; multiple guards may separate two atoms.
fn body_stage<const N: usize>(rule: &DlClause<N>, body_index: usize) -> usize {
    rule.guard_positions().map_or(0, |positions| {
        positions.partition_point(|&after| after <= body_index)
    })
}

/// Deterministic sideways-information-passing order for an acyclic positive body.
///
/// Connected atoms run first; ties retain the known/constant/repeated-variable preference
/// then available statistical counts and authored position. After a choice, all
/// of its variables become bound.
fn sips_order<const N: usize>(
    rule: &DlClause<N>,
    positive: &[usize],
    estimate: &impl Fn(&ClauseAtom<N>) -> Option<purrdf_core::StatisticCount>,
) -> Vec<usize> {
    binding_aware_order(
        (0..positive.len()).collect(),
        guard_bound_variables(rule),
        |&position, bound| {
            let (connected, known, constants, repeated, statistical) =
                atom_priority(&rule.body()[positive[position]], bound, estimate);
            (
                std::cmp::Reverse(body_stage(rule, positive[position])),
                connected,
                known,
                constants,
                repeated,
                statistical,
                usize::MAX - position,
            )
        },
        |&position, bound| bind_atom_variables(&rule.body()[positive[position]], bound),
    )
}

// ── Lowered operators ───────────────────────────────────────────────────────────

/// Argument position 0 of an atom: the subject.
pub const POSITION_SUBJECT: usize = 0;
/// Argument position 1 of an atom: the predicate — a TERM, which may be a variable.
pub const POSITION_PREDICATE: usize = 1;
/// Argument position 2 of an atom: the object.
pub const POSITION_OBJECT: usize = 2;
/// Argument position 3 of an atom: the graph.
pub const POSITION_GRAPH: usize = 3;
/// The number of argument positions in the default quad shape.
pub const ATOM_ARITY: usize = 4;

/// The statically selected shape of ONE argument position.
///
/// Term-kind dispatch happens once, here: the tuple loop never re-interprets a term enum,
/// never re-renders a constant surface, and never looks a variable up by name.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum PositionPlan {
    /// A constant, rendered once to the exact lexical surface the store interns.
    Constant(String),
    /// A variable already bound when this atom runs — READ this frame slot.
    Bound(usize),
    /// A variable this atom binds — WRITE this frame slot.
    Free(usize),
}

impl PositionPlan {
    /// The frame slot of a variable position, or `None` for a constant.
    pub fn slot(&self) -> Option<usize> {
        match self {
            Self::Bound(slot) | Self::Free(slot) => Some(*slot),
            Self::Constant(_) => None,
        }
    }

    /// The lexical surface of a constant position, or `None` for a variable.
    pub fn constant(&self) -> Option<&str> {
        match self {
            Self::Constant(surface) => Some(surface),
            Self::Bound(_) | Self::Free(_) => None,
        }
    }

    /// Whether this position's value is known before the atom is scanned — a constant, or
    /// a variable an earlier atom already bound. This is the position's ADORNMENT bit.
    pub fn is_known(&self) -> bool {
        matches!(self, Self::Constant(_) | Self::Bound(_))
    }
}

/// One positive atom lowered to a plan over its statically selected positions.
///
/// The subject and object positions drive the arrangement's `(subject, object)` index; the
/// predicate and graph positions address the store PARTITION. Both are the same kind of
/// plan value, because the predicate is a term like any other: nothing here privileges it.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct AtomShape<const N: usize = 4> {
    /// The RDF positions in subject, predicate, object, then optional quad graph order.
    positions: [PositionPlan; N],
    /// Body read authority, outside the RDF coordinates.
    source: crate::clause::ReadSource,
    /// Position pairs `(left, right)` with `left < right` that hold the SAME variable, in
    /// ascending order. A row matches only where those positions agree — the general form
    /// of the repeated-variable diagonal filter, over any pair of the four positions
    /// (`T(?p, ?p, ?o, ?g)` is as much a self-join as `p(?x, ?x)` is).
    equalities: Box<[(usize, usize)]>,
}

impl AtomShape<4> {
    /// The graph position's plan.
    pub fn graph(&self) -> &PositionPlan {
        &self.positions[POSITION_GRAPH]
    }
}

impl<const N: usize> AtomShape<N> {
    /// The immutable relation selected by this body atom.
    pub const fn read_source(&self) -> crate::clause::ReadSource {
        self.source
    }

    /// The stored position plans, with a fourth graph plan only for quad atoms.
    pub fn positions(&self) -> &[PositionPlan; N] {
        &self.positions
    }

    /// The subject position's plan.
    pub fn subject(&self) -> &PositionPlan {
        &self.positions[POSITION_SUBJECT]
    }

    /// The predicate position's plan.
    pub fn predicate(&self) -> &PositionPlan {
        &self.positions[POSITION_PREDICATE]
    }

    /// The object position's plan.
    pub fn object(&self) -> &PositionPlan {
        &self.positions[POSITION_OBJECT]
    }

    /// The position pairs that must agree for a row to match.
    pub fn equalities(&self) -> &[(usize, usize)] {
        &self.equalities
    }

    /// This atom's static-arity adornment: bound where the position's value is known before the
    /// scan, free where the scan binds it.
    ///
    /// The same [`BindingPattern`] lattice a backward magic-sets demand is keyed by, now
    /// over the whole atom rather than over the indexed columns alone — so
    /// `"bbbb"` is a fully ground probe and `"fbfb"` is the constant-predicate,
    /// constant-graph shape almost every authored rule has.
    pub fn adornment(&self) -> BindingPattern {
        BindingPattern::from_bools(self.positions.iter().map(PositionPlan::is_known))
    }

    /// Whether this atom addresses exactly ONE store partition — its predicate and graph
    /// are known before the scan; a triple partition has only a predicate.
    ///
    /// This is the plan-time statement of the performance contract: an atom for which this
    /// holds reaches its arrangement through one ordered-map probe and then uses the very
    /// same `(subject, object)` index it always did. Only an atom for which it does NOT
    /// hold sweeps partitions.
    pub fn addresses_one_partition(&self) -> bool {
        self.predicate().is_known()
            && self
                .positions
                .get(POSITION_GRAPH)
                .is_none_or(PositionPlan::is_known)
    }
}

/// The plan for one argument position: its slot if it is a variable, its rendered surface
/// if it is a constant, and whether an earlier atom already bound it.
fn position_plan(
    term: &ClauseTerm,
    bound: &BTreeSet<String>,
    slots: &BTreeMap<String, usize>,
) -> PositionPlan {
    match term {
        ClauseTerm::Var(name) => {
            let slot = slots[name];
            if bound.contains(name) {
                PositionPlan::Bound(slot)
            } else {
                PositionPlan::Free(slot)
            }
        }
        constant => PositionPlan::Constant(constant.surface().unwrap_or_else(|| {
            unreachable!("a non-variable clause term always has a lexical surface: {constant:?}")
        })),
    }
}

/// The shape of `atom` against the variables bound before it runs.
fn atom_shape<const N: usize>(
    atom: &ClauseAtom<N>,
    bound: &BTreeSet<String>,
    slots: &BTreeMap<String, usize>,
) -> AtomShape<N> {
    let terms = atom.terms();
    let positions = std::array::from_fn(|position| position_plan(terms[position], bound, slots));
    let mut equalities = Vec::new();
    for left in 0..N {
        for right in (left + 1)..N {
            if let (ClauseTerm::Var(left_name), ClauseTerm::Var(right_name)) =
                (terms[left], terms[right])
                && left_name == right_name
            {
                equalities.push((left, right));
            }
        }
    }
    AtomShape {
        source: atom.read_source(),
        positions,
        equalities: equalities.into_boxed_slice(),
    }
}

/// The guaranteed index shape of a lowered atom: the `(subject, object)` face of its
/// adornment, read off the SHAPE rather than re-derived from the clause, so the
/// index tag and the adornment cannot drift apart.
///
/// Only those two positions take part: the predicate and graph positions choose the
/// PARTITION, and the partition's arrangement is what the index is built over. That split
/// is why an atom with a free predicate keeps the very same subject/object index it would
/// have had with a constant one — it just applies it once per partition.
fn index_choice<const N: usize>(shape: &AtomShape<N>) -> IndexChoice {
    IndexChoice::from_pattern(BindingPattern::from_bools([
        shape.subject().is_known(),
        shape.object().is_known(),
    ]))
}

/// A positive atom lowered to a body coordinate plus its statically-selected shape.
///
/// Runtime binding presence still selects the concrete store bound (through
/// [`IndexChoice::bound`]), but variable-name and term-enum interpretation is absent from
/// the tuple loop entirely.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct AtomOperator<const N: usize = 4> {
    /// Index into the rule's authored body.
    body_index: usize,
    /// Index within the rule's positive-atom sequence.
    positive_position: usize,
    /// The guaranteed `(subject, object)` index shape at this point in the execution order.
    index: IndexChoice,
    /// The statically selected shape of all stored positions.
    shape: AtomShape<N>,
}

impl<const N: usize> AtomOperator<N> {
    /// Index into the rule's authored body.
    pub fn body_index(&self) -> usize {
        self.body_index
    }

    /// Index within the rule's positive-atom sequence.
    pub fn positive_position(&self) -> usize {
        self.positive_position
    }

    /// The guaranteed `(subject, object)` index shape at this point in the execution order.
    pub fn index(&self) -> IndexChoice {
        self.index
    }

    /// The statically selected shape of all stored positions.
    pub fn shape(&self) -> &AtomShape<N> {
        &self.shape
    }
}

/// Lower every positive atom, in execution order, to its operator — computing each
/// atom's index shape and position plans against exactly the variables bound before it
/// runs.
fn lower_operators<const N: usize>(
    rule: &DlClause<N>,
    positive: &[usize],
    execution_order: &[usize],
    slots: &BTreeMap<String, usize>,
) -> Vec<AtomOperator<N>> {
    let mut bound = guard_bound_variables(rule);
    let mut operators = Vec::with_capacity(execution_order.len());
    for &positive_position in execution_order {
        let body_index = positive[positive_position];
        let atom = &rule.body()[body_index];
        let shape = atom_shape(atom, &bound, slots);
        operators.push(AtomOperator {
            body_index,
            positive_position,
            index: index_choice(&shape),
            shape,
        });
        bind_atom_variables(atom, &mut bound);
    }
    operators
}

/// Precompute a minimal deterministic swap program from physical execution order back to
/// authored positive-body order.
///
/// The executor applies these swaps directly to each completed solution, so restoring
/// authored provenance order costs no per-solution permutation allocation.
fn restore_body_order_swaps(execution_order: &[usize]) -> Vec<(usize, usize)> {
    let mut current = execution_order.to_vec();
    let mut swaps = Vec::new();
    for wanted in 0..current.len() {
        let position = current
            .iter()
            .position(|&value| value == wanted)
            .expect("physical groups cover every positive atom exactly once");
        if position != wanted {
            current.swap(wanted, position);
            swaps.push((wanted, position));
        }
    }
    debug_assert!(current.iter().copied().eq(0..current.len()));
    swaps
}

// ── Cyclic certification ────────────────────────────────────────────────────────

/// One positive atom together with both of its stable coordinates.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct PlannedAtom {
    /// Index into the rule's authored body.
    body_index: usize,
    /// Index within the rule's positive-atom sequence.
    positive_position: usize,
}

impl PlannedAtom {
    /// Index into the rule's authored body.
    pub fn body_index(self) -> usize {
        self.body_index
    }

    /// Index within the rule's positive-atom sequence.
    pub fn positive_position(self) -> usize {
        self.positive_position
    }
}

/// A planner-certified cyclic component, lowered to the multiway (leapfrog) kernel.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct CyclicPlan {
    /// The component's atoms, in authored positive-body order.
    atoms: Vec<PlannedAtom>,
    /// The deterministic variable order the trie join descends: structural degree
    /// descending, then first authored occurrence, then lexical name.
    variables: Vec<String>,
    /// The same order lowered to the rule's flat binding slots.
    variable_slots: Vec<usize>,
}

impl CyclicPlan {
    /// The component's atoms, in authored positive-body order.
    pub fn atoms(&self) -> &[PlannedAtom] {
        &self.atoms
    }

    /// The deterministic variable order the trie join descends.
    pub fn variables(&self) -> &[String] {
        &self.variables
    }

    /// The same order lowered to the rule's flat binding slots.
    pub fn variable_slots(&self) -> &[usize] {
        &self.variable_slots
    }
}

/// One physical group in a rule's positive join.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum JoinGroup {
    /// The indexed binary operator for one atom.
    Binary(PlannedAtom),
    /// One certified cyclic component evaluated as a multiway leapfrog join.
    Leapfrog(CyclicPlan),
}

impl JoinGroup {
    /// The group's atoms, in authored positive-body order.
    fn atoms(&self) -> &[PlannedAtom] {
        match self {
            Self::Binary(atom) => std::slice::from_ref(atom),
            Self::Leapfrog(plan) => plan.atoms(),
        }
    }
}

/// Apply the same binding frontier to binary atoms and whole certified cycles.
///
/// A group connects when ANY member shares a bound variable. Its best member supplies
/// the remaining selectivity preferences, and its earliest authored atom breaks ties.
/// Selecting a cycle binds all of its variables without changing its internal descent.
fn sips_group_order<const N: usize>(
    rule: &DlClause<N>,
    groups: Vec<JoinGroup>,
    estimate: &impl Fn(&ClauseAtom<N>) -> Option<purrdf_core::StatisticCount>,
) -> Vec<JoinGroup> {
    binding_aware_order(
        groups,
        guard_bound_variables(rule),
        |group, bound| {
            let atoms = group.atoms();
            let (connected, known, constants, repeated, statistical) = atoms
                .iter()
                .map(|atom| atom_priority(&rule.body()[atom.body_index], bound, estimate))
                .max()
                .expect("a join group contains at least one atom");
            (
                std::cmp::Reverse(body_stage(rule, atoms[0].body_index)),
                connected,
                known,
                constants,
                repeated,
                statistical,
                usize::MAX - atoms[0].positive_position,
            )
        },
        |group, bound| {
            for atom in group.atoms() {
                bind_atom_variables(&rule.body()[atom.body_index], bound);
            }
        },
    )
}

/// A disjoint-set forest over variable nodes, with path halving and union by size.
///
/// Hand-rolled rather than pulled from a graph crate: it is a dozen lines, it must build
/// for every target this crate supports, and the component identity it produces is
/// deliberately not read out of it — see [`certified_cyclic_components`], which keys
/// components by their smallest node so that nothing observable depends on which element
/// the forest happened to make a representative.
#[derive(Debug)]
struct UnionFind {
    /// `parent[i]` is `i`'s parent, or `i` itself for a root.
    parent: Vec<usize>,
    /// Subtree size per root, for union by size.
    size: Vec<usize>,
}

impl UnionFind {
    /// A forest of `n` singleton sets.
    fn new(n: usize) -> Self {
        Self {
            parent: (0..n).collect(),
            size: vec![1; n],
        }
    }

    /// The representative of `x`'s set, halving the path on the way up.
    fn find(&mut self, mut x: usize) -> usize {
        while self.parent[x] != x {
            self.parent[x] = self.parent[self.parent[x]];
            x = self.parent[x];
        }
        x
    }

    /// Merge the sets of `a` and `b`.
    fn union(&mut self, a: usize, b: usize) {
        let (mut ra, mut rb) = (self.find(a), self.find(b));
        if ra == rb {
            return;
        }
        if self.size[ra] < self.size[rb] {
            core::mem::swap(&mut ra, &mut rb);
        }
        self.parent[rb] = ra;
        self.size[ra] += self.size[rb];
    }
}

/// The bridges of an undirected graph: the edges whose removal disconnects their
/// component — equivalently, exactly the edges that lie on NO cycle.
///
/// Tarjan's discovery/low-link search, iterative rather than recursive so a pathological
/// rule cannot overflow a small stack. `edges[e] = (u, v)`; the returned ids index that
/// slice. Adjacency is built in edge order, so the traversal — and therefore the answer —
/// is a pure function of the input.
fn bridge_edges(node_count: usize, edges: &[(usize, usize)]) -> BTreeSet<usize> {
    let mut adjacency: Vec<Vec<(usize, usize)>> = vec![Vec::new(); node_count];
    for (id, &(u, v)) in edges.iter().enumerate() {
        adjacency[u].push((v, id));
        adjacency[v].push((u, id));
    }

    /// Sentinel discovery time for a node the search has not reached.
    const UNVISITED: usize = usize::MAX;
    let mut discovery = vec![UNVISITED; node_count];
    let mut low = vec![0usize; node_count];
    let mut timer = 0usize;
    let mut bridges = BTreeSet::new();

    for start in 0..node_count {
        if discovery[start] != UNVISITED {
            continue;
        }
        discovery[start] = timer;
        low[start] = timer;
        timer += 1;
        // Each frame is (node, the edge id it was entered by, the next adjacency slot).
        let mut stack: Vec<(usize, Option<usize>, usize)> = vec![(start, None, 0)];
        while let Some(&(node, entered_by, slot)) = stack.last() {
            if slot < adjacency[node].len() {
                stack.last_mut().expect("the frame just observed").2 += 1;
                let (next, edge) = adjacency[node][slot];
                // Skip only the exact edge the node was entered by, never every edge to
                // the parent: parallel edges between two nodes are never bridges.
                if Some(edge) == entered_by {
                    continue;
                }
                if discovery[next] == UNVISITED {
                    discovery[next] = timer;
                    low[next] = timer;
                    timer += 1;
                    stack.push((next, Some(edge), 0));
                } else {
                    low[node] = low[node].min(discovery[next]);
                }
            } else {
                stack.pop();
                if let Some(&(parent, _, _)) = stack.last() {
                    low[parent] = low[parent].min(low[node]);
                    if low[node] > discovery[parent] {
                        bridges.insert(entered_by.expect("a child frame has an entering edge"));
                    }
                }
            }
        }
    }
    bridges
}

/// Certify the positive-body cycle components eligible for a multiway join.
///
/// Each atom with two DISTINCT variable positions contributes one undirected variable
/// edge. Duplicate pairs are collapsed before the graph analysis: two relations over the
/// same `(X, Y)` edge are an acyclic intersection, not a two-edge cycle. Removing every
/// bridge leaves exactly the edges that participate in a simple cycle, and their
/// connected components are the subplans safe to promote. Constants, repeated variables,
/// trees and bridge atoms therefore all stay binary.
///
/// # Only a single-partition atom is eligible
///
/// An atom whose predicate or graph is a VARIABLE denotes a union of arrangements, not one
/// of them, and a trie level is one sorted arrangement — a leapfrog seek has nothing to
/// seek over until the partition is fixed. Such an atom contributes no edge here and stays
/// on the indexed binary path, which handles it by sweeping partitions. This is a
/// certification rule, not a shortfall: the multiway kernel's precondition is a single
/// trie, and an atom that does not name one does not meet it.
///
/// Components are keyed by their SMALLEST variable node, so the emitted order depends on
/// the (lexically ordered) variable numbering alone and never on a disjoint-set forest's
/// internal choice of representative.
fn certified_cyclic_components<const N: usize>(
    rule: &DlClause<N>,
    positive: &[usize],
    slots: &BTreeMap<String, usize>,
) -> Vec<CyclicPlan> {
    let mut edge_atoms: BTreeMap<(String, String), Vec<PlannedAtom>> = BTreeMap::new();
    let mut first_occurrence: BTreeMap<String, usize> = BTreeMap::new();
    let mut occurrence = 0usize;

    for (positive_position, &body_index) in positive.iter().enumerate() {
        let planned = PlannedAtom {
            body_index,
            positive_position,
        };
        let atom = &rule.body()[body_index];
        for term in [atom.subject(), atom.object()] {
            if let ClauseTerm::Var(var) = term {
                first_occurrence.entry(var.clone()).or_insert(occurrence);
                occurrence += 1;
            }
        }
        if atom.predicate().is_var()
            || atom
                .terms()
                .get(POSITION_GRAPH)
                .is_some_and(|term| term.is_var())
        {
            // Not a single trie level — see the doc comment.
            continue;
        }
        let (ClauseTerm::Var(left), ClauseTerm::Var(right)) = (atom.subject(), atom.object())
        else {
            continue;
        };
        if left == right {
            continue;
        }
        let edge = if left < right {
            (left.clone(), right.clone())
        } else {
            (right.clone(), left.clone())
        };
        edge_atoms.entry(edge).or_default().push(planned);
    }

    // A simple undirected cycle needs at least three distinct edges.
    if edge_atoms.len() < 3 {
        return Vec::new();
    }

    let variable_names: Vec<String> = edge_atoms
        .keys()
        .flat_map(|(left, right)| [left.clone(), right.clone()])
        .collect::<BTreeSet<_>>()
        .into_iter()
        .collect();
    let variable_id: BTreeMap<&str, usize> = variable_names
        .iter()
        .enumerate()
        .map(|(id, name)| (name.as_str(), id))
        .collect();

    let edge_keys: Vec<(String, String)> = edge_atoms.keys().cloned().collect();
    let edges: Vec<(usize, usize)> = edge_keys
        .iter()
        .map(|(left, right)| (variable_id[left.as_str()], variable_id[right.as_str()]))
        .collect();

    let bridge_ids = bridge_edges(variable_names.len(), &edges);
    let mut union = UnionFind::new(variable_names.len());
    for (id, &(left, right)) in edges.iter().enumerate() {
        if bridge_ids.contains(&id) {
            continue;
        }
        union.union(left, right);
    }

    // Group the surviving (cycle) edges by component, keyed by the component's smallest
    // node, so the emitted order is a function of the lexical variable order alone.
    let mut component_key: BTreeMap<usize, usize> = BTreeMap::new();
    for (id, &(left, _)) in edges.iter().enumerate() {
        if bridge_ids.contains(&id) {
            continue;
        }
        let root = union.find(left);
        let key = component_key.entry(root).or_insert(left);
        *key = (*key).min(left);
    }
    let mut component_edges: BTreeMap<usize, Vec<usize>> = BTreeMap::new();
    for (id, &(left, _)) in edges.iter().enumerate() {
        if bridge_ids.contains(&id) {
            continue;
        }
        let root = union.find(left);
        component_edges
            .entry(component_key[&root])
            .or_default()
            .push(id);
    }

    let mut plans = Vec::new();
    for ids in component_edges.into_values() {
        // A simple undirected cycle has at least three unique edges. This also makes the
        // duplicate-pair exclusion explicit at the promotion boundary.
        if ids.len() < 3 {
            continue;
        }
        let mut atoms = Vec::new();
        let mut degree: BTreeMap<String, usize> = BTreeMap::new();
        for id in ids {
            let key = &edge_keys[id];
            atoms.extend(edge_atoms[key].iter().copied());
            *degree.entry(key.0.clone()).or_default() += 1;
            *degree.entry(key.1.clone()).or_default() += 1;
        }
        atoms.sort_by_key(|atom| atom.positive_position);
        let mut variables: Vec<String> = degree.keys().cloned().collect();
        variables.sort_by(|left, right| {
            degree[right]
                .cmp(&degree[left])
                .then_with(|| first_occurrence[left].cmp(&first_occurrence[right]))
                .then_with(|| left.cmp(right))
        });
        let variable_slots = variables.iter().map(|variable| slots[variable]).collect();
        plans.push(CyclicPlan {
            atoms,
            variables,
            variable_slots,
        });
    }
    plans
}

// ── The per-rule plan ───────────────────────────────────────────────────────────

/// The cyclic-only physical sidecar.
///
/// Boxed so the overwhelmingly common acyclic [`RulePlan`] carries one null pointer
/// instead of two more slices: selective multiway joining must not tax the binary
/// majority's resident plan footprint.
#[derive(Debug, Clone, PartialEq, Eq)]
struct HybridPlan {
    /// The physical positive-join groups, in execution order.
    join_groups: Box<[JoinGroup]>,
    /// Swaps restoring the cyclic execution order to authored order.
    source_order_swaps: Box<[(usize, usize)]>,
}

/// A per-rule precomputed join plan.
///
/// This is the store-independent relational-algebra plan: body partition, flat binding
/// frame, sideways-information-passing order, index and term-shape kernels, certified
/// cyclic groups, and the swap programs that restore authored provenance order.
/// Store-local term ids remain runtime values, but which columns are bound and which
/// concrete kernel consumes them are decided here, once.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct RulePlan<const N: usize = 4> {
    /// Body indices of the POSITIVE atoms, in body order (the join drivers).
    positive: Box<[usize]>,
    /// Body indices of the NEGATED atoms, in body order (the negation filters).
    negated: Box<[usize]>,
    /// Variable names in authored first-occurrence order; the executor stores bindings
    /// in a flat frame indexed by these slots.
    variables: Box<[String]>,
    /// One statically-shaped operator per positive body atom, in physical execution
    /// order. Each retains its authored positive position for provenance restoration.
    operators: Box<[AtomOperator<N>]>,
    /// In-place swaps restoring positive-source provenance from physical execution order
    /// to authored body order.
    operator_source_order_swaps: Box<[(usize, usize)]>,
    /// Present only for a structurally-certified cyclic rule.
    hybrid: Option<Box<HybridPlan>>,
}

impl<const N: usize> RulePlan<N> {
    /// Plan one rule.
    ///
    /// The body is partitioned into positive (join) and negated (filter) atoms,
    /// preserving body order; variables are assigned flat slots in authored
    /// first-occurrence order across the body and then every head ATOM, disjunct by
    /// disjunct and conjunct by conjunct, and within an atom in
    /// `(subject, predicate, object, graph)` position order. Body-first preserves the
    /// join's natural binding order, and including the head gives diagnostics a complete
    /// rule layout without changing the positive operators. For the atomic head this crate
    /// evaluates, "the head atoms" is the one head atom.
    pub(crate) fn for_rule(rule: &DlClause<N>) -> Self {
        Self::for_rule_with_estimates(rule, &|_| None)
    }

    fn for_rule_with_estimates(
        rule: &DlClause<N>,
        estimate: &impl Fn(&ClauseAtom<N>) -> Option<purrdf_core::StatisticCount>,
    ) -> Self {
        let mut positive = Vec::new();
        let mut negated = Vec::new();
        for (i, atom) in rule.body().iter().enumerate() {
            if atom.is_negated() {
                negated.push(i);
            } else {
                positive.push(i);
            }
        }

        let mut variables = Vec::new();
        let mut slots = BTreeMap::new();
        let mut assign = |name: &String| {
            if !slots.contains_key(name) {
                let slot = variables.len();
                variables.push(name.clone());
                slots.insert(name.clone(), slot);
            }
        };
        for atom in rule.body() {
            for term in atom.terms() {
                if let ClauseTerm::Var(name) = term {
                    assign(name);
                }
            }
        }
        // A guard output is a body binding like any other, so it takes a frame slot
        // after the atoms and before the head: the head reads it exactly as it reads a
        // join binding. A negated conjunction's own variables are existentially
        // quantified inside the group and never reach the frame.
        for guard in rule.guards() {
            for output in guard.outputs() {
                assign(output);
            }
        }
        for atom in rule.head_atoms() {
            for term in atom.terms() {
                if let ClauseTerm::Var(name) = term {
                    assign(name);
                }
            }
        }

        // A simple undirected cycle requires at least three positive edges. Avoid all
        // graph and planned-atom scratch for the very common 0/1/2-atom rules.
        let cyclic = if positive.len() < 3 {
            Vec::new()
        } else if let Some(barriers) = rule.guard_positions() {
            let mut plans = Vec::new();
            let mut start = 0;
            for end in barriers
                .iter()
                .copied()
                .chain(std::iter::once(positive.len()))
            {
                let mut segment = certified_cyclic_components(rule, &positive[start..end], &slots);
                for plan in &mut segment {
                    for atom in &mut plan.atoms {
                        atom.positive_position += start;
                    }
                }
                plans.extend(segment);
                start = end;
            }
            plans
        } else {
            certified_cyclic_components(rule, &positive, &slots)
        };

        if cyclic.is_empty() {
            let execution_order = sips_order(rule, &positive, estimate);
            let operators = lower_operators(rule, &positive, &execution_order, &slots);
            let operator_source_order_swaps = restore_body_order_swaps(&execution_order);
            return Self {
                positive: positive.into_boxed_slice(),
                negated: negated.into_boxed_slice(),
                variables: variables.into_boxed_slice(),
                operators: operators.into_boxed_slice(),
                operator_source_order_swaps: operator_source_order_swaps.into_boxed_slice(),
                hybrid: None,
            };
        }

        // Map every promoted atom to its owning component. Components are edge-disjoint
        // after bridge removal, so one atom belongs to at most one of them.
        let mut component_of: Vec<Option<usize>> = vec![None; rule.body().len()];
        for (component, plan) in cyclic.iter().enumerate() {
            for atom in &plan.atoms {
                component_of[atom.body_index] = Some(component);
            }
        }

        // Emit a component at its first authored atom and skip its later atoms; any
        // non-cycle atom stays a binary group at its own authored position.
        let mut cyclic: Vec<Option<CyclicPlan>> = cyclic.into_iter().map(Some).collect();
        let mut join_groups = Vec::new();
        for (positive_position, &body_index) in positive.iter().enumerate() {
            let atom = PlannedAtom {
                body_index,
                positive_position,
            };
            match component_of[atom.body_index] {
                Some(component) => {
                    if let Some(plan) = cyclic[component].take() {
                        join_groups.push(JoinGroup::Leapfrog(plan));
                    }
                }
                None => join_groups.push(JoinGroup::Binary(atom)),
            }
        }

        let join_groups = sips_group_order(rule, join_groups, estimate);
        let execution_source_order: Vec<usize> = join_groups
            .iter()
            .flat_map(|group| group.atoms().iter().map(|atom| atom.positive_position))
            .collect();
        let source_order_swaps = restore_body_order_swaps(&execution_source_order);
        let operators = lower_operators(rule, &positive, &execution_source_order, &slots);
        let operator_source_order_swaps = restore_body_order_swaps(&execution_source_order);
        Self {
            positive: positive.into_boxed_slice(),
            negated: negated.into_boxed_slice(),
            variables: variables.into_boxed_slice(),
            operators: operators.into_boxed_slice(),
            operator_source_order_swaps: operator_source_order_swaps.into_boxed_slice(),
            hybrid: Some(Box::new(HybridPlan {
                join_groups: join_groups.into_boxed_slice(),
                source_order_swaps: source_order_swaps.into_boxed_slice(),
            })),
        }
    }

    /// The positive body-atom indices, in body order.
    pub fn positive(&self) -> &[usize] {
        &self.positive
    }

    /// The negated body-atom indices, in body order.
    pub fn negated(&self) -> &[usize] {
        &self.negated
    }

    /// The stable slot-to-variable table for the rule's physical binding frame.
    pub fn variables(&self) -> &[String] {
        &self.variables
    }

    /// The prelowered positive atom operators, in physical execution order.
    pub fn operators(&self) -> &[AtomOperator<N>] {
        &self.operators
    }

    /// The operator for one authored positive-body coordinate.
    ///
    /// # Panics
    ///
    /// Panics if `positive_position` is not a positive coordinate of this rule.
    pub fn operator_at(&self, positive_position: usize) -> &AtomOperator<N> {
        self.operators
            .iter()
            .find(|operator| operator.positive_position == positive_position)
            .expect("every positive atom has exactly one physical operator")
    }

    /// Whether this rule has a planner-certified cyclic positive subplan.
    pub fn has_cyclic_subplan(&self) -> bool {
        self.hybrid.is_some()
    }

    /// The physical positive-join groups, in deterministic execution order.
    ///
    /// # Panics
    ///
    /// Panics unless [`has_cyclic_subplan`](Self::has_cyclic_subplan): an acyclic rule
    /// allocates no group sidecar at all, and fabricating one here would erase the
    /// distinction the type exists to make.
    pub fn join_groups(&self) -> &[JoinGroup] {
        &self
            .hybrid
            .as_ref()
            .expect("join groups exist only for a certified cyclic plan")
            .join_groups
    }

    /// In-place swaps restoring physical operator order to authored body order.
    pub fn operator_source_order_swaps(&self) -> &[(usize, usize)] {
        &self.operator_source_order_swaps
    }

    /// Source restoration for the cyclic groups' physical execution order.
    ///
    /// # Panics
    ///
    /// Panics unless [`has_cyclic_subplan`](Self::has_cyclic_subplan).
    pub fn hybrid_source_order_swaps(&self) -> &[(usize, usize)] {
        &self
            .hybrid
            .as_ref()
            .expect("hybrid source swaps exist only for a cyclic plan")
            .source_order_swaps
    }
}

// ── The type-state pipeline ─────────────────────────────────────────────────────

/// Stage 1: a parsed rule program, not yet stratified.
///
/// Owns the rules behind an [`Arc`], so the terminal executable can be shared across
/// calls without borrowing a caller's scratch buffer.
#[derive(Debug, Clone)]
pub struct Parsed<const N: usize = 4> {
    admission: Option<Arc<crate::admission::NeverDeriveCertificate>>,
    /// The program, in authored order.
    rules: Arc<[DlClause<N>]>,
}

impl<const N: usize> Parsed<N> {
    /// Admit the complete clause IR under every supplied declaration source.
    /// # Errors
    /// Returns exact admission or ordinary Datalog fragment refusal.
    pub fn with_declarations(
        rules: Vec<DlClause<N>>,
        declarations: &crate::admission::NeverDeriveDeclarations,
    ) -> Result<Self, crate::seminaive::EvalError> {
        let certificate = declarations
            .admit(&rules)
            .map_err(crate::seminaive::EvalError::NeverDerive)?;
        let mut parsed =
            Self::new(rules).map_err(|error| crate::seminaive::EvalError::NonDatalogHead {
                rule: error.clause(),
                form: error.form(),
            })?;
        parsed.admission = Some(Arc::new(certificate));
        Ok(parsed)
    }

    /// Enter the pipeline with a parsed rule program, or refuse a clause the semi-naive
    /// evaluator has no semantics for.
    ///
    /// This is the head-form gate, and it sits here — at the pipeline's ONLY entrance —
    /// rather than at the executor, because that is what makes the refusal unbypassable:
    /// an [`Executable`] is reachable only through this constructor, so a value of that
    /// type is a proof that every clause in it is
    /// atomic or conjunctive without existential variables, on top of the
    /// stratification and planning proofs the later stages add.
    ///
    /// # Errors
    ///
    /// [`NonDatalogClause`], naming the first clause in authored order whose head is
    /// existential, disjunctive or `false`. Such a clause needs a different calculus;
    /// accepting or dropping it would not compute the supplied program's model.
    pub fn new(rules: Vec<DlClause<N>>) -> Result<Self, NonDatalogClause> {
        for (index, rule) in rules.iter().enumerate() {
            let form = rule.head_form();
            if !form.is_datalog() {
                return Err(NonDatalogClause::new(index, form));
            }
        }
        Ok(Self {
            rules: Arc::from(rules),
            admission: None,
        })
    }

    /// Compute the stratification ONCE and lower it into the per-stratum rule grouping.
    ///
    /// `None` means the program is non-stratifiable — a negative dependency edge inside a
    /// cycle. That is a declared gap the caller reports; there is no fallback engine and
    /// no partial answer.
    ///
    /// A rule runs at its lowest head-predicate stratum; within a stratum the
    /// authored program order is preserved, so rules fire in a stable order.
    pub fn stratify(self) -> Option<Stratified<N>> {
        let dependencies = Arc::new(
            DependencyGraph::new_in(&self.rules, &mut Memory::new(&mut Resident))
                .expect("resident dependency construction requires physical storage"),
        );
        let stratum_of = stratify_dependencies(&dependencies)?;

        let max_stratum = self
            .rules
            .iter()
            .flat_map(DlClause::head_atoms)
            .map(|head| stratum_of[&predicate_symbol(head)])
            .max()
            .unwrap_or(0);
        let mut strata: Vec<Vec<usize>> = vec![Vec::new(); max_stratum + 1];
        for (i, rule) in self.rules.iter().enumerate() {
            // Every head depends on the same body. The lowest head stratum is
            // already late enough for all body reads. Higher-stratum heads may
            // be emitted early, but settle only after all their producers run.
            let level = rule
                .head_atoms()
                .map(|head| stratum_of[&predicate_symbol(head)])
                .min()
                .expect("admitted Datalog clauses have a nonempty head");
            strata[level].push(i);
        }

        let mut settled_predicates = vec![Vec::new(); max_stratum + 1];
        let heads: BTreeSet<_> = self
            .rules
            .iter()
            .flat_map(DlClause::head_atoms)
            .map(predicate_symbol)
            .collect();
        for predicate in heads {
            settled_predicates[stratum_of[&predicate]].push(predicate);
        }
        Some(Stratified {
            dependencies,
            settled_predicates,
            admission: self.admission,
            rules: self.rules,
            strata,
        })
    }
}

/// Stage 2: a stratifiable program with its per-stratum rule grouping memoized.
#[derive(Debug, Clone)]
pub struct Stratified<const N: usize = 4> {
    dependencies: Arc<DependencyGraph>,
    /// Predicates complete after each stratum, independent of early head emission.
    settled_predicates: Vec<Vec<String>>,
    admission: Option<Arc<crate::admission::NeverDeriveCertificate>>,
    /// The program, in authored order.
    rules: Arc<[DlClause<N>]>,
    /// `strata[k]` = the program-order indices of stratum `k`'s rules.
    strata: Vec<Vec<usize>>,
}

impl<const N: usize> Stratified<N> {
    /// Precompute one complete store-independent [`RulePlan`] per rule.
    pub fn plan(self) -> Planned<N> {
        self.plan_with_estimates(&|_| None)
    }

    /// Plan with immutable RDF snapshot statistics as a connected-order tie-break.
    /// The caller resolves each atom into the provider's own identity space;
    /// no RDF identity is stored in the resulting executable or remapped at joins.
    /// Unknown estimates preserve authored ordering. Connectivity and existing
    /// binding preferences take precedence, and proof sources retain authored order.
    /// Estimates select an order; they are never output or allocation certificates.
    pub fn plan_with_statistics<I: purrdf_core::ViewTermId>(
        self,
        statistics: &dyn purrdf_core::SnapshotStatistics<I>,
        probe: impl Fn(&ClauseAtom<N>) -> Option<purrdf_core::ProbePattern<I>>,
    ) -> Planned<N> {
        self.plan_with_estimates(&|atom| statistics.pattern(probe(atom)?))
    }

    fn plan_with_estimates(
        self,
        estimate: &impl Fn(&ClauseAtom<N>) -> Option<purrdf_core::StatisticCount>,
    ) -> Planned<N> {
        let plans = self
            .rules
            .iter()
            .map(|rule| RulePlan::for_rule_with_estimates(rule, estimate))
            .collect();
        Planned {
            dependencies: self.dependencies,
            settled_predicates: self.settled_predicates,
            admission: self.admission,
            rules: self.rules,
            strata: self.strata,
            plans,
        }
    }
}

/// Stage 3: a stratified program with its per-rule join plans memoized.
#[derive(Debug, Clone)]
pub struct Planned<const N: usize = 4> {
    dependencies: Arc<DependencyGraph>,
    /// Predicates complete after each stratum.
    settled_predicates: Vec<Vec<String>>,
    admission: Option<Arc<crate::admission::NeverDeriveCertificate>>,
    /// The program, in authored order.
    rules: Arc<[DlClause<N>]>,
    /// `strata[k]` = the program-order indices of stratum `k`'s rules.
    strata: Vec<Vec<usize>>,
    /// One entry per rule, parallel to `rules` by index.
    plans: Vec<RulePlan<N>>,
}

impl<const N: usize> Planned<N> {
    /// Seal the plan into the terminal [`Executable`], preparing immutable rule shapes
    /// once and memoizing the head-predicate set a completion frontier reads.
    pub fn into_executable(self) -> Executable<N>
    where
        Arity<N>: StoreShape<N>,
    {
        let head_predicates: BTreeSet<String> = self
            .rules
            .iter()
            .flat_map(DlClause::head_atoms)
            .map(predicate_symbol)
            .collect();
        let runtimes = self
            .rules
            .iter()
            .zip(&self.plans)
            .map(|(rule, plan)| RuleRuntime::new(rule, plan))
            .collect::<Arc<[_]>>();
        let mut rule_levels = vec![0; self.rules.len()];
        for (level, rules) in self.strata.iter().enumerate() {
            for &rule in rules {
                rule_levels[rule] = level;
            }
        }
        let program_hash = crate::cache::canonical_rule_hash(&self.rules);
        let base_read_rule = self.rules.iter().position(DlClause::reads_base);
        Executable {
            dependencies: self.dependencies,
            rule_levels: Arc::from(rule_levels),
            program_hash,
            base_read_rule,
            settled_predicates: self.settled_predicates,
            admission: self.admission,
            rules: self.rules,
            strata: self.strata,
            plans: self.plans,
            head_predicates,
            runtimes,
        }
    }
}

/// Stage 4 (terminal): a fully stratified, join-planned program.
///
/// The SOLE input type of a semi-naive executor. Its fields are private and its only
/// constructor is [`Planned::into_executable`], so a value of this type is a proof that
/// the program was stratified (stage 1 → 2) and planned (stage 2 → 3).
#[derive(Debug, Clone)]
pub struct Executable<const N: usize = 4>
where
    Arity<N>: StoreShape<N>,
{
    /// Immutable analysis and identity belong to the compiled program, never a
    /// per-model copy or a supplemental grant adopting existing allocation.
    pub(crate) dependencies: Arc<DependencyGraph>,
    pub(crate) rule_levels: Arc<[usize]>,
    pub(crate) program_hash: [u8; 32],
    pub(crate) base_read_rule: Option<usize>,
    /// Predicates complete after each stratum.
    settled_predicates: Vec<Vec<String>>,
    admission: Option<Arc<crate::admission::NeverDeriveCertificate>>,
    /// The program, in authored order.
    rules: Arc<[DlClause<N>]>,
    /// `strata[k]` = the program-order indices of stratum `k`'s rules.
    strata: Vec<Vec<usize>>,
    /// One entry per rule, parallel to `rules` by index.
    plans: Vec<RulePlan<N>>,
    /// The IDB-derivable (rule-head) predicates, in lexical order.
    head_predicates: BTreeSet<String>,
    /// Immutable lowered shapes shared by executions and clones of this program.
    /// Pending round keys may borrow authored constants here for the program's lifetime.
    runtimes: Arc<[RuleRuntime<N>]>,
}

impl<const N: usize> Executable<N>
where
    Arity<N>: StoreShape<N>,
{
    /// The same prepared rule metadata for every evaluation of this immutable program.
    pub(crate) fn runtimes(&self) -> &[RuleRuntime<N>] {
        &self.runtimes
    }

    /// Every declaration source admitted with this immutable program.
    #[must_use]
    pub fn declarations(&self) -> Option<&crate::admission::NeverDeriveDeclarations> {
        self.admission
            .as_deref()
            .map(crate::admission::NeverDeriveCertificate::declarations)
    }

    crate::admission::program_declarations!();

    /// The number of strata (a completion frontier's total).
    pub fn stratum_count(&self) -> usize {
        self.strata.len()
    }

    /// The number of rules, so an executor can size a per-rule side table by index
    /// instead of discovering the index space by sweeping every stratum.
    pub fn rule_count(&self) -> usize {
        self.rules.len()
    }

    /// The immutable authored program, including its original clause order.
    pub fn rules(&self) -> &[DlClause<N>] {
        &self.rules
    }

    /// Whether stratum `k` has no rules (a trivially-saturated empty stratum).
    ///
    /// # Panics
    ///
    /// Panics if `k` is not a stratum of this program.
    pub fn stratum_is_empty(&self, k: usize) -> bool {
        self.strata[k].is_empty()
    }

    /// The IDB-derivable (rule-head) predicate SYMBOLS — the ones settled only when their
    /// stratum completes, and therefore excluded from a pure-EDB seed frontier.
    ///
    /// A constant head predicate contributes its lexical surface, which is the same string
    /// the store keys its partitions by. A rule whose head predicate is a VARIABLE derives
    /// into a relation named by data, so it contributes [`ANY_PREDICATE`]: the set then
    /// says, truthfully, that no finite list of predicates bounds what this program
    /// derives — see [`Self::derives_any_predicate`].
    pub fn head_predicates(&self) -> &BTreeSet<String> {
        &self.head_predicates
    }

    /// Whether some rule's head predicate is a variable, so [`Self::head_predicates`] is
    /// not an exhaustive list of what the program can derive.
    pub fn derives_any_predicate(&self) -> bool {
        self.head_predicates.contains(ANY_PREDICATE)
    }

    /// The program-order rule indices assigned to stratum `k`.
    ///
    /// Exposing the immutable index slice lets an executor drive an INDEXED parallel
    /// iterator while preserving program order at the deterministic merge boundary.
    ///
    /// # Panics
    ///
    /// Panics if `k` is not a stratum of this program.
    pub fn stratum_rule_indices(&self, k: usize) -> &[usize] {
        &self.strata[k]
    }

    /// Resolve one rule index to its immutable rule and precomputed plan.
    ///
    /// # Panics
    ///
    /// Panics if `index` is not a rule of this program.
    pub fn rule_entry(&self, index: usize) -> (&DlClause<N>, &RulePlan<N>) {
        (&self.rules[index], &self.plans[index])
    }

    /// Head predicate SYMBOLS that become complete at stratum `k`, recorded into
    /// the settled frontier when it reaches its natural fixpoint. See
    /// [`Self::head_predicates`] for what a variable head predicate contributes.
    ///
    /// # Panics
    ///
    /// Panics if `k` is not a stratum of this program.
    pub fn stratum_head_predicates(&self, k: usize) -> impl Iterator<Item = String> {
        self.settled_predicates[k].iter().cloned()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::clause::{HeadDisjunct, HeadForm};
    use crate::test_support::permute;

    const P: &str = "https://example.org/p";
    const Q: &str = "https://example.org/q";
    const R: &str = "https://example.org/r";

    #[test]
    fn guard_barriers_constrain_sips_and_bind_later_index_positions() {
        use crate::clause::BodyLiteral::{Atom, Guard as Compute};
        use crate::guard::Guard;
        let rule = DlClause::datalog(atom("?X", R, "?V"), Vec::new()).with_ordered_body(vec![
            Atom(atom("?X", P, "?Y")),
            Compute(Guard::assign("key", vec!["?Y".into()], "?K")),
            Atom(atom("?K", Q, "?V")),
        ]);
        let plan = RulePlan::for_rule(&rule);
        assert_eq!(
            plan.operators()
                .iter()
                .map(AtomOperator::body_index)
                .collect::<Vec<_>>(),
            [0, 1],
            "a selective later atom cannot cross its producing guard",
        );
        assert!(matches!(
            plan.operator_at(1).shape().subject(),
            PositionPlan::Bound(_)
        ));
    }

    #[test]
    fn cycles_are_certified_within_guard_segments_only() {
        use crate::clause::BodyLiteral::{Atom, Guard as Compute};
        use crate::guard::Guard;
        let program = |crosses| {
            let mut body = vec![Atom(atom("?X", P, "?Y"))];
            if crosses {
                body.push(Compute(Guard::filter("test", vec!["?X".into()])));
            }
            body.extend([Atom(atom("?Y", Q, "?Z")), Atom(atom("?Z", R, "?X"))]);
            if !crosses {
                body.push(Compute(Guard::filter("test", vec!["?X".into()])));
                body.push(Atom(atom("?X", P, "?W")));
            }
            DlClause::datalog(atom("?X", R, "?Z"), Vec::new()).with_ordered_body(body)
        };
        assert!(!RulePlan::for_rule(&program(true)).has_cyclic_subplan());
        assert!(RulePlan::for_rule(&program(false)).has_cyclic_subplan());
    }
    const S: &str = "https://example.org/s";

    fn v(name: &str) -> ClauseTerm {
        ClauseTerm::var(name)
    }

    fn atom(subject: &str, predicate: &str, object: &str) -> ClauseAtom {
        ClauseAtom::positive(v(subject), predicate, v(object))
    }

    /// The lexical surface of an IRI — the predicate SYMBOL a stratum is keyed by.
    fn surface(iri: &str) -> String {
        format!("<{iri}>")
    }

    #[test]
    fn snapshot_statistics_change_connected_order_and_preserve_native_proofs() {
        use crate::store::RelationStore;
        use purrdf_core::{DatasetView, GraphMatch, ProbePattern, RdfDatasetBuilder};

        let rule = DlClause::datalog(
            atom("?x", S, "?q"),
            vec![
                atom("?x", P, "?p"),
                atom("?x", Q, "?q"),
                atom("?u", R, "?v"),
            ],
        );
        let mut builder = RdfDatasetBuilder::new();
        let mut input = RelationStore::new();
        for (predicate, count) in [(P, 5), (Q, 1), (R, 1)] {
            let p = builder.intern_iri(predicate).unwrap();
            for index in 0..count {
                let subject = format!("https://example.org/subject/{index}");
                let object = format!("https://example.org/object/{index}");
                let s = builder.intern_iri(&subject).unwrap();
                let o = builder.intern_iri(&object).unwrap();
                builder.push_quad(s, p, o, None).unwrap();
                input
                    .insert(
                        &surface(&subject),
                        &surface(predicate),
                        &surface(&object),
                        RelationStore::DEFAULT_GRAPH,
                    )
                    .unwrap();
            }
        }
        let dataset = builder.freeze().unwrap();
        let parsed = Parsed::new(vec![rule]).unwrap().stratify().unwrap();
        let ordinary = parsed.clone().plan().into_executable();
        let statistical = parsed
            .plan_with_statistics(dataset.statistics().unwrap(), |atom| {
                Some(ProbePattern {
                    s: None,
                    p: Some(dataset.term_id_by_iri(atom.predicate_iri()?)?),
                    o: None,
                    g: GraphMatch::Default,
                })
            })
            .into_executable();
        let order = |executable: &Executable| {
            executable
                .rule_entry(0)
                .1
                .operators()
                .iter()
                .map(AtomOperator::positive_position)
                .collect::<Vec<_>>()
        };
        assert_eq!(order(&ordinary), [0, 1, 2]);
        // The disconnected one-row atom cannot outrank the connected five-row atom.
        assert_eq!(order(&statistical), [1, 0, 2]);
        let baseline = crate::seminaive::evaluate_guarded(
            &ordinary,
            input.clone(),
            &crate::guard::NoGuards,
            &crate::seminaive::EvalOptions::default()
                .with_derivation_mode(crate::seminaive::DerivationMode::Record),
            None,
        )
        .unwrap();
        let actual = crate::seminaive::evaluate_guarded(
            &statistical,
            input,
            &crate::guard::NoGuards,
            &crate::seminaive::EvalOptions::default()
                .with_derivation_mode(crate::seminaive::DerivationMode::Record),
            None,
        )
        .unwrap();
        assert_eq!(actual.facts().row_count(), baseline.facts().row_count());
        assert_eq!(actual.facts().row_count(), 8);
        assert_eq!(
            actual
                .derivations()
                .expect("derivation recording was requested")
                .len(),
            1
        );
        let proof = &actual
            .derivations()
            .expect("derivation recording was requested")[0];
        assert_eq!(
            proof.fact(),
            baseline
                .derivations()
                .expect("derivation recording was requested")[0]
                .fact()
        );
        assert_eq!(
            proof.sources(),
            baseline
                .derivations()
                .expect("derivation recording was requested")[0]
                .sources()
        );
        assert_eq!(
            proof
                .sources()
                .iter()
                .map(|source| source.predicate.as_str())
                .collect::<Vec<_>>(),
            [surface(P), surface(Q), surface(R)]
        );
    }

    /// The three-atom triangle `p(X,Y), q(Y,Z), r(Z,X)` — the canonical cyclic body.
    fn triangle_body() -> Vec<ClauseAtom> {
        vec![
            atom("?X", P, "?Y"),
            atom("?Y", Q, "?Z"),
            atom("?Z", R, "?X"),
        ]
    }

    fn triangle_rule(body: Vec<ClauseAtom>) -> DlClause {
        DlClause::datalog(atom("?X", S, "?Z"), body)
    }

    #[test]
    fn plan_partitions_the_body_preserving_authored_order() {
        let rule = DlClause::datalog(
            atom("?X", S, "?Z"),
            vec![
                atom("?X", P, "?Y"),
                ClauseAtom::negated(v("?Y"), Q, v("?Z")),
                atom("?Y", R, "?Z"),
            ],
        );
        let plan = RulePlan::for_rule(&rule);
        assert_eq!(plan.positive(), [0, 2]);
        assert_eq!(plan.negated(), [1]);
        assert!(!plan.has_cyclic_subplan());
        assert_eq!(rule.body()[1].subject().variable(), Some("?Y"));
        assert!(!rule.datalog_head().unwrap().is_negated());
    }

    /// Variable slots are authored first-occurrence order across the body, then the head
    /// — a head-only variable still gets a slot, at the end.
    #[test]
    fn plan_assigns_slots_in_authored_first_occurrence_order() {
        let rule = DlClause::datalog(
            ClauseAtom::positive(v("?W"), S, v("?X")),
            vec![atom("?X", P, "?Y"), atom("?Y", Q, "?X")],
        );
        let plan = RulePlan::for_rule(&rule);
        assert_eq!(plan.variables(), ["?X", "?Y", "?W"]);
    }

    /// A constant is bound from the start, so the planner runs the constant-bearing atom
    /// first and every later atom inherits its bindings — the whole point of the
    /// sideways-information-passing order.
    #[test]
    fn plan_sips_runs_the_most_bound_atom_first() {
        let rule = DlClause::datalog(
            atom("?X", S, "?Z"),
            vec![
                atom("?Y", Q, "?Z"),
                ClauseAtom::positive(ClauseTerm::iri("https://example.org/a"), P, v("?Y")),
            ],
        );
        let plan = RulePlan::for_rule(&rule);
        let order: Vec<usize> = plan
            .operators()
            .iter()
            .map(AtomOperator::positive_position)
            .collect();
        assert_eq!(order, [1, 0], "the constant-subject atom drives the join");
        // The driver has a bound subject; the second atom's subject is bound by it.
        assert_eq!(plan.operator_at(1).index(), IndexChoice::Subject);
        assert_eq!(plan.operator_at(0).index(), IndexChoice::Subject);
        assert_eq!(plan.operator_at(1).body_index(), 1);
        let driver = plan.operator_at(1).shape();
        assert_eq!(
            driver.subject(),
            &PositionPlan::Constant("<https://example.org/a>".to_owned())
        );
        // Slots follow AUTHORED body order, not execution order: `?Y` first occurs in
        // body atom 0, so it holds slot 0 even though the atom that binds it runs second.
        assert_eq!(driver.object(), &PositionPlan::Free(0));
        // Restoring authored order is a swap program, applied in place.
        assert_eq!(plan.operator_source_order_swaps(), [(0, 1)]);
    }

    /// The connecting edge must run before another selective type atom. Even sharing
    /// every constant (predicate, class and default graph) does not connect variables.
    #[test]
    fn plan_sips_connects_before_scanning_another_type() {
        for other_class in ["https://example.org/A", "https://example.org/B"] {
            let rule = DlClause::datalog(
                atom("?v", S, "?s"),
                vec![
                    ClauseAtom::positive(v("?v"), P, ClauseTerm::iri("https://example.org/A")),
                    ClauseAtom::positive(v("?s"), P, ClauseTerm::iri(other_class)),
                    atom("?v", Q, "?s"),
                ],
            );
            let plan = RulePlan::for_rule(&rule);
            assert_eq!(
                plan.operators()
                    .iter()
                    .map(AtomOperator::positive_position)
                    .collect::<Vec<_>>(),
                [0, 2, 1],
                "class {other_class}: the edge connects the two type variables"
            );
            assert_eq!(plan.variables(), ["?v", "?s"]);
            assert_eq!(plan.operator_at(2).index(), IndexChoice::Subject);
            assert_eq!(plan.operator_at(1).index(), IndexChoice::Both);
            assert_eq!(plan.operator_source_order_swaps(), [(1, 2)]);
            assert!(!plan.has_cyclic_subplan());
        }
    }

    /// Predicate and graph bindings connect an atom even when its subject/object remain
    /// free and an independent atom has strictly more known constant positions.
    #[test]
    fn plan_sips_connects_through_predicate_and_graph_variables() {
        for (position, connected) in [
            (
                POSITION_PREDICATE,
                ClauseAtom::quad(v("?s"), v("?key"), v("?o"), ClauseTerm::DefaultGraph),
            ),
            (
                POSITION_GRAPH,
                ClauseAtom::quad(v("?s"), ClauseTerm::iri(Q), v("?o"), v("?key")),
            ),
        ] {
            let rule = DlClause::datalog(
                atom("?s", S, "?o"),
                vec![
                    ClauseAtom::positive(
                        v("?key"),
                        P,
                        ClauseTerm::iri("https://example.org/Class"),
                    ),
                    ClauseAtom::positive(
                        v("?independent"),
                        P,
                        ClauseTerm::iri("https://example.org/Class"),
                    ),
                    connected,
                ],
            );
            let plan = RulePlan::for_rule(&rule);
            assert_eq!(
                plan.operators()
                    .iter()
                    .map(AtomOperator::positive_position)
                    .collect::<Vec<_>>(),
                [0, 2, 1],
                "connection in position {position} outranks disconnected constants"
            );
            let shape = plan.operator_at(2).shape();
            assert_eq!(shape.positions()[position], PositionPlan::Bound(0));
            assert_eq!(plan.operator_at(2).index(), IndexChoice::Any);
            assert_eq!(plan.variables(), ["?key", "?independent", "?s", "?o"]);
        }
    }

    /// With no connected choice, the repeated-variable equality still outranks an
    /// otherwise identical shape; the remaining equal shapes retain authored order.
    #[test]
    fn plan_sips_preserves_repetition_and_authored_ties() {
        let rule = DlClause::datalog(
            atom("?X", S, "?Y"),
            vec![
                atom("?X", P, "?Y"),
                atom("?Z", Q, "?Z"),
                atom("?W", R, "?U"),
            ],
        );
        let plan = RulePlan::for_rule(&rule);
        assert_eq!(
            plan.operators()
                .iter()
                .map(AtomOperator::positive_position)
                .collect::<Vec<_>>(),
            [1, 0, 2]
        );
        assert_eq!(plan.operator_at(1).shape().equalities(), [(0, 2)]);
        assert!(!plan.has_cyclic_subplan());
    }

    /// Every subject/object term shape is selected statically, and a fully ground atom
    /// becomes a membership probe with both surfaces rendered once.
    #[test]
    fn plan_lowers_every_position_shape() {
        let a = ClauseTerm::iri("https://example.org/a");
        let lit = ClauseTerm::literal("\"7\"^^<http://www.w3.org/2001/XMLSchema#integer>");
        let rule = DlClause::datalog(
            atom("?X", S, "?Y"),
            vec![
                atom("?X", P, "?Y"),
                ClauseAtom::positive(v("?X"), Q, lit.clone()),
                ClauseAtom::positive(a.clone(), R, v("?Y")),
                ClauseAtom::positive(a, R, lit),
            ],
        );
        let plan = RulePlan::for_rule(&rule);
        let shapes: Vec<&AtomShape> = (0..4).map(|i| plan.operator_at(i).shape()).collect();
        // variable/variable, variable/constant, constant/variable, constant/constant.
        // A variable position lowers to a frame SLOT (bound or free, depending on where
        // the sideways-information-passing order put the atom); a constant lowers to its
        // rendered surface.
        assert!(shapes[0].subject().slot().is_some());
        assert!(shapes[0].object().slot().is_some());
        assert!(shapes[1].subject().slot().is_some());
        assert!(shapes[1].object().constant().is_some());
        assert!(shapes[2].subject().constant().is_some());
        assert!(shapes[2].object().slot().is_some());
        assert_eq!(
            shapes[3].subject(),
            &PositionPlan::Constant("<https://example.org/a>".to_owned())
        );
        assert_eq!(
            shapes[3].object(),
            &PositionPlan::Constant("\"7\"^^<http://www.w3.org/2001/XMLSchema#integer>".to_owned())
        );
        // Every one of them names a CONSTANT predicate and the DEFAULT graph, so every one
        // addresses exactly one partition — the shape an authored rule almost always has.
        for shape in &shapes {
            assert!(shape.addresses_one_partition(), "{shape:?}");
            assert_eq!(
                shape.predicate().constant(),
                Some(shape_predicate(shape)),
                "{shape:?}"
            );
            assert_eq!(shape.graph(), &PositionPlan::Constant(String::new()));
            assert_eq!(shape.equalities(), []);
        }
        assert_eq!(shapes[3].adornment().code(), "bbbb", "a ground probe");
    }

    /// The constant predicate surface a fixture shape carries.
    fn shape_predicate(shape: &AtomShape) -> &str {
        shape
            .predicate()
            .constant()
            .expect("the fixture predicates are constants")
    }

    /// A CONSTANT-PREDICATE atom still selects an index and still addresses exactly one
    /// partition — the performance contract, stated as a plan property rather than as a
    /// stopwatch reading.
    ///
    /// Both facts have to hold together: an atom that reached an index but swept every
    /// partition to do it would have regressed, and so would one that addressed a single
    /// partition and then scanned it.
    #[test]
    fn a_constant_predicate_atom_reaches_an_index_without_sweeping() {
        let rule = DlClause::datalog(
            atom("?X", S, "?Z"),
            vec![atom("?X", P, "?Y"), atom("?Y", Q, "?Z")],
        );
        let plan = RulePlan::for_rule(&rule);
        for (position, predicate) in [P, Q].into_iter().enumerate() {
            let shape = plan.operator_at(position).shape();
            assert!(
                shape.addresses_one_partition(),
                "atom {position} names a constant predicate and the default graph, so it \
                 addresses ONE partition and never sweeps"
            );
            assert_eq!(
                shape.predicate(),
                &PositionPlan::Constant(surface(predicate))
            );
            assert_eq!(shape.graph(), &PositionPlan::Constant(String::new()));
        }
        // The first atom drives (nothing is bound yet), the second is index-selected on
        // the subject `?Y` the first one bound — not a full scan of its partition.
        assert_eq!(plan.operator_at(0).index(), IndexChoice::Any);
        assert_eq!(
            plan.operator_at(1).index(),
            IndexChoice::Subject,
            "the joined atom gallops its subject column"
        );
        assert_eq!(plan.operator_at(1).shape().adornment().code(), "bbfb");

        // A VARIABLE predicate is the only shape that gives the single-partition property
        // up, and it gives up nothing else: the subject/object index is unchanged.
        let variable = DlClause::datalog(
            atom("?X", S, "?Z"),
            vec![
                atom("?X", P, "?Y"),
                ClauseAtom::quad(v("?Y"), v("?W"), v("?Z"), ClauseTerm::DefaultGraph),
            ],
        );
        let variable = RulePlan::for_rule(&variable);
        let swept = variable.operator_at(1).shape();
        assert!(
            !swept.addresses_one_partition(),
            "a free predicate position denotes a union of partitions"
        );
        assert_eq!(swept.predicate(), &PositionPlan::Free(2));
        assert_eq!(
            variable.operator_at(1).index(),
            IndexChoice::Subject,
            "and it still gallops the subject column inside every partition it visits"
        );
        assert_eq!(swept.adornment().code(), "bffb");
    }

    /// An unbound atom is a full scan; once a variable is bound the same atom becomes a
    /// one-column probe; two bound columns is the unique-key probe.
    #[test]
    fn index_choice_tracks_the_binding_frontier() {
        let rule = DlClause::datalog(
            atom("?X", S, "?Z"),
            vec![
                atom("?X", P, "?Y"),
                atom("?X", Q, "?Y"),
                atom("?Y", R, "?Z"),
            ],
        );
        let plan = RulePlan::for_rule(&rule);
        // Two atoms over the same (X, Y) pair are an intersection, never a cycle.
        assert!(!plan.has_cyclic_subplan());
        assert_eq!(plan.operator_at(0).index(), IndexChoice::Any);
        assert_eq!(plan.operator_at(1).index(), IndexChoice::Both);
        assert_eq!(plan.operator_at(2).index(), IndexChoice::Subject);
    }

    /// The index shape and the adornment lattice are one vocabulary: every shape round
    /// trips through its arity-2 pattern, and the codes are the canonical adornments.
    #[test]
    fn index_choice_round_trips_through_the_adornment_lattice() {
        let cases = [
            (IndexChoice::Any, "ff"),
            (IndexChoice::Subject, "bf"),
            (IndexChoice::Object, "fb"),
            (IndexChoice::Both, "bb"),
        ];
        for (choice, code) in cases {
            let pattern = choice.pattern();
            assert_eq!(pattern.code(), code, "{choice:?}");
            assert_eq!(IndexChoice::from_pattern(pattern), choice);
            assert_eq!(BindingPattern::from_code(code), pattern);
        }
        // The lattice order matches the index order: a full scan is the most general
        // shape and the unique-key probe the most specific.
        assert!(
            IndexChoice::Any
                .pattern()
                .subsumes(IndexChoice::Subject.pattern())
        );
        assert!(
            IndexChoice::Subject
                .pattern()
                .subsumes(IndexChoice::Both.pattern())
        );
        assert_eq!(
            IndexChoice::Subject
                .pattern()
                .join(IndexChoice::Object.pattern()),
            IndexChoice::Both.pattern()
        );
        assert_eq!(
            IndexChoice::Subject
                .pattern()
                .meet(IndexChoice::Object.pattern()),
            IndexChoice::Any.pattern()
        );
    }

    #[test]
    #[should_panic(expected = "an index choice is an arity-2 adornment")]
    fn index_choice_rejects_a_non_binary_adornment() {
        let _ = IndexChoice::from_pattern(BindingPattern::from_code("bfb"));
    }

    /// The plan-time shape lowers to a runtime store bound, and a bound position whose
    /// term the store has never interned short-circuits to "no rows".
    #[test]
    fn index_choice_lowers_to_a_store_bound() {
        let s = TermId::from_index(0).unwrap();
        let o = TermId::from_index(1).unwrap();
        assert_eq!(
            IndexChoice::Any.bound::<TermId>(None, None),
            Some(Bound::Any)
        );
        assert_eq!(
            IndexChoice::Subject.bound(Some(s), None),
            Some(Bound::Subject(s))
        );
        assert_eq!(
            IndexChoice::Object.bound(None, Some(o)),
            Some(Bound::Object(o))
        );
        assert_eq!(
            IndexChoice::Both.bound(Some(s), Some(o)),
            Some(Bound::Both(s, o))
        );
        // A missing term on a bound position means the selection is empty.
        assert_eq!(IndexChoice::Subject.bound(None, Some(o)), None);
        assert_eq!(IndexChoice::Both.bound(Some(s), None), None);
        assert_eq!(IndexChoice::Both.bound::<TermId>(None, None), None);
    }

    /// The swap program restores authored order from ANY execution order, in place, and
    /// emits no swap when the order is already authored.
    #[test]
    fn restore_body_order_swaps_is_a_correct_in_place_program() {
        let identity: Vec<usize> = (0..7).collect();
        assert_eq!(restore_body_order_swaps(&identity), [] as [_; 0]);
        for seed in 0..32u64 {
            let order = permute(&identity, seed);
            let swaps = restore_body_order_swaps(&order);
            let mut applied = order;
            for &(a, b) in &swaps {
                applied.swap(a, b);
            }
            assert_eq!(applied, identity, "seed {seed}: order restored");
            assert!(
                swaps.len() < identity.len(),
                "seed {seed}: at most n-1 swaps"
            );
        }
    }

    /// A triangle is certified: one leapfrog group covering all three atoms, with a
    /// deterministic descent order over all three variables.
    #[test]
    fn cyclic_certification_promotes_a_triangle() {
        let rule = triangle_rule(triangle_body());
        let plan = RulePlan::for_rule(&rule);
        assert!(plan.has_cyclic_subplan());
        let groups = plan.join_groups();
        assert_eq!(groups.len(), 1);
        let JoinGroup::Leapfrog(cyclic) = &groups[0] else {
            panic!("the triangle must be promoted to a multiway group");
        };
        assert_eq!(
            cyclic
                .atoms()
                .iter()
                .map(|a| a.positive_position())
                .collect::<Vec<_>>(),
            [0, 1, 2]
        );
        assert_eq!(cyclic.atoms()[0].body_index(), 0);
        assert_eq!(cyclic.variables(), ["?X", "?Y", "?Z"]);
        assert_eq!(cyclic.variable_slots(), [0, 1, 2]);
        assert_eq!(plan.hybrid_source_order_swaps(), []);
    }

    /// A tree (every edge a bridge) is never promoted, and neither is a body whose only
    /// repeated edge is a duplicate variable pair.
    #[test]
    fn cyclic_certification_leaves_acyclic_bodies_binary() {
        let path = DlClause::datalog(
            atom("?X", S, "?W"),
            vec![
                atom("?X", P, "?Y"),
                atom("?Y", Q, "?Z"),
                atom("?Z", R, "?W"),
            ],
        );
        assert!(!RulePlan::for_rule(&path).has_cyclic_subplan());

        // Three atoms but only two distinct variable edges: an intersection, not a cycle.
        let duplicated = DlClause::datalog(
            atom("?X", S, "?Z"),
            vec![
                atom("?X", P, "?Y"),
                atom("?X", Q, "?Y"),
                atom("?Y", R, "?Z"),
            ],
        );
        assert!(!RulePlan::for_rule(&duplicated).has_cyclic_subplan());

        // A self-edge (repeated variable) contributes no graph edge at all.
        let self_edge = DlClause::datalog(
            atom("?X", S, "?Z"),
            vec![
                atom("?X", P, "?X"),
                atom("?X", Q, "?Y"),
                atom("?Y", R, "?Z"),
            ],
        );
        assert!(!RulePlan::for_rule(&self_edge).has_cyclic_subplan());
    }

    /// A bridge atom hanging off a triangle stays a binary group: only the edges on a
    /// cycle are promoted, and the plan still covers every positive atom exactly once.
    #[test]
    fn cyclic_certification_keeps_bridge_atoms_binary() {
        let mut body = triangle_body();
        body.push(atom("?Z", S, "?W"));
        let rule = DlClause::datalog(atom("?X", S, "?W"), body);
        let plan = RulePlan::for_rule(&rule);
        assert!(plan.has_cyclic_subplan());
        let groups = plan.join_groups();
        assert_eq!(groups.len(), 2, "one cycle group plus one bridge atom");
        assert!(matches!(groups[0], JoinGroup::Leapfrog(_)));
        let JoinGroup::Binary(bridge) = &groups[1] else {
            panic!("the bridge atom must stay binary");
        };
        assert_eq!(bridge.positive_position(), 3);
        assert_eq!(bridge.body_index(), 3);
        assert_eq!(plan.operators().len(), 4, "every positive atom is lowered");
    }

    /// Binary bridges and cycles share the binding frontier. Here the first cycle atom
    /// has no bound variable; its later members connect through Z, so the WHOLE group
    /// must outrank the independent type rather than testing only its first atom.
    #[test]
    fn hybrid_sips_connects_bridges_and_any_member_of_a_cycle() {
        let mut body = vec![
            ClauseAtom::positive(v("?V"), P, ClauseTerm::iri("https://example.org/A")),
            ClauseAtom::positive(v("?U"), P, ClauseTerm::iri("https://example.org/B")),
            atom("?V", S, "?Z"),
        ];
        body.extend(triangle_body());
        let plan = RulePlan::for_rule(&triangle_rule(body));
        assert!(plan.has_cyclic_subplan());
        let groups = plan.join_groups();
        assert_eq!(groups.len(), 4);
        assert!(matches!(groups[0], JoinGroup::Binary(atom) if atom.positive_position() == 0));
        assert!(matches!(groups[1], JoinGroup::Binary(atom) if atom.positive_position() == 2));
        assert!(matches!(groups[3], JoinGroup::Binary(atom) if atom.positive_position() == 1));
        let JoinGroup::Leapfrog(cycle) = &groups[2] else {
            panic!("the connected cycle must precede the independent type");
        };
        assert_eq!(
            cycle
                .atoms()
                .iter()
                .map(|atom| (atom.body_index(), atom.positive_position()))
                .collect::<Vec<_>>(),
            [(3, 3), (4, 4), (5, 5)]
        );
        assert_eq!(cycle.variables(), ["?Z", "?X", "?Y"]);
        assert_eq!(cycle.variable_slots(), [2, 3, 4]);
        assert_eq!(plan.variables(), ["?V", "?U", "?Z", "?X", "?Y"]);
        let order: Vec<usize> = plan
            .operators()
            .iter()
            .map(AtomOperator::positive_position)
            .collect();
        assert_eq!(order, [0, 2, 3, 4, 5, 1]);
        assert_eq!(plan.operator_at(2).index(), IndexChoice::Subject);
        assert_eq!(plan.operator_at(3).index(), IndexChoice::Any);
        assert_eq!(plan.operator_at(4).index(), IndexChoice::Both);
        assert_eq!(
            plan.operator_source_order_swaps(),
            plan.hybrid_source_order_swaps()
        );
        let mut restored = order;
        for &(left, right) in plan.hybrid_source_order_swaps() {
            restored.swap(left, right);
        }
        assert_eq!(restored, [0, 1, 2, 3, 4, 5]);
    }

    /// An acyclic plan allocates no group sidecar, and asking for one is a hard error
    /// rather than a fabricated empty answer.
    #[test]
    #[should_panic(expected = "join groups exist only for a certified cyclic plan")]
    fn acyclic_plan_has_no_join_groups() {
        let rule = DlClause::datalog(atom("?X", S, "?Y"), vec![atom("?X", P, "?Y")]);
        let _ = RulePlan::for_rule(&rule).join_groups();
    }

    /// Determinism: certification does not depend on the order the body's edges are
    /// discovered in. Over every permutation of the triangle's atoms the SAME component
    /// is promoted, covering the same atoms over the same variables; only the authored
    /// coordinates move with the atoms.
    #[test]
    fn cyclic_certification_is_independent_of_edge_discovery_order() {
        let body = triangle_body();
        for seed in 0..24u64 {
            let permuted = permute(&body, seed);
            let plan = RulePlan::for_rule(&triangle_rule(permuted));
            assert!(plan.has_cyclic_subplan(), "seed {seed}");
            let groups = plan.join_groups();
            assert_eq!(groups.len(), 1, "seed {seed}");
            let JoinGroup::Leapfrog(cyclic) = &groups[0] else {
                panic!("seed {seed}: the triangle must still be promoted");
            };
            assert_eq!(
                cyclic
                    .atoms()
                    .iter()
                    .map(|a| a.positive_position())
                    .collect::<Vec<_>>(),
                [0, 1, 2],
                "seed {seed}: the component covers every atom, in authored order"
            );
            let mut variables = cyclic.variables().to_vec();
            variables.sort();
            assert_eq!(variables, ["?X", "?Y", "?Z"], "seed {seed}");
            assert_eq!(
                cyclic.variable_slots().len(),
                3,
                "seed {seed}: every descent variable has a frame slot"
            );
        }
    }

    /// Determinism: planning is a pure function of the program. Repeated compilations of
    /// the same rules produce structurally identical plans.
    #[test]
    fn planning_is_reproducible() {
        let rules = [
            triangle_rule(triangle_body()),
            DlClause::datalog(
                atom("?X", Q, "?Y"),
                vec![
                    atom("?X", P, "?Y"),
                    ClauseAtom::negated(v("?Y"), R, v("?X")),
                ],
            ),
        ];
        let reference: Vec<RulePlan> = rules.iter().map(RulePlan::for_rule).collect();
        for _ in 0..8 {
            let again: Vec<RulePlan> = rules.iter().map(RulePlan::for_rule).collect();
            assert_eq!(again, reference, "the same rules always plan identically");
        }
    }

    // ── Stratification and the type-state pipeline ──────────────────────────────

    #[test]
    fn stratify_lifts_a_negated_dependency_one_stratum() {
        // q :- p.   r :- q, not p.
        let rules = vec![
            DlClause::datalog(atom("?X", Q, "?Y"), vec![atom("?X", P, "?Y")]),
            DlClause::datalog(
                atom("?X", R, "?Y"),
                vec![
                    atom("?X", Q, "?Y"),
                    ClauseAtom::negated(v("?X"), P, v("?Y")),
                ],
            ),
        ];
        let strata = stratify(&rules).expect("the program is stratifiable");
        assert_eq!(strata[&surface(P)], 0);
        assert_eq!(strata[&surface(Q)], 0);
        assert_eq!(
            strata[&surface(R)],
            1,
            "a negated read sits strictly below its reader"
        );
    }

    #[test]
    fn stratify_rejects_negation_inside_a_cycle() {
        // p :- not q.   q :- p.  — the negative edge is inside a cycle.
        let rules = vec![
            DlClause::datalog(
                atom("?X", P, "?Y"),
                vec![ClauseAtom::negated(v("?X"), Q, v("?Y"))],
            ),
            DlClause::datalog(atom("?X", Q, "?Y"), vec![atom("?X", P, "?Y")]),
        ];
        assert_eq!(stratify(&rules), None);
    }

    #[test]
    fn stratify_admits_positive_recursion() {
        // Transitive closure: p :- p, p. A positive cycle is one stratum.
        let rules = vec![DlClause::datalog(
            atom("?X", P, "?Z"),
            vec![atom("?X", P, "?Y"), atom("?Y", P, "?Z")],
        )];
        let strata = stratify(&rules).expect("positive recursion is stratifiable");
        assert_eq!(strata[&surface(P)], 0);
    }

    #[test]
    fn stratify_of_an_empty_program_is_empty() {
        assert_eq!(stratify::<4>(&[]), Some(BTreeMap::new()));
    }

    /// The pipeline is the only way to reach an [`Executable`], and it memoizes the
    /// per-stratum grouping, the per-rule plans and the head-predicate set.
    #[test]
    fn pipeline_seals_a_stratified_planned_program() {
        let rules = vec![
            DlClause::datalog(atom("?X", Q, "?Y"), vec![atom("?X", P, "?Y")]),
            DlClause::datalog(
                atom("?X", R, "?Y"),
                vec![
                    atom("?X", Q, "?Y"),
                    ClauseAtom::negated(v("?X"), P, v("?Y")),
                ],
            ),
        ];
        let exe = Parsed::new(rules)
            .expect("every fixture clause has an atomic head")
            .stratify()
            .expect("stratifiable")
            .plan()
            .into_executable();

        assert_eq!(exe.stratum_count(), 2);
        assert_eq!(
            exe.rule_count(),
            2,
            "the rule index space is the authored program, not the stratum grouping"
        );
        assert!(!exe.stratum_is_empty(0));
        assert_eq!(exe.stratum_rule_indices(0), [0]);
        assert_eq!(exe.stratum_rule_indices(1), [1]);
        assert_eq!(
            exe.head_predicates(),
            &[surface(Q), surface(R)].into_iter().collect(),
            "a head predicate symbol is the constant's lexical surface"
        );
        assert!(!exe.derives_any_predicate());
        assert_eq!(
            exe.stratum_head_predicates(1).collect::<Vec<_>>(),
            vec![surface(R)],
            "stratum 1 derives exactly r"
        );
        let (rule, plan) = exe.rule_entry(1);
        assert_eq!(rule.datalog_head().unwrap().predicate_iri(), Some(R));
        assert_eq!(rule.body().len(), 2);
        assert!(rule.body()[1].is_negated());
        assert_eq!(rule.body()[1].object(), &v("?Y"));
        assert_eq!(plan.positive(), [0]);
        assert_eq!(plan.negated(), [1]);
    }

    /// A non-stratifiable program never reaches the executor: the pipeline stops at
    /// stage 1 → 2, and there is no other constructor.
    #[test]
    fn pipeline_refuses_a_non_stratifiable_program() {
        let rules = vec![
            DlClause::datalog(
                atom("?X", P, "?Y"),
                vec![ClauseAtom::negated(v("?X"), Q, v("?Y"))],
            ),
            DlClause::datalog(atom("?X", Q, "?Y"), vec![atom("?X", P, "?Y")]),
        ];
        assert!(
            Parsed::new(rules)
                .expect("every fixture clause has an atomic head")
                .stratify()
                .is_none()
        );
    }

    /// Rules that all land in one stratum keep authored program order within it — the
    /// executor's stable firing order.
    #[test]
    fn pipeline_preserves_program_order_within_a_stratum() {
        let rules: Vec<DlClause> = (0..5)
            .map(|i| {
                DlClause::datalog(
                    atom("?X", P, "?Y"),
                    vec![atom("?X", &format!("https://example.org/b{i}"), "?Y")],
                )
            })
            .collect();
        let exe = Parsed::new(rules)
            .expect("every fixture clause has an atomic head")
            .stratify()
            .expect("stratifiable")
            .plan()
            .into_executable();
        assert_eq!(exe.stratum_count(), 1);
        assert_eq!(exe.stratum_rule_indices(0), [0, 1, 2, 3, 4]);
    }

    /// The pipeline's entrance is the head-form gate: an existential, a disjunctive and
    /// an empty head are each refused by name, so a non-Datalog clause can
    /// never reach an [`Executable`] — and therefore never reach the evaluator.
    #[test]
    fn pipeline_refuses_every_non_datalog_head_form() {
        let cases = [
            (
                HeadForm::Existential,
                DlClause::new(
                    vec![HeadDisjunct::atom(atom("?X", Q, "?Y"))],
                    vec!["?Y".to_owned()],
                    vec![atom("?X", P, "?Z")],
                ),
            ),
            (
                HeadForm::Disjunctive,
                DlClause::new(
                    vec![
                        HeadDisjunct::atom(atom("?X", Q, "?Y")),
                        HeadDisjunct::atom(atom("?X", R, "?Y")),
                    ],
                    Vec::new(),
                    vec![atom("?X", P, "?Y")],
                ),
            ),
            (
                HeadForm::Inconsistency,
                DlClause::inconsistency(vec![atom("?X", P, "?Y")]),
            ),
        ];
        for (form, clause) in cases {
            let refusal = Parsed::new(vec![
                DlClause::datalog(atom("?X", S, "?Y"), vec![atom("?X", P, "?Y")]),
                clause,
            ])
            .expect_err("a non-Datalog head form must be refused, never planned");
            assert_eq!(refusal.clause(), 1, "{form}");
            assert_eq!(refusal.form(), form);
        }
    }

    /// The bridge finder is exact on the shapes certification depends on: a path is all
    /// bridges, a cycle has none, and a lollipop has exactly its stick.
    #[test]
    fn bridge_edges_identifies_exactly_the_non_cycle_edges() {
        // Path 0-1-2: both edges are bridges.
        assert_eq!(
            bridge_edges(3, &[(0, 1), (1, 2)]),
            [0, 1].into_iter().collect()
        );
        // Triangle: no bridges.
        assert!(bridge_edges(3, &[(0, 1), (1, 2), (2, 0)]).is_empty());
        // Lollipop: triangle 0-1-2 plus the stick 2-3.
        assert_eq!(
            bridge_edges(4, &[(0, 1), (1, 2), (2, 0), (2, 3)]),
            BTreeSet::from([3])
        );
        // Two parallel edges between the same pair form a cycle: neither is a bridge.
        assert!(bridge_edges(2, &[(0, 1), (0, 1)]).is_empty());
        // A disconnected graph is handled component by component.
        assert_eq!(
            bridge_edges(4, &[(0, 1), (2, 3)]),
            [0, 1].into_iter().collect()
        );
        assert!(bridge_edges(0, &[]).is_empty());
    }

    /// The disjoint-set forest merges exactly the connected components.
    #[test]
    fn union_find_merges_connected_components() {
        let mut uf = UnionFind::new(6);
        uf.union(0, 1);
        uf.union(1, 2);
        uf.union(4, 5);
        assert_eq!(uf.find(0), uf.find(2));
        assert_eq!(uf.find(4), uf.find(5));
        assert_ne!(uf.find(0), uf.find(3));
        assert_ne!(uf.find(0), uf.find(4));
        // Merging an already-merged pair is a no-op.
        uf.union(2, 0);
        assert_eq!(uf.find(0), uf.find(1));
    }
}
