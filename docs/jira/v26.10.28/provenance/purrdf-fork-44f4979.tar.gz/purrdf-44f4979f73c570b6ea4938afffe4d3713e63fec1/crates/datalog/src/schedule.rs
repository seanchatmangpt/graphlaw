// SPDX-FileCopyrightText: 2026 Blackcat Informatics® Inc. <paudley@blackcatinformatics.ca>
// SPDX-License-Identifier: MIT OR Apache-2.0 OR MulanPSL-2.0

//! The ORDERED schedule: the same rule evaluator, driven layer by layer and group by
//! group in an order the caller's rule language defines.
//!
//! [`crate::seminaive`] computes the least model of a stratified program: the strata are
//! derived from the program, and inside a stratum rule order is unobservable. Two rule
//! languages PurRDF evaluates define their answer by an EXECUTION ORDER instead, and
//! this module is the one place that order is run — over the one rule IR
//! ([`DlClause`]), the one join, the one guard seam ([`crate::guard`]) and the one commit
//! the stratified fixpoint uses, so there is still exactly one rule evaluator:
//!
//! * SHACL 1.2 Inference Rules, "General Execution Instructions for SHACL Rules":
//!   "For all layers in the rule set (in ascending order): Compute the expected derived
//!   triples for all rules in the layer; Execute one iteration over all run-once rules
//!   in the layer; do Execute one iteration over all iterating rules in the layer while
//!   the iteration has produced newly inferred triples; Delete the derived triples
//!   (except those that were also inferred by rules) and their reifiers. Delete the
//!   temporary triples and their reifiers." — with, inside a layer, "rules with larger
//!   order values will be executed after those with smaller values. […] Rules with the
//!   same order are executed concurrently and must not see each other's inferences
//!   before they have all completed."
//! * SPARQL 1.2 RL, "Evaluation of a Rule Set": "A stratum is evaluated by first
//!   evaluating each of the run-once rules of that stratum, and then evaluating general
//!   rules of the stratum repeatedly until no new triples are produced" — with the
//!   strata computed by [`stratify_rules`] from clause atoms, or by
//!   [`stratify_dependency_graph`] from a dependency graph the rule language built.
//!
//! # The shape
//!
//! A [`Schedule`] is a sequence of [`Layer`]s. A layer holds RUN-ONCE groups, each
//! evaluated exactly once, and ITERATING groups, evaluated in order, pass after pass,
//! until a whole pass commits nothing. A GROUP is a set of rules evaluated CONCURRENTLY:
//! every rule of a group reads the model as it stood when the group started, and their
//! derivations are merged and committed together — which is the stratified fixpoint's
//! round, and exactly SHACL's same-order rule. A language whose rules run one after
//! another (SPARQL 1.2 RL) schedules one rule per group.
//!
//! # Semantics: inflationary, not least-model
//!
//! Negation — a negated atom, a negated conjunction, or a model-reading guard's
//! `NOT EXISTS` — is decided against the model AS IT STANDS when the rule runs. Facts are
//! never retracted inside a layer, so the model only grows, and a solution a negation
//! blocked once stays blocked: that is what makes the per-rule semi-naive delta exact
//! here too. A rule whose guard reads the model is re-evaluated against the whole model
//! each time it runs, because its answer may depend on any fact at all.
//!
//! # Assumptions and retractions
//!
//! A layer may carry ASSUMED facts ([`LayerHooks::assume`]): visible to every rule of the
//! layer, and withdrawn at its end unless some rule of the layer derived them too — SHACL's
//! expected derived triples. The hook then names further facts to retract with them
//! ([`LayerHooks::retract`]; a derived triple's reifiers), and one more hook runs after the
//! last layer ([`LayerHooks::finish`]; SHACL's temporary triples). Retraction vacates
//! the indexed native rows, preserving the original dictionary, surviving handles
//! and immutable base. Removed rows' own derivations are dropped.
//!
//! # Termination
//!
//! Every ceiling of [`crate::seminaive`] applies, each round of each group counting as a
//! round — the caller's term-generating round limit
//! ([`EvalOptions`]) included, which is what stops a rule
//! that computes a new term every pass (the SHACL rules specification: "Rule engines MAY
//! also report a failure after a pre-configured maximum iteration count has been
//! exceeded").

use std::collections::{BTreeMap, BTreeSet};
use std::sync::Arc;

use crate::cache::{self, ContractHash};
use crate::clause::{ClauseAtom, ClauseTerm, DlClause, HeadForm, ReadSource};
use crate::guard::{GuardEvaluator, Negation};
use crate::paths::{relax_strata, shortest_path};
use crate::plan::RulePlan;
use crate::seminaive::{
    Delta, EvalError, EvalOptions, Evaluation, FixpointState, JoinStrategy, RoundControl,
    RoundSnapshot, RuleEntry, RuleRuntime, check_budget, check_range_restricted, evaluate_round,
};
use crate::stop::{StopSignal, is_stopped};
#[cfg(test)]
use crate::store::Fact;
use crate::store::{Arity, RelationStore, ShapeFact, StoreShape, TermInterner};

/// The exact rule-partition defect that makes a schedule unusable.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ScheduleRefusal {
    /// A scheduled rule does not exist in the program.
    UnknownRule {
        /// The original scheduled index.
        rule: usize,
        /// The actual program length.
        rules: usize,
    },
    /// One rule occurs more than once.
    RepeatedRule {
        /// The original repeated index.
        rule: usize,
    },
    /// A program rule is absent from the schedule.
    MissingRule {
        /// The first omitted rule index.
        rule: usize,
    },
}

impl purrdf_hash::error::StructuredError for ScheduleRefusal {
    purrdf_hash::error_visit! {
        UnknownRule { rule, rules } => "schedule-unknown-rule" { "rule" => Unsigned(*rule as u128), "rules" => Unsigned(*rules as u128) },
        RepeatedRule { rule } => "schedule-repeated-rule" { "rule" => Unsigned(*rule as u128) },
        MissingRule { rule } => "schedule-missing-rule" { "rule" => Unsigned(*rule as u128) },
    }
}

impl core::fmt::Display for ScheduleRefusal {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        match self {
            Self::UnknownRule { rule, rules } => write!(
                f,
                "the schedule names rule {rule}, but the program has {rules} rules"
            ),
            Self::RepeatedRule { rule } => write!(f, "rule {rule} is scheduled more than once"),
            Self::MissingRule { rule } => write!(f, "rule {rule} is not scheduled"),
        }
    }
}

impl std::error::Error for ScheduleRefusal {}

/// One layer of an ordered schedule: its run-once groups and its iterating groups.
#[derive(Debug, Clone, PartialEq, Eq, Default)]
pub struct Layer {
    /// Groups evaluated exactly once, in order, at the start of the layer.
    once: Vec<Vec<usize>>,
    /// Groups evaluated in order, pass after pass, until a pass commits nothing.
    iterating: Vec<Vec<usize>>,
}

impl Layer {
    /// A layer from its run-once and iterating groups, each group a list of rule
    /// indices in authored program order.
    pub fn new(once: Vec<Vec<usize>>, iterating: Vec<Vec<usize>>) -> Self {
        Self { once, iterating }
    }

    /// The run-once groups, in execution order.
    pub fn once(&self) -> &[Vec<usize>] {
        &self.once
    }

    /// The iterating groups, in execution order.
    pub fn iterating(&self) -> &[Vec<usize>] {
        &self.iterating
    }
}

/// An ordered schedule: layers in execution order. See the [module docs](self).
#[derive(Debug, Clone, PartialEq, Eq, Default)]
pub struct Schedule {
    /// The layers, in execution order.
    layers: Vec<Layer>,
}

impl Schedule {
    /// A schedule from its layers, in execution order.
    pub fn new(layers: Vec<Layer>) -> Self {
        Self { layers }
    }

    /// The layers, in execution order.
    pub fn layers(&self) -> &[Layer] {
        &self.layers
    }

    /// Every scheduled rule index, layer by layer, run-once groups before iterating ones.
    fn rule_indices(&self) -> impl Iterator<Item = usize> + '_ {
        self.layers.iter().flat_map(|layer| {
            layer
                .once
                .iter()
                .chain(&layer.iterating)
                .flat_map(|group| group.iter().copied())
        })
    }
}

/// A rule program compiled for the ordered schedule.
#[derive(Debug, Clone)]
pub struct ScheduledProgram<const N: usize = 4>
where
    Arity<N>: StoreShape<N>,
{
    admission: Option<Arc<crate::admission::NeverDeriveCertificate>>,
    /// The program, in authored order.
    rules: Arc<[DlClause<N>]>,
    /// One store-independent join plan per rule.
    plans: Vec<RulePlan<N>>,
    /// One lowered runtime per rule.
    runtimes: Vec<RuleRuntime<N>>,
    /// The schedule the program runs under.
    schedule: Schedule,
}

impl<const N: usize> ScheduledProgram<N>
where
    Arity<N>: StoreShape<N>,
{
    /// Every source retained by this program's declaration union.
    #[must_use]
    pub fn declarations(&self) -> Option<&crate::admission::NeverDeriveDeclarations> {
        self.admission
            .as_deref()
            .map(crate::admission::NeverDeriveCertificate::declarations)
    }

    crate::admission::program_declarations!();

    /// The program's rules, in authored order.
    pub fn rules(&self) -> &[DlClause<N>] {
        &self.rules
    }

    /// The schedule the program runs under.
    pub fn schedule(&self) -> &Schedule {
        &self.schedule
    }

    /// The identity of the calculus this program is evaluated under `options`: the
    /// clause program, the schedule, every ceiling and the crate's calculus version
    /// ([`cache::scheduled_contract_hash`]).
    pub fn contract_hash(&self, options: &EvalOptions) -> ContractHash {
        cache::scheduled_contract_hash(&self.rules, &self.schedule, options)
    }
}

/// The original [`compile_scheduled`] with sourced full-IR never-derive admission.
/// # Errors
/// Returns exact protected/undecidable head refusal before the ordinary
/// executor's fragment checks, then the same errors as [`compile_scheduled`].
pub fn compile_scheduled_with_declarations<const N: usize>(
    rules: Vec<DlClause<N>>,
    schedule: Schedule,
    declarations: &crate::admission::NeverDeriveDeclarations,
) -> Result<ScheduledProgram<N>, EvalError>
where
    Arity<N>: StoreShape<N>,
{
    declarations.admit(&rules).map_err(EvalError::NeverDerive)?;
    compile_scheduled(rules, schedule)?
        .admit_declarations(declarations)
        .map_err(EvalError::NeverDerive)
}

/// Compile `rules` for the ordered `schedule`, or refuse them.
///
/// Admits the ATOMIC and the CONJUNCTIVE head forms: a conjunctive head asserts every
/// conjunct from one solution, which is how a rule whose head writes several triples
/// sharing one fresh term (a blank node a guard minted) keeps them co-referring. The
/// other three forms have no forward-chaining meaning and are refused by name. Every head
/// variable must be range-restricted, and the schedule must mention every rule exactly
/// once. Stratification is NOT required: see the [module docs](self).
///
/// # Errors
///
/// [`EvalError::NonDatalogHead`], [`EvalError::UnboundHeadVariable`] or
/// [`EvalError::MalformedSchedule`].
pub fn compile_scheduled<const N: usize>(
    rules: Vec<DlClause<N>>,
    schedule: Schedule,
) -> Result<ScheduledProgram<N>, EvalError>
where
    Arity<N>: StoreShape<N>,
{
    for (index, rule) in rules.iter().enumerate() {
        let form = rule.head_form();
        if !matches!(
            form,
            HeadForm::Atomic | HeadForm::Conjunctive | HeadForm::NoOutput
        ) {
            return Err(EvalError::NonDatalogHead { rule: index, form });
        }
    }
    check_range_restricted(&rules)?;
    let mut seen: BTreeSet<usize> = BTreeSet::new();
    for index in schedule.rule_indices() {
        if index >= rules.len() {
            return Err(EvalError::MalformedSchedule {
                detail: ScheduleRefusal::UnknownRule {
                    rule: index,
                    rules: rules.len(),
                },
            });
        }
        if !seen.insert(index) {
            return Err(EvalError::MalformedSchedule {
                detail: ScheduleRefusal::RepeatedRule { rule: index },
            });
        }
    }
    if let Some(missing) = (0..rules.len()).find(|index| !seen.contains(index)) {
        return Err(EvalError::MalformedSchedule {
            detail: ScheduleRefusal::MissingRule { rule: missing },
        });
    }
    let plans: Vec<RulePlan<N>> = rules.iter().map(RulePlan::for_rule).collect();
    let runtimes = rules
        .iter()
        .zip(&plans)
        .map(|(rule, plan)| RuleRuntime::new(rule, plan))
        .collect();
    Ok(ScheduledProgram {
        admission: None,
        rules: Arc::from(rules),
        plans,
        runtimes,
        schedule,
    })
}

/// The caller's layer-boundary actions. Every method has a do-nothing default.
pub trait LayerHooks<const N: usize = 4>
where
    Arity<N>: StoreShape<N>,
{
    /// The facts to ASSUME for the duration of layer `layer`, read over the model it
    /// starts from. See the [module docs](self).
    ///
    /// # Errors
    ///
    /// A message, which aborts the evaluation as [`EvalError::LayerHook`].
    fn assume(
        &mut self,
        layer: usize,
        model: &RelationStore<TermInterner, N>,
    ) -> Result<Vec<ShapeFact<N>>, crate::guard::CallbackError> {
        let _ = (layer, model);
        Ok(Vec::new())
    }

    /// Further facts to retract at the end of layer `layer`, alongside the `withdrawn`
    /// assumptions no rule of the layer derived. Read over the model before anything is
    /// retracted.
    ///
    /// # Errors
    ///
    /// A message, which aborts the evaluation as [`EvalError::LayerHook`].
    fn retract(
        &mut self,
        layer: usize,
        model: &RelationStore<TermInterner, N>,
        withdrawn: &[ShapeFact<N>],
    ) -> Result<Vec<ShapeFact<N>>, crate::guard::CallbackError> {
        let _ = (layer, model, withdrawn);
        Ok(Vec::new())
    }

    /// Facts to retract after the last layer.
    ///
    /// # Errors
    ///
    /// A message, which aborts the evaluation as [`EvalError::LayerHook`].
    fn finish(
        &mut self,
        model: &RelationStore<TermInterner, N>,
    ) -> Result<Vec<ShapeFact<N>>, crate::guard::CallbackError> {
        let _ = model;
        Ok(Vec::new())
    }
}

/// The hooks of a schedule with no layer-boundary actions.
#[derive(Debug, Clone, Copy, Default)]
pub struct NoHooks;

impl<const N: usize> LayerHooks<N> for NoHooks where Arity<N>: StoreShape<N> {}

/// Evaluate `program` over the seeded store `edb` under its schedule.
///
/// The returned [`Evaluation`]'s derivations are those of the facts in its final model:
/// a fact retracted at a layer boundary takes its derivation with it, while a surviving
/// fact's derivation keeps naming the sources it was derived from, retracted or not. An
/// assumed fact a rule derived too carries that rule's derivation.
///
/// # Errors
///
/// Every refusal [`crate::seminaive::evaluate_guarded`] makes, plus
/// [`EvalError::LayerHook`].
pub fn evaluate_scheduled<const N: usize>(
    program: &ScheduledProgram<N>,
    edb: RelationStore<TermInterner, N>,
    guards: &dyn GuardEvaluator<TermInterner, N>,
    hooks: &mut dyn LayerHooks<N>,
    options: &EvalOptions,
    stop: Option<&dyn StopSignal>,
) -> Result<Evaluation<TermInterner, N>, EvalError>
where
    Arity<N>: StoreShape<N>,
{
    if !edb.has_base()
        && let Some(rule) = program.rules.iter().position(DlClause::reads_base)
    {
        return Err(EvalError::MissingBase { rule });
    }
    let mut state = FixpointState::seeded(edb, *options);
    check_running(&state, stop)?;
    for (layer_index, layer) in program.schedule.layers.iter().enumerate() {
        run_layer(program, layer_index, layer, &mut state, guards, hooks, stop)?;
    }
    check_running(&state, stop)?;
    let finished = hooks.finish(&state.rel).map_err(|error| {
        error.into_eval_error(|message| EvalError::LayerHook {
            layer: None,
            message,
        })
    })?;
    check_running(&state, stop)?;
    retract(&mut state, &finished)?;
    check_running(&state, stop)?;
    Ok(state.finish())
}

/// Admission and actual resource refusal precede cooperative cancellation.
fn check_running<const N: usize>(
    state: &FixpointState<TermInterner, N>,
    stop: Option<&dyn StopSignal>,
) -> Result<(), EvalError>
where
    Arity<N>: StoreShape<N>,
{
    check_budget(state)?;
    if is_stopped(stop) {
        return Err(EvalError::Stopped {
            report: state.report(),
        });
    }
    Ok(())
}

/// Run one layer into `state`.
fn run_layer<const N: usize>(
    program: &ScheduledProgram<N>,
    layer_index: usize,
    layer: &Layer,
    state: &mut FixpointState<TermInterner, N>,
    guards: &dyn GuardEvaluator<TermInterner, N>,
    hooks: &mut dyn LayerHooks<N>,
    stop: Option<&dyn StopSignal>,
) -> Result<(), EvalError>
where
    Arity<N>: StoreShape<N>,
{
    let hook_error = |error: crate::guard::CallbackError| {
        error.into_eval_error(|message| EvalError::LayerHook {
            layer: Some(layer_index),
            message,
        })
    };
    check_running(state, stop)?;
    // The layer's assumptions become rows like any other, flagged so a rule that derives
    // one again is recorded as having done so.
    let assumptions = hooks.assume(layer_index, &state.rel).map_err(hook_error)?;
    check_running(state, stop)?;
    let mut assumed = purrdf_core::FastSet::default();
    assumed
        .try_reserve(assumptions.len())
        .map_err(|_| EvalError::Storage(purrdf_lex::allocation::StorageError::AllocationFailed))?;
    for fact in &assumptions {
        if !state.rel.contains_row(Arity::<N>::fact_terms(fact)) {
            state
                .report()
                .admit_fact()
                .map_err(|report| EvalError::BudgetExhausted {
                    resource: crate::seminaive::BudgetResource::StoredFacts,
                    report,
                })?;
        }
        if let Some((_, _, row)) = state.rel.insert_row(Arity::<N>::fact_terms(fact))? {
            state.seed_height(row);
            assumed.insert(row);
        }
    }
    check_budget(state)?;
    let mut confirmed: BTreeMap<ShapeFact<N>, crate::seminaive::Confirmation<N>> = BTreeMap::new();

    // Run-once groups: each rule evaluated exactly once, against the whole model.
    for group in &layer.once {
        run_group(
            program,
            group,
            state,
            GroupRun {
                guards,
                stop,
                assumed: &mut assumed,
                confirmed: &mut confirmed,
                seen: None,
            },
        )?;
    }

    // Iterating groups: pass after pass until a whole pass commits nothing. `seen[r]` is
    // the row count rule `r` last ran against, so its next run's delta is exactly what
    // was committed since — the per-rule semi-naive delta.
    let mut seen: Vec<Option<u64>> = vec![None; program.rules.len()];
    loop {
        let mut progressed = false;
        for group in &layer.iterating {
            progressed |= run_group(
                program,
                group,
                state,
                GroupRun {
                    guards,
                    stop,
                    assumed: &mut assumed,
                    confirmed: &mut confirmed,
                    seen: Some(&mut seen),
                },
            )?;
        }
        if !progressed {
            break;
        }
    }

    // Withdraw every assumption no rule derived, and whatever the hook retracts with them;
    // record the derivations of the ones a rule did derive.
    let rows = state.rel.facts_in_row_order();
    let withdrawn: Vec<ShapeFact<N>> = rows
        .iter()
        .filter(|(row, fact)| assumed.contains(row) && !confirmed.contains_key(fact))
        .map(|(_, fact)| fact.clone())
        .collect();
    if state.derivation_mode == crate::seminaive::DerivationMode::Record {
        state.derivations.extend(
            confirmed
                .into_values()
                .map(crate::seminaive::Confirmation::into_derivation),
        );
    }
    let mut retracted = hooks
        .retract(layer_index, &state.rel, &withdrawn)
        .map_err(hook_error)?;
    retracted.extend(withdrawn);
    retract(state, &retracted)?;
    Ok(())
}

/// The per-layer state one group evaluation reads and updates.
struct GroupRun<'a, 'g, const N: usize>
where
    Arity<N>: StoreShape<N>,
{
    /// The caller's guard evaluator.
    guards: &'g dyn GuardEvaluator<TermInterner, N>,
    /// The caller's stop signal.
    stop: Option<&'g dyn StopSignal>,
    /// Per-row assumed flags.
    assumed: &'a mut purrdf_core::FastSet<crate::id::RowId>,
    /// The canonical derivation of each assumed fact a rule derived again.
    confirmed: &'a mut BTreeMap<ShapeFact<N>, crate::seminaive::Confirmation<N>>,
    /// For an iterating group, the row count each rule last ran against; `None` for a
    /// run-once group, whose rules run once against everything.
    seen: Option<&'a mut Vec<Option<u64>>>,
}

/// Evaluate one group as one round and commit it. Returns whether it committed anything.
fn run_group<const N: usize>(
    program: &ScheduledProgram<N>,
    group: &[usize],
    state: &mut FixpointState<TermInterner, N>,
    run: GroupRun<'_, '_, N>,
) -> Result<bool, EvalError>
where
    Arity<N>: StoreShape<N>,
{
    if is_stopped(run.stop) {
        return Err(EvalError::Stopped {
            report: state.report(),
        });
    }
    let hi = state.rel.row_slots();
    let mut entries: Vec<RuleEntry<'_, N>> = Vec::with_capacity(group.len());
    let mut seen = run.seen;
    for &index in group {
        let (rule, plan) = (&program.rules[index], &program.plans[index]);
        let delta = match seen.as_deref_mut() {
            None => Delta::all(hi),
            Some(seen) => {
                let last = seen[index].replace(hi);
                match last {
                    // Model-reading guards need the full model. Positive Base probes
                    // have no model row-id delta; negative Base filters preserve it.
                    _ if rule.reads_model()
                        || rule.body().iter().any(|atom| {
                            !atom.is_negated() && atom.read_source() == ReadSource::Base
                        }) =>
                    {
                        Delta::all(hi)
                    }
                    None => Delta::all(hi),
                    // Nothing the rule's positive join could read has changed, and a rule
                    // with no positive atom has no delta at all: its answer can only have
                    // shrunk as the negations it reads became satisfied.
                    Some(last) if last == hi || plan.positive().is_empty() => continue,
                    Some(last) => Delta { lo: last, hi },
                }
            }
        };
        entries.push(RuleEntry {
            index,
            rule,
            plan,
            runtime: &program.runtimes[index],
            delta,
        });
    }
    if entries.is_empty() {
        return Ok(false);
    }
    let round = evaluate_round(
        &entries,
        RoundSnapshot {
            probe: None,
            rel: &state.rel,
            depth: state.depths(),
            assumed: run.assumed,
            delta_indexes: None,
        },
        state.execution,
        JoinStrategy::Planned,
        state.allowance(),
        RoundControl {
            guards: run.guards,
            stop: run.stop,
        },
    )?;
    for proof in round.confirmed() {
        match run.confirmed.get_mut(proof.fact()) {
            Some(existing) => existing.merge(proof.clone()),
            None => {
                run.confirmed.insert(proof.fact().clone(), proof.clone());
            }
        }
    }
    let committed = !round.is_empty();
    state.absorb(round)?;
    Ok(committed)
}

/// Retract indexed native rows and drop their own derivations without copying survivors.
fn retract<const N: usize>(
    state: &mut FixpointState<TermInterner, N>,
    facts: &[ShapeFact<N>],
) -> Result<(), EvalError>
where
    Arity<N>: StoreShape<N>,
{
    if facts.is_empty() {
        return Ok(());
    }
    // Admit the optional proof-filter index before changing any membership. A
    // model-only retraction needs no new storage, regardless of model size.
    let mut doomed = Vec::new();
    if !state.derivations.is_empty() {
        doomed
            .try_reserve_exact(facts.len())
            .map_err(|_| purrdf_lex::allocation::StorageError::AllocationFailed)?;
        doomed.extend(facts);
        doomed.sort_unstable();
        doomed.dedup();
    }
    for fact in facts {
        state.rel.remove_row(Arity::<N>::fact_terms(fact));
    }
    state
        .derivations
        .retain(|derivation| doomed.binary_search(&derivation.fact()).is_err());
    Ok(())
}

// ── Rule-level stratification ───────────────────────────────────────────────────

/// Whether `pattern` (a body atom) could match a fact `template` (a head atom)
/// generates: SPARQL 1.2 RL's "the triple template can generate a triple that matches
/// the triple pattern".
///
/// Decided by unifying the two atoms position by position, each in its own variable
/// namespace: two constants must be the same surface, a variable takes whatever the
/// other side holds, and a variable used twice in one atom must take one value. A
/// position a guard fills (a triple term built or taken apart by caller code) is a
/// variable here, so it may match anything — the conservative direction, which can only
/// add a dependency, never lose one.
fn may_generate<const N: usize>(pattern: &ClauseAtom<N>, template: &ClauseAtom<N>) -> bool {
    if pattern.read_source() == ReadSource::Base {
        return false;
    }
    let mut unifier = Unifier::default();
    pattern
        .terms()
        .into_iter()
        .zip(template.terms())
        .all(|(left, right)| {
            let a = unifier.node(false, left);
            let b = unifier.node(true, right);
            unifier.union(a, b)
        })
}

/// A union-find over two atoms' variables and constants, each class carrying at most one
/// constant surface.
#[derive(Default)]
struct Unifier<'a> {
    /// `(parent, constant surface)` per node.
    classes: Vec<(usize, Option<String>)>,
    /// The node of each `(template side?, variable name)`.
    names: BTreeMap<(bool, &'a str), usize>,
}

impl<'a> Unifier<'a> {
    /// The node of `term` on one side: a variable's shared node, or a fresh constant one.
    fn node(&mut self, side: bool, term: &'a ClauseTerm) -> usize {
        let index = self.classes.len();
        match term.variable() {
            Some(name) => {
                let classes = &mut self.classes;
                *self.names.entry((side, name)).or_insert_with(|| {
                    classes.push((index, None));
                    index
                })
            }
            None => {
                self.classes.push((index, term.surface()));
                index
            }
        }
    }

    /// The class root of `node`, compressing the path.
    fn find(&mut self, mut node: usize) -> usize {
        while self.classes[node].0 != node {
            let parent = self.classes[node].0;
            self.classes[node].0 = self.classes[parent].0;
            node = parent;
        }
        node
    }

    /// Merge the classes of `a` and `b`; `false` when they hold different constants.
    fn union(&mut self, a: usize, b: usize) -> bool {
        let (ra, rb) = (self.find(a), self.find(b));
        if ra == rb {
            return true;
        }
        let merged = match (self.classes[ra].1.take(), self.classes[rb].1.take()) {
            (Some(x), Some(y)) if x != y => return false,
            (Some(x), _) | (_, Some(x)) => Some(x),
            (None, None) => None,
        };
        self.classes[rb].0 = ra;
        self.classes[ra].1 = merged;
        true
    }
}

/// One rule's body reads, each with whether the dependency it induces is CLOSED.
fn body_reads<const N: usize>(rule: &DlClause<N>) -> Vec<(&ClauseAtom<N>, bool)> {
    rule.body()
        .iter()
        .map(|atom| (atom, atom.is_negated()))
        .chain(
            rule.negations()
                .iter()
                .flat_map(Negation::atoms)
                .map(|atom| (atom, true)),
        )
        .collect()
}

/// Stratify a rule set by RULE dependencies, SPARQL 1.2 RL's way, into an ordered
/// [`Schedule`]; `run_once[i]` says whether rule `i` is a run-once rule.
///
/// SPARQL 1.2 RL, "Rule Dependency": "Rule R1 depends on R2 if any triple pattern in the
/// body of R1, whether as a triple pattern element or inside a negation element, depends
/// on a triple template in the head of R2", and the dependency is CLOSED when "A triple
/// pattern occurring inside a negation element of R1 matches a triple template in the rule
/// head of R2" or "Rule R1 depends on rule R2 and R1 is a run-once rule". "The stratification
/// condition requires that there is no recursive dependency involving a closed dependency
/// in the dependency graph for a rule set." A rule whose guard reads the model
/// ([`crate::guard::GuardReads::Model`]) reads every relation with unknown polarity, so it
/// depends — closed — on every rule.
///
/// The strata follow the specification's algorithm: an open edge puts the depending rule
/// at or above the stratum of the rule it depends on, a closed edge strictly above. Each
/// stratum becomes one [`Layer`] whose run-once rules are each a group of their own, in
/// authored order, followed by its general rules, each a group of its own, in authored
/// order — "for each rule R in ST.once … for each rule R in ST.general", every rule seeing
/// the inferences of the rules before it.
///
/// # Errors
///
/// [`EvalError::NonStratifiableRules`] naming the first closed edge, in authored order,
/// that lies in a cycle, and one shortest cycle through it.
///
/// # Panics
///
/// Panics if `run_once` does not have one entry per rule — a construction bug.
pub fn stratify_rules<const N: usize>(
    rules: &[DlClause<N>],
    run_once: &[bool],
) -> Result<Schedule, EvalError> {
    assert_eq!(
        rules.len(),
        run_once.len(),
        "stratify_rules needs one run-once flag per rule"
    );
    let mut graph = DependencyGraph::new(rules.len());
    for (r1, rule) in rules.iter().enumerate() {
        let reads = body_reads(rule);
        for (r2, other) in rules.iter().enumerate() {
            // A rule reading the model depends on every OTHER rule with a
            // head — not on itself: the closed self-edge carries no
            // stratification information (run_group re-evaluates the rule
            // against the whole model per round anyway) and `shortest_path`
            // answers the one-node path for from == to, so leaving it in
            // refused every model-reading program as degenerately
            // non-stratifiable.
            if rule.reads_model() && r1 != r2 && other.head_atoms().next().is_some() {
                graph.depend(r1, r2, true);
            }
            for (pattern, negated) in &reads {
                if other.head_atoms().any(|head| may_generate(pattern, head)) {
                    graph.depend(r1, r2, *negated || run_once[r1]);
                }
            }
        }
    }
    stratify_dependency_graph(&graph, run_once)
}

/// A rule-set DEPENDENCY GRAPH: SPARQL 1.2 RL, "A dependency graph of a rule set is a
/// directed graph where each vertex is a rule in the rule set, and an edge exists from
/// rule R1 to rule R2 if R1 depends on R2. The edge is labeled either open or closed".
///
/// [`stratify_rules`] builds one from clause atoms; a caller whose rule language can
/// decide "the triple template can generate a triple that matches the triple pattern"
/// more precisely than the clause IR can state it — a triple term taken apart or built by
/// caller code is an opaque guard variable to the clause IR, but a structured term to
/// the caller — builds its own and stratifies it with [`stratify_dependency_graph`], so
/// there is still exactly one stratifier.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct DependencyGraph {
    /// The number of rules (vertices).
    rules: usize,
    /// `(R1, R2) -> closed?`, merged "closed overrides open".
    edges: BTreeMap<(usize, usize), bool>,
}

impl DependencyGraph {
    /// A graph over `rules` vertices and no edges.
    #[must_use]
    pub fn new(rules: usize) -> Self {
        Self {
            rules,
            edges: BTreeMap::new(),
        }
    }

    /// Record that rule `rule` depends on rule `depends_on`, the dependency CLOSED when
    /// `closed`. A repeated edge keeps the specification's `mergeLabel`: "Closed
    /// dependency overrides open dependency."
    ///
    /// # Panics
    ///
    /// Panics if either index is not a vertex — a construction bug.
    pub fn depend(&mut self, rule: usize, depends_on: usize, closed: bool) {
        assert!(
            rule < self.rules && depends_on < self.rules,
            "dependency edge {rule} -> {depends_on} outside a {}-rule graph",
            self.rules
        );
        let label = self.edges.entry((rule, depends_on)).or_insert(false);
        *label |= closed;
    }

    /// The number of rules.
    #[must_use]
    pub fn rule_count(&self) -> usize {
        self.rules
    }

    /// Every edge as `(rule, depends_on, closed)`, in `(rule, depends_on)` order.
    pub fn edges(&self) -> impl Iterator<Item = (usize, usize, bool)> + '_ {
        self.edges
            .iter()
            .map(|(&(r1, r2), &closed)| (r1, r2, closed))
    }
}

/// Stratify a [`DependencyGraph`] SPARQL 1.2 RL's way into an ordered [`Schedule`];
/// `run_once[i]` says whether rule `i` is a run-once rule. See [`stratify_rules`] for the
/// condition checked and the strata produced.
///
/// # Errors
///
/// [`EvalError::NonStratifiableRules`] naming the first closed edge, in `(rule,
/// depends_on)` order, that lies in a cycle, and one shortest cycle through it.
///
/// # Panics
///
/// Panics if `run_once` does not have one entry per rule — a construction bug.
pub fn stratify_dependency_graph(
    graph: &DependencyGraph,
    run_once: &[bool],
) -> Result<Schedule, EvalError> {
    assert_eq!(
        graph.rules,
        run_once.len(),
        "stratify_dependency_graph needs one run-once flag per rule"
    );
    let edges = &graph.edges;
    let rule_count = graph.rules;

    // The stratification condition, decided before any stratum is assigned: a closed
    // edge R1 -> R2 violates it exactly when R2 reaches R1.
    let mut depends: BTreeMap<usize, BTreeSet<usize>> = BTreeMap::new();
    for &(r1, r2) in edges.keys() {
        depends.entry(r1).or_default().insert(r2);
    }
    for (&(r1, r2), &closed) in edges {
        if !closed {
            continue;
        }
        if let Some(path) = shortest_path(&depends, &r2, &r1) {
            let mut cycle = vec![r1];
            cycle.extend(path);
            cycle.pop();
            return Err(EvalError::NonStratifiableRules {
                rule: r1,
                depends_on: r2,
                cycle,
            });
        }
    }

    // The specification's relaxation; it terminates because the condition holds.
    let mut stratum = vec![0usize; rule_count];
    relax_strata(
        &mut stratum,
        || edges.iter().map(|(&(p, q), &closed)| (p, q, closed)),
        |levels, &rule| levels[rule],
        |levels, &rule, level| levels[rule] = level,
        None,
    );
    let top = stratum.iter().copied().max().unwrap_or(0);
    let layers = (0..=top)
        .filter(|level| stratum.contains(level))
        .map(|level| {
            let members = (0..rule_count).filter(|&index| stratum[index] == level);
            let once = members
                .clone()
                .filter(|&index| run_once[index])
                .map(|index| vec![index])
                .collect();
            let iterating = members
                .filter(|&index| !run_once[index])
                .map(|index| vec![index])
                .collect();
            Layer::new(once, iterating)
        })
        .collect();
    Ok(Schedule::new(layers))
}

#[cfg(test)]
mod tests {
    use std::collections::BTreeSet;

    use super::*;
    use crate::clause::HeadDisjunct;
    use crate::guard::{Guard, GuardCall, GuardReads, GuardSite};
    use crate::seminaive::{
        BudgetResource, DEFAULT_MAX_TERM_GENERATING_ROUNDS, EvalOptions,
        GENERATED_TERM_BUDGET_FLOOR, compile, evaluate_guarded,
    };

    const EX: &str = "https://example.org/";

    fn iri(local: &str) -> ClauseTerm {
        ClauseTerm::iri(format!("{EX}{local}"))
    }

    fn v(name: &str) -> ClauseTerm {
        ClauseTerm::var(name)
    }

    fn atom(s: ClauseTerm, p: &str, o: ClauseTerm) -> ClauseAtom {
        ClauseAtom::positive(s, format!("{EX}{p}"), o)
    }

    fn surface(local: &str) -> String {
        format!("<{EX}{local}>")
    }

    fn store(facts: &[(&str, &str, &str)]) -> RelationStore {
        let mut store = RelationStore::new();
        for (s, p, o) in facts {
            store
                .insert(&surface(s), &surface(p), o, RelationStore::DEFAULT_GRAPH)
                .unwrap();
        }
        store
    }

    fn has(model: &RelationStore, s: &str, p: &str, o: &str) -> bool {
        model.contains(&surface(s), &surface(p), o, RelationStore::DEFAULT_GRAPH)
    }

    /// A test guard evaluator: `gt:N` keeps an integer literal input above `N`,
    /// `succ` answers the next integer, `cat` appends `x` to a string literal, `fork`
    /// answers the string extended by `a` and by `b` (`fork-below:N` only while it is
    /// shorter than `N`), `fresh` mints a counter-numbered blank, `count:p` counts the
    /// `p` facts of the model.
    #[derive(Default)]
    struct Guards {
        minted: std::cell::Cell<u32>,
    }

    fn int_of(surface: &str) -> Option<i64> {
        surface.trim_matches('"').parse().ok()
    }

    impl GuardEvaluator for Guards {
        fn evaluate(
            &self,
            call: &GuardCall<'_>,
        ) -> Result<crate::guard::GuardRows, crate::guard::CallbackError> {
            call.evaluate_lexical(|inputs| {
                let name = call.guard.name();
                if let Some(bound) = name.strip_prefix("gt:") {
                    let bound: i64 = bound.parse().map_err(|_| "bad bound".to_owned())?;
                    let value = int_of(inputs[0]).ok_or("not an integer")?;
                    return Ok(if value > bound {
                        vec![Vec::new()]
                    } else {
                        Vec::new()
                    });
                }
                if let Some(fork) = name.strip_prefix("fork") {
                    let inner = inputs[0].trim_matches('"');
                    if let Some(limit) = fork.strip_prefix("-below:") {
                        let limit: usize = limit.parse().map_err(|_| "bad limit".to_owned())?;
                        if inner.len() >= limit {
                            return Ok(Vec::new());
                        }
                    }
                    return Ok(vec![
                        vec![format!("\"{inner}a\"").into()],
                        vec![format!("\"{inner}b\"").into()],
                    ]);
                }
                if let Some(limit) = name.strip_prefix("succ-below:") {
                    let limit: i64 = limit.parse().map_err(|_| "bad limit".to_owned())?;
                    let value = int_of(inputs[0]).ok_or("not an integer")?;
                    return Ok(if value + 1 < limit {
                        vec![vec![format!("\"{}\"", value + 1).into()]]
                    } else {
                        Vec::new()
                    });
                }
                match name {
                    "succ" => {
                        let value = int_of(inputs[0]).ok_or("not an integer")?;
                        Ok(vec![vec![format!("\"{}\"", value + 1).into()]])
                    }
                    "cat" => {
                        let inner = inputs[0].trim_matches('"');
                        Ok(vec![vec![format!("\"{inner}x\"").into()]])
                    }
                    "fresh" => {
                        self.minted.set(self.minted.get() + 1);
                        Ok(vec![vec![format!("_:m{}", self.minted.get()).into()]])
                    }
                    "fail" => Err("the guard could not decide".into()),
                    "count-p" => {
                        let count = call
                            .model
                            .len_for(&surface("p"), RelationStore::DEFAULT_GRAPH);
                        Ok(vec![vec![
                            surface("a").into(),
                            format!("\"{count}\"").into(),
                        ]])
                    }
                    other => Err(format!("unknown guard {other}").into()),
                }
            })
        }
    }

    fn scheduled(rules: Vec<DlClause>, schedule: Schedule, edb: RelationStore) -> Evaluation {
        let program = compile_scheduled(rules, schedule).expect("compiles");
        evaluate_scheduled(
            &program,
            edb,
            &Guards::default(),
            &mut NoHooks,
            &EvalOptions::default().with_derivation_mode(crate::seminaive::DerivationMode::Record),
            None,
        )
        .expect("evaluates")
    }

    /// A FILTER guard drops a solution and an assignment guard binds a fresh term — the
    /// SPARQL 1.2 RL `FILTER` and `SET` elements, evaluated semi-naively.
    #[test]
    fn a_filter_and_an_assignment_guard_run_in_the_stratified_fixpoint() {
        let rule = DlClause::datalog(
            atom(v("?x"), "next", v("?n")),
            vec![atom(v("?x"), "value", v("?v"))],
        )
        .with_guards(vec![
            Guard::filter("gt:1", vec!["?v".to_owned()]),
            Guard::assign("succ", vec!["?v".to_owned()], "?n"),
        ]);
        let exe = compile(vec![rule]).expect("pure guards stratify");
        let edb = store(&[("a", "value", "\"1\""), ("b", "value", "\"5\"")]);
        let model = evaluate_guarded(
            &exe,
            edb,
            &Guards::default(),
            &EvalOptions::default().with_derivation_mode(crate::seminaive::DerivationMode::Record),
            None,
        )
        .expect("evaluates");
        assert!(has(model.facts(), "b", "next", "\"6\""));
        assert!(
            !has(model.facts(), "a", "next", "\"2\""),
            "the filter dropped a"
        );
        assert_eq!(
            model
                .derivations()
                .expect("derivation recording was requested")
                .len(),
            1
        );
    }

    /// Reordering ordinary and hybrid joins preserves guard-stage barriers and caller
    /// thread context through BOTH public fixpoint entry points.
    #[test]
    fn connected_joins_keep_guard_stages_on_the_caller_thread() {
        struct Trace {
            caller: std::thread::ThreadId,
            calls: std::cell::RefCell<Vec<(GuardSite, String, String)>>,
        }
        impl GuardEvaluator for Trace {
            fn evaluate(
                &self,
                call: &GuardCall<'_>,
            ) -> Result<crate::guard::GuardRows, crate::guard::CallbackError> {
                call.evaluate_lexical(|inputs| {
                    assert_eq!(std::thread::current().id(), self.caller);
                    assert_eq!(call.rule, 0);
                    self.calls.borrow_mut().push((
                        call.site,
                        inputs[0].to_owned(),
                        inputs[1].to_owned(),
                    ));
                    Ok(vec![Vec::new()])
                })
            }
        }

        for cyclic in [false, true] {
            let mut body = vec![
                atom(v("?v"), "kind", iri("Vault")),
                atom(v("?s"), "kind", iri("Spool")),
                atom(v("?v"), "target", v("?s")),
            ];
            if cyclic {
                body.extend([
                    atom(v("?s"), "cycle-a", v("?m")),
                    atom(v("?m"), "cycle-b", v("?n")),
                    atom(v("?n"), "cycle-c", v("?s")),
                ]);
            }
            let rule = DlClause::datalog(atom(v("?v"), "next", v("?s")), body).with_guards(vec![
                Guard::filter("first", vec!["?v".to_owned(), "?s".to_owned()]),
                Guard::filter("second", vec!["?v".to_owned(), "?s".to_owned()]),
            ]);
            let plan = RulePlan::for_rule(&rule);
            assert_eq!(plan.has_cyclic_subplan(), cyclic);
            assert_eq!(plan.operators()[0].positive_position(), 0);
            assert_eq!(plan.operators()[1].positive_position(), 2);
            for scheduled in [false, true] {
                let trace = Trace {
                    caller: std::thread::current().id(),
                    calls: std::cell::RefCell::new(Vec::new()),
                };
                let edb = store(&[
                    ("va", "kind", &surface("Vault")),
                    ("vb", "kind", &surface("Vault")),
                    ("sa", "kind", &surface("Spool")),
                    ("sb", "kind", &surface("Spool")),
                    ("va", "target", &surface("sa")),
                    ("vb", "target", &surface("sb")),
                    ("sa", "cycle-a", &surface("ma")),
                    ("ma", "cycle-b", &surface("na")),
                    ("na", "cycle-c", &surface("sa")),
                    ("sb", "cycle-a", &surface("mb")),
                    ("mb", "cycle-b", &surface("nb")),
                    ("nb", "cycle-c", &surface("sb")),
                ]);
                let options = EvalOptions::default()
                    .with_derivation_mode(crate::seminaive::DerivationMode::Record);
                let evaluation = if scheduled {
                    let program = compile_scheduled(
                        vec![rule.clone()],
                        Schedule::new(vec![Layer::new(vec![vec![0]], Vec::new())]),
                    )
                    .expect("the guarded hybrid rule compiles under the schedule");
                    evaluate_scheduled(&program, edb, &trace, &mut NoHooks, &options, None)
                } else {
                    let program =
                        compile(vec![rule.clone()]).expect("the binding-reading guards stratify");
                    evaluate_guarded(&program, edb, &trace, &options, None)
                }
                .expect("the connected guarded fixture evaluates");
                assert_eq!(
                    evaluation
                        .derivations()
                        .expect("derivation recording was requested")
                        .len(),
                    2
                );
                assert!(has(evaluation.facts(), "va", "next", &surface("sa")));
                assert!(has(evaluation.facts(), "vb", "next", &surface("sb")));
                let calls = trace.calls.borrow();
                assert_eq!(calls.len(), 4, "cyclic {cyclic}, scheduled {scheduled}");
                assert_eq!(
                    calls.iter().map(|call| call.0).collect::<Vec<_>>(),
                    [
                        GuardSite::Body(0),
                        GuardSite::Body(0),
                        GuardSite::Body(1),
                        GuardSite::Body(1),
                    ],
                    "every row reaches the first guard before any reaches the second"
                );
                let inputs = |call: &(GuardSite, String, String)| (call.1.clone(), call.2.clone());
                let first: Vec<_> = calls[..2].iter().map(inputs).collect();
                let second: Vec<_> = calls[2..].iter().map(inputs).collect();
                assert_eq!(first, second, "both stages visit the same rows in order");
                let mut rows = first;
                rows.sort();
                assert_eq!(
                    rows,
                    [
                        (surface("va"), surface("sa")),
                        (surface("vb"), surface("sb"))
                    ]
                );
            }
        }
    }

    /// A guard that could not decide aborts the run by name; it is never read as "no".
    #[test]
    fn a_failing_guard_is_a_typed_error() {
        let rule = DlClause::datalog(
            atom(v("?x"), "q", v("?v")),
            vec![atom(v("?x"), "p", v("?v"))],
        )
        .with_guards(vec![Guard::filter("fail", vec!["?v".to_owned()])]);
        let exe = compile(vec![rule]).expect("compiles");
        let error = evaluate_guarded(
            &exe,
            store(&[("a", "p", "\"1\"")]),
            &Guards::default(),
            &EvalOptions::default().with_derivation_mode(crate::seminaive::DerivationMode::Record),
            None,
        )
        .expect_err("the guard fails");
        assert!(matches!(error, EvalError::Guard { rule: 0, .. }), "{error}");
        assert!(error.to_string().contains("could not decide"), "{error}");
    }

    /// A negated CONJUNCTION blocks a solution only when some extension matches every
    /// atom and passes every guard of the group.
    #[test]
    fn a_negated_conjunction_is_decided_as_a_whole() {
        let rule = DlClause::datalog(
            atom(v("?x"), "safe", iri("yes")),
            vec![atom(v("?x"), "type", iri("C"))],
        )
        .with_negations(vec![Negation::new(
            vec![
                atom(v("?x"), "exposed", v("?v")),
                atom(v("?v"), "severity", v("?s")),
            ],
            vec![Guard::filter("gt:8", vec!["?s".to_owned()])],
        )]);
        let exe = compile(vec![rule]).expect("stratifies");
        let edb = store(&[
            ("a", "type", &surface("C")),
            ("b", "type", &surface("C")),
            ("c", "type", &surface("C")),
            ("a", "exposed", &surface("v1")),
            ("b", "exposed", &surface("v2")),
            ("v1", "severity", "\"9\""),
            ("v2", "severity", "\"3\""),
        ]);
        let model = evaluate_guarded(
            &exe,
            edb,
            &Guards::default(),
            &EvalOptions::default().with_derivation_mode(crate::seminaive::DerivationMode::Record),
            None,
        )
        .expect("evaluates");
        let yes = surface("yes");
        assert!(
            !has(model.facts(), "a", "safe", &yes),
            "a is critically exposed"
        );
        assert!(
            has(model.facts(), "b", "safe", &yes),
            "b's exposure is not severe"
        );
        assert!(
            has(model.facts(), "c", "safe", &yes),
            "c is exposed to nothing"
        );
    }

    /// The stratified fixpoint refuses a model-reading guard by name; the ordered
    /// schedule runs the very same rule.
    #[test]
    fn a_model_reading_guard_is_refused_by_the_stratifier_and_run_by_the_schedule() {
        let rule = || {
            DlClause::datalog(atom(v("?s"), "count", v("?n")), Vec::new()).with_guards(vec![
                Guard::new(
                    "count-p",
                    Vec::new(),
                    vec!["?s".to_owned(), "?n".to_owned()],
                    GuardReads::Model,
                ),
            ])
        };
        assert_eq!(
            compile(vec![rule()]).expect_err("refused"),
            EvalError::ModelReadingGuard { rule: 0 }
        );
        let model = scheduled(
            vec![rule()],
            Schedule::new(vec![Layer::new(vec![vec![0]], Vec::new())]),
            store(&[("a", "p", "\"1\""), ("b", "p", "\"2\"")]),
        );
        assert!(has(model.facts(), "a", "count", "\"2\""));
    }

    /// A counter stepping `?n + 1` to 10,000 over one fact terminates after 10,000
    /// term-generating rounds, which the default round limit admits; a caller's smaller
    /// limit refuses it by name with the numbers, and a limit the counter fits in admits
    /// it.
    #[test]
    fn a_deep_constant_bounded_counter_completes_under_the_default_limits() {
        let counter = || {
            let rule = DlClause::datalog(
                atom(v("?x"), "value", v("?m")),
                vec![atom(v("?x"), "value", v("?n"))],
            )
            .with_guards(vec![Guard::assign(
                "succ-below:10001",
                vec!["?n".to_owned()],
                "?m",
            )]);
            compile(vec![rule]).expect("compiles")
        };
        let seed = || store(&[("a", "value", "\"0\"")]);
        let model = evaluate_guarded(
            &counter(),
            seed(),
            &Guards::default(),
            &EvalOptions::default().with_derivation_mode(crate::seminaive::DerivationMode::Record),
            None,
        )
        .expect("the 10,000-step counter terminates under the default limits");
        assert!(has(model.facts(), "a", "value", "\"10000\""));
        assert!(!has(model.facts(), "a", "value", "\"10001\""));
        assert_eq!(model.budget().term_generating_rounds(), 10_000);
        assert_eq!(
            model.budget().term_generating_round_limit(),
            DEFAULT_MAX_TERM_GENERATING_ROUNDS
        );

        let limited = EvalOptions::default()
            .with_derivation_mode(crate::seminaive::DerivationMode::Record)
            .with_max_term_generating_rounds(500);
        let error = evaluate_guarded(&counter(), seed(), &Guards::default(), &limited, None)
            .expect_err("the same counter is refused under a limit of 500");
        let rendered = error.to_string();
        let EvalError::TermLimitExceeded {
            resource,
            rules,
            report,
        } = error
        else {
            panic!("expected a term-limit refusal, got {error}");
        };
        assert_eq!(resource, BudgetResource::TermGeneratingRounds);
        assert_eq!(rules.as_ref(), &[0]);
        assert_eq!(report.term_generating_round_limit(), 500);
        assert_eq!(report.term_generating_rounds(), 501);
        assert!(
            rendered.contains(
                "exceeded the term-generating round limit: 501 rounds committed a term the \
                 store did not hold, past the limit of 500 (the caller's limit)"
            ),
            "{rendered}"
        );
        assert!(!rendered.contains("diverge"), "{rendered}");
        assert!(rendered.contains("rule(s) 0"), "{rendered}");
        assert!(
            rendered.contains("EvalOptions::with_max_term_generating_rounds"),
            "{rendered}"
        );
        let fits = EvalOptions::default()
            .with_derivation_mode(crate::seminaive::DerivationMode::Record)
            .with_max_term_generating_rounds(10_000);
        evaluate_guarded(&counter(), seed(), &Guards::default(), &fits, None)
            .expect("a limit the counter fits in admits it");
    }

    /// A counter bounded by its DATA: the depth of every node of a 600-edge chain is one
    /// more than its predecessor's — 600 term-generating rounds — so it completes under
    /// the default limits with every depth.
    #[test]
    fn a_data_bounded_counter_deeper_than_the_floor_completes() {
        const LENGTH: usize = 600;
        let rule = DlClause::datalog(
            atom(v("?y"), "depth", v("?m")),
            vec![
                atom(v("?x"), "depth", v("?n")),
                atom(v("?x"), "next", v("?y")),
            ],
        )
        .with_guards(vec![Guard::assign("succ", vec!["?n".to_owned()], "?m")]);
        let exe = compile(vec![rule]).expect("compiles");
        let mut edb = RelationStore::new();
        for index in 0..LENGTH {
            edb.insert(
                &surface(&format!("n{index}")),
                &surface("next"),
                &surface(&format!("n{}", index + 1)),
                RelationStore::DEFAULT_GRAPH,
            )
            .unwrap();
        }
        edb.insert(
            &surface("n0"),
            &surface("depth"),
            "\"0\"",
            RelationStore::DEFAULT_GRAPH,
        )
        .unwrap();
        let model = evaluate_guarded(
            &exe,
            edb,
            &Guards::default(),
            &EvalOptions::default().with_derivation_mode(crate::seminaive::DerivationMode::Record),
            None,
        )
        .expect("a data-bounded counter completes under the default limits");
        assert!(has(
            model.facts(),
            &format!("n{LENGTH}"),
            "depth",
            &format!("\"{LENGTH}\"")
        ));
        assert_eq!(model.budget().term_generating_rounds(), LENGTH as u64);
        assert!(model.budget().term_generating_round_limit() >= LENGTH as u64);
    }

    /// A rule appending to a string every round, with no bound, generates one term per
    /// round: it is refused at the default ROUND limit, named, with the numbers — and never
    /// called divergent, which no limit proves.
    #[test]
    fn an_unbounded_linear_generator_passes_the_default_round_limit() {
        let growing = DlClause::datalog(
            atom(v("?x"), "name", v("?m")),
            vec![atom(v("?x"), "name", v("?n"))],
        )
        .with_guards(vec![Guard::assign("succ", vec!["?n".to_owned()], "?m")]);
        let exe = compile(vec![growing]).expect("compiles");
        let error = evaluate_guarded(
            &exe,
            store(&[("a", "name", "\"0\"")]),
            &Guards::default(),
            &EvalOptions::default().with_derivation_mode(crate::seminaive::DerivationMode::Record),
            None,
        )
        .expect_err("an unbounded counter passes the round limit");
        let rendered = error.to_string();
        let EvalError::TermLimitExceeded {
            resource,
            rules,
            report,
        } = error
        else {
            panic!("a term-limit refusal: {error}");
        };
        assert_eq!(resource, BudgetResource::TermGeneratingRounds);
        assert_eq!(rules.as_ref(), &[0]);
        assert_eq!(
            report.term_generating_rounds(),
            DEFAULT_MAX_TERM_GENERATING_ROUNDS + 1
        );
        assert!(report.generated_terms() < report.generated_term_budget());
        assert!(rendered.contains("(the default)"), "{rendered}");
        assert!(!rendered.contains("diverge"), "{rendered}");
    }

    /// A rule whose terms double every round reaches the generated-term BUDGET within a
    /// few rounds — long before any round limit — and is refused by name with the
    /// numbers; the same rule bounded to strings of ten characters (2,046 terms) completes
    /// under the default budget.
    #[test]
    fn an_exponential_generator_passes_the_default_generated_term_budget() {
        let forking = |guard: &str| {
            let rule = DlClause::datalog(
                atom(v("?x"), "name", v("?m")),
                vec![atom(v("?x"), "name", v("?n"))],
            )
            .with_guards(vec![Guard::assign(guard, vec!["?n".to_owned()], "?m")]);
            compile(vec![rule]).expect("compiles")
        };
        let seed = || store(&[("a", "name", "\"\"")]);
        let error = evaluate_guarded(
            &forking("fork"),
            seed(),
            &Guards::default(),
            &EvalOptions::default().with_derivation_mode(crate::seminaive::DerivationMode::Record),
            None,
        )
        .expect_err("a doubling generator passes the budget");
        let rendered = error.to_string();
        let EvalError::TermLimitExceeded {
            resource, report, ..
        } = error
        else {
            panic!("a term-limit refusal: {error}");
        };
        assert_eq!(resource, BudgetResource::GeneratedTerms);
        assert_eq!(report.generated_term_budget(), GENERATED_TERM_BUDGET_FLOOR);
        assert!(report.generated_terms() > GENERATED_TERM_BUDGET_FLOOR);
        assert!(report.term_generating_rounds() < 20, "{rendered}");
        assert!(
            rendered.contains("exceeded the generated-term budget"),
            "{rendered}"
        );
        assert!(
            rendered.contains(&format!(
                "past the budget of {GENERATED_TERM_BUDGET_FLOOR} (the default, max(65536, 4 \
                 per input term))"
            )),
            "{rendered}"
        );
        assert!(
            rendered.contains("EvalOptions::with_max_generated_terms"),
            "{rendered}"
        );
        assert!(!rendered.contains("diverge"), "{rendered}");

        let bounded = evaluate_guarded(
            &forking("fork-below:10"),
            seed(),
            &Guards::default(),
            &EvalOptions::default().with_derivation_mode(crate::seminaive::DerivationMode::Record),
            None,
        )
        .expect("a bounded fork completes under the default budget");
        assert!(has(bounded.facts(), "a", "name", "\"ababababab\""));
        assert_eq!(bounded.budget().generated_terms(), 2_046);
        let tight = EvalOptions::default()
            .with_derivation_mode(crate::seminaive::DerivationMode::Record)
            .with_max_generated_terms(1_000);
        let error = evaluate_guarded(
            &forking("fork-below:10"),
            seed(),
            &Guards::default(),
            &tight,
            None,
        )
        .expect_err("the caller's smaller budget refuses it");
        assert!(
            error
                .to_string()
                .contains("past the budget of 1000 (the caller's budget)"),
            "{error}"
        );
    }

    /// A guard-free program never counts a term-generating round, and hashes exactly as it
    /// did; a guarded one hashes differently.
    #[test]
    fn guard_free_programs_keep_their_digests() {
        let plain = DlClause::datalog(
            atom(v("?x"), "q", v("?y")),
            vec![atom(v("?x"), "p", v("?y"))],
        );
        let guarded = plain
            .clone()
            .with_guards(vec![Guard::filter("gt:1", vec!["?y".to_owned()])]);
        assert_ne!(
            cache::canonical_rule_hash(std::slice::from_ref(&plain)),
            cache::canonical_rule_hash(std::slice::from_ref(&guarded))
        );
        assert_ne!(
            cache::contract_hash(std::slice::from_ref(&plain)),
            cache::contract_hash(std::slice::from_ref(&guarded))
        );
        let options = EvalOptions::default()
            .with_derivation_mode(crate::seminaive::DerivationMode::Record)
            .with_max_term_generating_rounds(7);
        assert_eq!(
            cache::contract_hash_with(std::slice::from_ref(&plain), &options),
            cache::contract_hash(std::slice::from_ref(&plain)),
            "a guard-free program's contract ignores the round limit"
        );
        assert_ne!(
            cache::contract_hash_with(std::slice::from_ref(&guarded), &options),
            cache::contract_hash(std::slice::from_ref(&guarded)),
            "a guarded program's contract names the round limit in force"
        );
        let exe = compile(vec![plain]).expect("compiles");
        let model = evaluate_guarded(
            &exe,
            store(&[("a", "p", "\"1\"")]),
            &crate::guard::NoGuards,
            &crate::seminaive::EvalOptions::default()
                .with_derivation_mode(crate::seminaive::DerivationMode::Record),
            None,
        )
        .expect("runs");
        assert_eq!(model.budget().term_generating_rounds(), 0);
    }

    /// Two negating rules in ONE group run concurrently and both fire; in two groups the
    /// first one's output blocks the second — SHACL's same-order rule, observed.
    #[test]
    fn a_group_runs_concurrently_and_groups_run_in_order() {
        let rules = || {
            let node = atom(v("?x"), "type", iri("Node"));
            vec![
                DlClause::datalog(
                    atom(v("?x"), "p", iri("t")),
                    vec![
                        node.clone(),
                        ClauseAtom::negated(v("?x"), format!("{EX}q"), iri("t")),
                    ],
                ),
                DlClause::datalog(
                    atom(v("?x"), "q", iri("t")),
                    vec![
                        node,
                        ClauseAtom::negated(v("?x"), format!("{EX}p"), iri("t")),
                    ],
                ),
            ]
        };
        let edb = || store(&[("n", "type", &surface("Node"))]);
        let t = surface("t");
        let together = scheduled(
            rules(),
            Schedule::new(vec![Layer::new(Vec::new(), vec![vec![0, 1]])]),
            edb(),
        );
        assert!(has(together.facts(), "n", "p", &t) && has(together.facts(), "n", "q", &t));
        let ordered = scheduled(
            rules(),
            Schedule::new(vec![Layer::new(Vec::new(), vec![vec![0], vec![1]])]),
            edb(),
        );
        assert!(has(ordered.facts(), "n", "p", &t) && !has(ordered.facts(), "n", "q", &t));
    }

    /// A run-once rule minting a fresh term runs exactly once. Left iterating, a rule
    /// whose guard is a function of its bindings fires once per body solution — the
    /// semi-naive delta never re-presents a solution — while the same rule reading the
    /// model is re-run against everything each pass, mints a new term every time, and is
    /// stopped by the ceiling with a typed error rather than hanging.
    #[test]
    fn a_run_once_group_runs_once() {
        let rule = |reads: GuardReads| {
            DlClause::new(
                vec![HeadDisjunct::new(vec![
                    atom(v("?x"), "head", v("?b")),
                    atom(v("?b"), "value", iri("zero")),
                ])],
                Vec::new(),
                vec![atom(v("?x"), "type", iri("Container"))],
            )
            .with_guards(vec![Guard::new(
                "fresh",
                Vec::new(),
                vec!["?b".to_owned()],
                reads,
            )])
        };
        let edb = || store(&[("c", "type", &surface("Container"))]);
        for layer in [
            Layer::new(vec![vec![0]], Vec::new()),
            Layer::new(Vec::new(), vec![vec![0]]),
        ] {
            let model = scheduled(
                vec![rule(GuardReads::Bindings)],
                Schedule::new(vec![layer]),
                edb(),
            );
            assert_eq!(
                model
                    .derivations()
                    .expect("derivation recording was requested")
                    .len(),
                2,
                "one solution, two conjuncts"
            );
            assert!(
                model
                    .facts()
                    .contains(&surface("c"), &surface("head"), "_:m1", "")
            );
            assert!(
                model
                    .facts()
                    .contains("_:m1", &surface("value"), &surface("zero"), "")
            );
        }

        let once = scheduled(
            vec![rule(GuardReads::Model)],
            Schedule::new(vec![Layer::new(vec![vec![0]], Vec::new())]),
            edb(),
        );
        assert_eq!(
            once.derivations()
                .expect("derivation recording was requested")
                .len(),
            2
        );
        let program = compile_scheduled(
            vec![rule(GuardReads::Model)],
            Schedule::new(vec![Layer::new(Vec::new(), vec![vec![0]])]),
        )
        .expect("compiles");
        let error = evaluate_scheduled(
            &program,
            edb(),
            &Guards::default(),
            &mut NoHooks,
            &EvalOptions::default().with_derivation_mode(crate::seminaive::DerivationMode::Record),
            None,
        )
        .expect_err("never converges");
        assert!(
            matches!(
                error,
                EvalError::TermLimitExceeded {
                    resource: BudgetResource::TermGeneratingRounds,
                    ref rules,
                    ..
                } if rules.as_ref() == [0]
            ),
            "{error}"
        );
        let error = evaluate_scheduled(
            &program,
            edb(),
            &Guards::default(),
            &mut NoHooks,
            &EvalOptions::default()
                .with_derivation_mode(crate::seminaive::DerivationMode::Record)
                .with_max_term_generating_rounds(100),
            None,
        )
        .expect_err("never converges");
        let EvalError::TermLimitExceeded {
            resource, report, ..
        } = error
        else {
            panic!("expected a term-limit refusal, got {error}");
        };
        assert_eq!(resource, BudgetResource::TermGeneratingRounds);
        assert_eq!(report.term_generating_round_limit(), 100);
    }

    /// Hooks: an assumption is visible to the layer and withdrawn at its end unless a rule
    /// derived it too; the retraction hook and the finish hook remove what they name.
    #[test]
    fn assumptions_are_withdrawn_unless_derived() {
        struct Hooks;
        impl LayerHooks for Hooks {
            fn assume(
                &mut self,
                _: usize,
                _: &RelationStore,
            ) -> Result<Vec<Fact>, crate::guard::CallbackError> {
                Ok(vec![fact("a", "area", "\"1\""), fact("b", "area", "\"2\"")])
            }
            fn retract(
                &mut self,
                _: usize,
                _: &RelationStore,
                withdrawn: &[Fact],
            ) -> Result<Vec<Fact>, crate::guard::CallbackError> {
                assert_eq!(withdrawn, [fact("a", "area", "\"1\"")]);
                Ok(vec![fact("a", "note", "\"withdrawn\"")])
            }
            fn finish(
                &mut self,
                _: &RelationStore,
            ) -> Result<Vec<Fact>, crate::guard::CallbackError> {
                Ok(vec![fact("b", "temp", "\"t\"")])
            }
        }
        fn fact(s: &str, p: &str, o: &str) -> Fact {
            Fact {
                subject: surface(s),
                predicate: surface(p),
                object: o.to_owned(),
                graph: String::new(),
            }
        }
        let rules = vec![
            // Reads the assumption: every area-carrying node is small.
            DlClause::datalog(
                atom(v("?x"), "small", iri("yes")),
                vec![atom(v("?x"), "area", v("?a"))],
            ),
            // Derives b's assumed area itself, so it survives the layer.
            DlClause::datalog(
                atom(v("?x"), "area", v("?a")),
                vec![atom(v("?x"), "size", v("?a"))],
            ),
        ];
        let program = compile_scheduled(
            rules,
            Schedule::new(vec![Layer::new(Vec::new(), vec![vec![0, 1]])]),
        )
        .expect("compiles");
        let edb = store(&[
            ("b", "size", "\"2\""),
            ("a", "note", "\"withdrawn\""),
            ("b", "temp", "\"t\""),
        ]);
        let model = evaluate_scheduled(
            &program,
            edb,
            &Guards::default(),
            &mut Hooks,
            &EvalOptions::default().with_derivation_mode(crate::seminaive::DerivationMode::Record),
            None,
        )
        .expect("evaluates");
        let yes = surface("yes");
        assert!(
            has(model.facts(), "a", "small", &yes),
            "the assumption was visible"
        );
        assert!(!has(model.facts(), "a", "area", "\"1\""), "withdrawn");
        assert!(
            has(model.facts(), "b", "area", "\"2\""),
            "derived too, so kept"
        );
        assert!(
            !has(model.facts(), "a", "note", "\"withdrawn\""),
            "retract hook"
        );
        assert!(!has(model.facts(), "b", "temp", "\"t\""), "finish hook");
        let kept = model
            .derivations()
            .expect("derivation recording was requested")
            .iter()
            .find(|d| d.fact().subject == surface("b") && d.fact().predicate == surface("area"))
            .expect("the confirming derivation is recorded");
        assert_eq!(kept.rule(), 1);
    }

    /// Every witness component applies to assumptions too, across individual
    /// firings, concurrent rules and separately scheduled groups. Retraction of
    /// an unrelated earlier row must not invalidate the retained proof surfaces.
    #[test]
    fn assumed_confirmations_use_the_canonical_witness_in_every_group_order() {
        struct Assumptions(Vec<Fact>);
        impl LayerHooks for Assumptions {
            fn assume(
                &mut self,
                layer: usize,
                _: &RelationStore,
            ) -> Result<Vec<Fact>, crate::guard::CallbackError> {
                Ok(if layer == 1 {
                    self.0.clone()
                } else {
                    Vec::new()
                })
            }
            fn retract(
                &mut self,
                layer: usize,
                _: &RelationStore,
                _: &[Fact],
            ) -> Result<Vec<Fact>, crate::guard::CallbackError> {
                Ok(if layer == 1 {
                    vec![test_fact("discard", "seed", "x")]
                } else {
                    Vec::new()
                })
            }
        }
        fn test_fact(s: &str, p: &str, o: &str) -> Fact {
            Fact {
                subject: surface(s),
                predicate: surface(p),
                object: surface(o),
                graph: String::new(),
            }
        }
        let fixed = |p: &str| atom(iri("a"), p, iri("x"));
        let head = |p: &str| atom(iri("answer"), p, iri("yes"));
        let rules = vec![
            DlClause::datalog(fixed("q"), vec![fixed("p")]),
            DlClause::datalog(fixed("r"), vec![fixed("q")]),
            DlClause::datalog(head("height"), vec![fixed("r")]),
            DlClause::datalog(head("height"), vec![fixed("p")]),
            DlClause::datalog(head("sum"), vec![fixed("r"), fixed("r")]),
            DlClause::datalog(head("sum"), vec![fixed("r"), fixed("p")]),
            DlClause::datalog(head("sorted"), vec![atom(iri("z"), "seed", iri("x"))]),
            DlClause::datalog(head("sorted"), vec![fixed("p")]),
            DlClause::datalog(head("rule"), vec![fixed("p")]),
            DlClause::datalog(head("rule"), vec![fixed("p")]),
            DlClause::datalog(
                head("authored"),
                vec![
                    atom(v("?x"), "edge", v("?y")),
                    atom(v("?y"), "edge", v("?x")),
                ],
            ),
        ];
        let seeds = [
            ("discard", "seed", surface("x")),
            ("a", "p", surface("x")),
            ("z", "seed", surface("x")),
            ("a", "edge", surface("b")),
            ("b", "edge", surface("a")),
        ];
        let assumed: Vec<_> = ["height", "sum", "sorted", "rule", "authored"]
            .iter()
            .map(|p| test_fact("answer", p, "yes"))
            .collect();
        let expected_rules = [3, 5, 7, 8, 10];
        for reverse_seeds in [false, true] {
            for groups in [
                vec![(2..11).collect()],
                (2..11).map(|i| vec![i]).collect(),
                (2..11).rev().map(|i| vec![i]).collect(),
            ] {
                let mut seeds = seeds.to_vec();
                if reverse_seeds {
                    seeds.reverse();
                }
                let edb = store(
                    &seeds
                        .iter()
                        .map(|(s, p, o)| (*s, *p, o.as_str()))
                        .collect::<Vec<_>>(),
                );
                let program = compile_scheduled(
                    rules.clone(),
                    Schedule::new(vec![
                        Layer::new(vec![vec![0], vec![1]], Vec::new()),
                        Layer::new(groups, Vec::new()),
                    ]),
                )
                .expect("compiles");
                let evaluation = evaluate_scheduled(
                    &program,
                    edb,
                    &Guards::default(),
                    &mut Assumptions(assumed.clone()),
                    &EvalOptions::default()
                        .with_derivation_mode(crate::seminaive::DerivationMode::Record),
                    None,
                )
                .expect("evaluates");
                for (fact, expected_rule) in assumed.iter().zip(expected_rules) {
                    let proof = evaluation
                        .derivations()
                        .expect("derivation recording was requested")
                        .iter()
                        .find(|proof| proof.fact() == fact)
                        .expect("confirmed proof survives retraction");
                    assert_eq!(proof.rule(), expected_rule, "{}", fact.predicate);
                    let expected_sources = match expected_rule {
                        3 | 7 | 8 => vec![test_fact("a", "p", "x")],
                        5 => vec![test_fact("a", "r", "x"), test_fact("a", "p", "x")],
                        10 => vec![test_fact("a", "edge", "b"), test_fact("b", "edge", "a")],
                        _ => unreachable!(),
                    };
                    assert_eq!(proof.sources(), expected_sources);
                    assert_eq!(proof.proof_height(), if expected_rule == 5 { 3 } else { 1 });
                }
                assert!(!has(evaluation.facts(), "discard", "seed", &surface("x")));
            }
        }
    }

    #[test]
    fn layer_capacity_refusal_preserves_identity_and_stops_later_phases() {
        struct Refusal {
            phase: u8,
            reached: Vec<u8>,
        }
        impl Refusal {
            fn run(&mut self, phase: u8) -> Result<Vec<Fact>, crate::guard::CallbackError> {
                self.reached.push(phase);
                if self.phase == phase {
                    crate::id::TermId::from_index(u64::MAX)
                        .map_err(purrdf_lex::allocation::StorageError::from)?;
                }
                Ok(Vec::new())
            }
        }
        impl LayerHooks for Refusal {
            fn assume(
                &mut self,
                _: usize,
                _: &RelationStore,
            ) -> Result<Vec<Fact>, crate::guard::CallbackError> {
                self.run(0)
            }
            fn retract(
                &mut self,
                _: usize,
                _: &RelationStore,
                _: &[Fact],
            ) -> Result<Vec<Fact>, crate::guard::CallbackError> {
                self.run(1)
            }
            fn finish(
                &mut self,
                _: &RelationStore,
            ) -> Result<Vec<Fact>, crate::guard::CallbackError> {
                self.run(2)
            }
        }
        let rule = DlClause::datalog(
            atom(v("?x"), "result", iri("yes")),
            vec![atom(v("?x"), "p", iri("x"))],
        );
        let program = compile_scheduled(
            vec![rule],
            Schedule::new(vec![Layer::new(vec![vec![0]], Vec::new())]),
        )
        .expect("authored schedule");
        for phase in 0..3 {
            let mut hooks = Refusal {
                phase,
                reached: Vec::new(),
            };
            let error = evaluate_scheduled(
                &program,
                store(&[("a", "p", &surface("x"))]),
                &crate::guard::NoGuards,
                &mut hooks,
                &EvalOptions::default()
                    .with_derivation_mode(crate::seminaive::DerivationMode::Record),
                None,
            )
            .expect_err("actual term mint capacity refusal");
            assert_eq!(hooks.reached, (0..=phase).collect::<Vec<_>>());
            let EvalError::Storage(purrdf_lex::allocation::StorageError::Capacity(capacity)) =
                error
            else {
                panic!("lost layer storage refusal: {error:?}");
            };
            assert_eq!(
                capacity.space,
                purrdf_lex::allocation::CapacitySpace::DatalogTerms
            );
            assert_eq!(capacity.attempted(), u128::from(u64::MAX) + 1);
            assert_eq!(capacity.limit(), u128::from(u64::MAX));
        }
    }

    /// Stage-major execution determines the first reached operational failure;
    /// processing each row through all guards would incorrectly report second.
    #[test]
    fn crossed_guard_errors_and_malformed_rows_are_reached_in_stage_order() {
        struct Errors {
            malformed: bool,
            storage: bool,
        }
        impl GuardEvaluator for Errors {
            fn evaluate(
                &self,
                call: &GuardCall<'_>,
            ) -> Result<crate::guard::GuardRows, crate::guard::CallbackError> {
                call.evaluate_lexical(|inputs| {
                    if call.guard.name() == "first" && inputs[0] == surface("b") {
                        if self.storage {
                            crate::id::TermId::from_index(u64::MAX)
                                .map_err(purrdf_lex::allocation::StorageError::from)?;
                        }
                        return if self.malformed {
                            Ok(vec![vec!["unexpected".into()]])
                        } else {
                            Err("first-later-row".into())
                        };
                    }
                    if call.guard.name() == "second" {
                        return Err("second-earlier-row".into());
                    }
                    Ok(vec![Vec::new()])
                })
            }
        }
        let rule = DlClause::datalog(
            atom(v("?x"), "result", iri("yes")),
            vec![atom(v("?x"), "p", iri("x"))],
        )
        .with_guards(vec![
            Guard::filter("first", vec!["?x".to_owned()]),
            Guard::filter("second", vec!["?x".to_owned()]),
        ]);
        let program = compile_scheduled(
            vec![rule],
            Schedule::new(vec![Layer::new(vec![vec![0]], Vec::new())]),
        )
        .expect("compiles");
        for (malformed, storage) in [(false, false), (true, false), (false, true)] {
            let error = evaluate_scheduled(
                &program,
                store(&[("a", "p", &surface("x")), ("b", "p", &surface("x"))]),
                &Errors { malformed, storage },
                &mut NoHooks,
                &EvalOptions::default()
                    .with_derivation_mode(crate::seminaive::DerivationMode::Record),
                None,
            )
            .expect_err("first-stage refusal");
            let message = error.to_string();
            assert!(!message.contains("second-earlier-row"), "{message}");
            if storage {
                let EvalError::Storage(purrdf_lex::allocation::StorageError::Capacity(capacity)) =
                    error
                else {
                    panic!("lost typed guard refusal: {error:?}");
                };
                assert_eq!(
                    capacity.space,
                    purrdf_lex::allocation::CapacitySpace::DatalogTerms
                );
                assert_eq!(capacity.attempted(), u128::from(u64::MAX) + 1);
                assert_eq!(capacity.limit(), u128::from(u64::MAX));
            } else if malformed {
                assert!(
                    message.contains("first") && message.contains('1'),
                    "{message}"
                );
            } else {
                assert!(message.contains("first-later-row"), "{message}");
            }
        }
    }

    /// A later iteration can discover a better proof of an assumption without
    /// replacing the admission proof of an ordinary fact from an earlier round.
    #[test]
    fn later_confirmation_rounds_compete_but_prior_admissions_still_win() {
        struct Hooks;
        impl LayerHooks for Hooks {
            fn assume(
                &mut self,
                layer: usize,
                _: &RelationStore,
            ) -> Result<Vec<Fact>, crate::guard::CallbackError> {
                Ok(if layer == 1 {
                    vec![Fact {
                        subject: surface("answer"),
                        predicate: surface("confirmed"),
                        object: surface("yes"),
                        graph: String::new(),
                    }]
                } else {
                    Vec::new()
                })
            }
        }
        let rules = vec![
            DlClause::datalog(
                atom(iri("high"), "mid", iri("x")),
                vec![atom(iri("high"), "seed", iri("x"))],
            ),
            DlClause::datalog(
                atom(iri("high"), "alternative", iri("x")),
                vec![atom(iri("high"), "mid", iri("x"))],
            ),
            DlClause::datalog(
                atom(iri("answer"), "confirmed", iri("yes")),
                vec![atom(v("?s"), "alternative", iri("x"))],
            ),
            DlClause::datalog(
                atom(iri("answer"), "ordinary", iri("yes")),
                vec![atom(v("?s"), "alternative", iri("x"))],
            ),
            DlClause::datalog(
                atom(iri("low"), "alternative", iri("x")),
                vec![atom(iri("low"), "seed", iri("x"))],
            ),
        ];
        let program = compile_scheduled(
            rules,
            Schedule::new(vec![
                Layer::new(vec![vec![0], vec![1]], Vec::new()),
                Layer::new(Vec::new(), vec![vec![2, 3], vec![4]]),
            ]),
        )
        .expect("compiles");
        let evaluation = evaluate_scheduled(
            &program,
            store(&[
                ("high", "seed", &surface("x")),
                ("low", "seed", &surface("x")),
            ]),
            &Guards::default(),
            &mut Hooks,
            &EvalOptions::default().with_derivation_mode(crate::seminaive::DerivationMode::Record),
            None,
        )
        .expect("evaluates");
        for (predicate, expected_source, height) in
            [("confirmed", "low", 2), ("ordinary", "high", 3)]
        {
            let proof = evaluation
                .derivations()
                .expect("derivation recording was requested")
                .iter()
                .find(|proof| proof.fact().predicate == surface(predicate))
                .expect("proof recorded");
            assert_eq!(proof.sources()[0].subject, surface(expected_source));
            assert_eq!(proof.proof_height(), height);
        }
    }

    /// A malformed schedule is a typed refusal, and every rule must be scheduled once.
    #[test]
    fn a_schedule_must_partition_the_rules() {
        let rule = || {
            DlClause::datalog(
                atom(v("?x"), "q", v("?y")),
                vec![atom(v("?x"), "p", v("?y"))],
            )
        };
        for (schedule, code, index) in [
            (Schedule::new(Vec::new()), "schedule-missing-rule", 0_u128),
            (
                Schedule::new(vec![Layer::new(vec![vec![0]], vec![vec![0]])]),
                "schedule-repeated-rule",
                0,
            ),
            (
                Schedule::new(vec![Layer::new(vec![vec![0, 1]], Vec::new())]),
                "schedule-unknown-rule",
                1,
            ),
        ] {
            let error = compile_scheduled(vec![rule()], schedule).unwrap_err();
            let fields = purrdf_testkit::error_capture::Capture::read(&error);
            let detail = fields.child("detail");
            assert_eq!(detail.code, code);
            assert!(
                matches!(detail.field("rule"), purrdf_hash::error::ErrorValue::Unsigned(value) if value == index)
            );
        }
        let program = compile_scheduled(
            vec![rule()],
            Schedule::new(vec![Layer::new(Vec::new(), vec![vec![0]])]),
        )
        .expect("the neighbour partition compiles");
        let other = compile_scheduled(
            vec![rule()],
            Schedule::new(vec![Layer::new(vec![vec![0]], Vec::new())]),
        )
        .expect("compiles");
        assert_ne!(
            program.contract_hash(
                &EvalOptions::default()
                    .with_derivation_mode(crate::seminaive::DerivationMode::Record)
            ),
            other.contract_hash(
                &EvalOptions::default()
                    .with_derivation_mode(crate::seminaive::DerivationMode::Record)
            ),
            "the schedule is hashed"
        );
    }

    /// SPARQL 1.2 RL stratification: a negation over a lower stratum evaluates, with the
    /// negated rule placed strictly below; a negation inside a cycle is refused naming it.
    #[test]
    fn rule_stratification_evaluates_or_names_the_cycle() {
        // Rule 0: ?x exposedTo ?v <- ?x hasVuln ?v
        // Rule 1: ?x safe yes <- ?x type C, NOT ?x exposedTo ?v
        let exposed = DlClause::datalog(
            atom(v("?x"), "exposedTo", v("?v")),
            vec![atom(v("?x"), "hasVuln", v("?v"))],
        );
        let safe = DlClause::datalog(
            atom(v("?x"), "safe", iri("yes")),
            vec![
                atom(v("?x"), "type", iri("C")),
                ClauseAtom::negated(v("?x"), format!("{EX}exposedTo"), v("?v")),
            ],
        );
        let rules = vec![safe.clone(), exposed.clone()];
        let schedule = stratify_rules(&rules, &[false, false]).expect("stratifiable");
        assert_eq!(schedule.layers().len(), 2);
        assert_eq!(schedule.layers()[0].iterating(), [vec![1]]);
        assert_eq!(schedule.layers()[1].iterating(), [vec![0]]);
        let model = scheduled(
            rules,
            schedule,
            store(&[
                ("a", "type", &surface("C")),
                ("b", "type", &surface("C")),
                ("a", "hasVuln", &surface("v")),
            ]),
        );
        let yes = surface("yes");
        assert!(!has(model.facts(), "a", "safe", &yes));
        assert!(has(model.facts(), "b", "safe", &yes));

        // A negation that feeds itself through a positive edge is not stratifiable.
        let back = DlClause::datalog(
            atom(v("?x"), "exposedTo", iri("self")),
            vec![atom(v("?x"), "safe", iri("yes"))],
        );
        let error = stratify_rules(&[safe, exposed, back], &[false, false, false])
            .expect_err("negative cycle");
        assert_eq!(
            error,
            EvalError::NonStratifiableRules {
                rule: 0,
                depends_on: 2,
                cycle: vec![0, 2],
            }
        );
        assert!(
            error.to_string().contains("rule 0 -> rule 2 -> rule 0"),
            "{error}"
        );
    }

    /// Dependency matching is by unification: a pattern whose constant differs from the
    /// template's never depends on it, so a negation over a DIFFERENT class in the same
    /// predicate is stratifiable — where the predicate-level stratifier would refuse it.
    #[test]
    fn dependency_matching_is_finer_than_the_predicate() {
        let a = DlClause::datalog(
            atom(v("?x"), "type", iri("A")),
            vec![
                atom(v("?x"), "type", iri("B")),
                ClauseAtom::negated(v("?x"), format!("{EX}type"), iri("C")),
            ],
        );
        let c = DlClause::datalog(
            atom(v("?x"), "type", iri("C")),
            vec![atom(v("?x"), "type", iri("D"))],
        );
        let rules = vec![a, c];
        assert!(compile(rules.clone()).is_err(), "predicate-level: refused");
        let schedule = stratify_rules(&rules, &[false, false]).expect("rule-level: stratifiable");
        let model = scheduled(
            rules,
            schedule,
            store(&[
                ("x", "type", &surface("B")),
                ("y", "type", &surface("B")),
                ("y", "type", &surface("D")),
            ]),
        );
        assert!(has(model.facts(), "x", "type", &surface("A")));
        assert!(!has(model.facts(), "y", "type", &surface("A")));
        assert!(!may_generate(
            &atom(v("?x"), "p", v("?x")),
            &atom(iri("a"), "p", iri("b"))
        ));
        assert!(may_generate(
            &atom(v("?x"), "p", v("?x")),
            &atom(v("?y"), "p", iri("b"))
        ));
    }

    /// A run-once rule's dependency is closed, so it lands strictly above what it reads.
    #[test]
    fn a_run_once_rule_is_stratified_above_what_it_reads() {
        let general = DlClause::datalog(
            atom(v("?x"), "q", v("?y")),
            vec![atom(v("?x"), "p", v("?y"))],
        );
        let once = DlClause::datalog(
            atom(v("?x"), "r", v("?y")),
            vec![atom(v("?x"), "q", v("?y"))],
        );
        let schedule = stratify_rules(&[once, general], &[true, false]).expect("stratifiable");
        assert_eq!(
            schedule.layers(),
            [
                Layer::new(Vec::new(), vec![vec![1]]),
                Layer::new(vec![vec![0]], Vec::new())
            ]
        );
        let unique: BTreeSet<usize> = schedule.rule_indices().collect();
        assert_eq!(unique.len(), 2);
    }

    /// A caller-built dependency graph is stratified by the same core: an open cycle is
    /// one stratum, a closed edge lands its rule strictly above, a closed edge inside a
    /// cycle is refused naming it, and a repeated edge keeps "closed overrides open".
    #[test]
    fn a_caller_built_dependency_graph_is_stratified_by_the_same_core() {
        // 0 <-> 1 open, 2 -> 1 closed: two strata.
        let mut graph = DependencyGraph::new(3);
        graph.depend(0, 1, false);
        graph.depend(1, 0, false);
        graph.depend(2, 1, false);
        graph.depend(2, 1, true);
        assert_eq!(
            graph.edges().collect::<Vec<_>>(),
            [(0, 1, false), (1, 0, false), (2, 1, true)]
        );
        let schedule = stratify_dependency_graph(&graph, &[false, false, true]).expect("ok");
        assert_eq!(
            schedule.layers(),
            [
                Layer::new(Vec::new(), vec![vec![0], vec![1]]),
                Layer::new(vec![vec![2]], Vec::new())
            ]
        );
        // The same closed edge inside a cycle is refused by name.
        graph.depend(1, 2, false);
        assert_eq!(
            stratify_dependency_graph(&graph, &[false, false, true]),
            Err(EvalError::NonStratifiableRules {
                rule: 2,
                depends_on: 1,
                cycle: vec![2, 1],
            })
        );
    }

    /// The consumers that read only clause text refuse a guarded clause by name.
    #[test]
    fn text_only_consumers_refuse_guarded_clauses() {
        let guarded = DlClause::datalog(
            atom(v("?x"), "q", v("?y")),
            vec![atom(v("?x"), "p", v("?y"))],
        )
        .with_guards(vec![Guard::filter("gt:1", vec!["?y".to_owned()])]);
        assert!(matches!(
            crate::chase::chase(std::slice::from_ref(&guarded), RelationStore::new()),
            Err(crate::chase::ChaseError::GuardedClause { clause: 0 })
        ));
        let refusal = crate::resolve_fol::solve_datalog_goal(
            std::slice::from_ref(&guarded),
            &atom(v("?x"), "q", v("?y")),
            &crate::resolve_fol::FolBudget { max_steps: 10 },
        )
        .expect_err("refused");
        let crate::resolve_fol::FolError::Clause(refusal) = refusal else {
            panic!("the original guarded-clause refusal must be preserved");
        };
        assert!(refusal.is_guarded());
        let mut arena = crate::proof::ProofArena::default();
        let premise = arena
            .axiom(Fact {
                subject: surface("a"),
                predicate: surface("p"),
                object: "\"2\"".to_owned(),
                graph: String::new(),
            })
            .unwrap();
        let step = arena
            .by_rule(
                Fact {
                    subject: surface("a"),
                    predicate: surface("q"),
                    object: "\"2\"".to_owned(),
                    graph: String::new(),
                },
                0,
                &[premise],
            )
            .unwrap();
        let edb = store(&[("a", "p", "\"2\"")]);
        let rules = [guarded];
        let ctx = crate::proof::ProofContext::new(&rules, &edb, &edb);
        assert_eq!(
            arena.check(step, &ctx),
            Err(crate::proof::ProofError::GuardedRule { rule: 0 })
        );
    }
}
