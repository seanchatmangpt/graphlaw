# Changelog

All notable changes to the PurRDF crate suite are recorded here. The suite
ships one lockstep version across crates.io, PyPI, and npm; from 1.0.0 a
breaking change bumps the major version, a minor bump is additive, and a patch
bump is bugfix-only. The C ABI (`purrdf.h`) is versioned separately and remains
0.x.

## [Unreleased]

**n3:** Introduced `purrdf-n3` (`crates/n3`): native Notation3 parsing, forward/backward reasoning and proof writing/checking over RDF 1.2, re-exported through the `purrdf` umbrella as `purrdf::n3`.

- **Query-only bottom properties:** native axiom refutations install the same
  empty-role law as ontology parsing. Querying an unmentioned bottom object
  property now preserves its empty extension and native proof origin.

- **Certified direct OWL answers (breaking Rust API and incomplete outcomes):**
  direct class subsumptions and most-specific types are read from the certified
  result and require a fully decided supplied ontology. Typed refusals retain
  the original certificate; raw payloads no longer expose unproved candidates.
  Shared classification, realization and proof calls refuse incomplete directness
  with the full original certificate. Fully decided output bytes are unchanged.

- **Governed SRL inference (breaking error payloads):** borrowed stop signals
  reach `srl::infer_until` and `infer_triples_until`, including cancellation
  within scheduled rule groups. Success and all four rule limits retain the
  complete native usage report. Distinct stopped errors retain their native
  cause and never publish unfinished inference. Limit payloads are now boxed;
  their standard sources still borrow the original limit value. Unstopped
  results, proofs, contract identities and effective limits remain unchanged.

- **Segmented data profile 6 (breaking persisted format):** the reverse index
  stores identifiers into the forward dictionary, and dictionary blocks read
  their first key from its record instead of a second stored fence. Exact reverse
  lookup uses the same authenticated forward reader. Older segmented profiles
  must be regenerated from their original RDF input; the reader refuses them.
  Receipt encoding and hash laws remain separate from the data profile.
  Dictionary payloads use native DEFLATE when it admits more records per physical
  block; numeric reverse-index pages fill independently of the dictionary record
  cap. Readers admit bounded inflation scratch and preserve native codec causes.
  Source directories store each normalized source row in 37 bytes with one
  cumulative digest per 32 rows, so prefix reads reconstruct at most 31 tail
  digests; a 1,025-row image uses 82 directory and checkpoint pages instead of
  205 at the same 512-byte page size. An oversized dictionary term no longer
  sets every page's size: it is stored in fixed-size authenticated overflow
  pages behind a small routing descriptor, reverse comparisons stream only the
  bytes needed to order it, and lexical materialization admits its payload and
  scratch. Independent certification checks exact directory, checkpoint and
  overflow contents.

- **Regime arena controls (C ABI 0.12.0):** Rust, Python, JavaScript, C and
  CLI callers can set the retained term-surface byte limit. Refusals preserve
  the original counts and name the calling surface's available control.

- **Native integer dictionaries (breaking):** `TermDictionary::compare_terms`
  defines canonical publication order, preserving lexical RDF order while allowing
  original integer comparisons. `IntegerDictionary<u32/u64>` evaluates native
  model-only fixed points without string interning or lexical projection, using
  explicit caller-supplied program symbols. Explicit lexical requests fail with a
  typed error. Tied witnesses and round winners use the same dictionary contract.

- **Datalog guard values (breaking):** guard calls carry original identities or
  fresh spellings, and `GuardRows` returns typed identity/surface cells. Native
  callbacks and native inequality avoid lexical round trips. Lexical callbacks
  opt into `GuardCall::evaluate_lexical`, which retains original dictionary pins
  and preserves source refusals. The SHACL rule engine uses this shared boundary.

- **Native integer row storage:** `store::RowColumns<I, N, R>` retains arbitrary-width
  rows and original handles without interning or rendering. `store::RowIndex`
  indexes caller-selected columns and returns matching key-prefix rows without
  query-time allocation. RDF tails use the same column buffer, and RDF secondary
  indexes use the same integer-column sorter.

- **Guard-computed join keys:** `DlClause::with_ordered_body` interleaves positive
  atoms and guards through `clause::BodyLiteral`. Fresh guard outputs can bind
  subsequent binary and cyclic probes. Guards are evaluation barriers; absent
  computed keys match no row. Early guards enter a position-aware version 3
  clause identity, and physical planner version 6 invalidates cached plans.

- **SHACL SPARQL argument failures:** COALESCE, IF, boolean and membership forms can mask
  catchable nested node-expression failures using SPARQL semantics, while
  unmasked failures retain their original cause and empty results stay distinct.
  Validation recursion refusals now carry typed
  `ProcessorFailure::ValidationDepth` fields and cannot be caught as expression
  errors. Processor, storage and stop failures always escape the call.

- **Actionable SHACL arena refusals:** rule entry points retain the actual
  observed bytes and ceiling and advise reducing retained term sizes. Direct
  Datalog refusals continue to name their available `EvalOptions` setting.

- **Indexed round deltas:** Datalog builds native arrangements from each distinct
  new-row span once per round and shares them across rule tasks. Binary probes,
  cyclic leapfrog cursors and productive-anchor checks read those arrangements;
  the all-row seed borrows the accumulated store. Original row, partition and
  term IDs are retained, with no term rendering or whole-store delta scans.

- **Selective delta rule joins:** partial Datalog rounds bind their new-row anchor
  before visiting old join prefixes, including factored and cyclic bodies.
  Binary joins may first use one strictly smaller indexed seed, then immediately
  probe the delta. Cardinality advice reads existing runs and never constructs a
  cold historical object index. Impossible constant patterns skip delta seeding.
  Advice is frozen before rule tasks run, so a sibling warming a lazy index
  cannot change the round's candidate work.
  Dynamic probes constrain every already-bound position and retain authored
  proof order. A new physical planner version (`purrdf-datalog-plan-v6` at
  release) identifies the changed candidate accounting; completed models and
  semantic fact counts retain their meaning.

- **Indexed predicate iteration:** bound-predicate, free-graph Datalog probes
  visit only that predicate's partitions. `RelationStore::rows_for_predicate`
  returns original row and term identities for triple and quad stores without
  rendering terms or scanning other predicates, in lexical partition order.

- **Editor's-draft SHACL law (breaking):** `ShaclProfile::ED_20261016`
  (`shacl-ed-2026-10-16`) names the `w3c/data-shapes` editor's drafts at commit
  `4cd469867a1cc6d2fff80e8a40723b26c695d67a`, with XPath 3.1. It is the working
  draft law plus four rules first published after that draft: a node expression
  as `sh:deactivated` on a SPARQL-based or `sh:expression` constraint, the
  `owl:versionIRI` steps of the `sh:prefixes` path, a blank node as a custom
  SPARQL function argument being an error, and rule sets as `sh:entailment`
  values. `ShaclProfile::WD_20260918` now follows the working draft text and
  refuses or ignores each of the four, `ShaclProfile::REC_20170720` collects
  prefixes along `sh:prefixes/owl:imports*/sh:declare`, and the compatibility law
  reads the editor's draft. `ShaclProfile::is_shacl12` selects the two SHACL 1.2
  laws.

- **Rule sets are typed, and their includes are checked at load (breaking):** a rule
  set is a SHACL instance of `sh:RuleSet` and nothing else. An untyped subject of
  `sh:hasRule` or `sh:includesRuleSet` is no longer read as a rule set, and
  `RuleOptions::with_rule_set` on an untyped IRI is refused as not declared. An
  `sh:includesRuleSet` value that is not a declared rule set is refused when the shapes
  graph loads, with or without `sh:RulesEntailment`, where it used to fail only when
  the rules ran. `validate_change` on a shapes graph that declares `sh:RulesEntailment`
  or a rule set as `sh:entailment` answers with the whole graph and the reason
  `rules entailment`, where it used to report the validator as not bound.

- **BLAKE3 modes and extended output:** keyed hashing and context-separated key
  derivation share the existing portable and SIMD kernels. Both streaming buffer
  sizes support keyed and derived input; an owned output reader fills caller
  storage and seeks without rehashing input. One-shot XOF functions cover all
  three modes, with no added dependency.

- **Shared exact integer engine:** arbitrary-precision Integer, Decimal,
  Rational, numeric codecs and geometric facades share binary `u64` limbs.
  Small exact integers retain inline `i128` arithmetic; the binary engine adds
  inline magnitude storage, bounded reusable scratch and Karatsuba products.
  The governor profile now prices binary storage and decimal base conversion
  (`GOVERNOR_PROFILE_VERSION` is 22 at release).

- **RDFLib compatibility queries:** Graph, Dataset, ConjunctiveGraph and the
  SPARQL processor compile contextual mappings through the shared Rust evaluator.
  Repeated assignments and initial bindings now follow RDFLib's mapping/context
  laws through nested groups, OPTIONAL, MINUS, EXISTS and aggregation. Public
  columns, duplicate rows, empty projected mappings and query-wide labelled
  blank-node identity are preserved. Native Store and SHACL assignment rules
  remain unchanged.

### Breaking Changes

- **Canonical reserved-vocabulary refusals:** `ReservedVocabulary` lends its
  original IRI and position through `iri()` and `position()`; clones share the
  immutable payload and its original admission owner, and the refusal stays
  readable after its source is destroyed. A source provides
  `DatasetView::reserve_owned_workspace` when an offending IRI must be owned;
  without that capability canonicalization returns
  `CanonError::OwnedWorkspaceUnavailable`, and an unknown live ceiling grants
  no permission. `check_admissible` and `check_admissible_view` return
  `CanonError`, including physical allocation refusal, and flat boundaries
  retain native causes through `ViewCanonError::Refused`.

- **Canonical Function Ontology catalogs:** build an `FnoCatalogInput` and
  admit it with `FnoCatalog::try_new`; the admitted catalog is immutable and
  `as_input()` borrows its fields. Admission checks RDF values, conflicting
  node descriptions and references first, and an `FnoAdmissionError` owns the
  original rejected input and native reason. Labels, banners and descriptions
  are literal `TermValue`s that keep datatype, language and base direction;
  mapping identities use `FnBlank { label, scope }` instead of a sanitized
  label string. Set-valued fields sort canonically, `expects` keeps its list
  order, and distinct mapping labels and function IRIs no longer merge, so
  emitted bytes change while the admitted RDF facts are preserved. Slice's
  `list_functions_catalog` and `emit_list_functions` return admission results.
  `FnoCatalog::from_dataset(&view, ontology_iri)` reads a catalog through the
  same admission path under a strict profile that must account for every
  default-graph statement; unsupported content, named graphs and extra list
  facts are refused with boxed `FnoReadError` values, and a source failure
  discards the whole result. A write and read preserve catalog equality, and a
  read and write preserve graph isomorphism.

- **Fallible canonical identities:** canonicalization refusals (reserved
  vocabulary, exhausted search budgets) reach callers as errors instead of
  panics. The panicking `canonicalize`, `canonicalize_with`,
  `canonicalize_view`, `canonicalize_graph_view`, `graph_digest_view` and
  `ontology_identity` adapters are removed; use their `try_` forms.
  `datasets_isomorphic` returns `Result<bool, CanonError>`, and
  `Justification::digest` and `digest_hex`, `PipelineBundle::digest` and
  `canonical_flat_nquads` return the original refusal. JavaScript
  `Dataset.isomorphic` throws a JavaScript `Error` carrying it. Successful
  canonical bytes, labels and digest algorithms are unchanged.

- **Explicit Datalog capacity limits:** unstated stored-fact, join-step and
  term-arena settings impose no logical ceiling on any target; physical storage
  admission still applies. The target-specific `DEFAULT_MAX_STORED_FACTS`,
  `DEFAULT_MAX_JOIN_STEPS`, `DEFAULT_MAX_TERM_ARENA_BYTES` and their
  `NATIVE_`/`WASM_` presets are removed. Explicit limits keep typed refusals
  with original consumption, and `EvalOptions::without_stored_fact_limit`,
  `without_join_step_limit` and `without_term_arena_limit` remove a selected
  ceiling. Rule, entailment, SHACL rule and CLI, Python and JavaScript host
  paths share these options, so an omitted CLI limit no longer means 4,194,304
  facts, 1,048,576 steps or 16 MiB. The chase refuses a candidate past its
  last representable work observation, which advances the calculus identity to
  `purrdf-datalog-calculus-v3`; every reasoning-contract identity changes, and
  cached results must be recomputed. Canonical model bytes are unchanged.

- **Datalog store coordinates:** `RelationStore::rows_from` takes a `u64`
  boundary, and `row_slots` reports the next logical append coordinate apart
  from the live `row_count`. Indexed removal leaves surviving rows and handles
  in place; a reinserted row receives a fresh append identity, and an old
  handle never denotes a different row.

- **Retrieval decoding and profile errors:**
  `purrdf_retrieval::PlanError::InvalidUtf8` carries the original
  `source: core::str::Utf8Error` beside `what`, and
  `FusionError::MalformedProfile` carries `Box<ProfileRefusal>` instead of a
  rendered string. Its native reasons retain decoder and IRI causes, wire
  fields and original candidate owners; the inspected `reason` field is now a
  borrowed cause. Human messages and refusal identities are unchanged.

- **Columnar errors keep native causes:** `purrdf::columnar::project` and
  `write` return `ColumnarWriteError<D::ReadError>`, whose `SourceRead` carries
  the provider's original read error and whose `Codec` carries a
  `ColumnarError`. Content integrity failures are `ColumnarError::ContentStore`
  and `BlobContent { row, cause }`, and RDF reconstruction and freeze failures
  are `Reconstruction(RdfDiagnostic)`, replacing formatted `Malformed` details
  and `Storage` for freezes. Compact metadata, Parquet metadata and profile,
  page-body, value-decoder, fixed-schema construction, reader and projection
  refusals move from `Malformed` text to the `Compact`, `Metadata`, `PageBody`,
  `ValueBody`, `Construction`, `Reader` and `Projection` variants, which retain
  original operands and causes through borrowed inspection and standard error
  sources. Human messages, refusal order and emitted bytes are unchanged.

- **HNSW and distance refusals:** shared distance pair and batch APIs return
  `Result<f64, NonFinite>` instead of `Option<f64>`, and `Bounded::NonFinite`
  carries the same cause with the original checked `binary64` bits.
  `HnswError::NonFiniteDistance` adds `cause` beside `row`, exact kNN errors
  retain query and candidate rows and the metric, and
  `HnswError::ArithmeticOverflow` carries an `ArithmeticRefusal` naming the
  failed operation, original operands, units and destination limit.
  `HnswError::NonFiniteComponent` adds a `value: ComponentValue` keeping the
  original component width, sign and NaN payload. Successful values,
  checkpoint order and human messages are unchanged.

- **CDT parse error causes:** `CdtError::BadEscape` and
  `CdtError::BadLanguageTag` gain a `cause` field holding the original UCHAR or
  language-tag refusal, also reachable through the standard error source. CDT
  errors and comparison type errors expose every field through structured
  inspection. Grammar, messages and lexical bytes are unchanged.

- **SHACL shape catalogs and recursion refusals:** shapes graphs parse each
  definition once and retain the original shape and function domains behind
  identity references; `PropertyReference` edges keep their overrides apart
  from the shared property-shape definition. A cyclic shape reference
  (self-reference, mutual reference, logical shape list or nested property
  shape) is refused when the shapes graph loads with the new
  `ShapesError::Recursion`, whose `RecursionRefusal` lists the component's
  members and its dependency edges with their polarity; a shared acyclic
  reference is accepted. Preparation that would enter the stack margin, or a
  reference outside its catalog, returns the new `ShapesError::Preparation`.
  Exhaustive `ShapesError` matches must handle both, and `path::eval` and
  `eval_ids` now return a `Result`.

- **Incremental text indexes:** text updates maintain source identity and
  coverage and edit the persistent lexical and surface tables for changed
  subjects instead of collecting every literal row of the next source.
  Inconsistent deltas and unavailable source evidence are refused. Source and
  index identity domains are revised, so text index and source fingerprints
  change. `token_occurrences`, `documents_with_subject`,
  `SurfaceTerm::documents` and the `words` and `spans` accessors return
  iterators instead of slices, and `SurfaceTerm` and the substring and phonetic
  match types gain a corpus-profile parameter defaulting to `GraphLanguage`.

- **Explicit Datalog evidence and governors:** ordinary evaluation defaults to
  model-only output. Request `DerivationMode::Record` for exported derivations;
  `Evaluation::derivations` returns an `Option`, and proof construction returns
  a typed refusal if recording was disabled. Entailment and SHACL proof callers
  request recording explicitly. The term-arena ceiling is caller-selected through
  `EvalOptions`; an unstated ceiling imposes no logical limit (see "Explicit
  Datalog capacity limits"). Stored-fact refusal reports distinguish the
  admitted count from the first refused insertion. Semantic fact counts and
  versioned candidate work are available through `Evaluation::work`, and each
  call can select sequential rule execution without changing a global pool.

- **Shared Datalog head conjunctions:** ordinary semi-naive evaluation admits
  several unquantified head atoms over one shared body, including recursive
  and stratified programs. Recorded derivations expose the authored head
  ordinal. Independent proof encoding moves to version 2 and records that
  ordinal; version 1 proof bytes require regeneration. Physical plans use
  planner version 6 (`purrdf-datalog-plan-v6`), invalidating earlier cached
  plan identities.

- **Native Datalog inequality:** `Guard::not_equal` filters exact bound terms
  without a caller callback, including inside negated groups. Independent proofs
  recheck native top-level filters. Programs with native filters use an
  operation-tagged version 2 clause identity; unchanged callback-only identities
  remain stable.

- **One exact XSD numeric value API:** public `XsdValue::Integer` and
  `XsdValue::Decimal` carry the exact integer and decimal types at every size.
  The bounded `purrdf_xsd::Decimal`, bounded `owl:rational` module and decimal
  narrowing conversions are removed; callers that matched the old wide
  variants use the same exact variants as small values. Integer narrowing to
  `i128` or `i64` remains explicit and typed. The old `bigint_avg_decimal` and
  `bigint_avg_decimal_lexical` helpers are removed; use `numeric_div_with_policy`
  for aggregate division under the same exact policy as ordinary division.
  Decimal division now keeps every
  digit of a terminating quotient and otherwise rounds to 18 fractional
  places, half to even. Explicit `exact`, `N`, `N:ROUNDING` and
  `exact-or-N[:ROUNDING]` policies remain available. Temporal seconds use exact
  decimals, including fractional precision beyond 18 places, through
  arithmetic, comparisons and canonical output.

- **Rust query-algebra projections:** parsed `SELECT *` can now produce
  `GraphPattern::ProjectStar`, whose ordered `ProjectionVars` shares earlier
  projection snapshots. Explicit `Project` retains its `Vec<Variable>`.
  Downstream exhaustive matches must handle the new variant; code that reads
  either projection's names can use `GraphPattern::projected_names()`.
  This source break requires the 4.0 major release and must not ship as a 3.x
  patch. See the [4.0 migration guide](docs/MIGRATION-4.0.md).

- **Remembered empty named graphs are the default:** Rust `GraphExistenceMode`,
  `MutableDataset::new` and `QueryOptions`, Python `Store`/`MutableDataset`, WASM
  `Dataset` and `purrdf update` now retain named graphs after last-row removal or
  `CLEAR`. `CREATE` registers an empty graph; `DROP` removes it. Missing remembered
  graph targets or transfer sources fail before mutation unless `SILENT`.
  To retain row-driven behavior, select Rust `GraphExistenceMode::Implicit`, Python
  `remember_empty_graphs=False`, WASM `new Dataset(false)` or the fourth `false`
  argument to `Dataset.parse`, or CLI `--graph-existence implicit`. Otherwise use
  `DROP` where an old `CLEAR` was intended to remove the graph itself.
  C ABI **0.11.0** adds a required `int32_t graph_existence` to
  `purrdf_graph_from_dataset`, `purrdf_update_governed`,
  `purrdf_update_governed_xpath_regex` and `purrdf_update_governed_with_geo`:
  pass `PURRDF_GRAPH_EXISTENCE_REMEMBER_EMPTY`
  (0) or `PURRDF_GRAPH_EXISTENCE_IMPLICIT` (1); other values are invalid arguments.
  Recompile C callers against the generated header. Dataset status and capability
  layouts are unchanged; remembered empty graphs still set `named_graphs`.

- **Unrestricted exact BM25F ranking:** the ranking identity is now
  `purrdf-bm25f-fixed-v2`, revision 2. Query terms, ranking fields, corpus
  populations, field lengths/frequencies and nonnegative weights no longer have
  selected admission ceilings. Overflowing intermediates use the existing exact
  Integer/BigInt at the original rounding boundaries; previously admitted score
  lexicals remain byte-identical. Profile/index fingerprints change because the
  admission and bound laws changed. The fixed maximum/width exports are removed;
  `PreparedQuery::score` now returns `BoundedScore { value, bound }`, native
  `Scored` carries `score_bound`, and matched-term counts use usize. The bound is
  derived from the actual prepared query/corpus, with no reserved host tie bits.


- **Developer-schema output for ontologies without anonymous expressions:**
  correctness fixes change what an IRI-only ontology emits. Each change:
  - Every schema cache key (`SchemaCompilation.key`) changes, for every input,
    IRI-only ontologies and ontologies with no OWL at all included: the policy
    salt moves from `owl-rdfs-fragment-v1` to `owl-rdfs-fragment-v2`, and the
    fixed ceilings the key binds gain the class-membership ceiling below. A
    compilation cached under an earlier key is never reused.
  - `ex:X owl:equivalentClass xsd:…` (or any datatype) defines `ex:X` as a
    datatype. It is no longer a class: it gets no `$defs` entry and no coverage
    class rows. A property that is not an `owl:ObjectProperty` and ranges over
    it admits a literal tagged `ex:X` or a value of the defining datatype (and a
    node, as below). An
    `owl:DatatypeProperty` ranging over it, which used to be refused, is
    accepted. Its coverage rows are `representation_approximation` where the
    defining datatype's projection is.
  - A property that is not an `owl:ObjectProperty` and ranges over
    `rdf:JSON`, `rdf:HTML`, `rdf:XMLLiteral`, `rdf:PlainLiteral`, `owl:real` or
    `owl:rational` projects a literal of that datatype (beside a node, as
    every OWL-derived property does; see below), where it projected a node
    reference only.
    Its coverage rows are `representation_approximation`, because lexical
    forms are not judged. An `owl:DatatypeProperty` ranging over one of them,
    which used to be refused, is accepted.
  - A property ranging over an XSD datatype, which used to admit only literals
    tagged with that datatype, admits every literal whose value is in the
    datatype's value space (see "OWL datatypes are judged by value space"
    under Added). Its coverage rows are
    `representation_approximation` for a decimal or integer range, which
    admits `owl:rational` literals unjudged. SHACL-derived properties and
    shaped-only output are unchanged.
  - **Every OWL-derived property takes a node or a checked literal**, read by
    the OWL 2 RDF-Based Semantics (OWL 2 Full) with the OWL 2 datatype map,
    whatever its declared kind:
    - every `owl:ObjectProperty` now takes well-typed literals, where it took
      only nodes: with no range, any well-typed literal; under a class range,
      a well-typed literal whose membership is not judged; under a datatype
      range (`rdf:JSON`, say), that datatype's literals. A class declared
      disjoint with `rdfs:Literal` (or below `¬rdfs:Literal`) still rejects
      every literal;
    - every `owl:DatatypeProperty` (and `rdf:Property`) now also takes a node,
      since an IRI may denote a data value;
    - an ill-typed literal (`"abc"^^xsd:integer`, `" a "^^xsd:token`) is no
      value of any OWL-derived property; one typed `rdf:XMLLiteral` or with a
      datatype outside the map is admitted unjudged;
    - coverage cells: a property no range constrains is exact; a data range
      (which admits a node unjudged) and a class range (which admits a literal
      unjudged) are `representation_approximation`, unless the class rejects
      literals; the manifest reports a data-range `owl:allValuesFrom`
      `approximated` on every property kind;
    - the well-typed-literal schema is the new reserved `$defs/Literal`
      definition, so an ontology class whose local name is `Literal` is keyed
      by its CURIE, as one named `Node` or `Annotation` already is.
  - The schema `$id` under a hash namespace
    (`http://purl.org/goodrelations/v1#`) is fragment-free:
    `http://purl.org/goodrelations/v1/schema/instance.schema.json`, not
    `…/v1#schema/instance.schema.json`. JSON Schema draft 2020-12 §8.2.1
    requires a `$id` to resolve to an absolute URI without a fragment, and
    draft 2020-12 validators refused the old one. Slash namespaces keep their
    `$id`.
  - A class hierarchy whose closure holds more than 1,048,576 memberships (a
    subclass chain deeper than about 1,450) used to be refused with
    `LimitExceeded` "propagated class memberships". The closure now holds up to
    16,777,216 (a chain about 5,790 deep).
  - A class constructor on an IRI (`owl:oneOf`, `owl:unionOf`,
    `owl:intersectionOf`, `owl:complementOf`, an IRI typed `owl:Restriction`),
    which used to be ignored, is projected and reported as above.
  - Nothing else changes. A golden of the output frozen before anonymous class
    expressions were read is compared on every test run with today's: for an
    ontology with a hierarchy, an equivalence, disjointness, domains, ranges,
    functional, symmetric and inverse properties, a sub-property, a declared
    datatype and an object property over `rdf:JSON`, beside a SHACL shape, the
    shaped-only output is byte-identical, and the ontology-complete output
    differs only in the OWL-derived properties' value schemas (each takes a
    node or a checked literal, as above; `payload` over `rdf:JSON` takes its
    literals and any node), the new `$defs/Literal`, and coverage precision
    (the datatype ranges' and the class ranges' cells, `payload` on `Org`
    among them, move from exact to `representation_approximation`).
- **SPARQL pre-binding:** every lane that binds a variable before evaluation —
  `sh:sparql`, a prepared execution's parameters, a request's substitutions, a
  node expression's scope and `sh:expression`'s `value` — now takes the one
  pre-binding rewrite SHACL pre-binding used. They still differ where SHACL's
  Appendix A refuses a construct, as set out below. On the prepared-parameter and request-substitution lanes the bound
  value now reaches the right arms of `OPTIONAL` and `MINUS`, sub-`SELECT`s
  and `EXISTS`, which the ordinary-substitution rewrite those lanes used before
  did not reach, and it is carried past every `GROUP BY` at any depth as a
  constant column: `SELECT $this (COUNT(*) AS ?c) …`, at the top or in a sub-`SELECT`, answers
  the bound node, an implicit group over no rows answers `COUNT` 0 with the
  bound node, and `HAVING` and `ORDER BY` read it. On the engine lanes every
  assignment of a pre-bound name joins with the bound value where it is made
  (§18.5), by one rule at every depth, a sub-`SELECT` that does not project the
  name and an `EXISTS` body included: with `$this` bound to `ex:a`,
  `BIND(ex:z AS $this)` leaves the assigning pattern no row, whatever else the
  query holds. No scope has a `$this` of its own. On the engine lanes
  `MINUS` sees the bound value on both sides whether or not a side mentions it,
  as rdflib's `initBindings` does, so `?x ex:p ?o MINUS { ?s ex:q ?w }` answers
  no row once `ex:q` has a triple, as `?x ex:p ?o MINUS { $this ex:q ?w }` does.
  A `VALUES` over a pre-bound name keeps the rows that agree with the bound
  value, joined where it is written at every depth: `VALUES $this { ex:b }`,
  with `$this` bound to `ex:a`, answers no row in the query's `WHERE` group. The SHACL lanes refuse
  `MINUS` per SHACL 1.2 SPARQL Extensions, Appendix A, and refuse `VALUES` by
  lane. A node expression and `sh:expression` (like a `sh:SPARQLFunction` body
  and a `sh:SPARQLTargetType` query) refuse a `VALUES` that mentions any name
  they pre-bind, so `VALUES ?value { … }` inside `sh:expression` is refused at
  load as `VALUES $this { … }` already was, while `VALUES ?v { true }` loads.
  A `sh:sparql` constraint, a component validator, a `sh:SPARQLTarget`'s
  `sh:ask` and a SPARQL rule refuse every `VALUES`, as the W3C SHACL case
  `unsupported-sparql-002` requires. A query that reads
  every pre-bound variable from the seeded row (no `GROUP BY`, sub-`SELECT`,
  nested `FILTER` or `BIND`, `OPTIONAL`, `MINUS`, `LATERAL`, `SERVICE`,
  `EXISTS` or property-function call) skips the rewrite's expression walk
  (the `prebind_seed_fast_path` bench times both), which takes the SHACL
  allocation pins to 40 / 77 / 48 / 79 per focus node ungoverned and
  56 / 97 / 64 / 103 governed.

  **Migration.** A query run with request substitutions or prepared-execution
  parameters that reads a bound variable inside `OPTIONAL`, `MINUS`, a
  sub-`SELECT` or `EXISTS` now sees the bound value there; before, the
  variable matched freely in those positions. To keep the old answer, rename
  the variable to a fresh one inside that position: `OPTIONAL { ?s2 ex:p ?y }`
  in place of `OPTIONAL { ?s ex:p ?y }`. An assignment of a pre-bound variable
  keeps only the rows whose assigned value is the bound one, where before an
  assignment no other pattern met answered with the assigned value; assign a
  fresh variable to keep that answer. This holds in a sub-`SELECT` that does not
  project the name too. rdflib 7.6's `initBindings` is not the reference for
  this: it rebinds a pre-bound name wherever the query assigns it, at the top
  level as in a sub-`SELECT`, and PurRDF follows the single join rule instead. A `VALUES ?s { … }` over a pre-bound
  name that lists other terms than the bound one has no row, at any depth. A `MINUS` carries the
  bound value on both sides, so a right side that shares no other variable
  with the left now subtracts every left row once it has a row, where before
  it subtracted nothing; share the variables it should match on, as
  `MINUS { ?x ex:q ?w }` beside `?x ex:p ?o` does.

- **`purrdf_core::RdfTriple` implements `Drop`:** this is what makes dropping a
  deeply nested term stack-safe (see Fixed). Rust forbids moving a field out of
  a `Drop` type, so code that destructures an owned `RdfTriple` by value, or
  moves `triple.subject`, `triple.object`, `triple.predicate` or
  `triple.location` out of one, no longer compiles (E0509). Use the new
  `RdfTriple::into_parts`, which returns `(subject, predicate, object,
  location)` without copying: replace
  `let RdfTriple { subject, predicate, object, location } = *boxed;` with
  `let (subject, predicate, object, location) = boxed.into_parts();`.
  Struct update syntax from an owned triple (`RdfTriple { location: None,
  ..other }`) is refused the same way; take `other` apart with `into_parts`
  and rebuild it with a struct literal, or assign the field in place.
  Construction with a struct literal or `RdfTriple::new`, destructuring and
  matching by reference (`&triple`, `&mut triple`), reading and assigning
  fields in place, and moving the `Box<RdfTriple>` out of
  `RdfTerm::Triple` are unchanged. `RdfTerm` itself has no `Drop`, so moving
  values out of its variants is unchanged too. Code that took deep chains
  apart by hand to avoid the old recursive drop can simply drop them.
- **SPARQL evaluator errors:** this change and the next alter behaviour
  without changing a signature, so a semver check cannot see them;
  `EvalError` is `#[non_exhaustive]`, so existing matches still compile.
  When a native host function returns its own `Err`, a native function or a property function's `open`/`next` panics, a
  function hits a resource ceiling, or a host sends an invalid protocol
  response, the query now fails with the new `EvalError::FunctionOperational`
  instead of `EvalError::Function`. `EvalError::Function` now means only that
  the request was refused: an arity, type or access-mode mismatch. Code that
  matches `EvalError::Function` to catch host failures must also match
  `FunctionOperational`. `EvalError` also gains `FunctionAdmission`, for a
  SPARQL-bodied function a dated invocation law refuses, and `XPathRegex`, for
  a refused native XPath compile, match or replacement.
- **SPARQL diagnostic codes:** `EvalError::diagnostic_code()` and
  `EvalError::code()` now return a code for `Internal`
  (`native-sparql-internal`), `CompositeBound` (`native-sparql-composite-bound`)
  and `FloatEnvironment` (`native-sparql-float-environment`), where they used
  to return `None`. They also return one for `FunctionOperational`
  (`native-sparql-function-operational`) and `XPathRegex` (the exhausted
  resource's code, otherwise `native-sparql-xpath-operational`). The
  native engine used to report these failures as `native-sparql-query-eval`,
  so `RdfDiagnostic::code`, and the error codes the CLI, C ABI, Python and
  WebAssembly surfaces report, change to the specific codes.

### Added

- **`purrdf-glob` compiled Unicode globs:** a new crate, also at
  `purrdf::glob`, compiles one anchored Unicode glob in the `purrdf-glob-v1`
  language. Callers choose `Mode::Text` or `Mode::Path` semantics, a literal
  or an explicit lexical `IriComponent`, and a work allowance; percent escapes
  stay lexical and an absent IRI component differs from an empty one.
  Compilation validates before allocating, matching allocates nothing, and
  exhaustion publishes no partial decision. `CompiledGlobSet` holds an ordered
  pattern set and returns every matching source index, keeping order, overlaps
  and duplicate occurrences under one aggregate allowance. The `rdf` module
  executes RDF-authored ordered plans (`purrdf-glob-rdf-v1`) against original
  RDF literal or IRI terms and exports the plan description, evaluation and
  input identities, exact work and RDF 1.2 quoted membership statements, with
  every vocabulary role supplied by the caller. The CLI adds `purrdf glob` and
  `purrdf glob-set`, which require an explicit `--mode`, `--surface` and
  `--max-work`, and `purrdf glob-rdf`, which reads Turtle or N-Triples with an
  explicit `--vocabulary` mapping and `--max-work` and writes nothing on
  refusal.

- **`purrdf-toml` TOML 1.1 codec:** a new crate, also at `purrdf::toml`,
  analyzes TOML 1.1 source into a typed, ordered stand-off model and projects it
  into an RDF 1.2 dataset whose source cover reconstructs every original byte,
  including comments, whitespace, CRLF and numeric spellings. `analyze`,
  `project`, `encode` and `decode_document` take an explicit `Profile`;
  `Profile::standard()` selects the shipped vocabulary and `Profile::new` a
  caller's own. `decode_document` reparses the reconstructed bytes and verifies
  the whole projected metadata graph, refusing fabricated values, paths,
  parentage or keys. Parsing, projection and destruction use heap frames and a
  flat arena, so nesting consumes no native stack per level, and grammar and
  resource refusals carry byte, line and column locations.

- **Maintained Datalog models:** `seminaive::Maintained` keeps one materialized
  model across signed `maintenance::ChangeBatch` transactions over original
  dictionary IDs, so recursive deletion, alternative groundings and stratified
  negation update only affected facts. `apply`, `begin`, `resume` and
  `resume_until` retain a transaction under a cumulative work allowance, with
  `MaintenanceError::WorkLimit` stating consumed and required work;
  `apply_next` polls a `ChangeSource`. `model_delta` and `applied_watermark`
  publish exact net deltas only at completed host watermarks, and `relation`
  distinguishes complete, sound lower-bound and withheld extensions. Witnesses
  are repaired even when membership is unchanged. `store::ReclaimingInterner`
  with `Maintained::new_reclaiming` retires unused terms for fresh-term
  streams. Entailment refutation uses the maintained model.

- **Resumable Datalog sessions with certified partial models:**
  `EvaluationSession` retains rule, round, ordered publication and stratum
  progress, including positive joins, guard batches, negative searches and
  factored products, across resource and stop refusals; raising a cumulative
  allowance resumes without replaying completed joins or guard calls. A
  `SessionContext` binds caller-supplied snapshot, guard-semantics and
  evidence-regime identities beside the authored-program digest, and a changed
  binding or derivation mode is refused before work. `partial_model` exposes
  published certified facts, independently checkable recorded derivations and
  per-stratum `StratumStatus`; only completion permits `take_complete`.

- **Fallible evidence queries and scoped retrieval:** lazy sources that can
  fail mid-query are accepted by `NativeSparqlEngine`'s
  `query_evidence_answer_fallible_view`, `query_evidence_status_fallible_view`,
  `query_interned_evidence_fallible_view` and
  `execute_witnessed_evidence_fallible`, and by retrieval's
  `search_scoped_fallible` and `execute_scoped_in_read`. A shared
  `ReadOperation` (entered through `with_fallible_read`) keeps the original
  typed read error through deferred reads, fusion and the final checkpoint;
  provider refusal or stream failure publishes no partial answer. Answer tiers,
  unknowns and evidence receipts keep their meaning.

- **Caller-owned loss profiles:** `purrdf_core::loss::LossProfile::builtin()`
  extends with `LossDefinition` rows declaring caller-owned projection pairs
  and loss codes; pass the profile to `check_ledger_sound_in` and
  `LossLedger::render_json_in`. Conflicting registered meanings return
  `LossProfileError` with the rejected definition. Soundness also checks that
  each entry belongs to the requested conversion pair, so a reused code can no
  longer hide a mismatched pair; the explicit check returns a borrowed
  `LossSoundnessError`. Builtin renders and generated loss matrices keep their
  bytes, and a custom profile never affects another caller's builtin profile.

- **Structured TEXT errors:** `TextError`, `TextDeltaError`, capacity,
  substring and phonetic refusals expose every retained field (native causes,
  ordered HTML diagnostics, original terms, generation identities, work
  counters and limits) through borrowed structured inspection, and single
  native causes through the standard error source.

- **Dated SHACL profiles:** `purrdf_shapes::ShaclProfile` selects the law a
  validation follows: `ShaclProfile::LEGACY` (the default, unchanged),
  `ShaclProfile::REC_20170720` (the SHACL Recommendation of 20 July 2017) and
  `ShaclProfile::WD_20260918` (SHACL 1.2 Core of 17 September 2026 with the
  SPARQL Extensions of 18 September 2026). Each dated profile names its exact
  Core, SPARQL and XPath specifications, and `ShaclProfile::from_id` refuses
  any other identifier with `UnsupportedProfile` rather than picking a nearby
  date. `ValidationOptions::with_profile` selects one. Pre-binding admission
  follows the selected law. Both refuse `MINUS`, `SERVICE` and assignment to a
  potentially pre-bound variable. The draft's potentially pre-bound variables
  are `this`, `value` and the parameters alone, so under it `$shapesGraph`
  and `$currentShape` are never pre-bound: they are the query's own
  variables, whether or not the validation has a value for them. The Recommendation also refuses every
  `VALUES` and a subquery that does not project a potentially pre-bound
  variable; the draft refuses a `VALUES` only when it names one, and has no
  subquery rule. A refusal is a typed `AdmissionRefusal` with its reason,
  query role and variable.
- **Complete SHACL reports:** `CompleteValidationReport` sits beside the
  unchanged `ValidationReport`. Each result carries its `sh:sourceConstraint`
  (the actual `sh:sparql` value), recursive `sh:detail` results with their own
  evidence, and messages chosen in the dated order: a bound `?message`, then
  the constraint's or validator's messages, then the component's. Its graph
  (`to_graph`) keeps a report root and records, for every emitted blank node,
  the data or shapes blank node it stands for, so independently parsed
  documents never share blank identity. `CompleteValidationError` keeps
  admission, semantic, resource, source and native XPath refusals apart from a
  verdict.
- **Complete reports at the shared boundary:** `purrdf_validate` adds
  `validate_complete_sources`, `validate_complete_documents`,
  `validate_complete_product`, `complete_report_payload`,
  `complete_report_to_json`, `complete_report_to_sarif_string`,
  `complete_profile` and `complete_validation_status` with
  `CompleteValidationStatus`. Existing functions, JSON payloads and SARIF
  output are unchanged under the default profile.
- **Community SHACL corpus:** `corpora/community/` holds 64 SHACL cases with
  inline expected reports and an agent review of every expectation. Their
  applicable dated executions (57 under the Recommendation, 58 under the
  draft) run through the fresh, prepared and restored-product routes in
  `cargo test -p purrdf-sparql-conformance --test community_conformance`, and
  the `community-conformance` binary writes their records and EARL. The new
  unpublished `purrdf-conformance-kit` compares each complete report with its
  expectation by graph isomorphism in source context. A catalog profile with no
  built-in dated law is counted as unsupported, apart from failures. The
  conformance matrix gains the row.
- **Test vocabularies:** `purrdf_iri::vocab` adds the W3C test manifest
  (`mf`), result set (`rs`), SHACL test (`sht`) and EARL (`earl`) terms.
- **`purrdf-hash` BLAKE3 subtree primitives:** `blake3::ChainingValue`,
  `left_subtree_len`, `subtree_chaining_value`, `merge_subtrees_non_root` and
  `merge_subtrees_root`, the same primitives and rules as the `blake3` crate's
  `hazmat` module, over the existing tree code. BLAKE3's hash is the root of a
  Merkle tree over 1 KiB chunks, so a piece of an input can be proved to belong
  to its hash by its siblings' chaining values alone: verified streaming,
  verified range reads, and erasure shards checked against the identity of the
  artifact they belong to. A subtree at a misaligned offset panics rather than
  yielding a chaining value no input produces. Zero new dependencies.

- **SPARQL 1.0 conformance corpus:** the W3C data-r2 suite (all 29 groups,
  482 cases, and the sort extension) is vendored byte-for-byte and graded in
  `make conformance` beside the SPARQL 1.1 and 1.2 corpora. The extension's
  one case, whose frozen order RDF 1.2 makes unreachable, is graded in its
  own row against the SPARQL 1.2 order. The conformance
  harness now reads DAWG RDF result sets (ASK booleans, `rs:index` ordering,
  unbound rows), honors `mf:LaxCardinality` for `REDUCED`, loads
  `FROM`/`FROM NAMED` documents under their query IRIs, and runs each case
  with exactly the `mf:requires` features it names, refusing a feature it
  does not model. Every vendored file keeps its upstream name: a manifest
  named like a discovered one may include others only as an index, which the
  runner checks for coverage and never runs through its members. The vendored
  files no upstream manifest lists are accounted for in their own
  conformance row.
- **SPARQL `=` extension for language-tagged strings:**
  `QueryOptions::with_disjoint_language_strings(true)` makes `=` answer
  `false`, rather than a type error, when a language-tagged string meets an
  ill-typed literal or one of an unrecognized datatype, as in
  `"xyz"@en = "xyz"^^xsd:integer`; `!=` is then `true`. This is the
  operator extension SPARQL 1.2 §17.3.1 permits and the W3C tests call
  `mf:KnownTypesDefault2Neq`. The default stays the SPARQL 1.2 answer, an
  error.
- **`purrdf_lex::walk::write_debug_scalars`:** the heap-walking `Debug` writer
  for scripts whose leaves are standard strings and unsigned integers
  (`DebugScalar`). Unlike `write_debug`, it applies every option of the
  caller's formatter to those leaves exactly as `#[derive(Debug)]` does,
  including newline fill in the pretty form, and it fails only when the
  caller's writer does.
- **Remembered empty named graphs:** `GraphExistenceMode`
  (`RememberEmpty`, the default, and `Implicit`, the opt-out),
  `MutableDataset::new_with_graph_existence`, `MutableDataset::graph_existence`,
  `MutableDataset::create_named_graph`, `MutableDataset::has_named_graph`,
  `MutableDataset::try_withdraw_named_graph_declarations` and
  `QueryOptions::with_graph_existence`. In `RememberEmpty`, `CREATE GRAPH`
  registers an empty graph and refuses an existing one
  (`rdf-ir-graph-already-exists`); `CLEAR` keeps the graph and `DROP` removes
  it; removing a graph's last row keeps it; `ADD`, `COPY` and `MOVE` create
  their destination even from an empty source. A missing `CLEAR`/`DROP` target
  or transfer source is refused (`native-sparql-update-graph-missing`) before
  anything is touched. `SILENT` turns each refusal into a no-op. Python's `Store` and `MutableDataset` take a
  keyword-only `remember_empty_graphs` (default `True`) and gain `add_graph` and
  `named_graphs`. UPDATE, governed UPDATE, checkpoint and compaction retain the
  selected policy. WASM snapshots, matches and synchronous/asynchronous UPDATEs
  also retain their source dataset policy.
- **SPARQL governed UPDATE stop checks:** governed UPDATE checks the stop
  signal after freezing its result and before publishing it, and before each
  declaration a bulk `DROP`/`CLEAR NAMED`/`ALL` withdraws. The governor profile
  version advances; the charge schedule is unchanged.
- **Arbitrary-precision numeric tower (`purrdf_xsd::exact`):** exact
  `xsd:integer`, `xsd:decimal` and `owl:rational` values of any size, beside
  the bounded types, which are unchanged. `exact::Integer` keeps values that
  fit `i128` inline and computes on them with checked machine arithmetic.
  `exact::Decimal` has a big-integer coefficient and an unbounded scale.
  `exact::Rational` is reduced and closed under `+ − × ÷`. All three parse
  (`FromStr`) lexical forms of any length and render the XSD 1.1 canonical
  form, matching the bounded types byte for byte where both hold the value.
  `+ − ×` are exact. Decimal division follows a caller-chosen `DivisionPolicy`: a scale
  and one of nine `Rounding` directions, or the exact expansion, refusing a
  non-terminating quotient. The default is eighteen digits truncated, the
  bounded quotient. Conversions to `f64`/`f32` round once, to nearest with
  ties to even, subnormals included, using integer arithmetic only.
  Conversions from them are exact. Narrowing to `i128`, `i64`, the bounded
  `Decimal` or the bounded `Rational` returns the value or an `ExactError`
  carrying its XPath F&O error code (`FOCA0003`, `FOCA0001`, `FOAR0002`); it
  never wraps or rounds. Division by zero is `FOAR0001`, and `NaN` or an
  infinity is `FOCA0002`. Each operation has a cost method (`add_cost`,
  `mul_cost`, `div_cost`, `cmp_cost`, `render_cost`, `to_float_cost`,
  `pow_cost`, …) that returns an `exact::Cost` of work and working bytes from
  the operand sizes in constant time, so a governor can refuse an operation
  before it allocates. `exact::cost::Shape` reads a value's size from the value
  or from its lexical form without parsing it, and `sum_chain` and
  `compare_chain` price a whole `SUM` or sort before it runs.
  `Decimal::cmp_f64` and `Integer::cmp_f64` compare an exact value with a
  double exactly, in time linear in the value.
- **Exact numerics are the default:** `XsdValue` gains `BigInteger { value:
  exact::Integer, datatype }` and `BigDecimal(exact::Decimal)` for the
  integer-family and decimal values the bounded `Integer` (`i128`) and
  `Decimal` (`i128` mantissa, eighteen fractional digits) variants cannot
  hold. A value either holds keeps its bounded variant, so existing matches
  and payloads are unchanged, and `XsdValue::from_exact_integer` /
  `from_exact_decimal` choose the variant. `to_exact_integer`,
  `to_exact_decimal` and `is_exact_numeric` read either. The numeric
  operators (`numeric_add`/`sub`/`mul`/`div`, unary minus, `abs`, `ceil`,
  `floor`, `round`, `numeric_cmp`, `numeric_total_cmp`, `value_cmp`,
  `value_total_cmp`) compute on the bounded path and continue on the tower
  where it would overflow. Conversion to `xsd:float`/`xsd:double` rounds
  once, to nearest. `numeric_cost`, `numeric_unary_cost`,
  `numeric_to_float_cost` and `numeric_render_cost` give the `exact::Cost` of
  an operation on a value past machine words, and zero otherwise.
  The SPARQL evaluator (tree and VM), SHACL (`sh:minInclusive` and the other
  range constraints, `sh:in`, `sh:hasValue`, SHACL-SPARQL), OWL 2 DL/RL value
  identity and data ranges, CDT `=`/`<`, CSVW cell facets and every binding's
  canonical lexical form use these values.
- **`DivisionPolicy` for SPARQL decimal division:** `QueryOptions::with_division`
  and `EvalCtx::with_division_policy` select the scale and rounding of an
  `xsd:integer`/`xsd:decimal` quotient, or the exact quotient. The default
  keeps eighteen fractional digits, truncated toward zero, at every magnitude.
  Under `DivisionPolicy::Exact` a non-terminating quotient is a SPARQL
  expression error, as division by zero is: the value is unbound, `COALESCE`
  catches it, and a governed query counts it as F&O `FOAR0002` in its
  evidence. `AVG` and `/`
  share the policy, so `AVG(?x)` and `SUM(?x) / COUNT(?x)` always agree, and
  `fold_values_with_division` gives a value-level fold the same policy.
  `DivisionPolicy` has one text form (`FromStr`/`Display`): `exact`, a scale
  `N`, or `N:ROUNDING` such as `5:half-even`. The CLI's
  `purrdf query --division POLICY`, the C ABI, the WebAssembly package and the
  Python binding take it.
- **Typed F&O error codes:** `XsdError::code()` and `ExactError::code()` return
  the XPath F&O 3.1 error of a numeric refusal as `purrdf_xsd::ErrorCode`
  (`FOAR0001` division by zero, `FOAR0002` a quotient the division policy
  cannot express, `FORG0001` a malformed lexical form or a derived type past
  its facets, `FOCA0002` `NaN` or an infinity cast to an exact type,
  `FOCA0001`/`FOCA0003`/`FOCA0006` the bounded narrowings, `XPTY0004` a type
  error). `XsdError::presentation()` gives the failure as a typed
  `DiagnosticPresentation` with the code as an argument.
  `GovernorEvidence::expression_errors` counts, per code, every numeric error a
  governed query absorbed into an unbound value, as SPARQL requires for an
  expression error; the C, WebAssembly and Python evidence carry the counts.
  A governed `purrdf query` or `purrdf update` writes them to stderr, after
  the governor report, as a `purrdf-expression-errors 1` block of
  `absorbed CODE COUNT` lines; a run that absorbed none writes no block.
  `purrdf update` takes `--division` as `purrdf query` does.
- **ShEx exact facet bounds:** `purrdf_shex::ExactSchema` (`parse_shexc`,
  `parse_shexj`, `from_schema`, `resolve_imports`, `to_shexj`) keeps every
  numeric facet bound as written, per node constraint, and `validate_exact` /
  `validate_shape_map_exact` compare against it in the XSD value space.
  `purrdf shex` and the Python binding use it. The existing parsers and AST
  are unchanged, except that a DOUBLE bound past the double range
  (`MAXINCLUSIVE 1E400`, in ShExC or ShExJ) is now the infinity of its sign,
  as the same lexical form is in the data, where every parser used to refuse it.
- **`BigInt` arithmetic:** `purrdf_xsd::bigint::BigInt` gains truncating
  division with a quotient (`div_rem`, `div_rem_pow10`), `pow`, `gcd`, `abs`,
  `signum`, `pow10`, `decimal_digits`, `trailing_decimal_zeros`, `limb_len`,
  `to_i64`, a Karatsuba product (`mul_fast`, above `KARATSUBA_THRESHOLD`
  limbs), `Display`, and `+ − ×` and negation as operators.
- **XSD decimals:** `Decimal::from_integer` builds a decimal from an integer
  exactly, and `Decimal::from_f64_closest` gives the decimal closest to a
  binary64 value. It returns `None` for `NaN`, the infinities and magnitudes of
  2^127 or more.
- **SPARQL parse diagnostics:** `ParseError::presentation()` returns the parse
  failure as a typed `DiagnosticPresentation`. Each kind of failure has a stable
  message identity (`sparql-parse-lex`, `sparql-parse-syntax`,
  `sparql-parse-unsupported`, `sparql-parse-iri`, `sparql-parse-cdt-arity`)
  and exact typed arguments: byte offsets and counts as unsigned integers, and
  reasons, IRIs and construct names as text. `Display` renders through it, and
  its English is unchanged byte for byte. When `purrdf-iri` refused the IRI
  in an IRI failure, its presentation nests that condition as `detail`, for
  example `iri-bad-percent-encoding` with an unsigned `offset`, or
  `iri-relative-no-base`. The public fields of `ParseError::Iri` are
  unchanged.
- **Engine parse diagnostics carry the presentation:** for query and update
  parse failures from the native engine, `RdfDiagnostic::presentation()` now
  returns `Some`, where it used to return `None`. `RdfDiagnostic::to_json()`
  adds a `presentation` key to them. The message, the human `detail` (still
  absent) and the existing keys are unchanged.
- **`IriError::presentation()`:** an IRI failure as a typed presentation, with
  stable `iri-*` identities, typed fields and English identical to `Display`.
  `RdfDiagnostic::from_iri` builds through it, and its output is unchanged.
- **C ABI:** `purrdf_error_presentation_json` now returns the `sparql-parse-*`
  presentation, and any nested `iri-*` detail, for a SPARQL parse refusal
  from `purrdf_query`, `purrdf_query_json`, `purrdf_query_governed`,
  `purrdf_query_entailment_governed` and `purrdf_update_governed`. Byte offsets
  are typed unsigned decimal strings. Status codes and error messages are
  unchanged.
- **Python:** every `ValueError` raised by `query`, `query_governed`,
  `query_entailment_governed`, `prepare`, `update` and `update_governed`
  gains `message_id` and `presentation` attributes. The presentation is a
  dict of typed parameters with exact `int` offsets and a nested `detail`.
  Both attributes are `None` when the failure has no typed presentation, as
  for an argument refusal or an unknown entailment regime. The exception
  type, message and `args` are unchanged.
- **WebAssembly:** an error thrown or rejected for a SPARQL failure gains a
  `presentation` property holding `messageId`, typed `parameters` and an
  optional `detail`. The TypeScript declarations add `DiagnosticPresentation`,
  `DiagnosticParameterValue` and an optional `PurrdfError.presentation`. The
  `message` and `code` are unchanged, and the property is absent when the
  failure has no typed presentation.
- **Diagnostic presentations in `purrdf-lex`:** `DiagnosticValue`,
  `DiagnosticParameter`, `DiagnosticPresentation` and
  `DiagnosticPresentationError` now live in `purrdf_lex::diagnostic`, so crates
  below `purrdf-core` can build presentations. `purrdf_core::diagnostic` and the
  `purrdf_core` crate root re-export the same types, so existing paths and
  matches keep compiling.
- **Premise-IRI check:** `purrdf_validate::check_premise_iris` checks that
  every premise IRI is an absolute IRI, using the workspace IRI parser. A
  refusal is a `PremiseIriError`. It names the IRI and has a typed
  `presentation()` (`premise-iri-not-absolute`) whose `detail` is the IRI
  parser's own `iri-*` condition. A relative reference has the detail
  `iri-not-absolute-by-grammar.absent`; the empty string has `iri-empty`.
- **SPARQL query census and prepared parameters:**
  `purrdf_sparql_algebra::Query::for_each_variable` visits every variable a
  query mentions, including `CONSTRUCT` template slots and `DESCRIBE` targets.
  `PreparedExecution::check_parameters_mentioned` refuses declared parameters
  the query never mentions and names them, with presentation
  `sparql-prepared-parameter-unmentioned`. `prepare_execution` itself still
  admits such a parameter, because SHACL-SPARQL declares `$this` for
  constraints that may not read it.

- **core:** `loss::LOSS_EMPTY_NAMED_GRAPH_DROPPED`, a runtime loss code. The
  loss registry and `generated/transcode-loss-matrix.json` list it for every
  syntax pair whose source can write an empty named graph and whose target
  cannot. `pair_loss_ledger` never emits it as a contract entry.
- **rdf:** `NativeRdfFormat::carries_empty_named_graphs` and
  `empty_named_graphs_dropped(dataset, format, selection)`. The function lists
  the declared empty named graphs that a whole-dataset serialization to a format
  drops.
- **Host loss reports:** each host now reports the number of declared empty
  named graphs a whole-dataset serialization drops. Every existing field, key
  and prototype is unchanged.
  - Python: `SerializeLoss.empty_named_graphs_dropped` (also shown in its repr).
  - wasm: `SerializeLoss.emptyNamedGraphsDropped`, with the TypeScript
    declaration updated.
  - C: the new function `purrdf_serialize_empty_named_graphs_dropped`. The C ABI
    moves to 0.9.0 because a library exporting a new symbol must not report the
    shipped 0.8.0.
- **core:** `MutableDataset::declare_named_graph` and
  `MutableDataset::declared_named_graphs`. A graph declared this way follows the
  same withdrawal rules as an input declaration: `DROP` or `CLEAR` of the graph,
  `DROP NAMED`/`DROP ALL`, or removing its last row withdraws it. A declaration
  no operation touches survives. `declared_named_graphs` omits withdrawn base
  declarations. `visit_blank_identities` visits a declared blank graph name, so
  fresh blanks never reuse it, and `snapshot_view_with_limits` charges
  declarations before it freezes the delta. Declaring a base graph again after
  a mutation withdrew it restores the base's declaration, so the graph is listed
  once.
- **events:** `RdfEventSink::named_graph`, a method with a default
  implementation that ignores the event. The frozen-dataset replay emits it for
  each named graph, and `DatasetSink` keeps the declarations it receives.
- **rdf:** `flat_dataset_from_quads_declaring`.
- **core: dated native XPath regular expressions:** `xsd_regex::xpath` compiles
  and runs a pattern under an explicitly selected dated law. `Profile::Xpath20`
  is XPath and XQuery Functions and Operators 2.0 (Second Edition, 2010-12-14)
  and `Profile::Xpath31` is Functions and Operators 3.1 (2017-03-21).
  `Profile::name` gives the stable names `xpath-2.0-2010-12-14` and
  `xpath-3.1-2017-03-21`, `Profile::ALL` lists both, and `Profile::from_name`
  accepts exactly those names, with no case folding or undated alias. Both
  laws admit backreferences; only 3.1 admits non-capturing groups and the `q`
  flag. `compile(profile, pattern, flags, limits)` returns a
  `CompiledPattern` with `is_match`, `find` (ordered `Captures`) and
  `replace_all`. `Limits::new()` holds finite production bounds for each
  `Resource`: pattern source bytes (64 KiB), compile steps, program nodes,
  compile slots, match steps, match states, match slots and replacement
  output bytes. `Limits::with` replaces one bound, and zero withholds that
  resource. `Error` keeps the syntax verdicts (`Flags`, FORX0001; `Syntax`;
  `EmptyMatch`, FORX0003; `Replacement`, FORX0004) apart from the operational
  `Resource` refusal and `Allocation` failure. `Error::is_operational` tells
  them apart, and each `Resource::code` is a stable `xpath-*` diagnostic code.
  `PatternCache` keeps one successful program under its exact law, source and
  flags, and admits it again under the current limits on every reuse. The
  existing `xsd_regex::compile` compatibility API is unchanged.
- **SPARQL, SHACL and ShEx selection doors:**
  `NativeSparqlEngine::with_xpath_regex(profile, limits)` selects a law for
  every `REGEX` and `REPLACE` the engine evaluates, and
  `QueryOptions::with_xpath_regex` selects one for a single request; an unset
  request inherits the engine's selection. `PreparedShapes::with_xpath_regex`
  returns an `XPathPreparedShapes` that applies the law to `sh:pattern`,
  SHACL-SPARQL targets, constraints and SHACL-AF functions, including the
  governed and change-set paths. `purrdf_shex::validate_with_xpath` and
  `validate_shape_map_with_xpath` apply it to string-facet `PATTERN`s;
  `validate_exact_with_xpath`, `validate_shape_map_exact_with_xpath` and
  `XPathValidator::exact` do so over an `ExactSchema`, keeping its numeric
  facet bounds exact, and the `shex` command and Python `shex.validate` take
  that path under a selected law. In
  `purrdf-validate`, `xpath_regex::parse_profile` maps a host's name to a
  profile, `xpath_regex::sparql_engine` and `xpath_regex::query_options`
  build the selected SPARQL engine or request, and every SHACL entry point
  that evaluates a pattern gains a `*_with_xpath_regex` twin. A pattern the
  law does not define is still the host's ordinary invalid-pattern outcome: a
  SPARQL expression error, a SHACL finding or a failed ShEx facet. A resource
  or allocation refusal is an operational failure with its `xpath-*` code. It
  never becomes an unbound value, a `false` filter, a partial answer or a
  conforming report, and a refused UPDATE changes nothing. Without a selection,
  every surface keeps its compatibility regular expressions.
- **CLI:** `--xpath-regex <PROFILE>` on `query`, `update`, `validate`, `shex`,
  `rules` and `node-expr` selects a dated law by its exact name. Any other
  name is a usage error (exit 2) that lists the accepted names. A resource
  refusal fails the run (exit 1), names the resource and writes no answers,
  dataset, report or output. `rules --check` refuses the flag, and
  `shapes lint`, which compiles no pattern, does not offer it.
- **Python:** `purrdf.XPATH_REGEX_PROFILES` lists the accepted names. An
  `xpath_regex=` keyword selects a law on every SPARQL entry point (`query`,
  `query_governed`, `query_entailment_governed`, `update`, `update_governed`
  and `Store.prepare`, on `Store` and `MutableDataset`, and the rdflib layer's
  `Graph.query` and `Graph.update`), on `shapes.validate`,
  `Shapes.validate_nt`, `Shapes.validate_store`, `PreparedShapes.validate_nt`,
  `PreparedShapes.validate_store_changes`, `shapes.entail`,
  `shapes.apply_rules` and `shapes.eval_node_expr`, and on `shex.validate`.
  An unknown name raises `ValueError` listing the accepted names. A resource
  refusal raises `ValueError` carrying its `xpath-*` code.
- **WebAssembly:** an `xpathRegex` option, typed `XPathRegexLaw`, on every
  evaluating `QueryEngine` method and its asynchronous twin, and on the
  Cloudflare adapter. It is a trailing argument on `Dataset.query`,
  `queryRawConfigured`, `queryRawWithContext`, `shaclValidateToSarif`,
  `shaclValidateChangesToSarif`, the four `shaclProductValidateToSarif…`
  entries, `shaclEntail`, `shaclApplyRules` and `shaclEvalNodeExpr`; the
  asynchronous SHACL twins take it in their options object. An unknown name
  throws with the code `purrdf-wasm-options`. A resource refusal throws, or
  rejects, with the resource's `xpath-*` code.
- **C ABI:** fourteen `*_xpath_regex` twins take a nullable `regex_profile`
  before their out-parameters (before `governors` on the governed ones):
  `purrdf_query_xpath_regex`, `purrdf_query_json_xpath_regex`,
  `purrdf_query_governed_xpath_regex`,
  `purrdf_query_entailment_governed_xpath_regex`,
  `purrdf_update_governed_xpath_regex`,
  `purrdf_shacl_validate_to_sarif_xpath_regex`,
  `purrdf_shacl_validate_changes_to_sarif_xpath_regex`,
  `purrdf_shapes_product_admit_xpath_regex`,
  `purrdf_shapes_product_admit_expecting_xpath_regex`,
  `purrdf_shapes_product_rebuild_xpath_regex`,
  `purrdf_shapes_product_rebuild_expecting_xpath_regex`,
  `purrdf_shacl_entail_to_ntriples_xpath_regex`,
  `purrdf_shacl_apply_rules_xpath_regex` and
  `purrdf_shacl_eval_node_expr_xpath_regex`. NULL behaves exactly like the
  entry point without the suffix. An unknown name is
  `PURRDF_STATUS_INVALID_ARGUMENT`. The new status
  `PURRDF_STATUS_REGEX_RESOURCE_ERROR` (13) reports a resource refusal, and the
  call then writes no result, answer, report or dataset. These symbols and
  the status belong to the same 0.10.0 C ABI; no existing prototype changes.
- **SPARQL pre-bound declarations:** `SparqlParser::with_prebound_variables`
  declares the variables a caller binds before evaluation, which the grouping
  constraint then reads as constants, and `QueryOptions::with_declared_prebound`
  declares further names a caller's context binds without supplying a value.
  A prepared execution reads the declared names too.

### Deprecated

- **SPARQL pre-binding lane:** `ShaclPrebinding` and
  `QueryOptions::with_prebinding` are kept for compatibility and have no
  effect: both values select the one pre-binding rewrite every lane takes.

- **Anonymous OWL class expressions in developer schemas:** the
  ontology-complete schema surface no longer refuses an `rdfs:subClassOf` or
  `owl:equivalentClass` whose object is a blank node. Restrictions
  (`owl:someValuesFrom`, `owl:allValuesFrom`, `owl:hasValue`, `owl:hasSelf`,
  and the unqualified and qualified cardinalities over `owl:onClass` or
  `owl:onDataRange`) and the boolean forms (`owl:unionOf`,
  `owl:intersectionOf`, `owl:complementOf`, `owl:oneOf`) are recorded with
  their source axiom and inherited by subclasses. Data ranges
  (`owl:onDatatype`/`owl:withRestrictions`, `owl:datatypeComplementOf`, a
  literal `owl:oneOf`) are read as fillers and ranges, and
  `[ owl:inverseOf p ]` wherever a property expression may stand. A
  restriction on `inverse(p)` whose inverse is named is read as one on that
  property. A class constructor on an IRI (`ex:Day owl:oneOf ( … )`, an IRI
  typed `owl:Restriction`) is read as the equivalence OWL gives it. The JSON
  Schema and OpenAPI carriers, and the LinkML, TypeScript, GraphQL and
  Pydantic emitters that read them, carry what a schema can state:
  `owl:allValuesFrom` as a value constraint (`owl:Nothing` forbids the
  property), existentials and minimums as required properties with
  `contains`/`minContains`, maximums as `maxItems`/`maxContains`, datatype
  facets through the SHACL value compiler, an `owl:oneOf` of individuals as an
  `@id` enumeration, the complement of a named class as an `@type` exclusion,
  and a union of restrictions as `anyOf`. An inherited restriction is
  referenced through `allOf` to its owner's `<Class>.Restriction.<property>`
  fragment rather than copied, so output grows with the restrictions and not
  with the hierarchy's depth. A restricted property is emitted on the class
  carrying the restriction whatever its declared domain. An existential
  restriction places the class in the property's domain. A universal
  restriction on `owl:Thing` is a global range. Coverage rows that closed-world
  readings, class fillers, datatype complements or unchecked lexical forms
  touch are marked `representation_approximation`. The new
  `SchemaCompileRequest::class_expression_report` and
  `compile_schema_with_class_expressions` return a class-expression manifest
  (`SchemaClassExpressionReport`) listing every axiom with an anonymous class
  once: subclass, equivalence, disjointness (`owl:disjointWith`,
  `owl:AllDisjointClasses`, `owl:disjointUnionOf`), class assertions,
  anonymous `owl:hasKey` and datatype definitions. Each component carries its
  `SchemaExpressionOutcome` (projected, approximated, unrepresented or
  excluded) and reason, on the axiom or on each class that owns it. A class
  below an owner has its own row only where its outcome differs.
- **Refusals:** nothing the surface accepted before is refused. A malformed
  anonymous part of an axiom it used to skip (an anonymous subject,
  disjointness, a class assertion, an IRI-named constructor, `owl:hasKey`) is
  reported as unrepresented. An `owl:ObjectProperty` ranging over a datatype is
  refused only where the datatype is XSD, `rdfs:Literal`, `rdf:langString` or
  declared. A malformed expression in an axiom the surface always read (the
  object of `rdfs:subClassOf`, `owl:equivalentClass`, `rdfs:subPropertyOf`,
  `owl:equivalentProperty` or `owl:inverseOf` with a named subject, or an
  `rdfs:domain`/`rdfs:range`) is refused with a typed error when it has:
  a restriction without `owl:onProperty` or `owl:onProperties`; a
  cardinality that is not a non-negative integer literal; a
  qualified cardinality without its qualifier, or a qualifier without a
  qualified cardinality; `owl:hasSelf` other than `true`; `owl:onProperties`
  with a facet other than `owl:someValuesFrom`/`owl:allValuesFrom`; a blank
  node with no construct, or one that is both a class expression and a data
  range (OWL 2 Mapping to RDF Graphs §3.2.1); a mixed or triple-term
  `owl:oneOf`; an anonymous property
  expression that is not `owl:inverseOf` one named property; a non-IRI
  `owl:onDatatype`, a facet restriction that is
  not a blank node with one literal facet, or an `xsd:pattern` outside the XSD
  regular-expression language; an ill-formed or cyclic RDF list; an expression
  that contains itself; or a data range where a class expression is
  required. Every property's values are read
  by the OWL 2 RDF-Based Semantics (§5.3) with the OWL 2 datatype map,
  whatever its declared kind: any node (an IRI may denote a data value) or any
  well-typed literal (`"abc"^^xsd:integer` is none). A property no range
  constrains states that exactly; a data range holds literals to its value
  space and admits a node unjudged, and a class range or filler admits a
  well-typed literal unjudged, both approximations, except that a class
  disjoint with `rdfs:Literal` rejects every literal exactly. A literal
  `owl:hasValue` on an object property is `∃p.{v}`, as an individual one on a
  datatype property is, and `owl:hasSelf` on a datatype property is the self
  restriction. Each cell carrying an `owl:hasSelf` is an approximation.
  `owl:Nothing`, and an expression empty by its form (`¬owl:Thing`, the empty
  enumeration), admits no value in any range or filler position, reported
  exactly: an existential or a qualified minimum over it leaves the class no
  instance. A class below `owl:Nothing`
  (`A ⊑ ⊔()`) admits no instance: its definition is `false`. A blank node carrying several readings is their
  conjunction, as the OWL 2 RDF-Based Semantics gives each of them the node's
  class extension: several facets or values of one facet on a restriction
  node (an OWL 1 `owl:minCardinality` beside `owl:maxCardinality`,
  `owl:someValuesFrom` beside `owl:allValuesFrom`, two `owl:someValuesFrom`
  values), several properties or qualifiers, or several class constructs on
  one node. A facet over a defined datatype (`ex:Percent owl:equivalentClass
  xsd:integer[≥ 0]`) restricts the definition's values, and is reported as an
  approximation where it has no exact form over them. Constructs are read by
  their meaning rather than refused: a union of no class is `owl:Nothing` and
  an intersection of none `owl:Thing` (of no data range, the empty range and
  `rdfs:Literal`), a union or intersection of one member is that member,
  repeated members count once, `owl:oneOf ()` is `owl:Nothing` (Mapping Table
  18), and an empty `owl:withRestrictions` is its base datatype. A cardinality
  beyond `u64::MAX` is read as `u64::MAX`, which no finite set of values tells
  apart from it: such a maximum holds of every instance and such a minimum of
  none. An IRI declared several property kinds is read by the OWL 2 RDF-Based
  Semantics (§5.3): a datatype declaration decides, then an object one, so
  PROV-O's `prov:specializationOf`, an annotation and an object property,
  compiles as an object property.
- **OWL datatypes are judged by value space:** an OWL range, filler, data
  range, enumeration or `owl:hasValue` admits a literal by its value, as OWL 2
  §4 reads a datatype, not by its tag as SHACL's `sh:datatype` does.
  `xsd:decimal` admits the bare integer `1` and `"7"^^xsd:nonNegativeInteger`;
  `xsd:string` admits `xsd:normalizedString`, `xsd:token` and the other
  string datatypes, and `xsd:token` admits an `xsd:string` with no stray
  whitespace (an RDF literal's lexical form lies in its datatype's lexical
  space, which for every string datatype is its value space, XSD 1.1 Part 2
  §3.4); `xsd:integer[≥ 0]` admits `"5"^^xsd:int`; `xsd:dateTime` admits
  `xsd:dateTimeStamp`. An enumeration or `owl:hasValue` matches every literal
  of an equal value: `1` matches `"01"^^xsd:integer` and `"1.0"^^xsd:decimal`,
  `"a b"` matches `"a b"^^xsd:token`, `true` matches `"1"^^xsd:boolean`.
  OWL-Time's `time:years 1` is now valid. A literal typed `owl:rational` is in
  a decimal or integer value space exactly when its denominator divides out,
  which no pattern decides, so it is admitted unjudged and the range is
  reported as an approximation; a maximum counted over such a qualifier, and a
  datatype complement of it, count and negate only the literals they judge, so
  neither rejects a conforming value. A length or pattern facet holds of the
  value, which for every string datatype is the lexical form, so it is applied
  to every string literal (`"ABCDEFG"^^xsd:token` fails `maxLength 4`) and
  projected exactly. An equal value of another datatype (a `dateTime` in
  another time zone) is matched by any literal of that datatype, an
  approximation too. SHACL-derived schemas keep SHACL's tag check.
### Changed

- **Exact decimal parse, render and normalization work:** canonical decimal
  output reserves its exact prepared length, binary64 conversion keeps its
  inline and range gates together, and normalization tests divisibility by ten
  with an inverse multiply instead of a remainder. On the `exact` benches, per
  1,024 parse-render values allocation calls fall from 1,966 to 1,024 and
  requested bytes from 24,687 to 13,359; measured instruction counts fall about
  13.6% for parse and render, 3.3% for binary64 conversion and 3.7% for exact
  multiplication. Values, rounding and governor admission are unchanged.

- **Columnar allocation traffic:** Parquet headers, definition levels and
  compressed values are appended directly into the final output buffer and the
  footer is reserved exactly; a 1 MiB uncompressed write requests 3,147,054
  bytes instead of 5,244,206 and retains 1,048,878 instead of 2,097,340.
  Successful validation borrows its static metadata expectations, and blob
  decoding moves checked payloads into the content store instead of copying
  them. All frozen file identities are unchanged.

- **Grouped SPARQL output traffic:** parallel group aggregation consumes the
  original worker buffers in order instead of joining every minted row into a
  second full bag, cutting requested bytes by about 397 KB per measured numeric
  query with identical retained bytes, row order and governor accounting.

- **OWL-Direct decisions that used to run out of budget now decide.** A
  witness that a nominal axiom (`D ⊑ {n}`, `D ⊑ {n, l}`) would absorb no longer
  mints a chain of witnesses of its own under a universal over a transitive
  role. At a tree node still to be identified with a nominal, a witness that
  could itself come to await an identification waits until hyperresolution reaches a
  fixpoint, and, when the identification is a choice, until that choice is
  made. Those ontologies used to answer `unknown` under `completeness
  budget-exhausted`; they now answer `true`. Nothing else waits, so a search
  in which no such chain can start takes the same rounds, nodes and branches
  as it would without the wait. Across 15,000 generated ontologies, every one
  that decided before still decides, and 43 that ran out of budget now decide.
- **OWL-Direct certificate counters move; verdicts do not.** The decision core
  saturates by delta: a round re-matches only what a change can reach, reads
  cached transitive closures, and keeps blocking and the open-disjunction index
  current incrementally rather than rescanning the graph. It derives in a
  different order, so the certificate's `steps`, `peak-nodes` and
  `disjunctions` change on some knowledge bases. Of 14,920 generated ontologies
  that both 3.0.1 and this release decide, 642 report different figures: 516
  in `steps` (339 higher, 177 lower), 379 in `peak-nodes` and 192 in
  `disjunctions`. That count includes the witness wait above. No verdict
  differs except the 27 that the transitive sub-role fix under Fixed corrects.
- **The OWL-Direct work meter bills what a search reads.** A neighbourhood step
  is charged the edges indexed under its node plus one, not the whole graph's
  edge count. A choice beside a large saturated ABox therefore costs what it
  changes. Work figures move: a co-typed shape of ten equivalence blocks now
  decides inside its derived work cap, where it used to answer `unknown` at the
  cap. The caps themselves are unchanged.
- **`xsd:integer` and `xsd:decimal` values past machine words are values, not
  errors.** `purrdf_xsd::parse` and `parse_by_iri` return
  `XsdValue::BigInteger` / `XsdValue::BigDecimal` for a well-formed lexical
  form they used to refuse with `XsdError::OutOfRange`; the bounded
  integer-derived types (`xsd:long`, `xsd:int`, …) still refuse a value
  outside their range. Numeric operators return the exact result where they
  used to return `OutOfRange` (integer overflow) or a rounded decimal product.
  In SPARQL, an overflowing integer or decimal operation and a cast of a large
  `xsd:double` to `xsd:integer`/`xsd:decimal` now return the exact value where
  they used to be an error (unbound). A float or double cast to `xsd:decimal`
  is its exact binary value: `xsd:decimal("0.1"^^xsd:double)` is
  `0.1000000000000000055511151231257827021181583404541015625`, where 3.0.1
  gave `0.100000000000000006`. The negation, absolute value and rounding
  functions of a derived integer type return `xsd:integer`, so `-5` is never
  minted as an `xsd:unsignedByte`. `XsdError`'s `Display` ends with the F&O
  code in parentheses, for example `(err:FORG0001)`. *Migration:* a `match` on `XsdValue`
  needs arms for the two new variants (the enum is `#[non_exhaustive]`, so
  existing wildcard arms compile); code that relied on `OutOfRange` to reject
  large values must check the variant or the magnitude itself.
- **Governed exact numeric operations:** the charge schedule is unchanged. Every
  operation on a value past machine words — arithmetic, comparison, the
  unary functions, casts, the rendering of a result, `SUM`, `AVG`, `MIN`,
  `MAX`, `ORDER BY` and the statistical aggregates — and every division under
  a non-default policy now also charges `row-expression-evaluation` once per
  unit of `exact::Cost` work, and admits its working bytes against the
  scratch-byte ceiling, before it runs. A fuel or scratch ceiling therefore
  refuses a run of repeated squaring before it computes or allocates, however
  short its coefficients stay. Operations on machine-word values charge
  nothing new. `CustomAggregate::exact_numeric_cost` (default zero) lets a
  custom aggregate price its own arithmetic; `exact_numeric_cost_under` and
  `init_under` pass it the query's `DivisionPolicy`, and
  `AggregateAccumulator::finish_absorbing` lets it report the F&O errors it
  absorbed into an unbound answer (all three default to the existing
  methods). `VARIANCE`, `VAR_POP`, `STDDEV` and `STDDEV_POP` use them: an
  integer or decimal variance is one quotient under the query's policy, so
  under `exact` a variance with no finite expansion is unbound with
  `FOAR0002` counted, and under `N:ROUNDING` it has `N` digits, rounded once.
  These charges reach the governor in evaluation order on every host. A
  governed `FILTER`, `BIND`, `GROUP BY` or `OPTIONAL` filter can fork under
  fuel/scratch ceilings when no other caller-set ceiling prevents it: each
  worker records every charge its rows (groups, left rows) make from inside
  their evaluation (fuel, explicit scratch, transient working sets and the
  arena's growth), and the loop's ordered commit makes them again in source
  order on the evaluation's own context, counting the workers' mints into its
  arena as it goes. The trip, the consumption and the answer are therefore
  those of the loop run in order (which is what the wasm32 build runs), at
  every thread count, under fuel and scratch ceilings alike. As in that loop,
  a trip inside an expression withholds the operator's output. A caller's
  fuel or scratch ceiling selects small blocks that workers take in input order, so
  they advance together from the front of the input. The workers share one
  running total of what they have spent, minted bytes included, and every
  worker stops once that total passes the headroom. The commit then trips
  where the in-order loop does, or finishes the loop in order from the first
  row a worker stopped at. What a forked loop holds past its ceiling is
  therefore about one headroom plus each worker's unreported sharing interval
  and row in flight. Stop-only and unlimited metering retain normal chunks
  and exact ordered accounting. Cell accounting remains engaged on every
  governed driver. A cell limit whose row bound cannot form an outer solution-vector
  allocation does not force sequential evaluation; reachable cell limits retain their
  bounded sequential path. The CLI's metered `--fuel` can therefore fork an eligible
  `OPTIONAL` filter while recording its cells. Newly eligible join workers and ordered
  concatenation retain typed output allocation errors. Historically measured on 4,400 rows of
  3,125-digit integers, each raised to the 32nd power and rendered (about
  1.75 MB of scratch per row; the data takes 67 MB to load, and an
  ungoverned run peaks at 2.7 GB), peak memory at 1, 2, 4, 8 and 32 threads
  is:
  - under `--max-scratch-bytes 100000000`: 130, 179, 208, 231 and 284 MB
    (145, 237, 343, 393 and 595 MB when a worker stopped only once the
    workers before it had spent the headroom);
  - under `--max-scratch-bytes 400000000`: 438, 460, 473, 505 and 536 MB
    (451, 816, 1,184, 1,626 and 1,425 MB before).
  Every run trips at the same charge with the same answer. Scratch is now
  the same whether a loop forks: a forked loop used to drop the terms its
  workers minted and did not keep (a query's constants, intermediate
  values), so it charged less than the same loop run in order. `SELECT (UCASE("abc") AS ?u) {}` now charges the 148
  bytes of `"abc"` and `"ABC"` that the in-order loop holds (74 before), and
  the corpus's `concat` cases charge 465 (353 before).
  `exists-inner-counters` charges 153 (76 before). The custom aggregate's
  scratch over-bound case certifies the fold's empty prefix.
  `GOVERNOR_CORPUS_DIGEST`, `GOVERNOR_PROFILE_VERSION` (22 at release) and
  `GOVERNOR_PROFILE_DIGEST` change; consumers that pin any of them must re-pin.
- **OWL 2 RL value identity with doubles is exact:** `dt-eq` and `dt-diff`
  compare an `xsd:integer`/`xsd:decimal` literal with an
  `xsd:float`/`xsd:double` one exactly, instead of rounding the exact value to
  binary first. `"1"^^xsd:integer` is still the same value as
  `"1.0E0"^^xsd:double`, but two different integers past the double's
  precision are no longer both equal to the double nearest them.
- **core:** composite and delta-view probe cursors are much smaller. A
  `CompositeDatasetView` probe now picks the source's carrier (native, delta or
  graph selection) and statement table before it builds a cursor. The cursor
  holds only that branch inline, and walks sources forward with one inner cursor
  at a time. The cursor used to inline every inactive carrier and table branch:
  44,440 bytes per probe on x86_64, now 624. Native and delta probes still
  allocate nothing, whether their rows are pulled by `next` or by `fold`. A
  graph selection still boxes the retained view's cursor once per
  selected-graph probe, but that box is now the compact cursor: a two-level
  nested selection's scan requests 1,248 bytes where it requested 88,880.
  `DeltaDatasetView` probes and statement-table cursors also drop their unused
  `flat_map` slots: the ordinary probe goes from 816 to 280 bytes. Results and
  iteration order do not change. `crates/rdf-core/tests/composite_probe_alloc.rs`
  caps these sizes and pins the zero-allocation probes, and the probe-order
  golden `crates/rdf-core/tests/golden/probe-order.txt` pins the order. The new
  `composite_probes` group in `crates/rdf-core/benches/shared_views.rs` times
  subject, statement-table and scan probes on each carrier.

### Fixed

- **JSON-LD writing of large ontology bundles:** the source carrier's
  retained-text budget stayed at 256 MiB, so writing a bundle that retains
  858,591,805 bytes of term text failed. The budget is now the 4 GiB document
  ceiling, and the working-memory check runs before the reifier and annotation
  indexes are sorted, so their sort-key copies are bounded by it.

- **SHACL conformance across models:** shapes with equal declaration
  identifiers could reuse a conformance answer from another original model or
  a distinct inline body, giving incorrect results. Answers are now keyed by
  original model and evaluated definition.

- **SHACL validation requests through function calls:** registered built-in
  and custom expression functions dropped the validation request, so a
  warning-only inner shape could conform through a native call and fail through
  a SPARQL call under the same severity policy. The complete request now
  reaches bindings, expressions, targets and rule heads and conditions, and
  each call reads the actual query's focus graph.

- **Frozen entailment warrants bind their premise:** verifying a frozen
  implication warrant accepted an empty or weakened replacement premise.
  `FreezeWarrant` now retains the asserted premise in term-value order;
  equivalent content with different dataset-local IDs or insertion order is
  still accepted.

- **Deep RDFC blank-node searches:** n-degree hash search grew the native call
  stack for each child search, so deep blank-node chains could exhaust it.
  Suspended parents now wait in heap frames; related-hash and permutation
  order, pruning, ties, canonical bytes, work charging and stop checkpoints are
  unchanged.

- **OpenAPI schema references:** OpenAPI output holds its definitions under
  `components/schemas` but kept `#/$defs/...` references. References now point
  to `#/components/schemas/...`, preserving escaped suffixes and recursive
  edges; JSON Schema output is unchanged. The schema policy salt adds
  `openapi-3.1-local-refs-v1`, so `SchemaCompilation.key` changes.

- **Large compiled schemas emit and read back:** the GraphQL, TypeScript,
  Pydantic and LinkML emitters and the JSON Schema importer refused a compiled
  schema over 16 MiB (QUDT's is 55 MB), LinkML a document over 1,000,000
  nodes, the LinkML importer one over 65,536 elements (QUDT's has 90,765),
  and the JSON Schema importer one over 65,536 definitions or 65,536
  properties on one object (so bare `import_linkml` refused QUDT's document,
  whose pivot has 90,765 definitions). The importers now read any number of
  definitions and properties, bounded by the input's own size under the depth
  and string ceilings; the emitters read any size under their depth, definition, field and
  enumeration ceilings; each emitted artifact is bounded at four bytes per
  input byte (at least 16 MiB), and LinkML's YAML alias expansion by the
  input's size. QUDT's schema now emits in every language and reads back
  through every importer. A TypeScript or Pydantic name that is reserved or taken
  (QUDT's `qudt:Symbol`) takes `<Name>Type` or `<Name>Model`, and a Pydantic
  field whose name is taken (`@id` beside `qudt:id`) takes `id_2`, in key
  order, instead of being refused.
- **Pydantic negation audit in linear time:** the check of which `not`
  schemas the runtime evaluates exactly re-walked every `$ref` path, taking
  time exponential in a chain of definitions referencing each other; eight
  classes with existentials over the next one never finished. It now judges
  each definition once. The `ontology_schema_emitters` bench times every
  emitter over a 400-class tree.
- **Ontology-complete schemas read back:** a restriction's value schema nests
  a list's or a literal's projection, and a restriction fragment over one
  literal (`A ⊑ ∀m.xsd:float` with `≤1 m`) is one, which the importers read as
  a node shape with `@list` or `@value` properties and refused. They are read
  as value constraints, and ontology-complete output reads back through every
  importer.

- **GraphQL type-name collisions with a nested schema:** a class whose
  derived nested type name another class already holds (GoodRelations'
  `gr:BusinessEntity`, whose `@type` field would be named
  `BusinessEntityType`, beside the class `gr:BusinessEntityType`) no longer
  aborts emission with `GraphqlError` "type name … collides". The nested type
  takes the first free name of `<Name>Nested`, `<Name>Nested2`, …, in the
  definitions' order, so the choice is deterministic; a definition keeps its
  own name.
- **GraphQL emission of enumerated values beside their array form:** a
  property whose values are an enumeration, written as one value or several
  (a SHACL `sh:in`), no longer aborts with
  `GraphqlError` "type name … collides". The wrapper object that carries the
  enum in the `@oneOf` union is named `<Enum>Value`, apart from the enum.
- **SPARQL pre-binding, `VALUES` at every depth:** a `VALUES` over a pre-bound
  name in an `OPTIONAL` arm, a `MINUS` operand, an `EXISTS` body or a
  sub-`SELECT` that does not project the name was combined with its neighbours
  before it met the bound value, so its answer depended on unrelated sibling
  patterns. With `$this` bound to `ex:a`, `?s ex:p ?o OPTIONAL { VALUES $this
  { ex:b } }` answered no row instead of every `?s ex:p ?o` row, and
  `{ SELECT ?x WHERE { ?x ex:q ?y VALUES $this { ex:b } } }` answered every
  `?x` beside an unrelated triple pattern. Such a `VALUES` now joins with the
  bound value where it is written, as an assignment does, for prepared
  parameters and request substitutions alike. Every row a sub-`SELECT` makes
  now carries the bound value before it deduplicates or groups, so
  `{ SELECT DISTINCT $this ?x … }` and `GROUP BY $this` inside one beside
  another pattern no longer split rows that never mention the name from rows
  that bind the bound value.

- **SPARQL pre-binding, one value in every sub-`SELECT`:** a sub-`SELECT` that
  assigned a pre-bound name without projecting it gave the name a variable of
  its own, and the check that decided so also counted an assignment in a
  nested sub-`SELECT` or an `EXISTS` body, so the outer sub-`SELECT`'s reads
  lost the bound value: `{ SELECT (COUNT($this) AS ?c) WHERE { ?s ex:p ?o
  FILTER EXISTS { BIND(ex:a AS $this) } } }` counted 0. There is now no such
  scope: an assignment of the name in any sub-`SELECT` joins with the bound
  value like every other assignment, so that query counts every row,
  `{ SELECT ?y WHERE { BIND(?nothing AS $this) $this ex:p ?y } }` reads the
  bound value after the failed assignment, and `{ SELECT ?w WHERE { BIND(ex:b
  AS $this) } }` has no row.

- **SPARQL `SERVICE` refusal messages:** refusing a property-function or
  custom-aggregate call inside a `SERVICE` body no longer prints runs of
  spaces in the middle of its diagnostic.
- **SPARQL `OPTIONAL` filters:** every `FILTER` written directly in an
  `OPTIONAL` group now becomes part of the left-join condition, conjoined in
  written order. Before, only the last one did, and the others filtered the
  optional side alone. A `FILTER` inside a nested group stays in that group.
- **SPARQL `=` and `!=`:** two literals with known but different values now
  compare unequal when one is a language-tagged string, as with
  `"xyz"@en = "xyz"` or `"xyz"@en != 7`, instead of raising an error. An
  `xsd:dateTime` and an `xsd:date` compare unequal. Comparisons involving an
  unknown datatype or an ill-typed literal still raise an error.
- **OWL-Direct consistency over sub-roles and inverse partners of transitive
  roles:** a transitive role's closure followed only edges labelled with that
  role, so `s ⊑ r` with `r` transitive, `x s y`, `y : ∃r.E`, `x : ∀r.D` and
  `E ⊑ ¬D` answered `consistency true` (decided), and so did the same shape
  spelled with an `owl:inverseOf` partner of `r`. Both are inconsistent and now
  answer `false`. The proof checker recomputes closures the same way.
- **Deeply nested owned RDF terms:** `Clone`, `PartialEq`/`Eq`, `Hash`,
  `Debug` and dropping a `purrdf_core::RdfTerm` or `RdfTriple` no longer
  recurse once per quoted-triple level, so a term nested 100,000 levels deep
  clones, compares, hashes, prints and drops on a 256 KiB stack, and on
  wasm32's shadow stack, where each used to abort with a stack overflow.
  Results are unchanged: `Hash` feeds the hasher the same writes in the same
  order as the derive, and `Debug` prints the derive's bytes under every format
  spec (fill, alignment, width, precision, sign, `#`, `0`, `{:x?}`/`{:X?}`,
  compact and pretty). An IRI, a blank node or a literal runs the derive's own
  code (`Clone`'s leaf arms are the derive's, verbatim), and a triple term
  nested up to four levels deep is walked by direct calls; only deeper terms
  switch to heap work lists. Dropping a triple whose subject and object are
  leaves costs two discriminant checks. Counted in retired instructions
  against the previous release, no bounded case costs more than 1% more: the
  largest increase is +0.9%, for dropping a four-level term, while `Hash`
  retires 5% to 24% fewer instructions and `==` 2% to 7% fewer. See Breaking Changes for the one source change this needs.
- **Named-graph capability of declared empty graphs:** a frozen dataset whose
  only named graphs are declared empty ones (TriG `<g> {}`) now reports
  `capabilities().named_graphs` as true, as does the C ABI's
  `PurrdfCapabilities.named_graphs`. Before, it reported false while
  `named_graphs()` and `GRAPH ?g` enumerated the graph. A mutable snapshot
  derives the bit from the graphs it actually enumerates. PACK header flags,
  which describe the pack's own sections, are unchanged.
- **wasm32 compile time of `purrdf-text`:** a release build of `purrdf-text`
  for `wasm32-unknown-unknown` (one codegen unit, with or without `simd128`)
  took over half an hour, nearly all of it in LLVM's WebAssembly register
  stackification of the text analyzer's normalization pipeline, which inlining
  had turned into one function of about 140,000 instructions. On wasm only,
  `purrdf_lex::unicode`'s decomposition stage now hands each character to the
  next stage through a call that is not inlined, and the crate builds in about
  ten seconds. Native code generation is unchanged.
- **Premise IRIs:** every entailment service that takes premise IRIs now
  refuses one that is not an absolute IRI, such as `"::bad"`, `"lib"` or `""`,
  and names it. Before, it was accepted silently and could never match an
  `owl:imports` object. This applies to the shared `purrdf_validate` boundary
  (`premise_import_map` and the string services), the C ABI, WebAssembly, and
  Python's `purrdf.entail` functions and `Store.query_entailment_governed`. The
  premise IRIs are checked before the import table. On Python the
  `ValueError` carries `message_id` `premise-iri-not-absolute` and the typed
  `presentation`.
- **Python `Store.prepare`:** a declared parameter that the query never
  mentions, such as `parameters=["zz"]`, raises `ValueError` naming it, with
  `message_id` `sparql-prepared-parameter-unmentioned`. Before, it was
  accepted and bound nothing. A declared parameter that the query uses still
  prepares and runs. Mentions in filters, `EXISTS`, `CONSTRUCT` templates and
  `DESCRIBE` targets all count.

- **core:** `MutableDataset::snapshot_view_with_limits` no longer refuses a
  snapshot because of terms whose rows were all removed. Its check before the
  freeze now charges exactly the terms, payload bytes and auxiliary bytes the
  frozen delta retains, so a limit the published snapshot meets is admitted.
- **XSD temporal parsing:** a date, time, dateTime or `xsd:g*` lexical form
  with a non-ASCII character where the timezone suffix would be, such as
  `"2001-01-01€12345"`, is rejected as an invalid lexical form instead of
  panicking. SPARQL casts, typed-literal ordering, D-entailment and SHACL
  validation over such literals no longer abort.
- **SHACL Core:** `sh:datatype` now rejects ill-formed literals of every XSD
  datatype PurRDF models, not only the numeric and boolean types. This covers
  `xsd:dateTime`, `xsd:date`, `xsd:time`, `xsd:dateTimeStamp` (which also
  requires a timezone), the `xsd:g*` types, the duration types, `xsd:hexBinary`
  and `xsd:base64Binary`. For example, `"notadate"^^xsd:date` no longer
  conforms. Well-formed values that exceed PurRDF's numeric range, such as
  years beyond 64 bits, still conform. Custom datatypes are not checked.
- **XSD lexical forms:** durations follow the XSD grammar. Designators must
  appear in order, each at most once, and `T` must be followed by a time
  component, so `P1YT` and `P1D1Y` are rejected. A `base64Binary` value's
  final character before padding may not encode extra bits, so `AQJ=` is
  rejected. Years, duration fields and fractional seconds that are well-formed
  but too large to represent now report an out-of-range error instead of an
  invalid lexical form. Fractional seconds with trailing zeros beyond 18
  digits now parse.
- **SHACL `subClassOfInShapesGraph`:** the shapes graph's `rdfs:subClassOf`
  chains through blank nodes now count toward SHACL type. With
  `ex:A rdfs:subClassOf _:b . _:b rdfs:subClassOf ex:B` in the shapes graph,
  an `ex:A` instance is a member of `ex:B`. Before, such an instance was
  missed by `sh:targetClass ex:B` and wrongly violated `sh:class ex:B`.
  Chains of several blank nodes, and cycles among them, work too. A blank node
  that is not on a path between two IRI classes adds no membership. Results
  with the option off are unchanged. The superclasses reached through blank
  nodes are computed once per blank node, so many classes that share one long
  blank chain stay linear in the size of the shapes graph.
- **SHACL-SPARQL custom components:** a constraint component or a SPARQL
  validator now has the SHACL type that any other node has. Its `rdf:type`
  values may be blank nodes, and its `rdfs:subClassOf` chain may run through
  blank nodes. Before, a component typed through `_:x rdfs:subClassOf
  sh:ConstraintComponent` was silently not registered, so its constraints
  never ran. A validator whose class reached `sh:SPARQLAskValidator` through a
  blank node was refused as a `validator-class` syntax violation. Cycles
  among blank nodes terminate, and a blank node on no path to the SHACL class
  registers nothing.
- **SPARQL Update graph existence:** a named graph that an Update empties is
  gone afterwards. This covers `DROP`/`CLEAR` of a graph, `NAMED` or `ALL`, the
  source of a `MOVE`, and a `DELETE` that removes the graph's last quad,
  reifier binding or annotation. The graph is no longer enumerated by
  `GRAPH ?g` later in the same request or over the result. It is no longer
  kept in the frozen dataset, so serializers stop writing it, for example as
  `<g> {}` in TriG. Before this fix, every graph of the input stayed listed
  after its quads were deleted, and graphs the input declared empty survived
  `DROP ALL`. A graph the input declared empty (TriG `GRAPH <g> {}`) that no
  operation touches is still kept, so a no-op or unrelated update writes the
  declaration back unchanged. `CREATE GRAPH` still registers nothing, and
  dropping a missing graph still succeeds. The new
  `MutableDataset::withdraw_graph_declaration` and
  `MutableDataset::withdraw_named_graph_declarations` remove an input
  declaration directly.

- **SPARQL string functions:** `SUBSTR` follows XPath `fn:substring` for a
  start at or below zero (`SUBSTR("12345", 0, 3)` is `"12"`, not `"123"`),
  computes its bounds without overflow across the whole integer range, treats a
  supplied but unbound length as an error rather than an omitted one, and keeps
  the source's base direction as well as its language tag. `CONTAINS`,
  `STRSTARTS` and `STRENDS` now apply SPARQL argument compatibility — an
  incompatible pair such as `CONTAINS("abc", "b"@en)` is an error, not `true`
  — and, with `STRBEFORE` and `STRAFTER`, treat two RDF 1.2 directional
  strings as compatible only when their language and base direction both
  match; `STRBEFORE` and `STRAFTER` keep the base direction of their result.
  `UCASE`, `LCASE` and `REPLACE` keep the base direction of a directional
  input as well as its language tag. A `REGEX` or `REPLACE` flags argument
  that is supplied but unbound, or is not a simple literal, is an error
  instead of being read as no flags; omitted flags still mean none. A
  language-tagged `REGEX` or `REPLACE` pattern, or `REPLACE` replacement, is
  an error, as their signatures require simple literals; the text they search
  may still be any string. `STRLANGDIR`, like `STRLANG`, refuses a lexical
  form that is already tagged instead of silently replacing its language and
  direction.
- **SPARQL simple-literal arguments:** the hash built-ins (`MD5`, `SHA1`,
  `SHA256`, `SHA384`, `SHA512` and the SHA-3 family) take only a simple
  literal or `xsd:string`, as SPARQL 1.1 §17.4.6 requires; a language-tagged
  or directional string is an error instead of being hashed on its text.
  Plain and `xsd:string` inputs keep the same digests. The same rule now
  holds for the language and direction of `STRLANG` and `STRLANGDIR`, both
  arguments of `LANGMATCHES`, the label of `BNODE` and the string form of
  `IRI`/`URI`, which also no longer resolves a non-string literal such as
  `IRI(1)` against the base.
- **SPARQL `LANGMATCHES`:** an empty language tag or range now gives `false`,
  and `"*"` matches only a non-empty tag, as SPARQL requires.
  `FILTER langMatches(lang(?v), "*")` no longer keeps untagged literals, and
  its negation now keeps them (the W3C `q-langMatches-3` and `-4` results).
- **SPARQL numeric casts:** an XSD constructor cast from a numeric or boolean
  literal converts its value instead of reparsing its lexical form, following
  the XPath casting rules SPARQL 1.1 §17.5 adopts. `xsd:double("0.1"^^xsd:float)`
  is now `1.0000000149011612E-1`, the float's value, and
  `xsd:integer("16777217"^^xsd:float)` is now `16777216`. A double cast to
  `xsd:float` rounds the double's value to the nearest float, ties to even.
  This deliberately differs from F&O 3.1 §19.1.2.1, whose text truncates the
  mantissa. Rounding is more accurate (within half an ulp, unbiased), matches
  XSD 1.1 `floatingPointRound` as the string, decimal and integer casts already
  do, and agrees with common engines. The F&O rule also flushes the float
  subnormal band to zero, which is a defect in its text. A double exactly halfway
  between the largest float and 2^128 now gives `INF`:
  `xsd:float("3.4028235677973366e38"^^xsd:double)` was `3.4028235E38`.
  `xsd:float("1e-40"^^xsd:double)` gives the nearest subnormal, `1.0E-40`.
  A float or double cast to `xsd:decimal` gives its exact binary value, so
  `xsd:decimal("0.1"^^xsd:float)` is `0.100000001490116119384765625` instead
  of `0.1`, and a cast to an integer type keeps the exact integer part at any
  magnitude. Casts from strings still parse the string.
- **SPARQL `AVG` and `SUM`:** a decimal `AVG` whose running `SUM` passed the
  128-bit mantissa was unbound although its mean exists; it now answers the
  exact mean, as the same values do as integers. An integer `AVG` emitted
  `"170141183460469231731687303715884105726.5"^^xsd:decimal` for
  {`i128::MAX`, `i128::MAX - 1`}, a literal 3.0.1 could not read back, while
  `SUM(?v) / COUNT(?v)` over the same group was unbound. `AVG` is now `SUM`
  divided by `COUNT` through the one quotient `/` computes, on every group,
  and every `SUM` and `AVG` result is a value that reads back as itself.
- **XSD decimal division:** dividing decimals or integers no longer fails
  when an intermediate value overflows, and keeps eighteen fractional digits
  at every magnitude. Previously any dividend of about 10^21 or more was
  refused: `"1000000000000000000000"^^xsd:decimal / 2` is now
  `500000000000000000000` instead of an error. A quotient is exact when it
  ends within 18 fractional digits and is truncated toward zero there
  otherwise, so `1 / 3` is still `0.333333333333333333` and
  `"170141183460469231731687303715884105727"^^xsd:integer / 2` is
  `85070591730234615865843651857942052863.5`. `i128::MAX / 0.1`, negating the
  smallest 128-bit decimal and taking its absolute value answer their exact
  values. Dividing two `xsd:dayTimeDuration`s follows the same rule, so one
  day divided by one attosecond is now `86400000000000000000000` instead of
  an error.
- **XSD decimals:** the decimal lexical form of the smallest 128-bit integer,
  `-170141183460469231731687303715884105728` (also with up to 18 fractional
  digits), now parses. It was refused as out of range although its value is
  representable, so `xsd:decimal` of that integer produced a literal that did
  not read back.
- **SPARQL numeric-to-string casts:** `xsd:string` of a float or double uses
  plain notation only for magnitudes from 0.000001 up to, but not including,
  1000000, and scientific notation with a digit after the point otherwise:
  `xsd:string("1e7"^^xsd:double)` is `1.0E7` instead of `10000000`, and
  `1e-7` gives `1.0E-7` instead of `1E-7`. Digits are the shortest that read
  back as the same value, at the source's own precision.
  `xsd:string("0.1"^^xsd:double)` is now `0.1` instead of
  `0.100000000000000006`, and `xsd:string("0.1"^^xsd:float)` is `0.1` instead
  of `0.100000001490116119`. `STR` still returns a literal's lexical form
  unchanged.
- **rdf:** Serializing a named graph the dataset does not contain
  (`SerializeGraph::Named` with an absent name) now emits no rows. Previously it
  emitted the default graph's triples in place of the requested graph.
- **rdf:** Declared empty named graphs survive JSON-LD, YAML-LD and TriX, as
  they already did in TriG. The JSON-LD and YAML-LD writers emit
  `{"@id": g, "@graph": []}` and their readers declare such a graph; the TriX
  writer emits an empty named `<graph>` block and the reader declares it.
  Documents for datasets without empty named graphs are byte-identical to
  before; existing graph order is unchanged.
- **core:** Packs keep declared empty named graphs, IRI- and blank-named.
  `PackBuilder` writes each named graph that has no base quad, reifier row or
  annotation row as a zero-row partition in the existing TRIPLES section.
  `PackView::named_graphs`, `dataset_from_view`, `restore_pack`,
  `SegmentedImage::from_pack_v1`, queries over a pack and
  `purrdf convert --from pack` all return these graphs. The pack format version
  (1) and section count (3) are unchanged. Existing packs read as before, and
  3.0.x readers open the new packs and list their declared graphs. A dataset
  with no declaration-only graph writes byte-identical pack bytes. The canonical
  `rdfc_digest` never changes, because canonical N-Quads has no empty graph.
  `PackView::named_graphs` now also lists graphs that hold only reifier or
  annotation rows, matching the frozen dataset.
- **cli:** `--loss-ledger` records one `empty-named-graph-dropped` entry for each
  declared empty named graph dropped by a target that cannot write one: N-Quads,
  HexTuples, and every single-graph syntax. Before, this loss produced an empty
  ledger. Conversions of datasets without such graphs, and conversions to TriG,
  TriX, JSON-LD, YAML-LD or a pack, record no entry.
- **python:** `Store.load` and `MutableDataset.load` keep the named graphs a
  document declares with no row. Before, the load dropped them silently. A
  later `dump` writes them where the format allows (TriG, TriX, JSON-LD,
  YAML-LD). A store that loaded no such graph dumps exactly as before.
- **capi:** `purrdf_parse` keeps declared empty named graphs. Its event replay
  used to drop them.
- **rdf:** HexTuples now has the loss codec name `hextuples`. Its ledger entries
  name the target instead of `unknown` and are classified against its
  registered profile. The transcode matrix gains the HexTuples pairs:
  quad-capable, no triple terms, so star-capable sources record
  `rdf12-star-unrepresentable`.

- **SPARQL NaN comparisons:** a NaN compared with a number now gives a
  boolean instead of an error, as XPath `op:numeric-equal`,
  `op:numeric-less-than` and `op:numeric-greater-than` define. `=`, `<`, `>`,
  `<=` and `>=` give `false`, and `!=` gives `true`, so
  `FILTER("NaN"^^xsd:double != ?x)` keeps every numeric row. NaN equals
  nothing and orders against nothing, itself included (SPARQL 1.2 §17.4.2.2):
  `"NaN"^^xsd:double = "NaN"^^xsd:double`, `"NaN"^^xsd:float =
  "NaN"^^xsd:double` and `<=` between two NaNs are `false`, `NaN IN (1, NaN)`
  is `false`, and `FILTER(?o = ?o)` drops a row whose `?o` is NaN. A triple
  term compares componentwise, so one holding a NaN at any depth is unequal
  to itself as well: `<<( :a :b "NaN"^^xsd:double )>> = <<( :a :b
  "NaN"^^xsd:double )>>` is `false`. `sameTerm(NaN, NaN)` is still `true`, and a NaN against a non-number is
  still an error. `ORDER BY`, `MIN` and `MAX` are unchanged.
- **SPARQL casts:** a cast to a numeric, boolean or date/time type is now an
  error when the source literal's datatype has no row in the casting table.
  `xsd:double("1.5"^^ex:custom)` and `xsd:integer("1"@en)` are unbound instead
  of `1.5E0` and `1`. Casts the table marks never allowed are errors too:
  numbers and booleans cast to no date, time, Gregorian or binary type
  (`xsd:gYear(2020)`), and date, time, duration, Gregorian and binary values
  cast to no number or boolean (`xsd:integer("2020"^^xsd:gYear)`). Simple
  literals, `xsd:string` and the types derived from it, such as `xsd:token`,
  cast by lexical form to every target, calendar types included:
  `xsd:dateTime("2002-10-10T17:30:05Z"^^xsd:token)` is a `xsd:dateTime`
  rather than unbound. `xsd:dateTimeStamp` casts to the calendar types by
  value, as `xsd:dateTime` does. `xsd:anyURI`, `xsd:QName` and `xsd:NOTATION`
  cast to `xsd:string` alone, so `xsd:date("2024-01-01"^^xsd:anyURI)` is an
  error. A string cast to a non-string type is first normalized by the
  target's `whiteSpace` facet (`collapse`, XPath F&O 3.1 §19.2), so
  `xsd:integer(" 12 ")`, `xsd:double(" 1.5 ")` and `xsd:boolean(" true ")`
  bind where they were unbound, while white space inside a value is still an
  error. Every numeric and boolean cast the table allows is unchanged, and
  casting any literal or IRI to `xsd:string` still works.
- **SPARQL duration and binary casts:** the casts XPath allows between these
  types now work, by value; before, they were unbound or re-read the source's
  spelling. `xsd:duration` and its two subtypes cast among themselves
  (`xsd:dayTimeDuration("P1Y2M3DT4H"^^xsd:duration)` is `"P3DT4H"`), and
  `xsd:hexBinary` and `xsd:base64Binary` cast into each other by their bytes
  (`xsd:hexBinary("abcd"^^xsd:base64Binary)` is `"69B71D"`, not `"ABCD"`). A
  calendar, duration or binary value casts to no other non-string type, so
  `xsd:hexBinary("2020"^^xsd:gYear)` is an error.
- **SPARQL keywords:** `true` and `false` match case-insensitively like every
  other SPARQL keyword except `a`, so `SELECT (TRUE AS ?t) (False AS ?f) {}`
  parses (the W3C `case-insensitive-booleans` test). They work this way in
  expressions, `VALUES` and triple patterns, and are always written as the
  canonical `"true"`/`"false"`.
- **SPARQL grammar:** the parser now refuses several forms the grammar does
  not allow. `GROUP BY` and `ORDER BY` need at least one condition.
  `HAVING` and `FILTER` need a bracketed expression or a function call, and a
  function call needs its argument list, so `HAVING ?x`, `FILTER ?x`,
  `FILTER true`, `FILTER :f`, `HAVING <f>`, `GROUP BY :f` and `ORDER BY :f`
  are refused while `FILTER :f(?o)` still parses. For the same reason a bare
  unary operator is no `FILTER` constraint, so `FILTER !BOUND(?x)` and
  `FILTER -1` are refused while `FILTER(!BOUND(?x))` and `FILTER(-1)` parse,
  and a `FOLD(… ORDER BY :f)` key needs its argument list as an `ORDER BY`
  key does. Two triples need a `.` between them in a pattern or template; a
  `.` separates two triples, may end a block of them once before its `}`, and
  may follow a non-triples element once, so `{ . }`, `{ ?s ?p ?o . . }` and
  `{ :a :b :c :d :e :f }` are refused while `{ ?s ?p ?o . }` parses (the W3C
  `syn-bad-02`, `-03`, `-05`, `-06`, `-07`, `-14` and `filter-missing-parens`
  tests). The same rules hold in `INSERT DATA`, `DELETE DATA`, `DELETE WHERE`
  and the templates of `INSERT`/`DELETE`. One case was refused wrongly
  before: a non-empty collection may now stand alone as a triple, as in
  `{ ( ?x ) }` or `{ ( ( ) ) }`, as the grammar allows for blank-node
  property lists (the W3C `syntax-lists-03`, `-04`, `-05` and
  `syntax-forms-02` tests). In update quad data, such a standalone collection
  or blank-node property list may be followed directly by a `GRAPH` block,
  as in `INSERT DATA { ( 1 ) GRAPH <g> { … } }`. `()` on its own is still
  refused. A `;` may now repeat in a property list (`?s :p 1 ; ; :q 2`), in
  patterns, templates and quad data, as grammar productions [77] and [83]
  allow; it was refused before.
- **SPARQL grouping constraint:** in an aggregate query, a `SELECT`
  expression may read, outside an aggregate, only group keys, aggregate
  results and earlier `SELECT` targets (SPARQL 1.1 §11.4). Grouping by an
  expression does not make its variables keys, so `SELECT ((?a + ?b) AS ?s) …
  GROUP BY (?a + ?b)` is refused (the W3C `agg08` and `agg11` tests), and so is
  a variable the `WHERE` clause never binds or binds only inside `MINUS`. The
  one exemption is a variable the caller binds before evaluation:
  `SparqlParser::with_prebound_variables` declares them, a prepared execution
  declares its parameters, `QueryOptions::with_declared_prebound` declares
  names a caller binds per run, and SHACL-SPARQL declares `$this`, the shape
  context and the parameters of a component or target type. A SHACL node
  expression's query may read `$this` and the names its context binds: `value`
  inside `sh:expression`, a custom function's arguments inside its body, and
  `node-expr --scope` names. A custom function's argument is evaluated in the
  empty scope (SHACL 1.2 Node Expressions §6.3), so a query inside one may read
  `$this` alone: reading the call site's `$value` or an enclosing body's `$arg0`
  there is refused at load instead of aborting validation, and the argument may
  assign `?value`. A node expression never binds `$currentShape` or
  `$shapesGraph`, so reading either — like any other variable — is refused when
  the shapes graph is loaded or packed, even in an expression no focus node
  reaches. Assigning a name a SHACL lane pre-binds, by `BIND(… AS ?x)` or
  `(… AS ?x)` at any depth, is refused there, as Appendix A requires. A
  SHACL-SPARQL query declares
  `$shapesGraph` and `$currentShape` pre-bound whether or not the validation
  gives them a value, so a `sh:sparql` constraint reading `$shapesGraph` above
  its `GROUP BY` validates, unbound, when the shapes graph has no IRI instead
  of loading and then aborting, and assigning either name is refused when the
  shapes graph loads. A shape rule's `CONSTRUCT` is checked with the names its
  run pre-binds, so a sub-`SELECT` there may read `$this` above its group. A
  named-parameter custom function's body may read each parameter its own
  `sh:optional` marks required, whatever the parameters' IRI order.
- **SPARQL conformance:** the W3C SPARQL 1.1 `aggregates` group is vendored
  verbatim at the suite's pinned commit, replacing a 3-test curated subset,
  and all 47 cases pass. The results comparer now reads two numeric literals
  of the same datatype by value, so `"2"^^xsd:decimal` matches
  `"2.0"^^xsd:decimal`. The datatype must still match exactly, every other
  literal compares as an exact term, and NaN matches NaN. The five fixtures
  ledgered for spelling a computed number inconsistently (`cast-decimal`,
  `cast-double`, `cast-float`, `coalesce01`, `plus-1-corrected`) pass, so the
  SPARQL evaluation row ledgers nothing: 911 pass, 0 ledgered.
- **SPARQL grouping:** a `GROUP BY` condition that is only a variable,
  bracketed or not, is a key: `SELECT ?s (COUNT(*) AS ?c) … GROUP BY (?s)` and
  `GROUP BY ((?s))` answer as `GROUP BY ?s` does instead of being refused.

## [3.0.1] - 2026-10-02

### Fixed

- **SHACL-SPARQL:** pre-bound focus nodes now constrain every nested triple and
  path pattern, including the right arm of `OPTIONAL`. Missing-property
  constraints of the form `OPTIONAL { $this <predicate> ?value }
  FILTER (!BOUND(?value))` report the focus nodes that lack the property.
  Blank and quoted focus identities remain exact, and prepared executions
  refresh their bindings when the focus changes.
- **SHACL data views:** `ShaclDatasetView::named_graph(source, graph)` reads one
  named graph as the default graph through the source's native indexes,
  without copying quads or building a second index. Other source graphs stay
  invisible to Core validation, class membership and SHACL-SPARQL. RDF 1.2
  statement metadata and graph isolation survive shape-only term supplements.
- **SPARQL planning:** fixed-length paths containing alternatives use native
  indexed joins. Connected basic graph patterns around `UNION` pass their
  bindings into the selected join schedule instead of first materializing
  independent tables. Duplicate solution bags, blank-label scope and visible
  column order survive these rewrites; compiler-generated match witnesses stay
  hidden when algebra is evaluated or rendered to a SPARQL carrier. Existing
  query limits and operator scope boundaries still apply.
- **Governed SPARQL:** when fuel runs out, unfinished basic graph pattern
  matches are withheld instead of being returned as certain partial answers.
- **Rust publishing:** dependent crates wait for their exact, unyanked versions
  to become visible in Cargo's sparse registry index. GitHub Release assets are
  attached and verified in a draft before publication makes them immutable.
  Resumed published releases verify their retained assets without altering them.

### Acknowledgements

Thanks to [@dshchyhlinski](https://github.com/dshchyhlinski) for the excellent
reports behind the SHACL and SPARQL fixes, including the minimal reproductions,
passing controls, representative validation benchmarks and query permutations
that exposed the planning problem.

## [3.0.0] - 2026-10-01

### Breaking Changes

The [3.0 migration guide](docs/MIGRATION-3.0.md) documents the new read, identity,
diagnostic and export boundaries. Generic `DatasetView` term access now returns
typed results and pinned guards; logical global addresses/counts use `u64`.
Resident datasets retain compact IDs, borrowed access and native parallel
execution. Diagnostic-only engine conveniences require an `Infallible` reader;
operational storage uses the typed fallible query and scoped execution APIs.
JavaScript dataset identities, generations and asynchronous exchange IDs are
`bigint`; settlement methods accept those exact BigInt IDs. Construct diagnostics
through their validated constructors rather than external struct literals.
Python SQL/Parquet exports now use native canonical five-table IDs and schemas;
folded inspection IDs remain a separate authority.

Every job the workspace does now has one implementation, named in
`helpers-ledger.toml`. The consequences a consumer sees are listed here; the
new homes are under Added, and the behaviour changes they carry are repeated
under Changed and Fixed where a longer account helps.

**Removed dependencies**

- **deps:** 43 external packages leave the dependency graph, each replaced by a
  first-party home and banned on every edge by `scripts/check-banned-deps.py`:
  `serde`, `serde_core`, `serde_derive`, `serde_json`, `itoa`, `ryu`, `zmij`,
  `indexmap` and `equivalent` (JSON: `purrdf_lex::json`); `serde_yaml_ng` and
  `unsafe-libyaml` (YAML: `purrdf_lex::yaml`); `ciborium`, `ciborium-io`,
  `ciborium-ll`, `half`, `crunchy`, `zerocopy` and `zerocopy-derive` (CBOR:
  `purrdf_lex::cbor`); `roxmltree` (XML: `purrdf_lex::xml`); `ed25519-dalek`,
  `curve25519-dalek`, `curve25519-dalek-derive`, `fiat-crypto`, `ed25519`,
  `signature`, `subtle`, `zeroize`, `rustc_version` and `semver` (Ed25519:
  `purrdf-ed25519`); and `criterion`, `criterion-plot`, `anes`, `is-terminal`,
  `hermit-abi`, `cast`, `num-traits`, `autocfg`, `itertools`, `oorandom`,
  `tinytemplate`, `walkdir`, `same-file` and `winapi-util` (benchmarks:
  `purrdf_testkit::bench`). `pkcs8`, `spki`, `der`, `base64ct`, `hex`, `time`
  and its closure, `unicode-normalization` and `tinyvec` are banned the same
  way. No workspace member depends on `memchr` (refused as a direct
  dependency), and `regex` is built without its `perf-literal` prefilter, so
  neither `memchr` nor `aho-corasick` is compiled into any build. `sha2` stays
  as the one SHA-2 implementation.
- **all crates:** no public type implements `serde::Serialize` or
  `serde::Deserialize`. Types that crossed JSON through derives cross it
  through `purrdf_lex::json::record`'s `ToJson`/`FromJson` over
  `purrdf_lex::json::Value` (most declared through `purrdf_lex::json_record!`),
  writing the same document shape: the projection configurations, sideband
  models and reports; `NativeRdfFormat` and the visualization types; the ShEx
  `Schema`; the slice catalog records; the SARIF model of `purrdf-validate`;
  and the retrieval `Plan`.

**Public signatures**

- **core, validate, shapes:** `ImportMap::insert` is `ImportMap::try_insert`,
  which returns `Result<(), ImportKeyError>` instead of the replaced document.
  `purrdf_validate::RuleLimits` is `purrdf_shapes::RuleLimits` (still
  re-exported from `purrdf_validate`).

- **lex, jsonschema, rdf:** `purrdf_lex::json::Value` and `Number` equality and
  `Hash` compare what a document says, not how it spelled it: numbers by the
  exact decimal they denote (`1 == 1.0 == 1e0`, `-0 == 0`, exponents of any
  size) and objects without regard to member order (RFC 8259 §4; a repeated
  name pairs its occurrences in document order), which is JSON Schema's
  `equal`. `serde_json::Value` was order-insensitive too but distinguished `1`
  from `1.0`; a caller that must see a respelling or a reordering uses the new
  `Value::same_text` / `Number::same_text`. `Number` no longer derives `Ord`
  (a lexeme order disagrees with value equality), and `Value == <integer>`
  compares by value (`1.0 == 1_u8`). The OKF writer's "JSON literal would lose
  precision or lexical identity" check and the research-object row
  de-duplication use `same_text`, so they refuse and keep exactly what they did
  before.

- **jsonschema, rdf, shapes, slice, geo:** JSON values in public signatures
  are `purrdf_lex::json::Value`, whose numbers keep their lexemes and whose
  objects keep their members in order: schemas and instances in
  `purrdf-jsonschema`; the JSON-LD context API
  (`CompiledJsonLdContext::{compile, compile_with_registry,
  apply_local_context, canonical_context, scoped_context}`,
  `JsonLdSerializeOptions::{context, context_with_registry, json_schema}`);
  `OfflineJsonLdContext::value`, `CsvwAnnotations`, the `CsvwDatatype` facets
  and `ResearchRecordSet` rows; `LinkmlDocument::from_value` and the JSON
  Schema importer; the slice catalog's `to_json`/`from_json`; and
  `purrdf_geo::json::JsonValue`.
- **gts, rdf:** every public CBOR value — the GTS writer, reader, model, wire
  and sinks, and `purrdf-rdf`'s GTS metadata and blob payloads — is
  `purrdf_lex::cbor::Value` instead of `ciborium::Value`.
  `purrdf_gts::wire::{encode, encode_into, canonical, append_canonical,
  map_get}` re-export `purrdf_lex::cbor`.
- **gts, rdf:** `Writer::sign_with`, `CompactionParams::packaging_signer`,
  `OpenPgpSigningKey` and the `purrdf-rdf` certification keyrings and signer
  parameters take `purrdf_ed25519` keys instead of `ed25519_dalek` keys.
- **core, gts:** `purrdf_core::hex` is removed (use `purrdf_hash::hex::encode`),
  and so is `purrdf_gts::wire::hex`.
- **rdf:** `JsonLdDirection` is the one base-direction type; its variants are
  `Ltr`/`Rtl` rather than `LeftToRight`/`RightToLeft`. `VizTextDirection` is
  a type alias of the same type rather than an enum of its own.
- **rdf:** `ProjectionDirection` (and with it the direction of a `ProjectionTerm`)
  is a type alias of the same base-direction type, so its `ltr`/`rtl` JSON
  spelling and parse come from `purrdf_events::TextDirection` and the JSON
  layer keeps one adapter (`direction_to_json`/`direction_from_json`) shared
  with the visualization documents. `CsvwTextDirection` and `CsvwTableDirection`
  keep their CSVW-only `auto`/`inherit` members and take `ltr`/`rtl` through
  `TextDirection`; serialized bytes are unchanged. The native codec seam's
  private `is_literal_direction` is gone (`TextDirection::from_str_token` at its
  one caller), and the ledger job `text-direction` now names
  `purrdf_gts::model::is_literal_direction` as the one predicate.
- **jsonschema:** `EvaluationError::cause` is an `EvaluationCause` rather than
  a `PatternError`.
- **retrieval, core:** `PLAN_ID_DOMAIN`, `FUSION_PROFILE_ID_DOMAIN`,
  `EVIDENCE_ID_DOMAIN` and `PIPELINE_ROOT_DOMAIN` are `purrdf_hash::Domain`
  constants rather than `&str`, with the same bytes.
- **gts, retrieval, slice:** maps in public signatures are keyed by the
  fixed-key `purrdf_hash::fixed::FixedState` rather than std's `RandomState`:
  `TrustPolicy::trusted_signers`, `Plan::stratum_depths`,
  `ExecutionResult::statuses` and `OwnershipReport::ownership` change hasher
  type, and `verify_file_with_keyring` and `verify_compaction` are generic
  over `S: BuildHasher`.
- **xsd:** `BigInt::to_decimal_lexical` takes its scale as `u32` (was `u8`).
- **core:** `DatasetView::rdf_list` refuses a cell with more than one
  `rdf:rest`; `rdf_list_strict` refuses every malformed list, `rdf:nil`
  carrying an `rdf:first` or `rdf:rest` included (`ListErrorKind`).
- **tests, CI:** `PURRDF_REQUIRE_SIMD_PATHS` replaces
  `PURRDF_REQUIRE_BLAKE3_PATHS`, `PURRDF_REQUIRE_HASH_PATHS`,
  `PURRDF_REQUIRE_DEFLATE_PATHS` and `PURRDF_REQUIRE_DISPATCH_PATHS`, and
  covers the CSV scanner. Its value is `1` (every path the host is expected to
  run, judged from the architecture and `/proc/cpuinfo`) or a comma-separated
  `family:path` list over the families `blake3`, `crc32`, `csv`, `deflate`,
  `distance`, `hex` and `sha1`; an unknown family or path fails the run.

- **hnsw:** every constructor is one generic body over the sealed
  `purrdf_hnsw::IndexArithmetic` family (`Exact`, the default, and
  `Reassociated`): `build::<A>`, `HnswIndex::<A>::decode`, `guard::load::<A>`
  and `HnswSpace::<A>::from_artifact`, with `guard_contract_for`,
  `derived_index`, `profile::implementation_for` and
  `profile::profile_declaration_for` bounded by `IndexArithmetic`. A call whose
  context does not fix the arithmetic names it (`guard::load::<Exact>`,
  `HnswIndex::<Exact>::decode`). `HnswIndex::build` stays as the named
  spelling of `build::<Exact>`. `HnswIndex::build_reassociated` (use
  `build::<Reassociated>`), `HnswIndex::decode_reassociated`, `guard::load_reassociated`,
  `HnswSpace::from_artifact_reassociated`, the free `build_reassociated`,
  `profile::loss_evidence_reassociated` (use
  `profile::loss_evidence_for::<Reassociated>`) and
  `profile::implementation_id_for` (use `IndexArithmetic::IMPLEMENTATION_ID`)
  are removed. No image, identity or profile byte changes.
- **datalog, entail, core, rdf, shapes, shex, sparql-eval:** a type whose empty
  value is the derived one derives `Default` and has no `new()`; call
  `T::default()`. This covers `SkolemRegistry`, `ProofArena`, `TermInterner`,
  `TermDag` and `Subst` (datalog), `rif::RuleSet` (entail), `ArtifactIndex`,
  `SegmentUnitMap` and `imports::ImportMap` (core), `OkfBundle` (rdf),
  `RecursionGuard` (shapes), `SemActRegistry` (shex), and
  `AggregateRegistry`, `ScratchInterner`, `ServiceCatalog`, `VarSchema` and
  `UserFunctionRegistry` (sparql-eval).
- **gts:** `VerifyOptions::strict()` is `VerifyOptions::new()`, the same value
  (embedded key lookup, signatures required), which `Default` returns.
- **sparql-eval:** `PartialAnswers` is generic over the carrier of its rows,
  `PartialAnswers<R = PartialSparqlResult>`, with `as_ref` (the same
  certificate over a borrow) and a generic `into_result`; `result` is no
  longer a `const fn`.
- **rdf:** each selection the curated projections share is one type:
  `projections::GraphSelection` and `projections::SubjectSelector`, with
  `CsvwTermsGraphSelection`/`OkfGraphSelection` and
  `CsvwTermsSelector`/`OkfConceptSelector` as type aliases. `LpgIriSelection`
  and `LpgNamedGraphSelection` are aliases of `LpgSelection<T>`, whose variant
  fields are `include` and `exclude` (an IRI selection's fields were `allow`
  and `deny`; its JSON still names them so). `CroissantConfig` and
  `DcatConfig` are aliases of `research_object::JsonLdProfileConfig<V>`.
- **rdf:** `viz::VizJson` is removed; the visualization types read and write
  JSON through `purrdf_lex::json::record`'s `FromJson`/`ToJson`.
- **core:** `ir::pack::PackSideError` and `PackTriplesError` are aliases of
  `PackBitsError`, so their messages start `pack:` rather than `pack-side:` and
  `pack-triples:`. `EffectiveF32Row` and `EffectiveF64Row` are aliases of
  `EffectiveRow<R, N>`, and `TermBox` is an alias of `purrdf_lex::walk::Nested`
  (as is `purrdf_sparql_algebra::tree::Child`).
- **cdt, events:** `purrdf_cdt::TextDirection` re-exports
  `purrdf_events::TextDirection`, the one RDF 1.2 base-direction type (with
  `as_str` and `from_str_token`), so the two are no longer separate enums.
- **shapes:** `json_schema::local_name` returns `&str`: it is a re-export of
  `purrdf_iri::local_name`.
- **sparql-conformance:** `owl2::ledger_lookup` and `owl2_rl::ledger_lookup`
  are removed; `ledger::lookup` reads either ledger, and each module's
  `LedgerEntry` is an alias of `ledger::LedgerEntry<G>`.

**New refusals**

- **shex:** a shape map refuses `<< s p o >>` as a node selector, with an
  error naming `<<( s p o )>>`. It is RDF 1.2 reifier syntax, not a triple
  term, and a shape map has no reifier form; the reader used to accept it as a
  triple term. `<<( s p o )>>`, nested or not, is unchanged. A ShExC schema
  has no triple-term value either: `<<` in a value set or node constraint is
  refused with an error saying so (and its byte offset), not a generic
  "not allowed in an IRI reference" lex error.

- **validate, cli, sparql-conformance:** an import list or `--import` table
  refuses a key that is not an absolute IRI (not only the empty one) with the
  same policy the shapes import table already applied: `ImportMap::try_insert`
  is the one key check, so the reasoning services, `purrdf query`/`entails`
  premise imports and the OWL 2 RL conformance imports refuse a relative key
  and a repeated key alike, and two distinct absolute keys are accepted.

- **gts:** COSE_Sign1 verification is strict: a non-canonical `S`, an
  undecodable `R`, and a small-order key or `R` are invalid even where the
  cofactorless equation holds, so a small-order key no longer validates a
  signature over every frame. `VerifyingKey::from_bytes` refuses a
  non-canonical key encoding, as RFC 8032 §5.1.3 requires.
- **gts:** a compaction certificate followed by trailing bytes is refused,
  bytes after a transformed payload item mark the frame `DamagedFrame`, and a
  read error before an item in the streaming reader is a torn tail rather
  than a clean end. `mmr::Proof::from_json` reads with a depth cap.
- **jsonschema:** a registered schema that repeats a member name is refused as
  `InvalidKeyword` naming the object.
- **rdf, shapes, shex:** a JSON-LD context, a JSON Schema being imported, a
  LinkML mapping and a ShExJ document that repeat a member name are refused;
  ShExJ admits 128 open containers.
- **rdf:** YAML-LD and OKF frontmatter refuse a duplicate key, a non-string key
  (`1:`), a non-core tag, `.inf`/`.nan` and a second document; YAML-LD also
  refuses aliases.
- **rdf:** a projection configuration record written as a JSON array, a
  closed-enum value written as a map, and extra members beside a field-less
  tagged variant are refused; projection JSON is read at most 128 containers
  deep.
- **retrieval, wasm:** retrieval `Plan` JSON, the wasm visualization options and
  the wasm SERVICE profiles refuse a repeated member and a record written as a
  JSON array; a plan's embedding component beyond the `f32` range is refused
  rather than read as infinity. A plan refusal is `PlanError::InvalidJson`
  with the JSON Pointer of the offending value.
- **sparql-results:** the JSON reader refuses a number outside the RFC 8259
  grammar such as `1-2+e` (`-1.2e+3` still parses), and the XML reader refuses
  a `DOCTYPE` and a root `<sparql>` element in a namespace other than the SPARQL
  results namespace.
- **shapes:** a SHACL list cell with two `rdf:rest` edges is refused.
- **rdf:** visualization JSON refuses an unknown member, a repeated member and
  a member of another tagged variant. `GraphSelection` and `SubjectSelector`
  are validated as they are read from JSON (an empty graph scope, a relative
  IRI, a type constraint without a type predicate), and so are the SKOS and
  OBO Graphs role groups (a relative or shared role IRI).

**Changed output**

- **cli:** a governed `query`, `update` or `validate` run starts from
  `QueryGovernors::METERED`; `--no-ceiling` asks for `UNBOUNDED` (see Changed).
- **rdf, python:** the GTS fold view builds in only the W3C prefixes; a
  schema.org IRI stays in full unless the caller supplies the prefix (see
  Changed).
- **sparql-eval:** golden change — CONSTRUCT loss-node labels hash with FNV-1a
  over framed bytes instead of std's unspecified hasher; the fixture triple's
  label is now `loss-53ade2f793c76fe0`.
- **sparql-results:** golden change —
  `crates/sparql-results/tests/golden/results_corpus/construct_starred_graph_json.json`
  writes an `xsd:string` literal as `"…"` rather than `"…"^^xsd:string`, inside
  and outside the triple term, because every term writer spells terms through
  `purrdf_lex::term_syntax`.
- **shapes:** `crates/shapes/corpus/32-datatype-derived-integer/shapes.ttl` and
  `36-sparql-prefixes/shapes.ttl` change in their comments only, so their
  frozen hashes in `scripts/conformance-frozen/shapes-corpus.sha256` move; no
  expected report changes.
- **rdf, core, cdt, shex:** literal escapes follow the carrier, from one
  escaper (`purrdf_lex::literal_escape`). The N-Triples/N-Quads/Turtle/TriG
  serializer writes BACKSPACE and FORM FEED as `\b` and `\f` and escapes
  U+FFFE and U+FFFF; the canonical Turtle renderer writes `\b`, `\f`, `\t` and
  `\r` and escapes a `"` that would close a long string; `cdt` canonical forms
  write `<<( s p o )>>` with inner spaces and C1 raw; ShExC escapes DEL, C1,
  `\b` and `\f`. The core Turtle writers `UCHAR`-escape predicate and datatype
  IRIs, and the fold-view token and statement triple-term predicate escape
  their IRIs.
- **rdf:** the fold-view and visualization labels drop `^^xsd:string` and
  write C1 raw; a compact visualization literal label escapes its lexical
  form.
- **iri, rdf, shapes:** CURIE compaction takes the longest matching namespace
  (`purrdf_iri::contract`), and a local name is the longest suffix holding no
  `#`, `/` or `:` (`purrdf_iri::split_local_name`). An empty CURIE prefix no
  longer compacts in `purrdf-shapes`, and the LinkML exact-namespace fallback
  follows the longest match; the canonical Turtle renderer compacts under
  `@prefix :` and yields a namespace whose local part the grammar refuses to
  the next longest (`purrdf_iri::contract_where`).
- **shapes:** the engine's sort key writes BACKSPACE and FORM FEED as `\b` and
  `\f` and DEL as `\u007F`, escapes an IRI that needs it, and keeps the
  datatype of an untagged `rdf:langString` literal, so the order of reports
  over such terms changes. Object lookups are deduplicated and in id order,
  which changes which object `first_object` returns and the blank-label
  numbering of a report.
- **shex:** shape-map terms are written as RDF 1.2 triple terms
  `<<( s p o )>>` with their base direction kept, and the shape-map parser
  reads that spelling back.
- **entail, shex:** reasoning answers and shape-map node sets sort by
  `TermValue`'s total order (see Changed).
- **rdf:** JSON-LD list cells are minted before their members, in the order
  JSON-LD 1.1 §8.4 walks them, which renumbers blank-node labels; a
  well-formed list suffix behind a shared cell now folds to a list. The XML
  nesting limit counts self-closing elements.
- **sparql-eval:** EXPLAIN spells a base direction `--ltr`/`--rtl` and escapes
  a backslash; graph names in the named-graph refusal and SERVICE endpoint
  text are escaped; the Update display writes SPARQL literals rather than Rust
  debug strings; a list read through a FROM merge counts an edge asserted in
  two graphs once.
- **entail:** an OWL negation member list whose cells are typed `rdf:List` is
  accepted.
- **rdf, python:** `GtsFoldView::rdf_list` and the OBO Graphs collection reader
  read through the strict walker: a cell with no or several `rdf:first`, or no
  or several `rdf:rest`, ends the list there rather than having one of its
  values picked.
- **rdf, wasm, sparql-results, geo:** JSON error text names the
  member and drops the `line X column Y` suffix, and reader syntax errors use
  `purrdf_lex::json`'s messages; the duplicate-member diagnostic reads "an
  object repeats a member name".
- **rdf, shapes:** JSON and YAML numbers keep their lexemes: YAML-LD and LinkML
  values beyond binary64 round-trip instead of being refused, and the OKF
  writer spells a decimal as its shortest JSON lexeme (`1e+20`).
- **jsonschema:** the `properties` annotation follows the instance's member
  order, and the `application/json` `contentMediaType` check has no depth cap.
- **rdf:** a CBOR simple value in GTS metadata surfaces as
  `RdfMetadataValue::Opaque` spelt by the CBOR value (`undefined` for simple
  value 23).
- **core, datalog, retrieval:** the derived `Debug` of `ContractHash` and
  `PlanIdentity` prints `Digest32(<hex>)`. No rendered or parsed hex byte
  changed case anywhere.
- **wasm:** a blank node outside the default scope crosses into JS as its scope
  envelope rather than its bare label (see Fixed).
- **gts:** the writer encodes term ids as CBOR unsigned integers; the bytes are
  identical for every id up to `i64::MAX`.
- **slice:** `Dataset::canonical_nquads_flat` writes a graph-scoped reifier and
  its annotations into their graph rather than the default graph, so its output
  changes for such datasets (see Fixed).
- **rdf:** the GTS import sink reports a bad literal base direction as
  `gts-invalid-direction` and `gts-direction-without-language` (it used
  `native-codec-invalid-direction` and
  `native-codec-direction-without-language`), the codes the GTS reader uses.
- **rdf:** projection refusal wording: selection errors no longer name the
  projection (`graph selection must include at least one graph`), a CSVW
  fragment IRI failure reads `invalid CSVW fragment URL`, a research-object
  role map that binds two roles to one term reads "research-object vocabulary
  binds roles … both to …" (it read "research-object roles … both bind …"), and
  a visualization JSON decode failure is `purrdf_lex::json::record`'s
  (`missing field`, `unknown field`, `duplicate field … at <pointer>`) rather
  than `missing member` or `expected …, found …`.
- **core:** a malformed PURREMB target field reads `required field has wrong
  type or criticality`, like every other required field.
- **hnsw:** a space row with no bound term is refused in the exact relation's
  words, naming the row's target and saying the top-k would be a subset's.
- **validate:** `explain_shapes_product` renders an empty identity component as
  `""` rather than `0x`, through `purrdf_core::artifact::identity::render_value`.
- **capi:** a null string array with a non-zero count passed to
  `purrdf_shacl_eval_node_expr` is refused naming the parameter (`null scope
  array …`, `null expr_via array …`).
- **python:** a store snapshot failure reads `store snapshot failed: …`
  (`Store` and `MutableDataset` said `snapshot failed` or `dataset snapshot
  failed`), and `gts_from_rdf12_bytes` is the same function object as
  `gts_from_quads`.
- **sparql-conformance:** a result-kind mismatch names the query form
  (`select`, `ask`, `construct`) rather than `SELECT solutions`,
  `ASK boolean` or `graph`.

### Added

- **core:** certified provider-backed segmented snapshots with stable term IDs,
  front-coded dictionaries, authenticated sparse indexes, explicit empty graphs,
  pinned reads, shared live-memory admission and exact bounded request evidence.
  Persisted receipts require an explicit trusted certification authority. Bounded
  projected BGP queries and streaming TriG exports use the same native evaluator
  and RDF representation. The existing eager pack reader remains supported.
- **diagnostics:** validated message identities, typed parameters and structured
  details, with exact JSON/SARIF records and a borrowed C error-record accessor.
- **distribution:** generated recipient-specific rights inventories and full
  notices, actual Cargo/Python/npm/C archive audits, compiler runtime notices,
  coherent native/shadow Python versions, and isolated empty crate bootstrapping.
  The XML conformance suite is acquired and hash-verified in a local cache.

- **wasm:** `QueryEngine.blankScope` (`"keep"` or `"merge"`, typed as
  `BlankScopeMode`), the declared option for how a blank node's scope crosses to
  JS in the engine's typed results (`query`, `select`, `queryGoverned`,
  `queryEntailmentGoverned` and their `Async` twins, which take the value in
  force when the job begins). `"keep"`, the default and the behaviour of every
  earlier release of this cycle, hands a scoped blank over as its scope envelope,
  so two blank nodes that share a label in different scopes stay two nodes;
  `"merge"` drops the scope, so they are one node with the bare label (lossy by
  declaration). Any other value throws with the code `purrdf-wasm-options`.
- **sparql-eval, wasm, helper-census:** each wasm host import is declared once:
  the `Date.now` import is `purrdf_sparql_eval::wasm_host::date_now` (hidden
  public; `purrdf-wasm`'s job clock reads it) and the `Reflect.get` import is
  `purrdf_wasm::host::reflect_get` (hidden public; the option reader and the
  test-flag reader share it). The census rules `wasm-import-date-now` and
  `wasm-import-reflect-get`, held by the `wasm-host-clock` and
  `wasm-host-reflect-get` ledger jobs, fail `check-shared-helpers.py` on a second
  `#[wasm_bindgen]` import of either, in any file; the one variant is the wasm
  test runner's seal fixture, which must read the raw global.
- **core:** `purrdf_core::imports::ImportMap::try_insert`, `ImportMap::check_key`
  and `ImportKeyError`: the one import-table key policy (an absolute IRI naming
  one document), used by `ShapesImports`, the reasoning services' import lists,
  and the CLI's `--import` tables.
- **shapes:** `purrdf_shapes::run_rules`, `RuleSource` and `RuleLimits`: the one
  rules-dispatch entry for a SHACL shapes graph's rules or a SPARQL 1.2 RL rule
  set under the four rule-evaluation limits. The `purrdf rules` command,
  `apply_rules_to_ntriples` (Python, WebAssembly and C) and the entailment
  service all run through it.

- **core, testkit:** test-support homes for what the test suites and benches
  each spelt out for themselves (doc-hidden, no stability promise):
  `purrdf_core::purremb_fixture::Identities` (the PURREMB artifact and stage
  identities of a family contract, the IRI bases, stage payload and salt as
  fields so each suite keeps its sealed bytes), `purrdf_core::distance::control`
  (`mxcsr`/`set_mxcsr`/`Mxcsr` and `fpcr`/`set_fpcr`/`Fpcr`: the one assembly
  wrapper per float control register, `set_mxcsr` clearing the reserved bits
  that would fault), and `purrdf_testkit::rng::permute` (an unbiased
  Fisher-Yates over `Xoshiro256::up_to`). The four lex, the xsd and the geo,
  text, retrieval and `purrdf` bench SplitMix wrappers, the hash and deflate
  xorshift benches and the sparql-eval counting allocator now draw from
  `purrdf_testkit::rng` and `purrdf_alloc_probe`; bench inputs are byte for byte
  the ones they were.
- **core:** `purrdf_core::ir::skolem::escape_label_bytes_into`, the one `-xx`
  blank-label escape (ASCII-alphanumerics pass, every other byte becomes `-`
  plus two lowercase hex digits). The genid path segment and the SHACL rule
  engine's minted-blank tags (`purrdf-shapes`) both call it; their output is
  byte-identical to before. Ledger job `blank-label-hex-escape`.
- **ed25519:** `purrdf-ed25519`, a new published, wasm32-clean crate and the
  workspace's one Ed25519 (RFC 8032): `SigningKey` (key expansion from a
  32-byte seed, deterministic `sign`, secrets overwritten on drop),
  `VerifyingKey` (`from_bytes` refuses a non-canonical encoding) with
  `verify_strict` (refuses `S ≥ L`, an `R` or key that fails §5.1.3 decoding,
  a small-order key or `R`, and a failed cofactorless equation), and
  `Signature`. Field arithmetic is radix 2^51 and scalar arithmetic Montgomery
  mod `L`; signing reads its fixed-base table by masked selection, with no
  secret-dependent branch or index. SHA-512 is `sha2`'s. Every RFC 8032 §7.1
  vector and frozen vectors for signing, verification edge cases, key
  decoding and torsion and mixed-order signatures
  (`crates/ed25519/tests/vectors/`) are replayed.
- **ed25519:** the crate is now graded against Project Wycheproof's Ed25519
  vectors, vendored byte-frozen in `vectors/wycheproof/` (pinned upstream
  commit and SHA-256 in its `PROVENANCE.md`, re-fetched only by
  `scripts/vendor-wycheproof-ed25519.py`, guarded by
  `scripts/check-corpus-frozen.py`): `tests/wycheproof.rs` runs every group and
  case (151 cases, 88 valid accepted and 63 invalid refused). A
  `purrdf_testkit::bench` target
  (`benches/ed25519.rs`) times sign, verify_strict, key expansion, key
  decoding and a GTS-shaped 64-signature batch, and the SIMD audit carries
  `ed25519.sign` and `ed25519.verify` site rows.
- **lex:** `purrdf_lex::json`, the workspace's one RFC 8259 JSON home: the pull
  `Reader` (events with byte offsets, `next_key`/`next_item`, `skip_value`,
  `read_value`), `read`/`read_with`/`read_slice`, `occurrences`, a `Value`
  whose `Number` keeps its lexeme (`as_f64` correctly rounded,
  `Number::from_f64` the shortest round-trip lexeme) and whose `Object` keeps
  every member in order, `Limits` (a depth cap of 128 by default, value and
  string bounds, and RFC 7493 unique members), and the deterministic
  `write_compact`/`write_pretty`. `json::record` is the one typed decoder over
  a `Value`: the strict `Record` reader (required, optional, defaulted and tag
  members; unknown, repeated and non-object records refused), `FromJson`,
  `ToJson`, `JsonKey`, `Within`, `json_string_enum!` and `DecodeError`, which
  carries the RFC 6901 pointer of the offending value. No reader, writer,
  drop, clone, comparison or `Debug` walk recurses on the machine stack.
- **lex, sparql-results, geo:** the pull reader is enough to decode from:
  `json::Reader::check_value` holds a value to everything `read_value` does
  (escapes decoded, the string bound, repeated names) without building it, and
  on every JSONTestSuite document gives `read_value`'s verdict and error, and
  `Reader::peek_kind` names the value at the cursor from its first byte. A
  string token records whether it holds an escape as it is scanned, so
  `Str::has_escapes` is a field and `Str::decode` borrows an escape-free body
  without reading it again. The SPARQL-results JSON `SELECT` readers
  (`from_json`, `from_json_bounded`) and the GeoJSON literal reader decode from
  the events — rows, terms and exact positions built directly, no JSON tree —
  and refuse exactly what the tree readers did, with the same message:
  400,000 mutated SRJ documents and 300,000 mutated GeoJSON literals, compared
  against the tree readers, never diverged. The tree-walking GeoJSON reader is
  kept in the tests, as the reference the streaming one is compared against.
- **lex:** `json::Number::decimal` (the canonical exact value: sign, significant
  digits, a base-ten exponent that is a machine word until it leaves `i64` and
  its digits after), `Value::same_text` and `Number::same_text`, and
  `Hash for Value`/`Object` (an iterative, order-independent walk consistent
  with `==`). `purrdf_xsd::json_number::JsonNumber::parse` builds on
  `Number::decimal` instead of a second canonicalizer, and
  `purrdf-jsonschema`'s private `equal`/`hash_value` are gone: `const`, `enum`
  and `uniqueItems` compare with `Value`'s `==` and `Hash`.
- **lex:** the JSONTestSuite `test_parsing/` corpus (318 documents: 95 `y_`, 188
  `n_`, 35 `i_`), vendored byte-frozen in `vectors/JSONTestSuite/` by
  `scripts/vendor-jsontestsuite.py` (pinned commit, tree id and licence digest;
  registered in `scripts/check-corpus-frozen.py`). `tests/json_test_suite.rs`
  requires every `y_` to be accepted and to round-trip, every `n_` to be
  refused (on a 256 KiB stack, with the depth cap lifted too), and pins each
  `i_` outcome by file name with its reason (UTF-8 only and no byte-order
  mark, an unpaired surrogate refused, a number kept as its lexeme, depth an
  explicit cap). The reader needed no change: no `y_` was refused and no `n_`
  accepted.
- **lex:** `purrdf_lex::yaml` reads one YAML 1.2 document (block and flow
  styles, every scalar style, explicit keys, core-schema tags, anchors and
  aliases under a node bound) into a `json::Value` and writes the block layout
  (`read`, `read_with`, `write`), with numbers kept as lexemes; a duplicate
  key, a non-string key, a non-core tag, `.inf`/`.nan` and a second document
  are refused with typed errors.
- **lex:** the official yaml-test-suite (`data-2022-01-17`, 402 cases),
  vendored byte-frozen in `vectors/yaml-test-suite/` by
  `scripts/vendor-yaml-test-suite.py` (pinned commit, tree digest and licence
  digest; registered in `scripts/check-corpus-frozen.py`), grades the YAML
  reader in `tests/yaml_test_suite.rs`: 244 valid cases read as the suite's
  JSON, 5 empty streams read as `null`, 94 invalid cases are refused, and 59
  valid cases outside the JSON subset (15 second documents, 27 non-string keys,
  17 non-core tags) are refused by their own error kind, each shown against the
  suite (a refused key has no JSON in the suite, a refused stream has two
  documents); none is read wrongly. The classification comes from the reader's
  error kinds, not from a skip list. The grading found 38 defects, all fixed:
  20 invalid inputs read (a tab after a block indicator, a document marker
  inside a quoted scalar or flow collection, a quoted or flow line indented no
  more than its block, `[-]`, a multi-line implicit key in a flow sequence, a
  duplicate or malformed `%YAML`/`%TAG` directive, an anchor before `- ` on its
  line, and a block scalar whose empty lines hold more spaces than its first
  content line), 15 valid inputs refused (a tab as separation before a flow
  node or inside a block scalar, a zero-indented top-level block scalar, an
  anchor on both a mapping and its first key, an alias key after the mapping's
  anchor, a flow entry of only properties), 2 values read wrongly (a
  whitespace-only last line of a block scalar at the end of the stream), and 1
  entry silently dropped (the empty key after `?` in a flow mapping, now a
  refused null key).
- **lex:** `yaml::Limits::scalar_keys` (off by default): a number, boolean or
  null mapping key is accepted as its source text (`1: a` is the key `1`,
  `True: a` the key `True`, `? 1` and `!!int 1: a` likewise); a collection key
  is refused either way. OKF frontmatter sets it, so it reads scalar keys as
  their source text as before (uniqueness is checked on that text: `1: a` with
  `"1": b` repeats a key). YAML-LD does not: it requires the refusal ("every
  mapping key MUST be a YAML scalar whose resolved node tag ... is
  `tag:yaml.org,2002:str`, otherwise a mapping-key-error MUST be detected",
  "Mapping Key Types"), so `1: a`, `true: a`, `1.5: a` are refused there where
  the `serde_yaml` to `serde_json` bridge had written them as string keys
  (`null: a` and `~: a` were refused on both), while `'1': a` and `!!str 1: a`
  are read. LinkML refuses every non-string key, as before.
- **lex:** `purrdf_lex::cbor`, the RFC 8949 codec: `Value`, the shortest-form
  head writers and readers (`cbor::head`), as-is and core deterministic
  encoding (`encode`, `canonical`, `write_canonical_map`, `encoded_len`), and
  well-formed, deterministic, prefix, streaming and sequence decoders
  (`decode`, `decode_deterministic`, `decode_prefix`, `read_from`,
  `decode_sequence`) under `Limits`, reproducing RFC 8949 Appendix A.
- **lex:** `purrdf_lex::xml`, the XML 1.0 + Namespaces reader: a pull `Reader`
  and a `Document` tree, an explicit depth cap, no machine-stack recursion and
  byte offsets in every error. A `DOCTYPE` is refused unless the caller asks
  for the internal subset (`Dtd::internal_subset`), whose internal general and
  parameter entities expand under one expansion budget; nothing is ever
  fetched (see the XML conformance entry below for what is refused).
- **lex:** `purrdf_lex::xml` reads parameter entities as XML 1.0 §4.4.8 and
  §5.1 require of a non-validating processor. `<!ENTITY % name "...">` and
  `%name;` between markup declarations of the internal subset are read
  (including the declarations a replacement text produces, so the Appendix D
  `&#37;` example works); a reference inside a markup declaration ("PEs in
  Internal Subset"), malformed syntax, a recursive entity, a declaration that
  does not close in the entity it opens in, and an expansion bomb are refused
  with their own errors, on a heap stack and the same replacement-text budget
  as general entities. An external parameter entity or external subset is
  never fetched: the generic reader stays spec-lenient and lets it be named,
  declared and referenced, the declarations
  after it are checked but bind nothing (`Reader::declarations_unread`,
  `Document::declarations_unread`), and a reference to an entity only such
  declarations could bind is refused (`XmlErrorKind::UnexpandedEntity`)
  rather than dropped. An external or unparsed entity may be declared; a
  reference to one is refused (`ExternalEntity`, `UnparsedEntity`). Before,
  any parameter entity, external subset or external entity declaration was
  refused, which refused well-formed documents.
- **lex:** the XML reader checks every markup declaration a non-validating
  processor must (`ELEMENT` content models, `ATTLIST` types and defaults,
  `NOTATION`, `ENTITY`, external identifiers, the predefined-entity
  redeclaration rule), so malformed declarations were accepted before; an
  `ATTLIST` default expands the entities declared before it (a forward
  reference is a well-formedness error), and processing instructions in the
  internal subset now reach the caller as events.
- **lex:** `purrdf_lex::xml::decode` turns document bytes into reader text
  under XML 1.0 Appendix F: UTF-8, UTF-16 (either byte order), US-ASCII and
  ISO-8859-1; any other encoding (UCS-4, EBCDIC, Shift_JIS, EUC-JP, ...) is
  refused as `XmlErrorKind::UnsupportedEncoding`, and bytes that contradict
  their declaration as `Encoding`. A document declaring `version="1.1"` is
  refused (`UnsupportedVersion`) instead of being read as XML 1.0; other
  `1.x` versions read as 1.0, per the Fifth Edition.
- **lex:** the W3C XML Conformance Test Suite (xmlts20130923), vendored
  byte-frozen in `vectors/xmlconf/` by `scripts/vendor-xmlconf.py` (pinned URL
  and SHA-256, `PROVENANCE.md`), grades the reader in
  `crates/lex/tests/xmlconf.rs`: 2585 cases, every one classified from its own
  `TYPE`, `VERSION`, `EDITION`, `ENTITIES` and `NAMESPACE` attributes and the
  reader's error kinds (no skip list), with `OUTPUT` canonical forms compared
  byte for byte; zero failures, totals pinned.
- **lex:** `literal_escape` (`write`/`escape` over `Carrier::{Canonical, Xml,
  TurtleLong}`, and the chunked kernels behind them), `iri_escape`,
  `term_syntax` (`write_iri`, `write_literal` with `xsd:string` elided,
  `write_blank` and the triple-term delimiters), `text_out::TextOut` and
  `crockford` (`encode_u128`, `write_u128`, `parse_u128`, the ULID text form).
  `purrdf_core` re-exports `iri_escape` and `TextOut` at their former paths.
- **hash:** `purrdf_hash::fnv` (`BASIS`, `PRIME`, `fnv1a64`, `fold`),
  `purrdf_hash::mix` (SplitMix64 `splitmix64_next`, `splitmix64_step`,
  `splitmix64_finalize` and `GOLDEN_GAMMA`; the `[-1, 1)` draws
  `signed_unit`, `signed_unit_next`, `signed_unit_step` and their `_nonzero`
  forms; and the MMIX linear congruential step `lcg64_next` with
  `LCG64_MULTIPLIER` and `LCG64_MMIX_INCREMENT`), `purrdf_hash::frame`
  (`frame_le`, `frame_le_into`, `frame_be_labelled`), and
  `purrdf_hash::dispatch::Backend`, the one trait every family of named
  execution paths implements (`selected`, `is_available`, `all_available`,
  `name`), with `PURRDF_REQUIRE_SIMD_PATHS`. All `const fn` where the
  arithmetic allows; every digest, identity and golden they compute is
  unchanged.
- **core:** `purrdf_core::collections`, the one RDF collection home:
  `walk_rdf_list` and the allocation-free `RdfListWalk` (the strict walk of
  RDF 1.2 Semantics §D.3, yielding `ListFault`), `ListError`/`ListErrorKind`,
  `build_rdf_list` over a `ListVocab` (every cell minted before any member),
  and `convertible_list_cells` (JSON-LD 1.1 §8.4.2). `DatasetView` gains
  `rdf_list_strict`, `objects`, `objects_of_predicate` and `sole_object`;
  `graph::scc_component_index`, `write_term_value` and `purrdf_core::bytes`
  (`read_u32_le` and its siblings) are public. `term_fixture` is a hidden
  public module, so the published crate builds its own unit tests.
- **gts:** `files::media_type_for_extension` and `files::media_type_for_path`,
  the one extension-to-media-type table (case-insensitive; the RDF, SPARQL,
  Markdown, YAML, HTML, image and archive types; `rdf` is
  `application/rdf+xml`), behind the GTS files profile, the slice catalog, the
  Python slice-artifact rows, the slice RDF loader and the SPARQL conformance
  harness's data-file loaders. Tar ingest is not one of them: tar entries carry
  no media type.
  `purrdf-slice` gains a direct `purrdf-gts` edge.
- **iri:** `contract_where`, CURIE and prefixed-name compaction under the
  longest namespace whose split the caller's name grammar admits (`contract`
  is its CURIE case), and `split_local_name` / `local_name`, the one
  namespace/local split.
- **xsd:** `purrdf_xsd::json_number::JsonNumber`, an exact RFC 8259 number:
  `parse`, numeric `Eq`/`Ord`/`Hash` (`1.0` equals `10e-1`), `is_integer`,
  `is_multiple_of` and `to_u64_saturating`, however many digits it carries.
- **stack:** `purrdf_stack::{on_stack, on_stack_scoped, StackError}`: run a
  computation on a stack of a stated size — a fresh thread natively, inline
  on wasm32 after checking the request against the floor, a request past the
  floor refused typed.
- **validate:** `purrdf_validate::governors::{from_parts, from_update_parts,
  GovernorParts, GovernorPartsError}`, the one governor decoder every host
  uses, from `QueryGovernors::METERED`; `purrdf_validate::query::provenance`
  and `ENGINE_LABEL`, the query identity and engine label a SPARQL results
  emission carries.
- **sparql-results, cli, python, wasm:** `SparqlResultsFormat::{from_name,
  token, media_type, ALL}`, the one reading of a results-format name. Every
  host now accepts `json`, `srj`, `sparql-json`,
  `application/sparql-results+json`, `xml`, `sparql-xml`,
  `application/sparql-results+xml`, `csv`, `text/csv`, `tsv` and
  `text/tab-separated-values`, ignoring ASCII case and surrounding
  whitespace.
- **retrieval:** `Plan::to_json_string` / `from_json_str` and the
  `to_json`/`from_json` of every value a plan carries, writing the document
  shape the plan always had; `PlanError::InvalidJson` carries the JSON Pointer
  of a refused value.
- **testkit:** `purrdf_testkit::bench`, the micro-benchmark harness every bench
  target runs on (`Bench`, groups, `BenchmarkId`, `Throughput`, `BatchSize`,
  `iter`/`iter_batched`/`iter_batched_ref`/`iter_with_large_drop`,
  `bench_group!`/`bench_main!`; warm-up, a median with MAD and a seeded
  bootstrap 95% interval, saved baselines and a fixed-schema `estimates.json`,
  natively and on wasm32). Group names, benchmark ids and workloads are
  unchanged, and CI's regression check reads the same `Performance has
  regressed.` line. Also `purrdf_testkit::{paths, golden, rng}`: the workspace
  root and Rust-source walks, byte goldens with one regeneration switch, and
  seeded draws over `purrdf_hash::mix`.
- **hash-conformance:** `purrdf-hash-conformance` (unpublished) holds the
  frozen-vector suites, differentials and benches of `purrdf-hash` on
  testkit's runner and harness, natively and on wasm32, so `purrdf-hash` has
  no dev-dependency on testkit.
- **lex:** `purrdf_lex::walk`, the heap-backed structures every whole-tree
  walk shares: `WorkList` (a work list with an inline prefix), `Nested` and
  `Dismantle` (an owned child box whose drop takes the nesting apart over a
  work list), and `write_debug` over `Tok` (a recursive type's `Debug`,
  byte-identical to the derive's, without recursion). `purrdf_lex::assoc`:
  `get`, `get_mut` and `insert` over an ordered `[(K, V)]` association list,
  read by first match.
- **lex:** the constructor and record macros: `constructors!` (constructors
  whose whole body is one conversion, text parameters as `impl Into<String>`),
  `variant_from!` (`From` impls that wrap a source into one variant, and
  `Variant(A, B) as convert` for a variant holding a rendering of its sources),
  `message_error!` (an error type whose whole content is one message, with an
  optional `detail` accessor) and `json_record!` (the `ToJson`/`FromJson` pair
  of a record from one member list, optionally built through a validating
  constructor).
- **hash:** `default_from_new!` (a `Default` that returns the type's `new`, or
  another no-argument constructor named with `T => name`),
  `debug_non_exhaustive!` (a `Debug` that shows the named fields and elides
  the rest), `vector_backend!` (a family of named dispatch paths with its
  `Backend` impl) and `fixed::hash_one`.
- **hnsw:** `IndexArithmetic`, the sealed family of arithmetics an index can be
  built, decoded, loaded and verified under, with its `IMPLEMENTATION_ID`.
- **sparql-eval:** `knn::{KnnInvocation, KnnAnswer, TermRows, RankSource,
  RankedCursor, neighbour_count, universe_size}` and the `KNN_*` position and
  mode constants: the nearest-neighbour call protocol the exact relation and
  the HNSW relation both run, each supplying only its ranking.
  `HostStopWatch`, a host's cancellation bit and wall deadline composed into
  the one latching `StopSignal` (a cancellation ranks ahead of a deadline), and
  `chunk_len_for_threads`, the fork-join chunk geometry.
- **core:** `SparqlResult::query_form` (`select`, `ask`, `construct`);
  `GraphSelector` with `resolve`, the one dataset-independent graph selector,
  which `purrdf_text` and `purrdf_geo::relation` re-export;
  `artifact::identity::render_value`, the one rendering of an identity
  component; `TermRef::map_ids`, `map_ids_scoped` and `QuadIds::map_ids`;
  `IntVector::from_values` and `RankSelectRef::mark_last_range`.
- **purrdf:** `QueryEntailment::for_regime`, the one mapping from a `Regime` to
  its query plan, and `GovernedEntailment::answered`.
- **rdf:** `flat_rdf_quads` is exported at the crate root beside
  `flat_rdf_quads_from_dataset`.
- **python:** `Store` and `MutableDataset` extend one native base class,
  `QuadStore` (not exported on the module), which holds the query, update,
  iteration and validation-capsule methods they share; each subclass keeps its
  own `load` and mutation surface.
- **sparql-conformance:** `ledger`, the one xfail-ledger reader
  (`LedgeredCase`, `LedgerEntry<G>`, `lookup`, `agreed`, `ledgered`,
  `unledgered`, `stale`, `tally`).
- **xsd, events, lex, sparql-algebra:** `purrdf_xsd::temporal::duration_result_datatype`
  (the duration tag join); `purrdf_events::CONTINUE`;
  `purrdf_lex::xml::Node::element_children`; `GraphPattern::empty_bgp`,
  `is_empty_bgp`, `as_property_function` and `as_property_function_mut`.
- **gates:** `helpers-ledger.toml` names the one home of every job, its
  specification, frozen vectors and sanctioned variants;
  `scripts/check-shared-helpers.py` runs the unpublished `helper-census` (a
  structural census of every function body, forwarder, constant and hex
  table) against it. `layers.toml` declares every first-party dependency edge
  (`scripts/check-layers.py`, with `--home-for` naming the lowest common home)
  and the kernel ring-fence `make rdf-core-hygiene` reads.
  `scripts/check-hash-domains.py` holds the `Domain` registry.
  `dependency-ledger.toml` gives every external package a census verdict
  (`distinct`, or `duplicates_native` naming the home that replaces it). Clippy
  bans std's `RandomState` maps and sets, and the `fixed-hasher-everywhere` job
  refuses every other spelling.
- **core:** `TermValue::to_rdf_term` / `into_rdf_term` and
  `TermValue::from_rdf_term` / `from_rdf_term_in_scope` are the one conversion
  between the dataset-independent value and the owned `RdfTerm` model. A blank
  node's `(label, scope)` pair crosses as `BlankScope::qualify_label` writes it
  and is read back by `BlankScope::unqualify_label`, so the round trip is exact;
  a literal's implied datatype (`xsd:string`, or the language datatype its base
  direction selects) is left implicit on the way out and expanded on the way
  in, with the language tag folded by `purrdf_iri::langtag::identity_fold`. A
  triple term whose predicate is not an IRI has no owned form and is refused
  with `NonIriPredicate`.
- **core:** `DatasetView::term_value(id) -> Result<TermValue, TermLookupError>`
  is the one resolution from a view's id to its value, through a literal's
  datatype and a triple term's components at any depth.
  `TermLookupError::ForeignId` reports an id whose literal datatype does not
  resolve to an IRI; no part of a value is invented in its place.
- **core:** `TermValue::integer` (any integer that widens to `i128`, written in
  its canonical decimal form) and `TermValue::boolean` are the one constructor
  for a computed `xsd:integer` and `xsd:boolean` literal.
- **sparql-eval:** `purrdf_sparql_eval::convert` is public: the query-text
  conversions from the algebra's terms to `TermValue` (`named_node_to_value`,
  `literal_to_value`, `ground_term_to_value`, `ground_term_pattern_to_value`,
  `ground_triple_pattern_to_value`). The algebra and the IR share one
  base-direction type, `purrdf_events::TextDirection` (re-exported as
  `purrdf_cdt::TextDirection`), so no direction mapping exists.
- **purrdf:** `purrdf::reasoning::query_bgp`, every basic-graph-pattern triple
  of a parsed query as the `QTriple`s OWL 2 Direct-Semantics augmentation reads.
- **entail:** `EntailError::ForeignTerm`, for an input view that hands back an
  id that is not its own.
- **helpers:** the `term-conversion` and `term-constructor` jobs of
  `helpers-ledger.toml` are enforced, each driven by a seeded fixture in
  `scripts/check-shared-helpers.py --self-test`.

- **lex:** `purrdf_lex` holds the workspace's escape decoders and lexical
  laws that grammar readers had each spelled for themselves:
  `terminals::decode_uchar` / `decode_uchar_at` (`UCHAR`), `echar_value`
  (`ECHAR`), `expand_uchars`, `decode_char_ref` (the XML 1.0 `CharRef`, which
  must name a `Char`), `skip_ws` / `trim_ws` (the four-scalar `WS`, XML `S` and
  JSON `ws`), `is_ncname`, `is_ncname_start`, `is_ncname_char` and `in_ranges`
  (now public); `json_escape::unescape`, `decode_escape`, `decode_u_escape` and
  `code_unit`, the one RFC 8259 string decoder, which refuses an unpaired
  surrogate; `json_pointer` (RFC 6901 `escape_token`, `push_token`,
  `unescape_token`, `tokens`, `array_index`); `percent` (`encode` and
  `push_encoded` over the sets RFC 3986, RFC 3987 and RFC 6570 define,
  `push_triplet`, strict `decode`, `decode_form` for
  `application/x-www-form-urlencoded`, and RFC 3986 §6.2.2 `normalize`); and
  `scan::find_byte` / `find_byte2`, the first occurrence of a byte known only
  at run time. `purrdf_iri` re-exports `json_pointer` and `percent` beside its
  other lexical modules. Frozen vectors in `crates/lex/tests/vectors/`
  (UCHAR/ECHAR over every value to U+11FFFF, JSON strings over every code unit
  and surrogate pair, JSON Pointer tokens, every percent-encoding set, needle
  search) were recorded from the implementations these replace and are
  replayed natively and on wasm32. `purrdf-lex` now depends on `purrdf-hash`,
  whose `hex::nibble` reads every digit.
- **hash:** `purrdf_hash::hex::parse_u32`, the number one or more hex digits
  spell, with no sign, prefix or whitespace (`u32::from_str_radix` accepts a
  leading `+`).
- **lex:** `purrdf_lex::unicode`, the workspace's one Unicode normalization
  pipeline: `nfc`, `nfd`, `nfkc`, `nfkd`, `is_nfc` (decided by streaming, with
  no allocation of the form), `ccc` (`Canonical_Combining_Class`), and the
  stage API — `Stage`, `Decompose`, `Compose`, `Out`, `Collect`, `Sink`,
  `Compare`, `drive`, `collect` and `lookup_two_stage` — for a caller that
  composes normalization with a stage of its own. `UNICODE_VERSION` is the
  version every Unicode table in the workspace is generated from.
- **lex:** `terminals::{is_ecma_line_terminator, ecma_line_terminator_ranges,
  is_ecma_class_space, ecma_class_space_ranges}`: ECMA-262 `LineTerminator`
  and `\s` (`WhiteSpace` ∪ `LineTerminator`).
- **iri:** `host::is_smtp_address_literal`, the RFC 5321 §4.1.3
  `address-literal` (`[192.0.2.1]`, `[IPv6:2001:db8::1]`).
- **core:** `xsd_regex::block_escape_unicode_version`, the Unicode version the
  XSD block-escape table is pinned to (that of the locked `regex-syntax`).
- **xsd:** `purrdf_xsd::rfc3339`, the workspace's one RFC 3339 reader and
  writer: `parse` (`date-time`, to Unix seconds and nanoseconds in UTC),
  `parse_date` (`full-date`), `parse_time` (`full-time`) and `format` (the
  canonical UTC spelling). Two parameters carry the one place the citing
  grammars differ: `Separator::{Rfc3339Abnf, GtsSpaceAllowed}` (a space
  between date and time) and `LeapSecond::{MonthEnd, AnyDay}` (whether a leap
  second must fall on a month's last day). `xsd:dateTime` stays its own
  grammar.
- **xsd:** `purrdf_xsd::wide::{wide_mul, div_wide, mul_div, gcd}`, exact `u128`
  arithmetic past `u128`.
- **xsd:** `BigInt::{from_digits, from_binary, mul_small, mul_pow5, mul, rem,
  is_odd, negated}`; `BigInt` also implements `Hash`. `from_binary` writes
  `numerator × 2^exponent` out as an exact decimal.
- **xsd:** `purrdf_xsd::json_number::cmp`, the exact order of two JSON number
  lexemes, however many digits or exponent digits they carry.
- **xsd:** `temporal::{civil_from_days, is_leap}` are public, and they,
  `days_from_civil` and `days_in_month` are `const fn`.
- **xsd:** `XsdDatatype::{is_numeric, is_integer_family, from_local}`,
  `XsdValue::is_numeric`, and `numeric::{is_integer_lexical,
  is_decimal_lexical}`.
- **iri:** `purrdf_iri::vocab`, the W3C vocabulary terms the workspace names,
  one module per namespace (`rdf`, `rdfs`, `owl`, `sh`, `shnex`, `sparql`,
  `sd`, `xpath`, `skos`, `prov`, `rif`, `its`, `xml`, `dcat`, `org`, `oa`,
  `odrl`, `time`, `sosa`, `ssn`, `ma`, `activitystreams`, `did`, `cred`), each
  with its namespace as `NS` and one constant per term. Every namespace is a
  W3C Recommendation's; nothing outside a W3C namespace is a constant here.
  `vocab::language_datatype_iri(has_direction)` gives the RDF 1.2 datatype of
  a language-tagged string (`rdf:dirLangString` with a base direction,
  `rdf:langString` without). The shapes crate's public `sh`, `shnex`,
  `sparql_ns`, `rdf`, `rdfs` and `xsd` modules re-export these constants under
  their existing names.
- **iri:** `langtag::identity_fold` and `langtag::is_identity_folded`, the
  RDF 1.2 value-space fold of a language tag (ASCII lowercase, equal to
  Unicode lowercase on every well-formed tag). Every place the workspace folds
  or compares a language tag by case now uses them.
- **xsd:** `datatype::{XSD_ANY_URI, XSD_NORMALIZED_STRING, XSD_TOKEN,
  XSD_LANGUAGE, XSD_NAME, XSD_NCNAME, XSD_NMTOKEN, XSD_DATE_TIME_STAMP}`, the
  fourteen constraining facets of XML Schema 1.1 Part 2 §4.3 (`XSD_LENGTH`
  through `XSD_EXPLICIT_TIMEZONE`), and `OWL_REAL`/`OWL_RATIONAL`, the two
  datatypes the OWL 2 datatype map adds. `rational::OWL_RATIONAL` re-exports
  the latter.
- **core:** `purrdf_core::vocab`, `purrdf_core::datatype` and
  `purrdf_core::langtag` re-export the three homes above, so every crate that
  reaches the kernel names each term, and folds each tag, the one way.
- **gates:** the helper census gains two literal rules. `rule:vocabulary-literal`
  (ledger job `w3c-vocab`, enforced) refuses a string literal in shipping code
  that equals or starts with a namespace declared in `purrdf_iri::vocab` or
  `purrdf_xsd::datatype` outside those modules, reading the namespaces from
  their `NS`/`*_NS` constants; a multi-line literal holding a Turtle or SPARQL
  keyword is an embedded document and exempt. `rule:home-literal` (job
  `text-direction`) refuses the `ltr`/`rtl` tokens outside
  `purrdf_events::TextDirection`, the one base-direction type.
- **hash:** `purrdf_hash::hex` is the workspace's base16 (RFC 4648 §8) codec.
  Rendering: `Lower` and `Upper` (`Display`, no allocation), `encode` /
  `encode_upper` (an owned `String`), `encode_into` / `encode_upper_into`
  (append to a `String`) and `encode_to_slice` / `encode_upper_to_slice`
  (into a caller's buffer, returning the written `&str`). Reading: `decode`
  (any even length, either case: the `xsd:hexBinary` lexical space),
  `decode_canonical` (lowercase only), each refusal a typed `HexError` naming
  the offset and byte of the first bad digit or the odd length; `decode_32` and
  `decode_32_canonical` (exactly 64 digits) and `nibble` and `nibble_canonical`
  (one digit) answer `None` for anything else. `Digest32` is the 32-byte digest value (`Display`,
  `from_hex`, `to_hex`, `as_bytes`) that every content identity now wraps.
  Inputs up to `hex::SHORT_MAX` (32) bytes render inline through the
  compare-select loop with no dispatch; longer ones run SSSE3 `pshufb` on
  x86-64, NEON `tbl` on
  aarch64 and `i8x16.swizzle` in a `simd128` build. The frozen tables
  `crates/hash-conformance/tests/vectors/hex_vectors.txt` and
  `hex_digit_vectors.txt` pin every path, natively and on wasm32. The
  `hex` group of `cargo bench -p purrdf-hash-conformance --bench digests`
  times each path and entry point at 8 B to 4 KiB.
- **lex:** `purrdf-lex`, a new published, wasm32-clean crate whose one runtime
  dependency is `purrdf-hash`, holding the lexical foundations every grammar in
  the workspace shares: the
  exact Turtle/SPARQL/XML terminal classes (`purrdf_lex::terminals`), the
  chunked byte-class scanners and the `ByteClass` kernel (`purrdf_lex::scan`),
  and the RFC 8259 JSON string escaper (`purrdf_lex::json_escape`). The three
  modules moved here from `purrdf-iri` unchanged, and `purrdf-iri` re-exports
  them, so every `purrdf_iri::terminals`, `purrdf_iri::json_escape` and
  `purrdf_iri::scan` path still names the same items; `purrdf-iri` now depends
  on `purrdf-lex` and `purrdf-hash` and on no third-party crate. The scanner benchmarks moved with them to
  `cargo bench -p purrdf-lex --bench scan` (groups `lex_scan_*` and
  `lex_json_escape_*`), and the assembly audit measures the scanners in
  `purrdf_lex` under the site ids `lex.scan-*`, `lex.json-escape-*` and
  `lex.terminals-in-ranges`.
- **hash:** `purrdf_hash::Domain`, a `const` newtype naming one hash preimage
  family. Every hash domain-separation string in the workspace is a registered
  `Domain` constant beside the construction it separates, byte-identical to the
  literal it replaces, so no digest, identity or golden moves. A domain is UTF-8
  text (`Domain::new` refuses other bytes at compile time for a `const`), and
  `as_str` serves the constructions that carry it as a CBOR text string or an
  IRI segment. `scripts/check-hash-domains.py` (in `make check` and CI) holds the
  set unique and prefix-free, refuses a domain-shaped literal handed to a hasher
  without a `Domain`, and keeps the registry table in `crates/hash/README.md`
  equal to the source. New domains are spelt `purrdf-<crate>/<purpose>/v<N>`.
- **jsonschema:** `MAX_REF_CHAIN` (250), the longest run of `$ref`,
  `$dynamicRef` and `$recursiveRef` resolutions followed at one instance
  location. Past it the evaluation stops with an `EvaluationError` whose new
  `EvaluationCause` names the bound (`ReferenceChain`, or `Pattern` for the
  matcher budget), never a guessed verdict. `ecma::MAX_GROUP_NESTING` names the
  pattern parser's group-nesting limit.
- **testkit:** `prop::parse_cases`, the parser behind `PURRDF_PROP_CASES`.
- **iri:** `purrdf_iri::idna`, IDNA2008 without third-party code: RFC 5891
  label validation over the RFC 5892 derived property, the Appendix A
  contextual rules, the RFC 5893 Bidi rule, RFC 3492 Punycode between A-labels
  and U-labels, and `map`, a local mapping step (RFC 5891 §5.2) that applies
  Unicode's NFKC_Casefold to DISALLOWED code points only, leaving code points
  IDNA2008 already permits (for example ß, ς, ZWJ and ZWNJ) and unassigned
  ones unchanged, maps U+3002 IDEOGRAPHIC FULL STOP to `.`, leaves unmapped
  any code point whose image would introduce a `.`, and then normalizes to
  NFC; it is not the UTS 46 mapping. The tables are generated from the
  Unicode 17.0.0 database vendored under `crates/iri/unicode/`, and
  IdnaTestV2.txt passes with zero failures on the rows the committed filter
  includes (2960 without mapping, 6202 with it).
- **iri:** `Iri::to_uri`, the RFC 3987 §3.1 mapping of an IRI to a URI:
  `ToASCII` of the host and percent-encoding of every other non-ASCII code
  point. The result always re-parses under `parse_uri`.
- **text:** `purrdf_text::unicode`, the analyzer's own Unicode layer: full
  case folding, NFD/NFC/NFKD/NFKC and UAX 29 word boundaries, generated from
  the vendored database. `caseless`, `unicode-normalization`,
  `unicode-segmentation` and `tinyvec` leave the dependency graph.
- **deflate:** `purrdf-deflate`, a native DEFLATE (RFC 1951) and gzip (RFC 1952)
  crate whose only runtime dependency is `purrdf-hash`. `Inflater` and
  `GzipDecoder` are push-based (`feed` input in chunks of any size; usable from a
  wasm32 stream callback), `GzipReader` is the `Read` adapter over them, and
  `set_limit` / `decompress_with_limit` refuse output past a caller's byte limit
  with `Error::LimitExceeded`. `Deflater`, `GzipWriter` and `gzip::compress` encode
  deterministically at `Level` 0–9. Match copies, match-length compares and window
  hashing have SSE2/AVX2, NEON and wasm simd128 kernels that return exactly what
  the portable ones do.


- **sparql-eval:** `protocol::FailureCode`, the exhaustive set of ways an operation
  behind a SPARQL Protocol endpoint can fail. `EvalError`, `LoadError` and
  `RemoteError` convert into it, `FailureCode::from_diagnostic_code` reads an engine
  diagnostic's code, and `protocol::problem_for` is the one mapping to the HTTP
  problem a host answers with (`Problem { status, code, detail }`, the detail either
  the failure's own words, a fixed description, or an internal one logged under a
  correlation id). A governed outcome's trip converts too (`FailureCode::GovernorCeiling`,
  a `422`, or the `503` of a stop signal). A new failure cannot compile until it has a
  status. The default
  request timeout and user agent are public (`remote_http::DEFAULT_TIMEOUT`,
  `DEFAULT_USER_AGENT`).

- **wasm:** every error the package throws for a failure it classifies carries its
  stable code as `error.code` — the engine diagnostic's own, a job's stop or fault
  (`native-sparql-cancelled`, `native-sparql-deadline`,
  `native-sparql-not-acceptable`, `native-sparql-update-in-flight`,
  `native-sparql-host-fault`), or the package's own refusals (`purrdf-wasm-options`,
  `purrdf-wasm-usage`, `purrdf-wasm-serialize`, `purrdf-wasm-entailment`,
  `purrdf-wasm-extension-environment`, `purrdf-wasm-shacl`,
  `purrdf-wasm-shacl-product-refusal`). `SparqlProtocolRequest.problemFor(error,
  cancelled)` answers a failure with its RFC 9457 problem,
  `SparqlProtocolRequest.problemForTrip(tripped)` a governed outcome's trip, and
  `SparqlProtocolRequest.statusTitle(status)` gives a status's reason phrase.
  `Dataset.snapshot()` returns an independent copy of a dataset, and
  `ServiceCatalog.copy()` an independent copy of a catalog. The asynchronous
  runtime's statuses are exported enums: `RunStatus`, `SuspendStatus`,
  `DeliveryStatus` and `EffectKind`.

- **shapes, validate, cli, python, wasm, capi (BREAKING):** the empty `sh:in` / `sh:xone`
  mandatory diagnostic is reported by EVERY run, not only by the lint (maintainer
  decision, "Every run reports it"). Appendix A's `in-minListLength` and
  `xone-minListLength` ("Each such list SHOULD have at least one member") leave the
  shapes graph well-formed, so a diagnostic is never a `sh:ValidationResult`: it changes
  neither `sh:conforms` nor any result, the W3C grading is unchanged, and the RDF report
  graph does not carry it (SHACL defines no report term for it and PurRDF mints none).
  Rust: `Shapes::mandatory_diagnostics`, `ValidationReport::diagnostics` (a new public
  field), `RulesOutcome::diagnostics`, `EntailOutcome::diagnostics`; `MandatoryDiagnostic`
  displays as `RULE SHAPE`. SARIF: each is a `level: "note"` notification in
  `invocations[0].toolExecutionNotifications` whose `descriptor` names the rule in
  `tool.driver.notifications` (SARIF 2.1.0 §3.20.21, §3.58). Command line: a `shacl
  diagnostic RULE SHAPE` stderr line after `validate`'s verdict and after `rules
  inferred N`. Python: a `diagnostics` list of `{"rule", "shape"}` on the `validate`
  dict, `ValidationReport`, and the `apply_rules` dict; `shapes.entail` now returns
  `{"ntriples", "diagnostics"}` instead of a string. WebAssembly: `shaclEntail` now
  returns a `ShaclEntailment` (`ntriples`, `diagnostics`) instead of a string, and
  `ShaclRulesInference` gains `diagnostics`. C: `purrdf_shacl_apply_rules` and
  `purrdf_shacl_entail_to_ntriples` gain a nullable `out_diagnostics` buffer before
  `out_error` (riding the unshipped 0.8.0 ABI bump). The diagnostics are computed once
  per shapes graph, from its retained dataset, so a parse and a prepared-product
  restore agree (the product stage id moves; existing products must be rebuilt), and a
  graph with no empty list allocates nothing more per validation.

- **entail, validate, cli, python, wasm, capi (BREAKING):** every entailment entry point
  closes the premise's `owl:imports` closure and refuses what it cannot use. `purrdf
  reason` and `purrdf convert --entailment` take `--import IRI=FILE` (they used to ignore
  `owl:imports` and close the premise alone, reporting the import unresolved): the
  closure is materialized over the premise merged with every imported document, an
  import no pair resolves is refused by name (exit 1), and the report states
  `ontology-import-resolved`. An import-table entry the premise's closure never reaches
  is now refused on every entailment service — `purrdf entails` (exit 2, as `validate`
  refuses an unused shapes-graph pair), Python `entail.graph_entails` /
  `verify_entailment` / `certain_answers`, WebAssembly `entailGraphEntails` /
  `entailVerifyEntailment` / `entailCertainAnswers`, C `purrdf_entail_graph_entails` /
  `purrdf_entail_verify_entailment` / `purrdf_entail_certain_answers`, Rust `entails` /
  `certain_answers` (`EntailError::UnreachedImport`, naming the entries and, when the
  premise states the `owl:imports` on a node that anchors nothing, saying so); it used to
  be read and silently unused. Rust gains `materialize_with_imports`.

- **entail, validate, `purrdf`, cli, python, wasm, capi (BREAKING):** the entailment-regime
  query, the OWL-Direct consistency question and the host materialization entry points
  close over the premise's `owl:imports` closure too, through the same kernel resolver
  and with the same refusals as `reason`. They used to answer over the premise alone —
  `purrdf query --entailment` and `purrdf consistency` silently omitted every imported
  axiom. Command line: `query --entailment … --import IRI=FILE` and `consistency --import
  IRI=FILE` (`--proof`/`--check-proof` record and check over the merge). Python:
  `entail.materialize(dataset, regime, program, imports, premise_iris, …)`,
  `entail.materialize_nt(text, regime, program, imports, premise_iris, …)`,
  `entail.consistency(data, imports, premise_iris, step_cap=0, work_cap=0)` (the two new
  arguments are required and positional, as on `certain_answers`), and
  `Store`/`MutableDataset.query_entailment_governed(..., imports=None,
  premise_iris=None)`. WebAssembly: `entailMaterialize(document, regime, program,
  importIris, importDocuments, premiseIris, maxStoredFacts?, maxJoinSteps?)`,
  `entailConsistency(document, importIris, importDocuments, premiseIris, stepCap,
  workCap)`, and `importIris`/`importDocuments`/`premiseIris` options on
  `queryEntailmentGoverned` (the raw binding takes them after `program`). C:
  `purrdf_entail_materialize_to_nquads`, `purrdf_entail_consistency` and
  `purrdf_query_entailment_governed` gain `import_iris`, `import_documents`,
  `import_count`, `premise_iris`, `premise_iri_count` (riding the unshipped 0.8.0 ABI
  bump). Rust: `validate::regime::materialize_to_nquads_string_with` and
  `consistency_to_string` take `imports` and `premise_iris`;
  `ReasonerSession::open_premise` and `premise_nquads`; `premise_import_map`;
  `purrdf::query_with_entailment_closure_governed` over an `EntailmentClosure`;
  `purrdf_entail::resolve_imports`, `ReasoningReport::with_resolved_imports`,
  `EntailError::with_resolved_imports`, `Reasoner::with_resolved_imports`. The Rust
  entry points that take no table (`query_with_entailment`,
  `query_with_entailment_governed`, `materialize_to_nquads_string`) resolve against the
  empty one, so an importing premise is refused there rather than closed without its
  imports. A resolved closure states `ontology-import-resolved` in the reasoning report
  and, now, in the DL certificate.

- **entail, validate, `purrdf`, cli, python, wasm, capi (BREAKING):** every entailment service
  that evaluates a regime's rule table takes the stored-fact and join-step limits the
  materialization path takes, and a refusal names the CALLING host's knob — never
  `MaterializeLimits::…` or `EvalOptions::…` to a non-Rust caller. The conclusion-directed
  services hold the premise's closure AND every re-chase of the refutation and freeze
  mechanisms to them; the entailment-regime query holds its closure to them (the query
  governors still price only the evaluation over the closure). Defaults are unchanged.
  Command line: `entails --max-stored-facts N --max-join-steps N` and `query --entailment …
  --max-stored-facts N --max-join-steps N`. Python: keyword-only `max_stored_facts=`,
  `max_join_steps=` on `entail.certain_answers`, `graph_entails`, `verify_entailment` and
  `Store`/`MutableDataset.query_entailment_governed`, each refusal naming that function's
  keyword. WebAssembly: trailing `maxStoredFacts?`, `maxJoinSteps?` (`bigint`) on
  `entailCertainAnswers`, `entailGraphEntails`, `entailVerifyEntailment`, and
  `maxStoredFacts`/`maxJoinSteps` options on `queryEntailmentGoverned` (the raw binding
  takes them after `premiseIris`). C: nullable `const uint64_t *max_stored_facts, const
  uint64_t *max_join_steps` after `premise_iri_count` on `purrdf_entail_certain_answers`,
  `purrdf_entail_graph_entails`, `purrdf_entail_verify_entailment` and
  `purrdf_query_entailment_governed` (riding the unshipped 0.8.0 ABI bump). Rust:
  `purrdf_entail::entails_with` / `certain_answers_with`; `certain_answers_to_string`,
  `graph_entails_to_string` and `verify_entailment_to_string` take a `MaterializeLimits`;
  `RegimeService`, `RegimeHost::service_knobs`, `render_entail_error_in`;
  `EntailmentClosure::with_limits`. The OWL-Direct consistency question runs no rule-table
  evaluation — its evaluator is the hypertableau, bounded by `step_cap`/`work_cap` on every
  host already — so it takes no stored-fact or join-step knob that would govern nothing;
  the term-generating round and generated-term limits govern no entailment lane either.

- **capi (BREAKING for C):** `purrdf_shacl_validate_changes_to_sarif` takes the two
  validation parameters the whole-graph `purrdf_shacl_validate_to_sarif` takes, in the same
  places: `conformance_disallows` / `conformance_disallows_count` after `removed_nt`, and
  `bool subclass_of_in_shapes_graph` after `import_count` (riding the unshipped 0.8.0 ABI
  bump). A change is judged exactly as the whole graph would be; before, the change path
  always used SHACL's default disallow set and read class membership from the data graph
  alone.

- **shapes, validate, cli, python, wasm, capi (BREAKING):** a node-expression evaluation
  reports the shapes graph's mandatory diagnostic (an empty `sh:in` / `sh:xone` list) like
  every other run. Command line: `purrdf node-expr` writes one `shacl diagnostic RULE
  SHAPE` stderr line per diagnostic after `node-expr outputs N`. Python:
  `shapes.eval_node_expr` returns `{"outputs": [...], "diagnostics": [{"rule", "shape"},
  ...]}` instead of a list. WebAssembly: `shaclEvalNodeExpr` returns a
  `ShaclNodeExprOutcome` (`outputs`, `diagnostics` of `ShaclDiagnostic` values with `rule`
  and `shape`) instead of an array. C: `purrdf_shacl_eval_node_expr` gains a nullable
  `out_diagnostics` buffer before `out_error` (riding the unshipped 0.8.0 ABI bump). Rust:
  `free_expression::evaluate` returns a `NodeExprEvaluation` (`outputs`, `diagnostics`),
  and `purrdf_validate::eval_node_expr` (a `NodeExprOutcome`) replaces
  `eval_node_expr_to_terms`. The diagnostics change no output.

- **wasm (BREAKING), capi:** the two SHACL rules entry points spell their shared parameters
  in one order, and a mandatory diagnostic has one encoding on every host. WebAssembly
  `shaclApplyRules` is now `(dataNt, shapesTtl?, srl?, shapesBase?, srlBase?, explain?,
  importIris?, importDocuments?, shapesGraph?, maxTermGeneratingRounds?,
  maxGeneratedTerms?, maxStoredFacts?, maxJoinSteps?)` — the import table, then
  `shapesGraph`, then the four limits contiguously, exactly as `shaclEntail(shapesTtl,
  dataNt, shapesBase?, importIris?, importDocuments?, shapesGraph?,
  maxTermGeneratingRounds?, maxGeneratedTerms?, maxStoredFacts?, maxJoinSteps?)` takes
  them (it used to interleave the limits with the import table and end on
  `shapesGraph`). `ShaclEntailment.diagnostics` and `ShaclRulesInference.diagnostics` are
  arrays of `ShaclDiagnostic` values (`rule`, `shape`) instead of `RULE SHAPE` strings —
  the structured form Python's `{"rule", "shape"}` dicts already carry. C keeps its
  `diagnostic RULE SHAPE` lines, now documented as the same two fields in the same order.

- **validate, python, wasm, capi (BREAKING for C):** SHACL-AF entailment takes the four
  rule-evaluation limits the rules run takes — the term-generating round limit, the
  generated-term budget, the stored-fact limit and the join-step limit — routed through
  the same `RuleOptions`, with the same defaults. Python `shapes.entail(...,
  max_term_generating_rounds=, max_generated_terms=, max_stored_facts=,
  max_join_steps=)`; WebAssembly four trailing `bigint` arguments on `shaclEntail`; C
  four nullable `const uint64_t *` parameters on `purrdf_shacl_entail_to_ntriples`
  between `import_count` and `out_buffer` (riding the unshipped 0.8.0 ABI bump); Rust
  `EntailRequest` / `entail_to_ntriples` and `RuleLimits`. A refusal names the knob in
  the calling host's own spelling (`entail(max_stored_facts=...)`, `shaclEntail's
  maxStoredFacts`, `purrdf_shacl_entail_to_ntriples's max_stored_facts`); it used to
  name `RuleOptions::with_max_*`, which no host caller can reach, and no host could
  raise a limit an entailment run passed.

- **sparql-eval, shapes (BREAKING):** a call to a SHACL-AF `sh:SPARQLFunction` whose
  `sh:select` body returns more than one solution fails, naming the count, instead of
  answering with the first row. SHACL Advanced Features: "Since all other bindings will
  be ignored, such SELECT queries should only return at most one solution", read as a
  must; the first row of an unordered result is no single value. A body that returns one
  solution, or none (no value, a SPARQL error as before), is unchanged.

- **shapes (BREAKING):** a SPARQL 1.2 RL rule set whose first `VERSION` directive follows
  a `RULE` or `DATA` block is refused at the syntax stage. §7.1: "The version
  announcement SHOULD be made early in the document", read as a must. A rule set that
  announces no version still parses, and a later `VERSION` after an early one is still a
  directive for what follows it. No W3C SPARQL 1.2 RL entry places a `VERSION` late; the
  counts are unchanged.

- **shapes, validate, cli, python, wasm, capi (BREAKING):** `SERVICE` is refused in every
  SHACL-SPARQL query that runs. SHACL 1.2 SPARQL Extensions, Appendix A: "SPARQL queries
  SHOULD not contain a federated query (SERVICE). Implementations that do not permit
  SERVICE MUST report a failure", read as a must. It was already refused in constraints,
  validators and rules; a `sh:SPARQLFunction` body (with or without parameters), a
  `sh:SPARQLTarget`, a `sh:SPARQLTargetType` and a `sh:select` / `sh:sparqlExpr` node
  expression used to run it. The refusal is `ShapesError::Prebinding`, raised where the
  query runs; a declaration nothing runs is listed by `lint` under `unexecuted`. Appendix
  A's MUSTs now apply where they were not checked: to a `sh:SPARQLTargetType` a shape
  instantiates (its parameters are pre-bound) and to a `sh:select` node expression a shape
  reaches (`$this` is pre-bound, §6.1). A `sh:sparql` constraint's pre-binding violation is
  now typed `ShapesError::Prebinding` too; it was `ShapesError::Invalid`.

- **shapes, validate, cli, python, wasm, capi (BREAKING):** a shape whose `sh:target` is a
  custom target PurRDF cannot compute — neither a `sh:SPARQLTarget` nor an instance of a
  declared `sh:SPARQLTargetType` — is refused typed, `ShapesError::UnsupportedTarget`
  (`UnsupportedTargetRefusal`: the shape, the target, the message). SHACL Advanced
  Features says such an engine "SHOULD at least report a warning"; the refusal is stronger,
  since a warning would sit beside a report about focus nodes nobody computed. The refusal
  used to be the untyped `ShapesError::Invalid`. Hosts report it as they report the other
  shapes-graph refusals (Python `ValueError`, WebAssembly `Error`, C
  `PURRDF_STATUS_PARSE_ERROR`, CLI exit `1`).

- **shapes, validate, cli, python, wasm, capi (BREAKING for C):** the shapes-graph IRI
  reaches the RULES entry points on every host, as it already reached validation.
  SHACL-AF SPARQL rules run in the shapes-graph context: a `sh:SPARQLRule`'s
  `$shapesGraph` is pre-bound to the named IRI and `GRAPH $shapesGraph { … }` reads the
  shapes graph; with none named it is an ordinary variable. `purrdf rules
  --shapes-graph IRI`; Python `shapes_graph=` on `shapes.apply_rules` and
  `shapes.entail`; WebAssembly a trailing `shapesGraph` on `shaclApplyRules` and
  `shaclEntail`; C a nullable `shapes_graph_iri` after `shapes_base_iri` on
  `purrdf_shacl_apply_rules` and `purrdf_shacl_entail_to_ntriples` (riding the
  unshipped 0.8.0 ABI bump); Rust `RulesRequest::shapes_graph`,
  `entail_to_ntriples_string_with_shapes_graph` and
  `engine::entail_graphs_with_shapes_graph`. A relative IRI resolves against the shapes
  document's base. A SPARQL 1.2 RL rule set has no shapes graph, so an IRI named beside
  one is refused (CLI exit `2`, `ValueError`, a thrown `Error`, `ParseError`).

- **shapes (BREAKING):** a `sh:SPARQLTarget` may carry one `sh:ask`, which used to be
  refused. SHACL Advanced Features §3.1: "SPARQL-based targets have at most one value for
  the property sh:ask"; "A SHACL engine can then determine whether a given shape applies
  to a given node by executing the ASK query with the variable this pre-bound to the
  node." The SELECT still defines the target a whole validation enumerates; every path
  that checks given candidates — `PreparedValidator::validate_focus_nodes` and
  `validate_focus_node_ids` (the change path over a SPARQL target validates the whole
  graph) — runs the ASK with `$this` pre-bound to the candidate, a node the data graph
  does not hold included, and CONFIRMS its answer against the target's own SELECT
  results: a node the two answer differently for is refused typed,
  `ShapesError::SparqlTargetDisagreement` (the shape, both queries, the node, both
  answers), rather than decided by the ASK alone. Both candidate methods now return
  `ShapesError` instead of `String`. The ASK is checked at
  load: an ASK query, meeting the pre-binding restrictions for `$this` (`SERVICE`
  included); a second `sh:ask` is refused by the built-in cardinality check.
  `Target::Sparql` gains `ask: Option<String>`; the prepared-product codec carries it,
  so the product stage id changes and existing products must be rebuilt.

- **shapes, validate, cli, python, wasm, capi:** an empty `sh:in` or `sh:xone` list is
  a MANDATORY DIAGNOSTIC (maintainer decision). Appendix A's `in-minListLength` and
  `xone-minListLength` ("Each such list SHOULD have at least one member") constrain the
  document author: the shapes graph is well-formed, validation proceeds as the approved
  W3C tests `core/node/in-002`, `in-003`, `xone-002` and `xone-003` require, and its
  report states `sh:shapesGraphWellFormed true`. `shapes lint` gains a `diagnostics`
  section, between `unexecuted` and `unanchored-imports`, that always lists each empty
  list as `diagnostic in-minListLength|xone-minListLength SHAPE`, whether or not the load
  succeeded; each line is a finding, so such a graph no longer lints clean.
  `shacl-shacl.ttl`'s own `sh:minListLength` warning on the same list is listed marked
  `diagnosed RULE` (`ShaclShaclResult::diagnosed`, Python key `diagnosed`) and is not
  counted a second time.
  `LintReport::diagnostics`, `lint::MandatoryDiagnostic`,
  `lint::MANDATORY_DIAGNOSTIC_RULES`; Python `lint_shapes` gains the `diagnostics` key
  (`rule`, `shape`); the CLI, WebAssembly and C carry the section in the rendered report.
  Every lint report's text gains the `diagnostics N` line.

- **shapes, validate, python, wasm, capi:** every validation report states
  `sh:shapesGraphWellFormed` (SHACL 1.2 Core §6.7.1.4: a processor that checks the
  shapes graph "SHOULD use the property sh:shapesGraphWellFormed to inform the consumer
  of the validation report"). It is `true`, since an ill-formed shapes graph is refused
  before validation; a shapes graph with an empty `sh:in` or `sh:xone` list is
  well-formed (see the mandatory-diagnostic entry below).
  `ValidationReport::shapes_graph_well_formed` (`None` for a report assembled by
  `from_results`, which states nothing) and `with_shapes_graph_well_formed`; the SARIF
  run property
  `shaclShapesGraphWellFormed`; Python `ValidationReport.shapes_graph_well_formed` and
  the `shapes.validate` dict key `shapes_graph_well_formed`. Report bytes change by the
  one added triple: the first-party corpus expectations and the change-path golden
  each gain exactly that line, and no other byte moves.

- **shapes (BREAKING):** a node whose `sh:message` values repeat a language tag, or
  hold more than one `xsd:string`, is ill-formed and refused as
  `ShapesError::IllFormed`, rule `message-datatype` (`SPARQLConstraint-message-datatype`
  on a SPARQL-based constraint): "A subject should neither have more than one value for
  sh:message with the same language tag, nor multiple values with datatype xsd:string",
  read as a must. Tags compare case-insensitively and a direction does not make two
  values of one tag distinct; `rdf:HTML` values are not limited. Such a node used to
  load, and its results carried every message.

- **shapes, validate, cli, python, wasm, capi (BREAKING for C):** SHACL 1.2 Core
  §6.3's `subClassOfInShapesGraph` ("SHACL processors SHOULD offer a parameter
  subClassOfInShapesGraph"), on every host. When set, the shapes graph's
  `rdfs:subClassOf` triples (its whole import closure's) are read, in addition to the
  data graph's, wherever SHACL type decides class membership: `sh:targetClass`,
  implicit class targets, `sh:class`, `sh:rootClass` and `shnex:instancesOf`. Only
  class membership changes: the shapes graph's triples do not become data-graph
  triples, and `rdf:type` is still read from the data graph alone. Off by default,
  the specification's default. Rust:
  `ValidationOptions::subclass_of_in_shapes_graph` /
  `with_subclass_of_in_shapes_graph`; CLI: `purrdf validate
  --subclass-of-in-shapes-graph` (document and `--shapes-product` routes); Python:
  `subclass_of_in_shapes_graph=` on `shapes.validate` and `shapes.Shapes`;
  WebAssembly: a trailing `subClassOfInShapesGraph` on `shaclValidateToSarif`; C:
  `bool subclass_of_in_shapes_graph` between `import_count` and `out_buffer` on
  `purrdf_shacl_validate_to_sarif` (incompatible; rides the unshipped `0.8.0` ABI
  bump). A binding over a mutation snapshot keeps its change path.

- **core, shapes, entail, validate, cli, python, wasm, capi (BREAKING):** an
  `owl:imports` closure that holds two versions of one series — two graphs declaring
  one IRI with different `owl:versionIRI` values — or a graph another declares
  `owl:incompatibleWith` is refused, naming both graphs. SHACL 1.2 Core §1.3 makes
  such a shapes graph ill-formed and §6.1 says the closure "SHOULD NOT" hold them; OWL
  2 §3.4 states the same two conditions for an ontology. The kernel's closure walk
  reports each pair (`ImportClosure::conflicts`, `VersionConflict`), SHACL refuses
  with the typed import error kind `incompatible-import-versions`
  (`ShapesImportError::IncompatibleVersions`) on every host, and entailment with
  `EntailError::IncompatibleImports`. Such a closure used to be merged and used.

- **shapes, validate, python, wasm, capi (BREAKING for C):** the shapes-graph IRI
  that `purrdf validate --shapes-graph` names — the IRI SHACL-SPARQL's `$shapesGraph`
  is pre-bound to, with the shapes graph exposed under it (SHACL 1.0 pre-binding,
  which SHACL 1.2 removed and PurRDF keeps as a caller's choice) — reaches every host.
  Python: `shapes_graph=` on `shapes.validate`, `shapes.Shapes` (carried into
  `prepare()`, `PreparedShapes` and `to_product()`), `shapes.pack_product` and
  `shapes.lint_shapes`. WebAssembly: a trailing `shapesGraph` on
  `shaclValidateToSarif`, `shaclValidateChangesToSarif`, `shaclPackProduct` and
  `shaclLintShapes`. C: a nullable `shapes_graph_iri` immediately after
  `shapes_base_iri` on `purrdf_shacl_validate_to_sarif`,
  `purrdf_shacl_validate_changes_to_sarif`, `purrdf_shacl_lint_shapes` and
  `purrdf_shapes_product_encode` (incompatible; rides the unshipped `0.8.0` ABI
  bump). Rust: `engine::parse_shapes_with_graph`,
  `engine::validate_graphs_with_shapes_graph`, `engine::resolve_shapes_graph_iri`,
  and `purrdf_validate::{validate_to_sarif_string_with_shapes_graph,
  validate_changes_to_sarif_string_with_shapes_graph,
  lint_shapes_ttl_with_shapes_graph, pack_shapes_product_with_shapes_graph}`. A
  relative IRI resolves against the shapes document's base, as the command line
  resolves it; one with no base is refused (`iri-relative-no-base`). Without it, W3C
  SHACL 1.0 `sparql/pre-binding/shapesGraph-001` silently conformed on Python,
  WebAssembly and C; named, every host reports its approved result, and unnamed,
  every host reports the SHACL 1.2 ordinary-variable answer (conforms). A `Shapes`
  parsed under a shapes-graph IRI is now exposed under it by `validate_dataset`,
  `validate_projected_dataset`, `validate_projected_dataset_with_focus_filter`,
  `PreparedShapes::bind_projected_dataset` and `bind_shared_dataset` too; they used
  to validate it as if the IRI were absent, leaving `$shapesGraph` unbound. A `Shapes`
  without one takes the same path it always did.

- **shapes, validate, cli, python, wasm, capi:** a SPARQL 1.2 RL rule set can be
  checked without being evaluated, on every host. `purrdf_shapes::srl::check(text,
  base, imports, level)` applies the static checks up to a `CheckLevel` — `Syntax`
  (the §7 grammar, for the rule set and every document its `IMPORTS` closure reads),
  `WellFormed` (§4.2, imported rules included) or `Stratified` (§4.4, the default) —
  resolving the closure from the same import table a rules run takes, reading no
  base graph and running no rule, and returns a `CheckedRuleSet` (the combined rule
  set, the imported IRIs, the strata, and the one-line `summary()` every host
  reports) or the `SrlError` of the stage that refused. The hosts: `purrdf rules
  --srl FILE --check[=syntax|well-formed|stratified]` (bare `--check` is
  `stratified`; one summary line on stdout, exit 1 naming the stage for a refused
  rule set, exit 2 for an unused `--import` pair and for the data, output, proof and
  limit flags a check never consumes), Python `purrdf.shapes.check_rules(srl, *,
  srl_base, imports, level)`, WebAssembly `shaclCheckRules(srl, srlBase?, importIris?,
  importDocuments?, level?)` returning `ShaclRulesCheck`, and C
  `purrdf_shacl_check_rules(srl, srl_base_iri, level, import_iris, import_documents,
  import_count, out_summary, out_error)` with the `PurrdfSrlCheckLevel` discriminant
  (riding the unshipped `0.8.0` ABI bump). `purrdf_validate::check_rules` and
  `parse_check_level` are the shared boundary. Every host's SPARQL 1.2 RL rules run
  now passes through the same check at `Stratified` before it evaluates, so a run
  refuses exactly what a check refuses. The W3C SPARQL 1.2 RL harness grades every
  syntax, well-formedness and stratification entry through `srl::check` — a positive
  entry at the level its type asks about, a negative one at the full check by the
  stage its type names — and a new CLI test drives every one of those entries, and
  every evaluation entry's rule set, through the built `purrdf rules --check`; the
  counts are unchanged (538 passed plus 6 non-canonical decimals). Fourteen positive
  syntax entries are not stratifiable and one is not well formed, so bare `--check`
  refuses exactly those fifteen, by a later stage, while `--check=syntax` accepts
  them.

- **core, shapes, validate, cli, python, wasm, capi (BREAKING):** a data graph's
  `sh:shapesGraph` links are part of the shapes graph that validates it (SHACL 1.2
  Core §6.4, whose SHOULD PurRDF reads as a MUST). A `sh:shapesGraph` whose subject is
  the data graph's loaded IRI (the command line's `--base` or the data file's `file://`
  retrieval IRI) or a `sh:DataGraph` node names a graph that is resolved through the
  SAME import table as the shapes graph's `owl:imports` — a table entry, a graph the
  shapes graph already declares, the `^owl:versionIRI` step, and the linked graph's
  own `owl:imports` closure — and unioned into the shapes graph; a table entry only a
  link names is reached, not refused as unreached. It was silently ignored. A
  `sh:shapesGraph` on any other node is data, and the data graph's own `owl:imports`
  stay unenacted (§6.2). `ShapesImportError` gains `UnresolvedLink`
  (`unresolved-shapes-graph-link`, a link nothing resolves), `UnheldLink`
  (`unheld-shapes-graph-link`) and `InvalidLink` (`invalid-shapes-graph-link`, a link
  value that is not an IRI); every host carries the new kinds in its existing typed
  import refusal, and the command line names the `--import IRI=FILE` pair that
  resolves a link. New API: `purrdf_shapes::imports::{data_graph_links,
  check_data_graph_links, SH_SHAPES_GRAPH_LINK}`, `ShapesImports::link_data_graph`
  and `links`, `ResolvedShapesGraph::included`, `ParseProvenance::included_graphs`,
  and `purrdf_core::imports::{ImportMap::closure_with_links, ImportMap::loaded,
  declared_import_targets}`. The text entry points (`validate_graphs_with_options`,
  `validate_graphs_with_config`, `validate_dataset_graphs`, the `purrdf-validate`
  SARIF and change-path boundaries every binding calls, and `purrdf validate
  --shapes`) fold the links in before parsing the shapes graph, so an empty shapes
  document validates against the linked graphs alone. A shapes graph built before
  the data graph was known — a `Shapes`, a `PreparedShapes`, a prepared product —
  cannot take a graph in: every validation and every binding checks that each link
  is one it already holds (its loaded IRI, a graph its closure or links folded in, or
  an anchor or version IRI it declares) and refuses any other as
  `ShapesError::Imports(UnheldLink)`, typed on every host. A prepared product records
  the IRIs of every graph its shapes graph absorbed by name in its identity section,
  so a product packed with a table-supplied document that declares no ontology header
  of its own holds a link to that document after `admit` and after `rebuild` alike;
  the preparation stage id now digests that preamble carrier (`ParseProvenance`) as
  well as the model, and moved to
  `b4c4a547c28b743e110bb68a8b766a9abfdeb4cbe37718443e69637c7620c8f5`, so every earlier
  product is refused at `admit` and re-derived by `rebuild` (holding only what its
  merged dataset declares); the fixture product was regenerated with its generator.
  The recorded set is bound by the product identity as a thirteenth component,
  `included-graphs` (row 12, after `parse-configuration`), refused under a new
  `ProductDimension::IncludedGraphs` (`included-graphs`, between
  `parse-configuration` and `unsupported-capability`; `ProductDimension::ALL` grows to
  22 and the later dimensions' ordinals move by one), so two products over one merged
  dataset that recorded different sets no longer share an identity. The parse base is
  recorded as the base, not repeated in the set. Every host's dimension list names it
  (and `parse-configuration`, which the C, Python and WebAssembly lists had omitted);
  the fixture product is 4,728 bytes and a restore's admit allocations are re-pinned
  from 291 to 304, attributed in `change_path_alloc`.
  **Breaking API:** the engine's validation entry points return the typed
  `ShapesError` instead of `String` — `validate_with`, `validate_with_focus_filter`,
  `validate_with_governors`, `validate_dataset`, `validate_dataset_with_governors`,
  `validate_dataset_with_shapes_graph`, `validate_projected_dataset`,
  `validate_projected_dataset_with_focus_filter`,
  `validate_projected_dataset_with_shapes_graph`, every `PreparedShapes::bind*`, and
  `PreparedValidator::new`, `from_dataset`, `from_projected_dataset` and
  `from_projected_dataset_with_shapes_graph`. A hard validation failure is
  `ShapesError::Invalid` carrying the old message, and `String: From<ShapesError>`
  keeps `?` working in string-error callers. A change that adds or retracts a link
  changes the shapes graph, so the incremental change path reports
  `ChangeScope::Everything` and validates in full. Python's
  `Shapes.validate_against_dataset` now returns a `Result`. `purrdf validate
  --changes` reads its change documents before the shapes graph, because the mutated
  graph's links decide what the shapes graph is. The change expansion's fixed
  allocation cost rises by one (the `sh:shapesGraph` lookup), re-pinned in
  `change_path_alloc` and `sparql_path_alloc`; binding a native dataset costs nothing
  more.

- **datalog, shapes, entail, validate, cli, python, wasm, capi:** the
  stored-fact and join-step limits are the caller's. `EvalOptions` gains
  `with_max_stored_facts` and `with_max_join_steps`; `RuleOptions` and
  `InferOptions` gain the same two; `chase::chase_with` and
  `purrdf_entail::materialize_with` run under the caller's options. Each host
  takes both limits for rules and for regime materialization: `--max-stored-facts`
  and `--max-join-steps` on `purrdf rules`, `purrdf reason` and `purrdf convert
  --entailment`; `max_stored_facts=` and `max_join_steps=` on Python's
  `shapes.apply_rules`, `entail.materialize` and `entail.materialize_nt`;
  `maxStoredFacts` and `maxJoinSteps` on WebAssembly's `shaclApplyRules` and
  `entailMaterialize`; and `max_stored_facts` / `max_join_steps` on C's
  `purrdf_shacl_apply_rules` and `purrdf_entail_materialize_to_nquads`. Each
  stored-fact default is sized for the target: 131,072 facts on `wasm32` (the
  value every target used while the limit was fixed) and 4,194,304 natively
  (`DEFAULT_MAX_STORED_FACTS`, chosen from the target architecture at compile
  time). The join-step default stays 1,048,576 on every target
  (`DEFAULT_MAX_JOIN_STEPS`): a body's candidates are materialised before the
  check, and a Cartesian body over 20,000 nodes allocated about 20 GB, still
  unrefused, under 268,435,456 where the default refuses it in about 2 s at under
  half a gigabyte. A program that needs
  more work states it — the non-linear closure of a 1,000-node chain completes
  with `--max-join-steps` raised. A single rule copying a predicate over 70,000
  triples, and the transitive closure of a thousand-node chain through SHACL
  rules or SPARQL 1.2 RL, now complete natively; both were refused. A run past
  either limit is refused naming the limit, the observed and permitted numbers,
  and the knob that raises it in the calling host's spelling (`LimitKnobs`,
  `RulesHost`, `RegimeHost`, `MaterializeLimits`); a run inside the limits
  returns exactly what larger limits would. The term-arena ceiling
  (`MAX_TERM_ARENA_BYTES`) is unchanged.
- **datalog:** a semi-naive round skips a decomposition whose anchoring atom
  gained no row since the last round, instead of enumerating every atom planned
  before it and then matching nothing. A linear recursion — `connected(x, z) :-
  connected(x, y), link(y, z)` — no longer rescans its whole closure every round:
  the closure of a 1,000-edge chain enumerates under 1,048,576 join steps where it
  passed 268,435,456. Solutions, derivations and every other budget coordinate are
  unchanged; join-step counts fall (OWL-RL join steps across the entailment golden
  corpus: 285,412 to 244,208). The `srl_closure` bench gains `infer_linear`, and
  `rules_divergence` gains `complete/copy` and `complete/closure`.

- **datalog, shapes, validate, cli, python, wasm, capi:** a guarded rule set
  that keeps generating new terms is stopped by two limits, each the caller's.
  The term-generating round limit defaults to 16,384 rounds
  (`DEFAULT_MAX_TERM_GENERATING_ROUNDS`), so a 10,000-step countdown completes
  and a counter with no bound is refused in well under a second. The new
  generated-term budget bounds the terms inferred beyond the input's and
  defaults to `max(65,536, 4 × N)` for `N` distinct input terms, so a rule set
  whose terms double every iteration is refused within a few iterations. A run
  past either limit is refused as `EvalError::TermLimitExceeded`,
  `RulesError::LimitExceeded` or `SrlError::LimitExceeded`, carrying a
  `RuleLimitExceeded`. The error names the limit, the observed numbers and the
  rules that generated a term last, and never calls the rule set divergent.
  It names the knob that raises the limit in the calling host's terms
  (`RuleOptions::with_limit_knobs`, `LimitKnobs`, `RulesRequest::host`):
  `--max-term-generating-rounds` and the new `--max-generated-terms` flag;
  Python `apply_rules(max_generated_terms=...)`; WebAssembly
  `shaclApplyRules(..., maxGeneratedTerms)`; and C
  `purrdf_shacl_apply_rules(..., max_term_generating_rounds,
  max_generated_terms, ...)`. The C parameter is new, so it is an ABI change.
  `EvalOptions`, `RuleOptions` and `InferOptions` gain
  `with_max_generated_terms`, and `srl::evaluate` returns `RulesError`.
- **shapes:** a global SPARQL rule whose CONSTRUCT is a conjunctive pattern
  (triple patterns, `FILTER` and `BIND`) runs as rule elements, evaluated
  semi-naively. It infers the same triples as the producer did, but an
  iteration now costs what is new instead of a pass over the whole graph. A
  10,000-step countdown takes well under a second instead of hitting the
  fixed join-step ceiling. `--explain` lists the premises of such a rule's
  inferences.
- **shapes:** a shapes graph in which a shape reaches the SHACL JavaScript
  Extensions is refused with the typed `ShapesError::ShaclJs(ShaclJsRefusal)`,
  which names the node and the SHACL-JS term, instead of `ShapesError::Invalid`.
  A shape reaches SHACL-JS through `sh:js` or a SHACL-JS type on the shape, a
  `sh:JSTarget` or an instance of a `sh:JSTargetType` as its `sh:target`, a
  `sh:JSRule` among its rules, and a call to a `sh:JSFunction` from a node
  expression or from SPARQL the shape runs, directly or through a
  `sh:SPARQLFunction`. SHACL-JS is a 2017 Working Group Note, not SHACL 1.2. A
  shapes graph that only declares `sh:JSLibrary`s and `sh:JSFunction`s nothing
  calls now loads with those declarations inert. `ShapesError` gains the
  variant, so an exhaustive match on it must name it; `purrdf-validate`
  re-exports `ShaclJsRefusal`. The Python, WebAssembly, C and command-line
  hosts report it with the same message as before.
- **BREAKING** **shapes, validate, cli, python, wasm, capi:** a SHACL-JS
  `sh:JSValidator` attached to a constraint component fails the load as
  `ShapesError::IllFormed`, naming the syntax rule, on built-in and custom
  components alike and whether or not a shape uses the component. SHACL 1.2
  SPARQL Extensions: "The values of sh:validator must be ASK-based validators"
  (`validator-class`), and the values of `sh:nodeValidator` and
  `sh:propertyValidator` "must be SELECT-based validators"
  (`nodeValidator-class`, `propertyValidator-class`). A `sh:JSValidator` is
  neither, and Core's ill-formed SHOULD is read as a MUST. Such a graph used to
  load, and `shapes lint` reported it clean. The class rules also judge a value
  of those properties whose subject is not a component the registry reads (an
  untyped owner, a blank-node component). `ValidatorLanguage` has no
  `JavaScript` variant, and no host's lint `validators` section prints a
  `javascript` label.
- **sparql-algebra:** `Query::custom_function_calls` lists the IRI of every
  extension function a query calls, anywhere in its algebra.
- **shapes:** the JSON Schema compiler projects the SHACL 1.2 list components
  onto a list value's `@list` array: `sh:minListLength` as `minItems`,
  `sh:maxListLength` as `maxItems`, `sh:uniqueMembers true` as `uniqueItems`,
  and `sh:memberShape` as `items`, compiled as one value's schema. Each
  component requires a list, and on a node shape they judge the focus node's
  `rdf:first` and `rdf:rest`. Lexical constraints judge an IRI's `@id`, the
  constants `rdf:nil`, `true` and `false`, and a bare integer's numeral length.
  Numeric datatypes are told apart over their lexical and value spaces. A range
  bound compares a typed integer-family or decimal literal by an order pattern
  on its lexical form, with SPARQL's numeric promotion against a double or
  float bound. `rdf:langString` and `rdf:dirLangString` are told apart. A node
  shape's node kind, `sh:in`, `sh:hasValue` and lexical constraints judge the
  focus node's `@id`. What remains recorded is what no JSON Schema keyword
  states, each case with its reason: a list kept as linked nodes, a pattern
  over a bare integer, a bound over double or float lexical forms, and a node
  shape's class membership. The Pydantic emitter enforces
  `uniqueItems`. LinkML carries `@list` and `@direction`, and its `any_of`
  branches keep to the anonymous-slot-expression fields.
- **shapes:** the GraphQL emitter carries a JSON Schema `anyOf` whose
  alternatives every value selects exactly one of (by JSON kind, or among
  object alternatives by a required key no other declares) as a `@oneOf` input
  object and an output union, instead of the fallback scalar. An alternative
  that is not an object type is a union member through a wrapper type with a
  `value` field. A SHACL list value (a node reference or a `@list` object) and
  its `sh:memberShape` members are therefore typed. `GraphqlNameMap` gains
  `unions` (so a struct literal of it must name the field), and
  `GraphqlPackage` gains `decode_input` and `encode_output` beside
  `encode_input` and `decode_output`. The GraphQL oracle serializes every valid
  value through its output type with GraphQL.js.
- **shapes:** the TypeScript emitter states array length bounds exactly at any
  size, with no tuple-expansion cap. Prefix positions are tuple elements.
  Lengths beyond them are element properties (`minItems: m` is a required
  `"m-1"`, `maxItems: n` an optional `never` `"n"`), which tuple-like
  contextual typing makes exact. `uniqueItems` over finitely many scalar items
  is enumerated by a generated `JsonDistinct` helper up to the compiler's
  instantiation-depth and union limits. Numeric keywords over a finite
  `const`/`enum` leave out the failing numbers. The
  `array-cardinality-validation-widened` and `tuple-array-validation-widened`
  codes leave the `json-schema` → `typescript-7.0` profile. The TypeScript
  oracle compiles the facts the remaining numeric and uniqueness losses rest
  on, and its scratch directory moves beside the build output.
- **shapes:** the JSON Schema compiler projects a temporal range bound
  (`sh:minInclusive` and the rest over `xsd:dateTime`, `xsd:date` or
  `xsd:time`) exactly, as order and lexical patterns on the literal's lexical
  form over the XSD timeline. A timezone makes the value an instant, and
  `24:00:00` is the next day's midnight. A zoned value and a local bound, or
  the reverse, compare only beyond ±14:00, and are an incomparable violation
  within it. The leap-year rule, the signed 64-bit year range and 18 fractional
  second digits are held as the validator parses them, and values of any other
  datatype are rejected. The validator trims a temporal lexical form by
  `whiteSpace` `collapse`, as it trims a numeric one. The generated Pydantic
  package evaluates a JSON Schema `not` at run time over the raw input for a
  closed keyword table, `$ref` included. So temporal bounds, typed numeric
  bounds and the other negations the compiler writes are enforced, not only
  recorded. A pattern conjunct restates `"type": "string"`, so LinkML reads it
  with its string carrier. Every emitter oracle runs a temporal fixture over
  projected instances.
- **shapes:** a range bound survives the SHACL → JSON Schema → SHACL round
  trip exactly. This covers integer-family, decimal, double and float bounds,
  and bounds over `xsd:dateTime`, `xsd:date` and `xsd:time`, with or without
  `sh:datatype`. Each rejection the compiler writes from a bound names the
  bound in its `$comment`: the facet's SHACL term and the bound as an N-Triples
  term. The importer believes the comment only when the rejections the bound
  projects to, narrowed by the value's datatype, are exactly the ones carrying
  it, and when the `minimum` / `maximum` beside a numeric bound are the
  integers it admits. `sh:maxExclusive 150` therefore reads back as itself, not
  as `sh:maxInclusive 149`. A decimal or temporal bound is no longer recorded as
  `schema-applicator-dropped`. A datatype's value schema with bounds folded into
  it keeps its `sh:datatype` too.
- **validate:** every host names an ANONYMOUS node expression. A
  `purrdf_validate::ExprSelector` names the expression in one of three ways:
  the node itself (an IRI or `_:label`, as before); a walk from a named node
  along one or more predicates, each step reaching exactly one value; or an
  inline Turtle document. The Turtle document is read under the shapes
  document's prefixes and base and merged into the shapes graph with its blank
  nodes kept apart, and its one root blank node is the expression. A step
  reaching no value or several, and a document with no root or several, are
  typed `ExprSelectorError`s naming the count. `NodeExprRequest::expr` is now an
  `ExprSelector`. The CLI's `node-expr` gains `--expr-at` / `--expr-via`,
  `--expr-turtle` and `--expr-turtle-file` beside `--expr`, exactly one of them
  required. Python's `eval_node_expr` takes `expr=None` with `expr_at`,
  `expr_via` or `expr_turtle`. WASM's `shaclEvalNodeExpr` takes an optional
  `expr` and trailing `exprAt`, `exprVia` and `exprTurtle`. The C ABI's
  `purrdf_shacl_eval_node_expr` gains `expr_at`, `expr_via`, `expr_via_count`
  and `expr_turtle` between `expr` and `focus`, with `expr` nullable. All 143
  W3C SHACL 1.2 `sht:EvalNodeExpr` tests run through the `purrdf node-expr`
  binary, each entry's expression named by the walk `mf:action` then
  `sht:nodeExpr`. The six entries whose approved result spells a computed
  decimal non-canonically are graded by the same table the library harness
  applies.
- **core:** `purrdf_core::xsd_regex::to_ecma_262` writes the `i` flag into the
  pattern as XPath case variants (F&O 3.1 section 5.6.2), instead of refusing
  it: each normal character and character range gains its variants, and every
  escape is left unaffected.
- **core:** `purrdf_core::distance`, the binary64 distance arithmetic that every
  ranked-retrieval surface computes with. The module holds:
  - `Scalar`, `Bound` and `Bounded`, which moved here from
    `purrdf_sparql_eval::knn` and are still re-exported at their old paths;
  - the sealed `Arithmetic` trait. Its `ID` is the law's identifier. Its
    `IMAGE_CODES` and `image_code(path)` give the codes an index image records.
    Its `evidence(path)` gives the divergence text, and `resolve()` checks the
    float environment and selects a dispatch path. `resolve_recorded(code)`
    checks the environment and selects the path an image code names, whenever
    the process can run it, rather than the widest. It refuses with a named
    `RecordedPathError`: `FloatEnvironment`, `UnknownCode`, or `Unavailable`
    carrying the `Path` and a `PathUnavailable` reason (`NotCompiled`, or
    `MissingFeature` naming the first feature the processor does not report);
  - `Resolved<A>`, an arithmetic bound to its dispatch `Path` for one scan, with
    `distances`, `distances_indexed`, `distance` and `distance_bounded`. It is
    neither `Send` nor `Sync`, because the float environment it proved belongs to
    the thread that resolved it;
  - `Selected<A>`, the thread-free form a long-lived structure stores
    (`Resolved::selected()`): the arithmetic and its dispatch path, with `path`,
    `image_code`, `evidence` and `build_shape`, `Send + Sync + Copy`, and
    computing nothing. `Selected::resolve()` checks the calling thread's float
    environment and returns that thread's `Resolved<A>` on the same path;
  - `Exact` (`binary64-lane16-tree-v1`). It accumulates 16 f64 lanes over array
    chunks, combines them in a fixed pairwise tree, adds the tail sequentially
    and uses no FMA. Every dispatch path returns the same bits;
  - `Reassociated` (`binary64-reassociated-v1`). It uses `f64::algebraic_*`
    inside each 64-element block and combines the block sums in ascending order,
    so every bounded checkpoint is a true prefix. On x86_64 it dispatches at run
    time to avx512f, then avx2+fma, then sse2. NEON, wasm simd128 and wasm scalar
    are chosen at compile time. Every other target runs its portable compilation,
    also fixed at compile time, so it resolves on every target. Each path has
    exactly one out-of-line copy, so every call site on a path gets the same bits.
    Its image codes are 2 (sse2), 3 (avx2+fma), 4 (avx512f), 5 (neon),
    6 (wasm-simd128), 7 (wasm-scalar) and 8 (portable); `Exact`'s is 1;
  - `Path` (`#[non_exhaustive]`), with one variant per dispatch path: `Portable`,
    `Avx2` and `Avx512f` for `Exact`; `Portable`, `Sse2`, `Avx2Fma`, `Avx512f`,
    `Neon`, `WasmSimd128` and `WasmScalar` for `Reassociated`. `Portable` names each
    arithmetic's own body compiled for the target's baseline features, and
    `Avx512f` each one's body compiled with AVX-512F, selected for both by one rule
    (the processor reports AVX-512F, AVX2 and FMA);
  - the batch kernels, which are the unit of dispatch. `Exact` has bit-identical
    AVX-512F and AVX2 paths on x86_64, chosen in that order once per scan. The
    AVX-512F compilation is kept on its emitted asm, not on an argument: under
    generic tuning it holds the sixteen lanes in two `zmm` registers where AVX2
    uses four `ymm`, so a sixteen-element block of the squared-Euclidean fold is
    two `vsubpd`, two `vmulpd` and two `vaddpd` rather than four of each, with no
    FMA, and the `f64` pair kernel is 117 vector instructions against AVX2's 157.
    It is executed, and held to the reference model bit for bit, by the
    `avx512-sde` CI job. They come with `RowsRef`,
    `Measure`, `EXACT_LANES` and a `norm` that delegates to the one normative
    PURREMB norm fold;
  - the float-environment refusal. `FloatEnvironmentError::FlushToZero`,
    `RoundingMode` and `DoubleRounding` name a thread that flushes subnormal
    results or operands to zero, rounds by any rule other than to nearest, ties
    to even, or rounds a binary64 result twice through a wider format. Each
    carries a `FloatEnvironmentEvidence`: `Register { name, bits }` where the
    control register was read (MXCSR on x86_64, FPCR on aarch64, the x87 control
    word where the x87 is the binary64 unit), or
    `Probe { operation, expected, observed }` for a binary64 operation whose
    bits differed from the IEEE-754 result. The environment is proven by that
    probe on every target: thirteen operations through `core::hint::black_box`,
    covering flushed results, flushed operands, all three directed roundings,
    ties-to-even, and five double-rounding witnesses (two sums and a product in
    the normal range, a product and a quotient in the subnormal range). So
    i686, i586, armv7, riscv64, powerpc64le, s390x, loongarch64 and any other
    target run both arithmetics, and are refused only when a departure is
    observed;
  - binary64 on the x87. Where `f64` arithmetic runs on the x87 (`i586`, or
    `i686` built without SSE2), each result is rounded to the register's 64-bit
    significand and again when stored, and kept at its 15-bit exponent. Both
    arithmetics, the norm and the probe compute there under a guard that sets
    the precision-control field to 53 bits and restores the caller's control
    word on exit, unwinding included; each operation stores its result as
    binary64, and a product or quotient is scaled by 2⁻¹⁵³⁶⁰ and back so a
    subnormal result is rounded once. `Exact` returns the same bits there as on
    every other target, proven against an integer software reference, and a
    thread where the guard does not take hold is refused as `DoubleRounding`.
    The layer is the workspace's, not the distance module's: `purrdf_xsd::ieee`
    holds the one implementation -- `Binary64Scope`/`Binary32Scope` (precision
    control at 53 or 24 bits), their `Binary64`/`Binary32` operation tokens, and
    the one-off `f64_add` ... `f32_sqrt` functions -- with the binary32
    subnormal range scaled by 2⁻¹⁶²⁵⁶ (the distance between the x87's and
    binary32's smallest normal exponents). `+`, `−`, `×`, `÷` and `√` are
    correctly rounded at both widths on every target; everywhere but the x87
    each is the bare operator, inlined. Every binary operation whose bits reach
    a result runs through it, so on the x87 the SPARQL `xsd:double` and
    `xsd:float` operators (and with them `SUM`, `AVG` and `VARIANCE`), `STDDEV`,
    `fn:round`, the decimal and big-integer conversions to `xsd:double` and
    `xsd:float`, the join planner's cost model (which orders an unordered
    query's rows and decides a governed refusal), the bulk read of a normalized
    binary32 projection row and the CSVW percentage scaling now return the bits
    every other target does; before, each rounded through the register's 64
    bits, and `1 + (2⁻⁵³ + 2⁻⁷⁸)` as `xsd:double` literals answered `1.0E0`.
    A big integer whose conversion to `xsd:double` ties to infinity also stayed
    finite there. On an x87 build a thread that loads a directed rounding
    control is refused by name at every HNSW and kNN entry point, rayon workers
    included, and the flush-to-zero suites run only where the MXCSR governs
    binary64.

- **sparql-eval:** `Kernel::distance_reassociated` and
  `Kernel::distance_bounded_reassociated` are named entry points for the
  reassociated law. The exact names are unchanged.
  `EmbeddingKnnRelation::new_reassociated` builds a relation over `Reassociated`.
  It resolves the dispatch path once and refuses an unsupported float environment
  by name. The relation carries `OrderFidelity::Perturbed`, composed with the
  resolved path's evidence verbatim, and `FusionTrailer::fidelities` carries that
  evidence too. `RankedDeclaration::arithmetic` is a new field holding a
  `RankArithmetic`: `FloatDistance(DeclaredArithmetic)`, whose payload can only be
  built from the sealed trait (`RankArithmetic::float_distance::<A>()`), or
  `FloatFree`, which declares that no floating-point operation decides the order
  (the BM25F text relation, or a table of given ranks). `FloatDistance` appends
  the law's id to `canonical_description`, so exact and reassociated plans have
  different identities; `FloatFree` adds no byte, so the integer-ranked
  producers keep exactly their old bytes and no pinned fingerprint moves.
  `composed_order_fidelity` has one implementation, here, and `purrdf-hnsw`
  re-exports it at its old path.

- **hnsw:** a reassociated HNSW index, `HnswIndex<Reassociated>`. The generic
  constructors build, decode and load it under `Reassociated`
  (`build::<Reassociated>`, `HnswIndex::<Reassociated>::decode`,
  `guard::load::<Reassociated>`, `HnswSpace::<Reassociated>::from_artifact`),
  each one body generic over the sealed `IndexArithmetic` family, and each one
  refuses the other arithmetic's image codes. The image records the
  dispatch path that built it, and decode, rebuild verification and search run
  that path, not the widest one: an image built on the sse2 or avx2+fma path runs
  on that path on an avx512f processor. Only a path the process cannot run
  (another target's compilation, or a missing processor feature) is refused, with
  `HnswError::ArithmeticPathUnavailable`, never a bare mismatch. Its profile
  is `hnsw-reassociated-v2` (`IMPLEMENTATION_ID_REASSOCIATED`). The loss evidence
  adds the arithmetic's divergence text and says that only the compiled build
  that made the image reproduces it, on the same dispatch path. `profile_declaration` folds in the arithmetic id. The
  guard derives its legal (implementation, revision, code set) pairs from both
  arithmetics and refuses cross pairings. `IndexLossContract` is unchanged,
  because the arithmetic transforms no vectors. Reassociated recall meets the
  exact floor in the tests.

- **core:** `purrdf_core::distance::BuildShape` and `Arithmetic::build_shape()`
  (also `Resolved::build_shape()`). A dispatch path does not pin the code that
  ran: every path is also compiled under the consumer build's
  `-C target-cpu`/`-C target-feature`, so the sse2 path contracts to FMA in a
  build compiled with `fma`, the avx512f path runs `ymm` under x86-64-v4, and
  the neon path becomes SVE under neoverse-v1. A `BuildShape` is a versioned
  `u64` holding the layout version, the target architecture's code and one bit
  per target feature that decides the reassociated body's vector and FMA code
  (x86/x86_64 `x87` through `avx512vl` and `soft-float`; aarch64 `neon`, `fp16`,
  `fcma`, `rdm`, `dotprod`, `f64mm`, `sve`, `sve2`; wasm `simd128` and
  `relaxed-simd`; rows for every other `target_arch`). `BuildShape::here()` is
  this build's, `BuildShape::encode(arch, features, identity)` is the pure
  encoder, `BuildShape::from_parts(bits, identity)` rebuilds a recorded one, and
  its `Display` lists the architecture, the features and the identity.
  `Reassociated` returns this build's shape and `Exact` returns `None`, because
  its bits are the same in every build.

- **core:** `purrdf_core::distance::BuildIdentity` and `BuildInputs`, the half
  of a `BuildShape` that no `cfg` exposes. `rustc` has no `cfg` for
  `-C target-cpu`, and neither CPU tuning (x86-64-v4's 256-bit preference, a
  Neoverse scheduling model), the compiler release nor the optimisation level is
  one, yet each can change what the reassociated body compiles to. A new
  `purrdf-core` build script records them as one line of text: `rustc -vV`'s
  release, commit hash and LLVM version (run on `RUSTC`, never through a
  `RUSTC_WRAPPER`), the target CPU (`-C target-cpu` as named, `native` resolved
  to the host CPU `rustc` reports, else the target's default from
  `rustc --print target-cpus`), every `-C target-feature` as `rustc` applies
  them, any `-C llvm-args`, `codegen-units`, `lto` or `overflow-checks` in
  `CARGO_ENCODED_RUSTFLAGS`, and the optimisation level; the crate appends its
  own `cfg(debug_assertions)`. Flags that change no code, such as `-D warnings`,
  are not recorded. The identity is the text's FNV-1a 64-bit digest.
  `BuildIdentity::here()` is this build's, `BuildIdentity::encode(inputs,
  debug_assertions)` and `BuildIdentity::describe` are the pure encoder over
  explicit `BuildInputs`, and `text()` returns this build's line. What no build
  script sees is documented on the type: a `[profile]` table's own `lto`,
  `codegen-units` and `overflow-checks`, flags appended by `cargo rustc --`, and
  a compiler whose `rustc -vV` does not tell it apart from another.

- **iri:** byte-class scanners in `purrdf_iri::terminals`:
  `find_first_trivia`, `find_first_iri_body_special`,
  `find_first_json_string_special` and `find_first_xml_special`. `ByteClass`
  (built with `ByteClass::from_table`) and `byte_run_count` let a writer bring
  its own `const [u8; 256]` table and use the same kernel. Each scanner maps a
  16-byte chunk to a lane mask built from compares. It tests the chunk with a
  branch-free OR and finds the offset with `u128::trailing_zeros`. A class with
  one run uses a max-fold instead. The crate stays dependency-free and
  `forbid(unsafe_code)`. The byte predicates now read `const [u8; 256]` tables,
  which `const fn` derives from the range tables. The range tables remain the
  single source.

- **core:** `purrdf_core::ir::canon::write_literal_escaped` is now public.
  `purrdf_core::iri_escape` gains `push_escaped`, `escape` and
  `find_first_candidate`. PURREMB `F32Scalars` gains `check_finite` and
  `decode_into`, which report the same first non-finite column as the iterator.

- **build:** `make simd-asm` and `scripts/check-simd-asm.py`, an asm evidence
  gate. It emits per-crate asm for x86_64 (baseline, x86-64-v3, x86-64-v4),
  aarch64 (generic, neoverse-v1) and wasm32 (baseline, +simd128). For each
  function it counts packed-arithmetic and compare mnemonics, excluding move and
  zeroing idioms. It enforces the floors and ceilings pinned in
  `scripts/simd-asm-manifest.toml`: required mnemonics, FMA floors and ceilings,
  a relaxed-simd ban and single-copy enforcement. It refuses unknown manifest
  keys. With `--doc` it holds `docs/design/purrdf-simd.md` to the measurements.
  That covers parity, coverage, a roster of minimum sites, and a ban on speed
  multipliers in the document and in this section. The gate has its own CI job.
  Its self-test, which proves each refusal beside a valid neighbour, also runs in
  `make check` and in the CI workspace job.

- **ci:** an aarch64 job on an arm64 runner. It runs the distance module's path
  and reference-model tests on NEON, the kNN kernel tests, and the pinned
  cross-target kNN answers, exact and reassociated. It also runs the HNSW
  determinism and conformance tests. It compares against the same goldens that
  x86_64 and wasm32 hold, so an aarch64 fold that diverges fails there. Before
  this job, NEON code was only disassembled, never executed.

- **serialization:** an incremental `io::Write` path beside the byte-vector one,
  for the native RDF codecs and the SPARQL-results serializers. `TextSink` stages
  into a bounded 64 KiB window over a pluggable `ByteDrain`; `WriterDrain` adapts
  `io::Write`, `Measure` reports a document's length without the document, `Digest`
  reports its SHA-256 without it, and `Tee` forwards to two drains so a document can
  be written and digested in one pass over the emitter. The eager whole-output APIs
  are unchanged and are expressed THROUGH the streaming body, so byte identity
  between the two spellings is a property of the structure rather than something a
  test establishes afterwards. `TextSink` deliberately exposes no `truncate`, `pop`,
  `clear` or read-back: a sink cannot un-write a drained byte, so the affordance that
  would silently break streaming is not expressible.

- **build:** `scripts/check-serializer-rewinds.py`, wired into `make check` and
  `make serializer-rewind-hygiene`. Three serializers decided what to emit by
  emitting it and taking it back — a retracted Turtle prefix header, a popped SRJ
  root brace, an XML escaper truncating on an unrepresentable scalar — and each works
  perfectly until a document is large enough for a window to drain. The gate reports
  candidates rather than verdicts, against a reasoned allowlist naming each receiver
  that is not an output buffer, because `pop` on an element stack and `pop` on an
  output buffer are the same six characters and a gate that refuses both teaches
  authors to route around it.

- **iri:** `purrdf_iri::json_escape`, the workspace's one JSON string-escape law:
  `escape_body`, `push_body` and `push_string` over four named spellings
  (`JsonEscapes::{Minimal, ShortForms, Controls, Ascii}`), each copying clean runs
  whole behind a chunked stop scan. The GTS proof and replication reports, the loss
  ledger, GeoJSON, the slice registries, the SPARQL results JSON writer and the
  envelope probe all route through it with byte-identical output; the per-writer
  copies are gone.

- **columnar:** a nullable INT64 column is held the way Parquet stores it — a
  presence bitmap beside a dense vector of the present values — rather than a
  `Vec<Option<i64>>`. The PLAIN value body is that vector in little-endian bytes, so
  encoding and decoding it is one contiguous copy, a single `memcpy` call
  (`memory.copy` on wasm32) on every measured configuration, and the present-row
  count is a popcount over the bitmap. Written bytes are unchanged: a new test pins
  the five files of a seeded dataset, both compressions, to digests taken from the
  previous encoder. The decoded-table budget still charges 16 bytes per INT64 row,
  so what the reader accepts or refuses is unchanged. The codec bench adds PLAIN
  INT64 encode and decode at 0%, 10% and 90% nulls.

- **core:** a pack's `(?, p, o)` lookup decodes only the shorter of its predicate
  and object position lists and tests each entry in place — an object-index
  position against the predicate stored there, a predicate-index position by a
  binary search of its object slice — instead of decoding and merging both. On the
  WatDiv and LUBM query sets the two lists differed by at least 32× in most calls,
  and the merge decoded 73,260,098 entries where the shorter lists hold 86,551.
  Results and their order are unchanged; the merge is kept as a test oracle.
- **rdf:** CSVW URI-template expansion (`{name}` and `{+name}`) finds each run of
  characters that need no percent-encoding with a chunked byte-class scan and
  copies it whole, instead of testing byte by byte; the expanded IRIs are
  identical.

- **retrieval:** exclusion lookups. A producer's `RankedDeclaration` and a stream's
  `StreamContract` carry an `ExclusionBasis` — `Unavailable`, or `Membership`: an
  exclusion is a fact about the producer's own index, which holds no entry through
  which the request could reach the candidate — and fusion may ask a stream whose
  contract declares a basis about one candidate through `RankedStream::exclusion`.
  `ExclusionVerdict::Excluded` makes the candidate final at once, so two strata that
  share a block but never name the same candidate stop at the threshold crossing
  instead of draining; `Possible` claims nothing. A lookup that fails is
  `ProtocolError::ExclusionLookupFailed` and fails the request rather than reading as
  `Possible`; a stream that names a candidate it excluded is
  `ProtocolError::ExclusionContradicted`; a stream asked while declaring no basis
  answers `ProtocolError::ExclusionUnavailable`. Each lookup is answered through the
  witnessed prepared lane and must stand behind exactly the attestation — generation
  and service level — the stratum's read pinned, or the request fails with
  `ProtocolError::ExclusionAttestationMoved` naming both sides. An exclusion from an
  index that attested itself incomplete settles only what the stream will name: the
  residual the missing documents owe the candidate's score is still charged. `execute`
  prepares each stratum's lookup once, binds each candidate by the dataset id its read
  found it under, and hands the lookup back inside the stream; a stratum whose lookup
  will not prepare is that stratum's `ExecutionFailed` status. A unit built from a
  caller-supplied query gets the same lookup whenever every value its `?candidate`
  column takes was emitted by one of its property-function calls: through
  projections, `FILTER`s, `DISTINCT`, `ORDER BY`, `LIMIT`/`OFFSET`, renaming `BIND`s
  and `GROUP BY` conditions, a join with any other pattern, the required side of an
  `OPTIONAL`, the left side of a `MINUS`, a `GROUP BY` key, `GRAPH`, or a `UNION`
  each of whose branches binds it from a call. `PreparedQuery::call_read_shape` (new,
  beside `CallReadShape`, `CallReadRefusal` and `ColumnSource`) describes which calls
  those are (`CallReadShape::sources_of`: alternatives, one per `UNION` branch, each a
  set of calls with the pattern that drives each) and whether the query is one call
  read on demand (`CallReadShape::read_on_demand`, which `is_call_read` asks). A node
  rebinding a variable its operand bound replaces that column's sources rather than
  adding a second column beside them. One lookup is derived per call whose ranked
  declaration states the unit's basis at the position the column is read from: that
  position is the parameter and a declared depth position is freed; where patterns
  before the call bind its inputs — a needle read out of the data — the lookup keeps
  them, as a `DISTINCT` sub-select, and invokes the call once per binding of them.
  They are kept as the text evaluates them (`ColumnSource::driving_pattern`), so the
  bindings are never fewer than the text's: a `LATERAL` whose right operand is not a
  call stays one pattern with its left, a `LATERAL` inside another's right operand is
  re-attached through a `LATERAL` of it, a pattern in a `GRAPH` is read in it, the
  lookup carries the text's dataset clause, and a pattern reading a variable a
  sub-select has injected from outside it is left out. A sub-select binding no input
  at all answers `Excluded` for every candidate without invoking the call.
  The stream answers `Excluded` only when every alternative excludes the candidate —
  an alternative excluding it when any of its lookups finds no row — each lookup held
  to the attestation the stratum's read pinned. A stratum with an alternative none of
  whose calls qualify fails by name. A supplied query whose `?candidate` column can
  take a value no call emitted — a `UNION` branch binding it from something that is
  not a call, an `OPTIONAL` whose required side can bind it, a call only on the
  subtracted side of a `MINUS`, a computed `BIND`, `SELECT` expression or `GROUP BY`
  condition, an aggregate, a `GRAPH` name, `VALUES` — cannot declare a basis
  (`UnitError::ExclusionNotRenderable`, whose `reason` names what is in the way), and
  registration refuses a declared basis on a relation with no candidate-bound access
  mode whose row bound is one and which leaves any declared depth position free (see
  the `register_ranked` entry below). `FusionTrailer::exclusion_bases` records each
  stream's basis, and `FusionTrailer::evidence_id` now also covers which strata
  answered lookups; an answer that asked none keeps its evidence id byte for byte.

- **retrieval:** an on-demand read schedule. `execute_within(compiled, registry,
  dataset, ReadSchedule)` runs a bundle as `execute` does under
  `ReadSchedule::Materialised`, or under `ReadSchedule::OnDemand` holds each unit
  whose prepared text is one property-function call under row-for-row operators
  open as a single invocation and produces a row each time its stream is pulled.
  `search` reads on demand, so every stratum is read exactly once, as far as its
  fusion pulls it — plus the probe row one past the planned depth where the read
  gets that far — and a consumer that stops at the sixth rank of a four-hundred-row
  plan has caused six rows to be produced. A caller's own text that is one call
  under a `FILTER` is read on demand too: the `FILTER` is evaluated per pulled row
  by the engine's own evaluator, a dropped row takes no rank, and a `LIMIT` above
  the `FILTER` is never offered to the producer as its ceiling. A text of any other
  shape (a join, an `ORDER BY`, a dataset clause, a `FILTER` embedding `EXISTS` or
  calling a custom function or a builtin that draws per-query state) is
  materialised under either schedule, and a caller's own single-call text that runs
  out ends `SuppliedQueryEnded` under both. The receipt is taken when the fusion stops: `RankedStream::settle` returns a
  `ReadSettlement` (the attestation, rows materialised and rows emitted the read
  stands behind), and a read whose generation or service level moved between the
  open and the stop is refused as `ProtocolError::AttestationMoved`. A read that
  fails after its first row has been merged fails the request as
  `ProtocolError::ReadFailed`, naming the stratum, the rows already handed out and
  the producer's reason; a failure before the first row stays that stratum's
  `ExecutionFailed` status.
  `RankedStreamImpl` gains `exclusion`, `settle`, `rows_materialised` and
  `rows_emitted`.

- **retrieval:** what a read cost, on the answer. `StratumResolution` gains
  `exclusion_lookups` and `rows_materialised` (the rows the stratum's read produced,
  probe row included; `None` only for a stream with no read behind it), and
  `StratumResolution::counters` names every counter once, in a fixed order, as
  `ObservedCounter`s whose `CounterReading` is a number or a word for an absent value.
  `observed_resolution` renders a trailer's resolution map from those counters, one
  line per stratum. `PlannedResolution::sharing_weights` lists the weights of every
  stratum whose declared blocks meet a stratum's own, and `crossing_rank_at` and
  `threshold_at` answer, from the plan alone, the head rank at which a candidate
  first beats the threshold those sharers impose (`CrossingRank`), through the same
  arithmetic fusion uses. A weight at or below zero is refused as
  `FusionError::NonPositiveCrossingWeight`. `ExclusionBasis` is re-exported from
  `purrdf-retrieval`.

- **sparql-eval:** `NativeSparqlEngine::open_call_cursor` opens a prepared `SELECT`
  over the default dataset that is one property-function call under nothing but
  projections, `OFFSET`-free `LIMIT`s, variable-renaming `BIND`s and `FILTER`s it can
  evaluate row by row as a `CallCursor` read one solution per
  `next_row(dataset)`, with the same registry admission, arguments, declared-mode
  check, row licence, width check and unification the governed lane applies, and
  each `FILTER` applied to the rows reaching it; `CallCursor::settle` returns the relation witness of the
  rows actually produced. `PreparedQuery::is_call_read` answers whether a plan has
  that shape without opening anything. `NativeSparqlEngine::execute_witnessed` runs a
  `PreparedExecution` and returns the run's `RelationWitness` beside the answer, so a
  relation's declared shortfall is reported rather than refused.

- **sparql-eval, text, hnsw:** membership answers. `TextSearchRelation`,
  `EmbeddingKnnRelation` and `HnswRelation` declare `ExclusionBasis::Membership`
  and a candidate-bound access mode with a row bound of one, answered by a binary
  search over the index's own terms: a document with no posting under any needle
  term, or a term with no vector row, is excluded without ranking, computing a
  distance or visiting a graph node. A held candidate still ranks through the one
  scoring path, and the vector relations' emitted distance is bit-identical to the
  one a scan or beam would give. `SearchObservations`, `KnnObservations` and
  `HnswObservations` (each relation's `observations()`) count lookups, rankings,
  scans, distances and graph candidates. `EmbeddingSpace::from_vectors` builds an
  exact kNN space from a host's `(term, vector)` rows with every check
  `from_artifact` makes and a content-addressed generation of its own, and
  `HnswIndex::row_distance` gives one pairwise distance.

- **python:** `retrieval.plan`, `compile` and `search` accept `hnsw_producers=` and
  `knn_producers=` beside `text_producers`: an approximate or an exact
  nearest-neighbour producer over the host's own `(iri, vector)` rows, with a
  metric, a guard, domains and an attestation, seeded by an `("entity", "<iri>")`
  request term. The three maps form one registry; a stratum or producer IRI claimed
  twice across them raises `ValueError` naming both. Every producer registers with
  the exclusion basis its relation declares, and there is no position to assert or
  withdraw one. The answer's `"observed_resolution"` entries carry
  `"exclusion_lookups"` and `"rows_materialised"`, its `"exclusion_bases"` maps each
  stratum to `"unavailable"` or `"membership"`, a compiled answer's planned
  resolution carries `"sharing_weights"`, and `retrieval.crossing_rank_at` computes
  a crossing rank from raw weights.

### Changed

- **entail:** `materialize_rif` and `materialize_rif_until` now run on
  `purrdf_datalog::seminaive` instead of a private semi-naive loop: each RIF rule
  becomes one default-graph clause per head atom, and the derived facts, their
  emission order, the range-restriction refusal and the stop-signal behaviour are
  unchanged (differentially checked against the old loop over 600 random rule
  sets). Two consequences: the report's `join_steps` is now the engine's own
  count, and a RIF run is under the engine's default stored-fact and join-step
  limits, so a run past them is `EntailError::Evaluate` rather than unbounded;
  the new `materialize_rif_with` (and `materialize_with` for `Materialization::Rif`)
  takes an `EvalOptions` so a larger legitimate program can raise them. A
  45,150-fact transitive closure still runs under the defaults.
- **core, text:** `LossLedger::new`, `BitVec::new` and
  `PartitionFilter::unconstrained` are `const fn`; each type's `Default`
  returns that constructor (`purrdf_hash::default_from_new!`).
- **rdf:** `VizDialect` and `VizLabelPolicy` are `Copy`.
- **hnsw:** the relation's neighbour count accepts any literal whose value is
  an XSD integer, `xsd:int` and the other derived integer types included, as
  the exact relation does; a negative count, a count past the guard's
  `max_neighbours` and a non-integer are still refused.

- **cli:** every command reads its document arguments through one shared-stdin
  check and one `--import IRI=PATH` parser. A refusal names every argument that
  reads standard input (`IN, --shapes and --changes each read standard
  input…`); `validate` also refuses `IN` beside a `--shapes-product` on stdin,
  and `rules --srl` counts an `--import IRI=-` as a stdin reader. A relative
  import IRI is `iri-relative-no-base` in every command (`shex` and
  `validate --import` printed `iri-non-absolute-base`), a repeated import IRI
  is "named twice" everywhere, and `entails`, `consistency` and the premise
  commands refuse it before reading any document. Exit codes are unchanged.
- **cli (BREAKING):** a governed `query`, `update` or `validate` run starts from
  `QueryGovernors::METERED` instead of `QueryGovernors::UNBOUNDED`, through
  `purrdf_validate::governors::from_parts`, the decoder the C ABI, the wasm
  package and the Python binding already share. A dimension no flag names is
  charged against a ceiling no run can reach rather than left unaccounted, so a
  `--deadline` is polled inside a long-running operator as well as between
  operators, and the trip report still prints it as `limit … unbounded`. The
  new `--no-ceiling` flag asks for `UNBOUNDED` (no ceiling and no accounting);
  it combines with `--deadline`, and is refused (exit 2) beside `--fuel`,
  `--max-answers`, `--max-intermediate-cells`, `--max-scratch-bytes` or
  `--max-remote-requests`, naming both flags, and beside `--explain`, which
  meters by definition. A run that names no governor flag still takes the
  ungoverned path unchanged.
- **owned model:** a plain literal resolved from a dataset into the owned
  `RdfTerm` model now carries no datatype (`datatype: None`) and a
  language-tagged one no `rdf:langString` / `rdf:dirLangString`, instead of
  the expanded IRI; any other datatype is kept. `RdfDataset::to_owned_term`,
  `to_owned_quad` and every owned-model export read through
  `TermValue::into_rdf_term`, so an owned term read out of a dataset now
  equals the one a caller builds with `RdfLiteral::simple` or
  `RdfLiteral::language_tagged`. Golden changes: the C API's
  `purrdf_term_to_ntriples` writes a plain literal as `"lex"` rather than
  `"lex"^^<http://www.w3.org/2001/XMLSchema#string>` (the form RDF 1.2
  N-Triples requires), a language-tagged one without the `rdf:langString`
  datatype, and a scoped blank node as its scope envelope rather than its bare
  label; `Display` of such an owned term (Python's `str()` of a term a parsed
  document yields) and the regime diagnostics that display a literal
  (`purrdf_validate::regime`) spell it the same way.
- **order:** the answers of the OWL 2 Direct-Semantics reasoning services
  (instance retrieval, realization, classification, module extraction and
  profile violations) and the node sets a ShEx shape-map selector expands to
  are sorted by `TermValue`'s total order, in which base direction and
  blank-node scope distinguish terms and equal terms tie. Golden change: the
  report order changes where it differs from the retired string sort key —
  literals now sort before blank nodes, and two blank nodes that share a label
  sort by scope.
- **absolute IRIs:** the embedding target, the JSON-LD context compiler, the
  JSON Schema and LinkML importers and the CLI's `--path-relation` decide an
  absolute IRI with `purrdf_iri::BaseIri::parse`; their messages are unchanged.
- **deps:** `memchr` is no longer a dependency of any workspace member: the SPARQL
  tokenizer, the line-oriented codecs, the XML nesting guard and the IRI
  component splitter search with `purrdf_lex::scan::find_byte` / `find_byte2`
  or a `ByteClass`. `regex` is built without its `perf-literal` prefilter, so
  neither `memchr` nor `aho-corasick` is compiled into any build; Cargo keeps
  both in `Cargo.lock` only because `regex`'s weak feature references name
  them. `scripts/check-banned-deps.py` refuses `memchr` as a direct
  dependency.
- **lex:** every reader that decoded a `UCHAR`, an `ECHAR`, an XML character
  reference or a JSON string escape, skipped or trimmed grammar whitespace,
  escaped a JSON Pointer token, percent-encoded or percent-decoded, or searched a
  range table does it through `purrdf_lex`. `purrdf_core::blank_label::is_valid_ncname`
  answers through `purrdf_lex::terminals::is_ncname`; the SHACL, OWL and CSVW
  lexical-form trims are `trim_ws`. HTTP Basic credentials in `SERVICE`
  requests are encoded by `purrdf_xsd::canonical_base64`.
- **xsd:** `BigInt::to_decimal_lexical` takes its scale as `u32` (was `u8`).
- **unicode:** one generator, `cargo run -p purrdf-lex --example
  gen_unicode_tables -- <set>`, writes every Unicode table in the workspace
  from the vendored Unicode Character Database at one version, and refuses
  files of another release; each consumer's table set asserts that version at
  compile time. The XSD block-escape table of `purrdf-core` is the one table
  at another version, pinned to the locked `regex-syntax`, and
  `scripts/check-generated.sh` fails when the two part. No table's data
  changed.
- **text:** `purrdf_text::unicode::{nfc, nfd, nfkc, nfkd, Sink, Compare}`
  re-export `purrdf_lex::unicode`; the analysis form composes the lex stages
  with the text case fold. `purrdf-text` now depends on `purrdf-lex`. Every
  form, fold and word boundary is unchanged, over every scalar value,
  `NormalizationTest.txt` and the frozen vectors.
- **iri:** `idna::map` and the U-label NFC check normalize through
  `purrdf_lex::unicode`; `idna::UNICODE_VERSION` is
  `purrdf_lex::unicode::UNICODE_VERSION`. No verdict changed.
- **jsonschema:** `\s` and `.` read ECMA-262 `WhiteSpace` and
  `LineTerminator` from `purrdf_lex::terminals`, and the `email`/`idn-email`
  address literals check through `purrdf_iri::host::is_smtp_address_literal`;
  `purrdf-jsonschema` now depends on `purrdf-lex`. No verdict changed.
- **lex:** the crate's licence expression is
  `(MIT OR Apache-2.0 OR MulanPSL-2.0) AND Unicode-3.0`: it ships the
  normalization tables.
- **gates:** ledger job `unicode-normalization` is enforced: outside
  `purrdf_lex::unicode`, no function may be named for a normalization form,
  the NFC verdict, the combining class, the pair composer or a Unicode
  version, the pinned block table excepted as a criterion-(a) variant.
- **gts:** the files and tar profiles' `modified` stamps read and write
  through `purrdf_xsd::rfc3339`; accepted spellings, instants and error
  messages are unchanged.
- **gts, slice, python:** file media types come from the one extension table,
  matched case-insensitively. The GTS files profile now records the RDF,
  SPARQL, Markdown, YAML and CFF types (`.ttl` is `text/turtle`, where it was
  `application/octet-stream`); the slice catalog and Python artifact rows gain
  the HTML, XML, text, image, PDF, archive and TriG types; a bare file named
  `ttl` or `json` with no extension is `application/octet-stream`. Tar ingest
  is unchanged: tar entries carry no media type. The slice RDF loader and the
  SPARQL conformance harness's data-file loaders route exactly as before.
- **jsonschema:** the `date-time`, `date` and `time` formats check through
  `purrdf_xsd::rfc3339`, and exact number order, equality, hashing,
  integrality and `multipleOf` compute on `purrdf_xsd::json_number::JsonNumber`
  (over `purrdf_xsd::bigint::BigInt` past 128 bits); `purrdf-jsonschema` now
  depends on `purrdf-xsd`. No verdict changed.
- **text:** the fixed-point product and quotient compute through
  `purrdf_xsd::wide::mul_div`; `purrdf-text` now depends on `purrdf-xsd`.
- **gates:** ledger jobs `wide-arith`, `bigint`, `calendar`, `rfc3339` and
  `numeric-predicate` are enforced; the SIMD manifest site
  `gts.rfc3339-lexical` is now `xsd.rfc3339-lexical`, measuring
  `purrdf_xsd::rfc3339::{parse, format}` with its floors unchanged.
- **rdf, python (BREAKING):** `GtsFoldView` compacts IRIs to CURIEs only under the W3C
  namespaces it builds in — `rdf`, `rdfs`, `owl`, `xsd` and `skos`, taken from
  `purrdf_iri::vocab` and `purrdf_xsd::datatype` — and under the prefixes the
  caller supplies in `GtsFoldViewConfig::curie_prefixes`. The built-in
  `schema:` prefix for `https://schema.org/` is gone: PurRDF supplies no
  vocabulary that is not a W3C Recommendation's, so a schema.org IRI is now
  returned in full by `GtsFoldView::curie` and `PublicValue::Iri` unless the
  caller supplies `("schema", "https://schema.org/")`. `rdfs:label` and the
  other W3C terms compact as before. Python's `GtsFoldViewNative.from_bytes`
  and `from_parts` take the caller's prefixes as a new optional
  `curie_prefixes` list of `(prefix, namespace)` pairs.
- **rdf (BREAKING):** `JsonLdDirection` is a re-export of the one RDF 1.2
  base-direction type (`purrdf_core::RdfTextDirection`): its variants are
  `Ltr`/`Rtl` rather than `LeftToRight`/`RightToLeft`, and it gains
  `from_str_token`. `as_str` and the JSON-LD bytes are unchanged.
- **core, sparql-algebra:** `RdfTextDirection` and `BaseDirection` are
  re-exports of `purrdf_events::TextDirection`, the one RDF 1.2 base-direction
  type; `as_str` is a `const fn`, `from_str_token` reads the `ltr`/`rtl`
  token, and `BaseDirection` gains `PartialOrd`/`Ord`.
- **deflate, core:** the common-prefix length of two byte strings has one
  implementation, `purrdf_deflate::common_prefix_len`, now public: eight-byte
  XOR words and a trailing-zero count, `#[inline]` with no dispatch. It is the
  encoder's portable match-length compare and the tail of its SSE2, AVX2, NEON
  and simd128 compares, and the pack dictionary's front coding calls it, so
  `purrdf-core` now depends on `purrdf-deflate`. No compressed byte, pack
  dictionary byte or golden changed. The frozen answers in
  `crates/deflate/tests/vectors/match_length_vectors.txt` (9,546 inputs) are
  replayed by every kernel path, natively and on wasm32, and
  `check-shared-helpers.py` refuses a hand-written copy of the word loop
  (`rule:xor-first-mismatch`).
- **core, gts:** base16 has one implementation, `purrdf_hash::hex`.
  **Breaking API:** the `purrdf_core::hex` module is removed
  (`purrdf_core::hex::lower(bytes)` is `purrdf_hash::hex::encode(bytes)`, the
  same text), and `purrdf_gts::wire::hex` is removed (use
  `purrdf_hash::hex::encode`). `purrdf_gts::wire::digest_label` spells an
  already-computed BLAKE3 digest as `blake3:<hex>`, and `wire::digest_str` is
  it over the digest of its input. Every rendered and parsed hex byte is
  unchanged: lowercase sites stay lowercase, and the sites whose grammar
  specifies uppercase (the `xsd:hexBinary` canonical form, `%XX` percent
  triplets, `\u00XX` escapes) render through `hex::Upper` and its siblings.
  No golden, fixture or vector moved.
- **core, datalog, retrieval:** every 32-byte content identity wraps
  `purrdf_hash::hex::Digest32`: `ContentDigest`, `Blake3ContentId`,
  `PackDigest`, the seventeen PURREMB identities, `ContractHash`,
  `PlanIdentity`, `PlanId`, `FusionProfileId` and `EvidenceId`. Their methods,
  `Display`, `to_hex` and `from_hex` answer exactly as before
  (`ContentDigest::from_hex` still reads either case; `Blake3ContentId::from_hex`
  still reads canonical lowercase only). The derived `Debug` of `ContractHash`
  and `PlanIdentity` now shows the digest as `Digest32(<hex>)` instead of a
  list of byte values.
- **retrieval:** `PLAN_ID_DOMAIN`, `FUSION_PROFILE_ID_DOMAIN` and
  `EVIDENCE_ID_DOMAIN` are `purrdf_hash::Domain` constants rather than `&str`;
  their bytes, and every `PlanId`, `FusionProfileId` and `EvidenceId`, are
  unchanged. `as_bytes()` reads them as before, and `as_str()` gives the text.
- **core:** `PIPELINE_ROOT_DOMAIN` is a `purrdf_hash::Domain` rather than a
  `&str`, with the same bytes and the same pipeline roots.
- **jsonschema:** `EvaluationError::cause` is an `EvaluationCause` rather than
  a `PatternError`; a matcher budget error is `EvaluationCause::Pattern`.
- **jsonschema:** the evaluator keeps the subschemas it is evaluating on a heap
  work stack instead of the call stack, so an instance's nesting depth costs
  memory, not thread stack: a 1,000-level recursive instance validates on a
  256 KiB thread (it needed more than 4 MiB before). `const`, `enum` and
  `uniqueItems` compare and hash values on a heap stack too, so values nested
  100,000 levels deep compare on a 256 KiB thread. The keyword named by an
  `EvaluationError` is rendered only when one is raised, so `is_valid` renders
  none, and the new `is_valid/tree_1000` bench measures the deep case.
- **jsonschema:** a regex-parser resource error for too-deep group nesting
  reads `group nesting exceeds 250` wherever it is raised.
- **text:** the analyzer profile is `purrdf-compatibility-caseless-uax29-v2`.
  Case folding moves from `CaseFolding.txt` 16.0.0 to 17.0.0, level with the
  normalization and word-break tables, and the word filter's alphanumeric
  predicate comes from the generated tables rather than the toolchain's
  `char` tables. `unicode_versions()` reports 17.0.0 for all four tables. The
  fold changes on exactly the 28 code points whose `CaseFolding.txt` entries
  differ between the two releases (Latin Extended-D letters and the Beria
  Erfe script), so an index built under v1 fingerprints differently.
- **text:** a letter or digit followed by `MidLetter`, `MidNumLet` or
  `Single_Quote`, ZERO WIDTH JOINER and a pictograph now segments as UAX 29
  rule WB6 requires, breaking before the punctuation.
- **jsonschema:** `uri-template` admits `'` in a literal, as RFC 6570
  verified erratum 6937 corrects the `literals` rule to.

- **wasm:** an asynchronous lane beside the synchronous one. Every evaluating
  `QueryEngine` method has a Promise-returning twin: `queryAsync`, `selectAsync`,
  `askAsync`, `constructAsync`, `describeAsync`, `queryRawAsync`,
  `queryRawBytesAsync`, `queryRawWithContextAsync`, `queryGovernedAsync`,
  `queryEntailmentGovernedAsync`, `updateAsync`, `updateGovernedAsync` and
  `explainQueryAsync`, with `Dataset.queryAsync` beside them. EXPLAIN evaluates the
  query it measures, so `explainQueryAsync` explains a `SERVICE` query over the host's
  answer where `explainQuery` refuses it for want of a source, and it yields and stops
  on its signal while it measures. SHACL evaluates SPARQL too, so the SHACL
  functions have twins: `shaclValidateToSarifAsync`, `shaclValidateChangesToSarifAsync`,
  `shaclEntailAsync`, `shaclApplyRulesAsync`, `shaclEvalNodeExprAsync`,
  `shaclProductValidateToSarifAsync`, `shaclProductValidateToSarifRebuildAsync`,
  `shaclProductValidateToSarifExpectingAsync` and
  `shaclProductValidateToSarifRebuildExpectingAsync`. Each takes its synchronous
  twin's arguments and then the host options, and returns exactly what the synchronous
  twin returns; a refused product rejects with the same `ShaclProductRefusal`, and an
  `owl:imports` closure not in hand with the same `ShaclImportError`. SHACL-SPARQL
  admits no `SERVICE` in any query, on either lane, so a validation never calls the
  host's handlers. The
  signal is polled between focus nodes as well as inside queries, so a validation with
  no SPARQL in it still yields and stops. `queryGovernedNegotiatedAsync` answers a governed
  query as a document in the format an HTTP `Accept` header negotiates. Each twin
  runs the same evaluator over a snapshot of the dataset, as a job on its own stack
  region, exactly as large as the module's own shadow stack (1 MiB in the shipped
  module), that suspends through WebAssembly JavaScript Promise Integration (JSPI)
  while the host answers a `SERVICE` or `LOAD`, and resolves to its synchronous
  twin's result shape. The options are:
  - `resolveService` and `resolveLoad`, the host's handlers. A handler answers with
    data or with a typed `{ kind: "transport" }` or `{ kind: "denied" }` failure. A
    handler that throws, rejects, answers with a value the protocol does not define, or
    names a failure kind it does not define fails the one invocation it was answering
    as `{ kind: "fault", message }`. Any failure fails the request — a fault with
    `native-sparql-host-fault` or `native-sparql-load-fault`, its message carrying the
    handler's words; under `SILENT` it is the join identity (`SERVICE`) or loads nothing
    (`LOAD`), and `evidence.async.silenced` records it. A job's own fault is only a
    broken delivery protocol or a stack region its frames overran;
  - `catalog`, a `ServiceCatalog` (deny by default, one profile per endpoint, an
    optional fallback) that authorizes each `SERVICE` request, each `LOAD` source and
    each location a `LOAD` is redirected to before the handler is called, and bounds
    each request by its profile's `timeoutMs`; and `localServices`, endpoints answered
    in process from a `Dataset`;
  - `signal`, an `AbortSignal` observed at every yield and every effect. It is the
    only way to cancel a twin: passing `cancel` is a `TypeError`;
  - `yieldEveryPolls` (default 65 536; `0` yields at every poll). A job gives the
    event loop one turn per that many governor polls, counted rather than timed.
    Every turn is one `setTimeout(…, 0)` task, on every host: a timer task queues
    behind the requests, timers and network responses already waiting, so each of
    them runs between a job's turns. `globalThis.setTimeout` is bound once when the
    runtime module loads; nothing is chosen per host.

  No option sizes a job's stack region: with equal stacks the two lanes run out of
  stack at the same depth, and a stack refusal is the evaluator's own typed error,
  word for word the same on both. `asyncStackRegionBytes()` reads the region's size
  off the module's layout. One canary word at the region's base is read before every
  suspension and when the run returns, and a job whose frames overwrote it fails with
  a fault naming its region. The options each operation accepts are validated in Rust
  (`AsyncJobOptions.fromJs`), and an unknown option is refused.

  One asynchronous update of a dataset may be in flight at a time — another begun
  meanwhile is refused with `native-sparql-update-in-flight` — and an update commits
  only if the dataset was not mutated while it ran; `Dataset.id` and
  `Dataset.generation` expose the identity and mutation count that check reads. A
  `LOAD` redirect is followed by the job itself (`{ kind: "redirect", location }`),
  re-authorized against the catalog at every hop, up to five hops; `resolveLoad`
  receives each hop's `accept`, `userAgent`, `headers` and `timeoutMs`. Every effect
  names when it is abandoned (`abandonAfterMs`: its request's timeout or the deadline,
  whichever is sooner), and a profile `timeoutMs` past 2 147 483 647 is refused. A
  `SERVICE` effect says whether it is `cacheable`. A job answers a
  `SERVICE` request it repeats from its own memo when the first answer was rows, and
  concurrent jobs share one host call for the same request when the joining job's
  deadline falls no later than the call's. Every error a twin rejects with carries
  its stable code as `error.code`. Governed outcomes and twin errors carry
  `evidence.async` (polls, yields, effects, time waited per effect kind,
  freeze/evaluate/serialize time, stack high-water mark).
  `hasAsyncQueries()` reports whether the lane can run: JSPI and `setTimeout` exist
  and the module's shadow stack is laid out stack-first. Without them every twin
  rejects before touching wasm, naming what is missing, and the synchronous API is
  unchanged. JSPI is on by default in
  Chrome and Edge 137+, Firefox 139+, Safari 27, Node 24.20+ and Cloudflare
  Workers. `configureAsync({ maxConcurrentJobs })` bounds the jobs in flight
  (default 16). `Dataset.queryAsync` takes `queryRawAsync`'s options. The synchronous
  methods run the same operation implementation as their twins with no source: an
  ungoverned one on the engine's ungoverned entry, and a governed one under exactly
  the governors its caller named. `SparqlProtocolRequest` reads a SPARQL
  1.1 Protocol request through the Rust `protocol` module. `ready()` accepts a
  compiled `WebAssembly.Module`, and the package exports its `.wasm` file for hosts
  that import it.

- **cloudflare:** a new package subpath, `@blackcatinformatics/purrdf/cloudflare`.
  `createFetchServiceResolver` answers `SERVICE` with `fetch`, or with a service
  binding chosen by origin, bounded by the query's own abandonment signal (the
  catalog profile's `timeoutMs` or the deadline). It sends the catalog profile's
  headers and credential, and reports network errors, abandoned requests and non-2xx
  responses as transport failures. Its optional Cache API layer is keyed by a digest
  of the endpoint, query, `Accept` header and headers; a request the job marks not
  `cacheable` (one carrying a credential) never touches it, and a failed
  `cache.match` or `cache.put` is the request's transport failure.
  `createFetchLoadResolver` fetches each `LOAD` hop the job authorized and answers a
  redirect for the job to follow. `handleSparqlRequest` answers one SPARQL 1.1
  Protocol request. It requires governors with a deadline. The statuses are
  200/204, 400/405/415 for a malformed request, 406 when no acceptable format can
  carry the result, 409 when another update of the dataset is in flight, 422 for a
  deterministic ceiling, 503 for a deadline or cancellation, and 500 for an
  evaluation failure, and a partial answer is never sent with a 200. Errors are
  `application/problem+json` bodies with a stable `code`, `Server-Timing` reports
  the job's phases, and CORS headers are sent only when configured.
  - Each failure answers with the status Rust maps its code to
    (`SparqlProtocolRequest.problemFor`), and the engine's own diagnostic code as
    `code`. An operation that does not parse is a 400 under its parse code. A
    `SERVICE` endpoint the catalog or the resolver's own policy refuses to contact is
    a 403 (`native-sparql-service-denied`, `native-sparql-service-host-denied`), and
    so is a `LOAD` source the catalog does not authorize (`native-sparql-load-denied`)
    or the resolver's own policy refuses (`native-sparql-load-host-denied`). A
    `SERVICE` endpoint or `LOAD` source that was contacted and gave no usable answer,
    whether by a network error, a timeout, an HTTP error status, a redirect or an
    undecodable body, is a 502 (`native-sparql-service-failed`,
    `native-sparql-load-failed`, `native-sparql-load-decode`). A 403 or 502 carries a
    fixed `detail` for its code, never the engine's message, which would echo the
    catalog's policy or a resolver's or remote's own words. A `SERVICE` or `LOAD` no
    resolver reaches (`native-sparql-service-unconfigured`,
    `native-sparql-load-no-resolver`), and a host fault or an exception no code
    classifies (`InternalError`) are a 500 with a fixed `detail` and a
    `correlationId`, and the real error goes to `onInternalError`. A `SILENT` clause
    over a throwing handler is answered with the clause's own answer (`200`, or `204`
    for an update), and the handler's error still goes to `onInternalError` under a
    correlation id. Every other
    evaluation failure is a 500 whose `code` is the engine's code, never a JavaScript
    error class name.
  `maxRemoteRequests` bounds the subrequests a request makes, because every
  `SERVICE` request and `LOAD` is charged before it reaches a handler.

- **core, sparql-eval, wasm:** every invocation a `SILENT` clause absorbs is recorded.
  `GovernorEvidence::silenced` lists one `SilencedInvocation` per failed invocation —
  its `SilencedTarget` (`Service { endpoint }` or `Load { iri }`), its `SilencedKind`
  (`transport`, `decode`, `disabled`, `unconfigured`, `denied`, `host-denied`,
  `not-an-iri`, `fault`) and the message the error would have carried — in ascending
  order, so the list does not depend on how the evaluation was scheduled. Every
  governed query and update carries it, complete or not. The answer `SILENT` requires
  is indistinguishable from an endpoint with nothing to add; this is where the
  difference is kept. An ungoverned entry returns a bare result and keeps no record;
  run the same request under `QueryGovernors::METERED` to read one. The wasm package's
  `GovernorEvidence` and `AsyncEvidence` expose the records as `silenced`, each with
  `target`, `endpoint` or `iri`, `kind` and `message`, and the JavaScript wrapper
  carries them on `evidence.silenced` and `evidence.async.silenced`.

- **sparql-eval:** `QueryOptions` gains `remote` (the `SERVICE` source) and `load`
  (the `LOAD` source, taking precedence over a resolver installed on the engine).
  Every query path, `CONSTRUCT` into a view, EXPLAIN and an UPDATE's `WHERE` see the
  request's sources, so a `SERVICE` inside `INSERT … WHERE` or `DELETE WHERE`
  federates exactly as it does in a query. The `*_with_source` entries are thin
  wrappers over these fields, with unchanged signatures. `protocol` is a SPARQL 1.1
  Protocol module:
  `ProtocolRequest::parse` reads a query by `GET`, or by `POST` with a direct body
  or URL-encoded parameters, and an update by `POST` in either form, together with
  the dataset parameters, and every refusal is a typed `ProtocolError`.
  `effective_text` applies the dataset parameters by splicing at positions the
  parser reports. `negotiate` picks a result format from `Accept` per RFC 9110, and
  offers an `ASK` result only JSON and XML, since CSV and TSV exist only for
  `SELECT`. `EvalError::StackExhausted` (`native-sparql-evaluation-stack-exhausted`)
  and `RemoteError::StackExhausted` report a request too deep for the stack that
  evaluates it; on `wasm32`, `EvalError::HostStackExhausted`
  (`native-sparql-host-stack-exhausted`) and `RemoteError::HostStackExhausted` report
  one past the budget kept under the JavaScript engine's call stack; see Fixed. A host
  source's handler that faulted is `RemoteError::HostFault { endpoint, message }` for a
  `SERVICE` source and `LoadError::Fault` for a `LOAD` source; a `SERVICE` without
  `SILENT` then raises `EvalError::ServiceHostFault`, whose code is
  `EvalError::HOST_FAULT_CODE` (`native-sparql-host-fault`), and `FailureCode::from`
  maps both to `FailureCode::HostFault`, so a protocol boundary answers it as the
  host's fault. `NativeSparqlEngine::explain_query_with_stop_signal`
  explains a query with a host stop signal polled by the measuring run, which is
  still metered and never bounded; a signal that fires is reported on the
  explanation's evidence as the stop it was.

- **shapes:** `sparql::enter_execution_scope` installs a governor state together with
  the `SERVICE` and `LOAD` sources (`sparql::QuerySources`) a validation's SPARQL
  reaches, for the length of a validation, change validation or rule application. A
  governed run polls its stop signal between focus nodes as well as inside every
  query, so a validation with no SPARQL in it stops too. An ungoverned run reads no
  sources and is unchanged. `sparql::AmbientContext` and
  `sparql::replace_ambient_context` take every scope the engine keeps on the thread
  (governors, sources, registries, parser options, call depth and the extension
  environment built from them) off it as one value and put it back, for a host that
  suspends a validation and runs other work on the same thread before resuming it.

- **sparql-algebra:** `SparqlParser::parse_query_dataset_slot` returns a
  `QueryDatasetSlot`: where a query's dataset clause is, or where one would go.
  `parse_update_split` returns an `UpdateSplit` giving each update operation's
  `WITH`/`USING`/`WHERE` positions (`UpdateDatasetSlot`). `parse_update_with` runs
  through the same split. `TermPattern::triple_term_nesting` and
  `GroundTerm::triple_term_nesting` count a term's triple-term levels without
  recursion.

- **stack:** a new publishable crate, `purrdf-stack`, that measures how much stack
  the running thread has left. `remaining`, `is_low` and `replace_floor` read that
  measurement, and `MARGIN_BYTES` (128 KiB natively, 64 KiB on `wasm32`) is the
  margin the SPARQL evaluator refuses at. Natively the floor is the
  operating system's thread limit, read once per thread by a small platform
  module: `pthread_getattr_np` (Linux, Android, NetBSD), `pthread_attr_get_np`
  (FreeBSD, DragonFly BSD), `pthread_stackseg_np` (OpenBSD),
  `pthread_get_stackaddr_np`/`pthread_get_stacksize_np` (macOS, iOS), or
  `GetCurrentThreadStackLimits` (Windows) — raw `libc`/`windows-sys`
  declarations resolved against the target's own C library at link time, so
  nothing here needs a build-time C toolchain and a cross build never fails
  looking for one. On a target none of those cover the bound cannot be read
  and the guard stays inactive, as it always has. On `wasm32` the floor is the
  shadow stack's low end, which a host can replace. The crate denies `unsafe`
  code everywhere but that platform module, where each block carries its own
  safety argument.

- **build, wasm:** `crates/wasm-link`, the post-link tool `make wasm-pkg` runs last on
  the optimized artifact, makes the asynchronous lane's suspend, run and poison
  guarantees properties of the wasm module itself. It exports the shadow-stack pointer
  as `purrdf_stack_pointer`; routes every call of the suspending import through an
  injected `$suspend` that parks the job on the idle pointer and restores the job's own
  pointer when the import returns; wraps `purrdf_jspi_run`, which takes the region top
  as its last argument and returns with the idle pointer restored; and puts every
  exported function behind a poison gate whose `WebAssembly.Global`s are exported
  (`purrdf_idle`, `purrdf_poisoned`, `purrdf_active`, `purrdf_parked`,
  `purrdf_outbound`). The JavaScript runtime passes the region top, reads those globals
  and never moves the stack pointer. A trap, a Rust panic, or a JavaScript exception
  thrown through wasm frames poisons the instance: the failing call throws its own
  error, every later synchronous entry traps at the gate, and the asynchronous twins
  and `ready()` reject with the poison error. The release exports behind `free()`,
  `[Symbol.dispose]()` and the glue's finalization registries have an inert gate: on a
  poisoned instance they return without entering it, releasing nothing (the instance's
  memory is abandoned whole), so a finalizer never throws where nothing can catch it. A
  job started from inside a synchronous sink callback is counted by the import's
  trampoline and runs.
  The pack checks fail when the tarball lacks a path `package.json` promises.

- **shapes:** SHACL 1.2 Core is complete: every constraint component the SHACL 1.2
  vocabulary declares is evaluated natively. New are the list components
  `sh:minListLength`, `sh:maxListLength`, `sh:uniqueMembers` and `sh:memberShape`,
  whose failing or duplicate members are reported as `sh:detail` results; a SHACL
  list as the value of `sh:class`, `sh:datatype` and `sh:nodeKind` (a disjunction),
  and `sh:TripleTerm` as a node kind; `sh:singleLine`; `sh:rootClass`;
  `sh:someValue`; `sh:subsetOf` and property-pair components over any SHACL property
  path; `sh:uniqueValuesFor`, resolved once per dataset binding and grouped by exact
  term tuple; and `sh:closed sh:ByTypes`, evaluated by the Core 7.9.1 algorithm over
  a shapes-graph-wide index built once at load. `Constraint` gains `MinListLength`,
  `MaxListLength`, `UniqueMembers`, `MemberShape`, `SingleLine`, `RootClass`,
  `SomeValue`, `SubsetOf` and `UniqueValuesFor`; `ClosedMode` and `ClosedTypeIndex`
  are new, and `NodeKindValue` gains `TripleTerm`.

- **shapes:** the SHACL 1.2 targets. An implicit class target applies to a shape that
  is also a SHACL instance of `rdfs:Class`, directly or through `rdfs:subClassOf`,
  and to every `sh:ShapeClass`; a data-graph node with `sh:shape s` is a focus node
  of `s`; `sh:targetWhere` targets every node of the data graph that conforms to the
  where-shape, triple terms included; and a node-expression `sh:targetNode` is
  evaluated with the shape as its focus node. `Target` gains `NodeExpression` and
  `Where`.

- **shapes:** computed values. A property shape's value nodes are those of its path,
  then the outputs of its `sh:values` node expression, then, only while the set is
  still empty, those of `sh:defaultValue`, each evaluated at the focus node
  (`PropertyShape::values`, `PropertyShape::default_value`). The rules engine derives
  the same values through `sh:expectedPredicate` (SHACL 1.2 Inference Rules 3.8).

- **shapes:** per-constraint reifier annotations. A reifier of an asserted constraint
  triple in the shapes graph may carry `sh:deactivated`, `sh:severity` or
  `sh:message` for that one constraint; severity and message resolve reifier first,
  then the constraint node, then the shape, and reifiers or statements that disagree
  are refused at load (`ConstraintAnnotation`, `AnnotatedConstraint`,
  `Shape::constraint_annotations`, `PropertyShape::constraint_annotations`).

- **shapes:** the `sh:Debug` and `sh:Trace` severities and the conformance-disallow
  set. `engine::ValidationOptions` (`#[non_exhaustive]`) carries
  `conformance_disallows`, a `report::ConformanceDisallows` that defaults to exactly
  `sh:Violation`, `sh:Warning` and `sh:Info`. A report conforms unless a result has a
  disallowed severity, every nested conformance check (`sh:node`, `sh:not`, the
  logical and qualified components, `sh:someValue`, `sh:memberShape`,
  `sh:reifierShape`, `filterShape`) uses the same set, and a non-default set is
  echoed as `sh:conformanceDisallows` triples. `ValidationReport::from_results`
  builds a report judged under a set, and `ValidationResult::details` carries
  `sh:detail` results.

- **shapes:** SHACL 1.2 Inference Rules, run on `purrdf-datalog`. `sh:layer` defines
  the strata and the rules of one `sh:order` run concurrently; `sh:runOnce`, global
  rules, `sh:RulesGraph`, rule sets with `sh:hasRule` and `sh:includesRuleSet`,
  SPARQL rule templates (a missing required parameter fails), temporary triples,
  `sh:expectedPredicate` derived triples, `sh:ruleProcessor` (a value the host has
  not registered fails) and `sh:entailment sh:RulesEntailment`, which runs the rules
  before validation. `infer` returns an `Inference` whose `Explanation`s name the
  rule and premises behind each derived triple; `RuleOptions` carries the registered
  rule processors, the rule-set selection and the term-generating round limit
  (default 65,536). `Shapes::rules` holds a `RuleGraph` of global rules and
  `RuleSetDeclaration`s.

- **shapes:** the SPARQL 1.2 RL rule language. `purrdf_shapes::srl` parses every
  production of the grammar over the `purrdf-sparql-algebra` lexer (data blocks,
  `WHERE DATA`, `NOT` and `NOT DATA`, `SET`, triple terms, reifiers and annotations),
  rejects the SPARQL built-ins the language leaves out, checks well-formedness (4.2),
  computes rule dependency with unification through nested triple terms (4.3),
  stratifies and names the rules of a cycle (4.4), resolves imports through a
  caller-supplied resolver (4.5 and Appendix A), and evaluates (6.4, 6.5) on the same
  rules engine as SHACL rules, with `parse`, `parse_and_check` and `infer` and one
  typed error per stage. Grammar rule [2] is implemented as written.

- **shapes:** SHACL-SPARQL result annotations. A `sh:resultAnnotation` on a
  SPARQL-based constraint or on a validator of a SPARQL-based constraint component
  copies the solution's binding of its `sh:annotationVarName` into every result as
  a value of its `sh:annotationProperty`. With no `sh:annotationVarName`, the local
  name of the property is the variable. When the variable is unbound, the
  `sh:annotationValue` defaults are used. An ASK validator's annotations read `this`,
  `value` and the component's parameters. `shapes::ResultAnnotation` is new,
  `ValidationResult::annotations` carries the pairs, and the report graph, prepared
  products, the SARIF result property `shaclResultAnnotations`
  (`build::PROP_SHACL_RESULT_ANNOTATIONS`) and the Python result dicts'
  `"annotations"` key all carry them. The shared W3C grader grades any annotation an
  expected report states.

- **shapes:** the SHACL Advanced Features 1.1 `sh:minus` node expression,
  `[ sh:nodes N ; sh:minus M ]`, evaluates as SHACL 1.2's `shnex:remove`: the nodes
  of N that are not in M, in N's order. `sh:nodes` is required.

- **sparql-algebra:** `lexer::is_varname`, the grammar's `VARNAME` test, is public.

- **shapes:** the spec symbol table. `purrdf_shapes::spec` reads what the vendored
  SHACL 1.2 vocabularies declare (`declared`, `declared_terms`, `Vocabulary`) and
  lists what the engine implements (`implemented`, with `ComponentRow`,
  `FunctionRow`, `TargetRow` and their parameter rows); a test pins the difference at
  zero. `spec::census` classifies every `sh:` and `shnex:` term the parser reads.
  `function_resolution::FunctionResolution` says, per node-expression call site,
  whether the function bound natively, to a custom body, to a SPARQL registration or
  to a host extension.

- **shapes:** `lint::lint` certifies a shapes graph: the loader's verdict, every
  result of validating it against the vendored `shacl-shacl.ttl` (a result SHACL 1.2
  Core makes well-formed is marked superseded), and the function resolution.
  `free_expression::evaluate` evaluates one node expression of a shapes graph at a
  focus node with scope bindings, as `evalExpr` defines.
  `text_ingest::parse_turtle_document` returns a `TurtleDocument` carrying the
  dataset, the document base and the prefixes the document declares.
  `NodeExpr::sequence_contract` and `SequenceContract` state the order and
  multiplicity each node-expression kind's evaluation clause defines.

- **validate:** `shapes_tools`, the string-in, string-out layer every host calls:
  `apply_rules_to_ntriples` (`RulesRequest`, `RulesOutcome`),
  `eval_node_expr_to_terms` (`NodeExprRequest`), `lint_shapes_ttl` and
  `parse_scope_binding`. SARIF gains `SarifOptions::validation`, the
  `ValidationOptions` a log is judged under; `ResultKind` with `SarifResult::kind`
  and `SarifResult::properties`; `shacl_kind`, which makes `sh:Debug` and `sh:Trace`
  results informational with level `none`; run properties `shaclConforms` and
  `shaclConformanceDisallows`; a result property `shaclMessages` listing every
  message whenever the primary text alone would lose one; `sh:detail` results as
  related locations; a curated rule summary for every component the SHACL 1.2
  vocabulary declares; and specification links for the SHACL 1.2 components.

- **cli:** `purrdf rules` applies a shapes graph's SHACL rules or a SPARQL 1.2 RL
  rule set (`--srl`) and writes only the inferred triples, with `--explain[=PATH]`
  for each derived triple's rule and premises and `--max-term-generating-rounds`;
  `purrdf node-expr` evaluates one node expression (`--expr`, `--focus`, `--scope
  NAME=TERM`); `purrdf shapes lint` reports the lint and exits 1 on any finding.
  `purrdf validate` gains `--shapes-base IRI`, the shapes document's parse base, and
  `--conformance-disallows IRI` (repeatable).

- **python:** `purrdf.shapes.apply_rules`, `eval_node_expr` and `lint_shapes`;
  `shapes.validate(..., conformance_disallows=[...])`, whose result dict carries the
  `conformance_disallows` set it was judged against; `RdfFormat.RDF_XML`; and
  `Store.load`, `Store.bulk_load` and `MutableDataset.load` return the document's
  prefix list, which the rdflib-compatible `Graph` binds.

- **wasm:** `shaclApplyRules` (returning `ShaclRulesInference`), `shaclEvalNodeExpr`,
  `shaclLintShapes` (returning `ShaclLintReport`), and an optional
  `conformanceDisallows` argument to `shaclValidateToSarif`, typed as
  `ShaclSeverity[]`.

- **capi:** `purrdf_shacl_apply_rules`, `purrdf_shacl_eval_node_expr` and
  `purrdf_shacl_lint_shapes`, within the unreleased 0.8 ABI.

- **datalog:** what the SHACL and SPARQL 1.2 RL frontends need. Guard literals
  (`guard::Guard`, `GuardEvaluator`) evaluated through `purrdf-sparql-eval` by
  `evaluate_guarded`; negated conjunctions (`Negation`); conjunctive heads; the
  `schedule` module, which runs layered run-once and iterating rule groups with
  per-layer hooks (`Schedule`, `Layer`, `compile_scheduled`, `evaluate_scheduled`,
  `LayerHooks`); SPARQL 1.2 RL rule-level stratification that names the cycle of a
  non-stratifiable set (`stratify_rules`, `stratify_dependency_graph`,
  `DependencyGraph`); and `EvalOptions`, whose term-generating round limit
  (`DEFAULT_MAX_TERM_GENERATING_ROUNDS`, 65,536) stops a guard that keeps computing
  new terms and is folded into `contract_hash_with` and `scheduled_contract_hash`.
  The limit cannot bind a guard-free program.

- **core:** `purrdf_core::imports`, the one rule for which `owl:imports` triple is an
  import, for when an import is resolved, and the one merge that folds a resolved
  closure into a dataset: `ImportMap` (`insert`, `declare_loaded`, `imported_iris`,
  `closure`, `unresolved_imports`), `ImportClosure`
  (`documents`, `unresolved`, `unreached`, `merge`), `unresolved_imports` and
  `imported_iris(graph, loaded)`. An `owl:imports` triple is an import only when its
  subject is an anchor of its document — an IRI it was loaded under (for an imported
  document, the IRI it was imported by), a subject it types `owl:Ontology`, or a subject
  naming one of those as its `owl:versionIRI` — per OWL 2's ontology header (Mapping to
  RDF Graphs §3.1.2) and SHACL 1.2's `^owl:versionIRI?/owl:imports`; any other
  `owl:imports` triple is data. Entailment and SHACL both take their verdict from it;
  `purrdf-entail` re-exports it from `entails::imports`.

- **core:** `purrdf_core::graph_roles`, the one graph-role classifier: `GraphRoles`
  (`ONTOLOGY_HEADER`, `SHAPES_GRAPH`, `DATA_GRAPH`; `is_import_anchor`,
  `declares_implicit_prefixes`, `labels`) and `GraphRoleIndex::classify`, which gives
  every node of a document its roles as a SHACL instance (`rdf:type/rdfs:subClassOf*`
  over the document) of `owl:Ontology`, `sh:ShapesGraph` (with `sh:RulesGraph` counted
  as one whether or not the document states its subclass axiom) and `sh:DataGraph`. The
  `owl:imports` rule and SHACL-SPARQL's implicit prefix collection both select from it,
  so the two node sets cannot drift apart. `purrdf_core::imports` gains
  `unanchored_import_triples`, `ImportMap::unanchored_imports` and `UnanchoredImport`:
  every `owl:imports` triple of a closure that is data rather than an import.

- **shapes, validate, cli, python, wasm, capi:** `shapes lint` reports a sixth,
  informational section, `unanchored-imports N`, with one `unanchored SUBJECT OBJECT
  document -|<IRI>` line per `owl:imports` triple of the shapes graph's closure whose
  subject is no anchor of its document, so it is data and imported nothing. The lines are
  never findings and do not affect `clean`. `LintReport::unanchored_imports` and
  `lint::UnanchoredImport` carry it, and Python's `lint_shapes` dict gains
  `"unanchored_imports"` (`document`, `subject`, `object`). The `shacl-shacl` section
  already reports W3C `shsh:DataGraphImportsShape`, at severity `sh:Info`, for a
  `sh:DataGraph` that uses `owl:imports` without the type `owl:Ontology`; that result is
  a finding, and a test now pins it.

- **shapes:** `purrdf_shapes::imports`: the `ShapesImports` table (`from_turtle`,
  `insert`, `insert_turtle`, `declare_loaded`), the typed `ShapesImportError`
  (`Unresolved`, `Unreached`, `InvalidEntry`, with a stable `kind()` label:
  `unresolved-import`, `unreached-import`, `invalid-import`), and
  `resolve_shapes_imports`, the one helper every shapes-graph entry point resolves a
  shapes graph's `owl:imports` closure through. `ShapesError` (`Imports` or
  `Invalid`) is the error those entry points return.

- **python/wasm/capi:** the shapes graph's `owl:imports` table on every host.
  Python's shapes functions and `Shapes(...)` take `imports=[(iri, turtle), ...]`
  and raise `purrdf.shapes.ShapesImportError` (a `ValueError`) with `.kind` and
  `.iris`. Every JavaScript `shacl*` function that takes a shapes graph takes
  trailing `importIris` / `importDocuments` arrays and rejects with the
  `ShaclImportError` class (`kind`, `iris`, `message`). The C ABI appends
  `PURRDF_STATUS_SHAPES_IMPORT_ERROR` (12) and adds
  `purrdf_shapes_import_error_kind`, `purrdf_shapes_import_error_iri_count` and
  `purrdf_shapes_import_error_iri`.

- **rdf:** `ParseOutcome::document_prefixes`, the prefixes a Turtle, TriG or RDF/XML
  document declares, and `parse_dataset_reporting_failure`, whose `ParseFailure`
  carries the directives in force at the failure point.

- **sparql-eval:** `UserFunctionRegistry::remove_sparql_bodied`, the seam the SHACL
  1.2 SPARQL Extensions redefinition rule needs.

- **conformance:** the W3C SHACL 1.2 vocabularies and the whole `shacl12-test-suite`
  are vendored byte-exact under `vectors/shacl12/` by `scripts/vendor-shacl12.py` and
  frozen by SHA-256 manifests. The new harness
  (`crates/shapes/tests/w3c12_conformance.rs`) runs every test type through the
  library API. Of the 544 entries an upstream manifest lists, 538 pass as approved
  and 6 are counted apart as non-canonical expected decimals: the approved result
  spells a computed `xsd:decimal` non-canonically (`"4.0"`, `"3.0"`, `"42.0"`,
  `"00"`) where the expected value is correct, and they are graded by substituting
  the XSD 1.1 canonical spelling, which for these six equals value comparison.
  `validator-001` passes by name in both suites (129 / 129 in the SHACL 1.0 suite)
  with no import supplied: its `owl:imports <http://datashapes.org/dash>` sits on a
  node that is neither the document's IRI nor an `owl:Ontology`, so it is data, and
  the harnesses load it with an empty import table. The expected-failure ledger is empty. The 3 entries of vendored files no manifest includes are graded
  and reported apart. The matrix gains a SHACL 1.2 row and a row for the unlisted
  files, and the prepared-product equivalence row now covers the SHACL 1.2
  `sht:Validate` entries (364 shapes graphs). Beside it,
  `vocabulary_import_invariance.rs` proves that merging the vocabularies changes no
  report, `shacl_shacl_differential.rs` holds the parser's refusals to the verdicts
  of `shacl-shacl.ttl` over 376 shapes graphs and 724 generated mutants,
  `node_expr_reference.rs` compares the evaluator with a clause-by-clause reference
  interpreter over 2048 generated cases, and `scripts/check-shapes-parser-drops.py`
  (in `make check` and CI) forbids the parser patterns that dropped terms silently.

- **gts, rdf, core, shapes:** the triple-term nesting bound and the schema nesting
  bound each have one home. `purrdf_events::MAX_TERM_NESTING_DEPTH` (16) replaces
  six redeclarations: `purrdf_gts::MAX_GTS_TERM_NESTING_DEPTH` is removed
  (**Breaking API**; use the events constant, same value), and the copies in the
  IR validator, the GTS resolver, importer and writer and the projection package
  limits are deleted. `purrdf_shapes::limits::{MAX_SCHEMA_DEPTH, ensure_depth}`
  (128) replaces four `MAX_SCHEMA_DEPTH` constants and the TypeScript and GraphQL
  `ensure_depth` pair; the messages users see are unchanged. The ledger jobs
  `term-nesting-depth` and `schema-nesting-depth` refuse a redeclaration:
  `forbidden.names` now also reads constant names, and `rule:sole-name` makes a
  same-named function inside the home crate a copy.
- **core:** `DatasetView::triple_term_nesting_bound` on a delta view and a
  composite view is the widest bound of their parts, and `None` when any part
  vouches for no bound; both used to claim 16 whatever they held. A composite
  over no sources reports 0. `RdfDataset` still reports 16, the bound its
  `freeze` enforces.

### Measured

Peak allocator bytes, from the deterministic counting allocator rather than timings.

- The serialization graph's interner memoized on an owned copy of every term's
  value, so each term's text existed twice for the life of a build. Building a
  40,000-quad graph fell from a 32,449,626-byte peak to 17,986,057 (-44.6%) at
  200,013 allocations down to 80,012, with the retained graph and the interned term
  count both unchanged — the evidence that the dedup relation did not move. This was
  the ceiling that made N-Quads and TriG report byte-identical serialization peaks
  for documents differing by 931,240 bytes, and with it gone streaming measurably
  helps for the first time: N-Quads streamed now costs 5,153,092 bytes less than
  eager, where it previously measured 65,536 bytes worse.

- Compacting a JSON-LD document cloned the whole carrier to reach a `&mut` through a
  `&self` receiver. On a 1,147,788-byte document the peak fell from 12,379,601 to
  9,310,041.

- YAML-LD serialized to a JSON `String`, reparsed it into a `serde_json::Value` and
  converted that, holding four representations at once. It now emits straight from
  the carrier. The reparse had been credited with producing sorted key order; the
  carrier already emitted sorted keys, which was verified byte-for-byte against the
  old path before the reparse was removed.

- The SPARQL-results CONSTRUCT arm rendered a whole N-Quads document and JSON-escaped
  it afterwards. It now renders through the escaper, so nothing between the producer
  and the drain holds the answer.

- What the helpers centralized into shared homes do, by construction (no
  wall-clock figures: two runs of the same code give different ones). The
  Turtle literal escape scan answers sixteen bytes per packed compare. The
  shared JSON reader no longer builds a whole `Value` tree for a reader that
  only wants rows or positions: the SRJ `SELECT` readers and the GeoJSON
  literal reader build their rows and positions straight from the pull
  reader's events; a whitespace run or a clean string run shorter than one
  scan chunk is crossed inline rather than through a call whose chunk loop it
  would never enter; the reader records whether a string holds an escape while
  scanning it, so decoding an escape-free string borrows it without a second
  pass; and each container the tree reader closes is one allocation of
  exactly its length. The shared writer walks each container's members in
  place, one frame per open container, instead of pushing a work item per
  token (byte-identical output). `hex::Lower` and `Upper` `Display` resolve
  their encoder once instead of walking every path's availability check on
  each call. The benches are `sparql_results_json_read`,
  `geojson_json`/`geojson_literal`, `core_escape_scan`/`core_pack_dict_prefix`
  and the `hex` group at 1 MiB.

- XSD patterns, SPARQL `REGEX` and `sh:pattern` since `regex` lost its literal
  prefilter. Without one, every unanchored search walked its whole haystack
  through the lazy DFA. `CompiledPattern::is_match` now runs a
  required-literal prefilter read from the engine's own syntax tree, searched
  with `purrdf_lex::scan::find_byte_pair` and `find_range_pair`, so a haystack
  without the window is refused without entering the engine and the engine
  starts where a match through the first window could begin. A plain-text
  pattern such as `example\.org` is answered by the literal search alone,
  its candidates verified by word compares and never by the engine; the
  single-byte positions next to an anchor (`^http://example\.org/`,
  `[0-9]{3}$`, `^[a-z]`) are compared with the haystack's first or last bytes
  before the engine, or instead of it when they are the whole pattern. Compile
  parses a pattern once: its plan is read when a match first needs it, decided
  without a parse for literals and for anchored patterns with only repeated
  atoms at their anchors, and a literal's engine is built only when a caller
  needs it. The pair search reads a hit chunk's offset from one lane mask
  (`pmovmskb` and a trailing-zero count on x86-64) rather than a walk of its
  lanes. The shared first-mismatch helper in `purrdf-deflate` compares sixteen
  bytes per step (one `pcmpeqb`/`pmovmskb` pair on x86-64) and answers the
  bytes after its last whole word with one overlapping word instead of a
  byte-at-a-time tail. The benches are `xsd_regex_match` and
  `xsd_regex_compile` in `xsd_regex`, `regex_long_literals` in `regex_eval`
  and `shacl_pattern_long_values` in `pattern_validate`.

### Fixed

- **shapes:** the canonical IRI comparison behind the focus-node sort compares
  from the first differing byte again; since the helper centralization it
  scanned both IRIs end to end on every comparison. It uses the one first-mismatch
  helper in `purrdf-deflate`, now 16 bytes a step, and checks only the scalars
  at the difference for bytes the rendering escapes (checked against full
  rendering over 20,000 pairs).
- **sparql-eval, wasm:** nested `FILTER NOT EXISTS` answers 181 levels deep on
  the synchronous wasm lane, up from 75; nested `FILTER EXISTS` answers 203, up
  from 117, and nested `LATERAL` 282, up from 193, where the query-height
  admission now ends it before the evaluator's stack does. One operator serving
  both `DISTINCT` and `REDUCED` had been inlined into the evaluator's recursive
  dispatcher, whose frame a nested negation pays twice per level. `eval_node` is
  now a thin dispatcher: every operator it calls is kept out of line, which also
  roughly doubles the nesting a native thread's stack evaluates.
- **rdf, entail:** the RDF/XML, TriX and RIF-XML readers read a document type
  declaration as XML 1.0 requires of a non-validating processor: internal
  entities (such as `<!ENTITY xsd "http://www.w3.org/2001/XMLSchema#">` used as
  `&xsd;integer`) expand under the reader's expansion budget, and an external
  subset, an external entity or an external parameter entity is never fetched
  (a reference to an external entity is refused), so no document causes a
  fetch. A document naming an external subset or external parameter entity is
  refused with the reason (`Document::declarations_unread`: default attributes
  and entity declarations may be missing), never read with declarations
  silently unapplied; the RDF/XML, TriX, GraphML, DataCite and RIF-XML
  readers all apply this. Such well-formed RDF/XML with only an internal subset
  was refused for its DTD before. GraphML, DataCite and SPARQL Results XML
  still refuse any DTD.
- **rdf:** the JSON-LD serializer folds a list of lists however deep without
  recursing: a 2 000-level list of lists serializes on a 128 KiB thread.
- **slice:** `Dataset::canonical_nquads_flat` flattens through
  `purrdf_rdf::flat_rdf_quads`, so a reifier declared or annotated inside a
  `GRAPH` block keeps its graph; it was written into the default graph.
- **rdf:** DataCite element text is trimmed by XML whitespace (SPACE, TAB, CR,
  LF) only; a NO-BREAK SPACE at either end is content.
- **jsonschema:** `OutputUnit`'s `Clone`, `PartialEq` and `Debug` walk the unit
  tree over a heap work list, so a thousand-deep output no longer overflows the
  thread stack.
- **wasm:** two blank nodes that share a label in different scopes are two
  blank nodes in JS. Query results and dataset iteration used to hand both to
  JS under the bare label, collapsing them; each now crosses as its
  deterministic scope envelope, and a JS term carrying one is read back as the
  same scoped node. A default-scope blank node keeps its label.
- **python:** a SPARQL result cell that is a triple term with a non-IRI
  predicate raises `ValueError` instead of being rendered with a fabricated
  predicate string.
- **geo, text:** building an index over a view that hands back an id whose
  literal datatype is not an IRI is refused (`GeoError::Config`, `TextError`)
  rather than indexing the literal under an empty datatype.
- **escapes:** a signed escape is refused. `\u+041` and `\U+0000041` were read
  as `A` by the retrieval term decoder and by the composite-literal blank-node
  rewriter (whose decoder used `u32::from_str_radix`, which accepts a leading
  `+`), `&#x+41;` and `&#+65;` as `A` by the SPARQL results XML reader, and
  `\u{+41}` by the JSON Schema language-tag import; `\u0041`, `&#x41;` and
  `&#65;` still decode.
- **sparql-results:** an XML character reference must be well formed and name an
  XML `Char` (XML 1.0 §4.1, WFC Legal Character): `&#x0;`, `&#1;`, `&#xFFFE;`
  and the uppercase `&#X41;` are refused; `&#x9;`, `&#xFFFD;` and `&#x10FFFF;`
  still decode.
- **retrieval:** the canonical term decoder separates terms by `WS` (space, tab,
  carriage return, line feed) only. FORM FEED was accepted as a separator
  through `is_ascii_whitespace`; it is now refused, and so is any other
  control character in a blank-node label, which the writer never emits.
- **gts:** the MMR document reader kept each raw byte of a non-ASCII JSON string
  as a separate Latin-1 scalar, and refused every surrogate-pair escape; strings
  now decode as UTF-8 with pairs combined, and an unpaired surrogate is still
  refused.
- **rdf:** a CSVW column name derived from a title is an RFC 6570 `varname`
  (CSVW Metadata Vocabulary §5.6): `~` is written `%7E`, a `.` that begins, ends
  or doubles is written `%2E`, and a table read without metadata writes a
  leading `_` as `%5F` as the metadata reader already did, so a derived name
  never takes a reserved one.
- **entail:** RIF-XML text is trimmed by XML `S`; a NO-BREAK SPACE at either end
  is content rather than trimmed.
- **slice:** the dependency fixer recognizes a `@prefix` directive only after
  Turtle `WS`; one led by a NO-BREAK SPACE or FORM FEED is not a directive.
- **shapes:** a PEP 440 version for the Pydantic projection may be surrounded by
  any whitespace Python's `str.isspace` names, as the reference pattern's `\s`
  admits; it was limited to ASCII whitespace.
- **core:** the composite-literal blank-node rewriter keeps a malformed `UCHAR` in
  a datatype IRIREF as written rather than dropping it.
- **jsonschema:** a pattern whose groups nest within the parser's limit but
  wrap repetitions, alternations and sequences between them (for example 250
  levels of `(?:a|…b)*`) is compiled; it was refused as a resource error
  because the translator counted every expression node as a nesting level.
- **testkit:** `PURRDF_PROP_SEED` and `PURRDF_PROP_CASES` refuse a sign: `+5`,
  `0x+ff` and `-0xff` were accepted by the standard integer parsers' leading
  `+`; `5` and `0xff` still parse.
- **retrieval:** the term decoder that reads an entity seed and a fused candidate's
  canonical lexical stepped over the character before a datatype IRI without checking
  that it was `<`. Text cut off after `^^` panicked past the end of the input, and
  `"1"^^X…>` was accepted with the `X` dropped. Both are now refused as text that is not
  one term — an entity seed with `PlacementError::Unrenderable`, a fused candidate as a
  failed lookup — and a well-formed `"1"^^<…>` still decodes. A caller that sent either
  malformed form writes the datatype IRI in angle brackets.

- **sparql-results:** a deeply nested SPARQL Results JSON document, such as a hostile
  `SERVICE` endpoint's answer, overflowed the stack while the reader parsed, decoded or
  dropped it, trapping a Wasm instance even under `SILENT`. The reader, its triple-term
  decoding and its value drop now keep their state on the heap, so such an answer is
  read, or refused with the reader's format error, however deep it nests.

- **sparql-eval:** `ServiceCatalog::authorize` named the `query` capability as the one
  withheld when no profile covered the endpoint, whatever the request needed; it now
  names the first capability the request needs, so a `LOAD` fetch refused by an empty
  catalog reads as withholding `network`.

- **sparql-eval:** nested correlated `FILTER EXISTS` / `NOT EXISTS` cost time and
  memory cubic in the nesting depth: each level's per-row substitution copied every
  level below it, walked that copy again for its variables at every `FILTER`, and
  prepared the nested body afresh. A nested body is now substituted when it is
  evaluated, from a preparation made once per evaluation, so one more outer row costs
  work proportional to the depth. Counted per extra outer row at depths 20, 40 and 80:
  26,773 / 315,343 / 4,205,883 tree nodes before, 78 / 158 / 318 after. Answers are
  unchanged.

- **sparql-eval:** EXPLAIN evaluated a nested `EXISTS` that reads an outer variable
  with the first outer row's value for every row, and could report rows the query does
  not return.

- **sparql-eval:** the default HTTP federation user agent named version 0.1. It is
  now `purrdf-sparql-eval/<crate version> (SERVICE federation)`.

- **sparql-eval:** EXPLAIN refused every query containing `SERVICE`. With
  `QueryOptions::remote` set it now explains the query, evaluating it against that
  source as the evaluation it explains would.

- **sparql-algebra:** only group patterns were bounded, so a query nested deeply
  enough anywhere else exhausted the parser's stack: about 950 nested parentheses
  trapped the wasm build, and every other recursive production overflowed a native
  stack at 10 000 levels. The parser no longer recurses on a request's nesting (see
  the **BREAKING** **sparql-algebra, sparql-eval** entry under Changed), so every
  construct of the query and update grammars nests as deep as memory holds it, on a
  thread of any stack size and on both wasm lanes. The 128-level group limit and the
  2 048-element count on a run of sibling elements are gone, and so are
  `MAX_GRAPH_PATTERN_DEPTH` and `MAX_GRAPH_PATTERN_NODES`.

- **sparql-eval:** evaluating what the parser admits could still exhaust the stack.
  On the synchronous wasm lane, 62 nested `NOT EXISTS` or about 104 nested `LATERAL`
  ran the shadow stack below its floor and trapped the instance. The evaluator now
  measures the stack it has left at every recursive step that can deepen without
  bound, and refuses with `native-sparql-evaluation-stack-exhausted` before the
  margin is spent. Walks that have no error channel run inside a scope that discards
  the half-built result. A stack refusal inside an in-process `SERVICE` body cannot
  be silenced by `SERVICE SILENT`. The evaluator's 128-level graph-pattern count and
  the 512-level expression height are gone: a plan is measured, whole and
  iteratively, against the stack its evaluation starts on, and refused with
  `native-sparql-evaluation-stack-exhausted` only where that stack cannot hold the
  walks over it, so a plan prepared on one thread and run on another is judged by
  the stack it runs on. On `wasm32`, where the JavaScript engine's own call stack
  bounds the recursion too, a plan past the host-stack bounds (graph patterns nested
  past 284 levels, a tree taller than 2 048 levels plus eight per nested group, or
  expressions and paths nested past 2 304 levels) is refused with `native-sparql-host-stack-exhausted` before it runs,
  on both lanes.

- **sparql-eval, core:** a triple term nested past anything a dataset holds is
  valid SPARQL 1.2 and is answered, not refused. A pattern whose triple term nests
  deeper than any the dataset holds matches nothing: `SELECT` answers no rows, `ASK`
  false, `COUNT` zero, and the neighbour of the same shape at the stored depth
  matches. `DatasetView::triple_term_nesting_bound` is how deep a view's triple terms
  can nest (16 for every frozen dataset, delta and composite view, 128 for a PACK,
  none by default), and the evaluator answers such a pattern before converting or
  looking up any of it. A deep triple term written as a value (`VALUES`, `BIND`) is
  returned whole. Every walk the evaluator makes over a triple term — interning,
  matching, instantiation, comparison and conversion — runs over a work list, so a
  term's nesting costs no stack on any host and is bounded by memory alone. Writing a triple term into a dataset is
  held to the dataset's own limit: `INSERT DATA`, an `INSERT` template and a
  `CONSTRUCT` graph nesting one past 16 levels are refused with
  `rdf-ir-triple-nesting-limit` (a `CONSTRUCT`'s through the new
  `EvalError::Dataset`, whose `EvalError::code` is the dataset's), and 16 levels are
  written and matched. An `UPDATE`'s `WHERE` is held to the stack it runs on as a
  query's pattern is.

- **BREAKING** **core:** `RdfDatasetBuilder::freeze` refused a triple term nested past
  16 levels only when its chain was interned outermost first. Every ingress interns innermost
  first, and then any depth was frozen. The limit now holds whatever the order: a
  chain of 17 triple terms is refused with `rdf-ir-triple-nesting-limit`, as the
  dataset contract and the GTS transport's own 16-level bound always stated. A
  document, update or `CONSTRUCT` that wrote a deeper triple term, and used to freeze,
  is now refused.

- **sparql-algebra, sparql-eval:** a `SERVICE` body the parser admitted could be
  forwarded as text the parser refuses. The serializer bracketed every binary
  operator, so a chain of a few hundred operators was forwarded nested hundreds of
  levels deeper than the body it rendered, which a count of 128 levels refused. The
  in-process resolver's re-parse then failed as a decode error, and under
  `SERVICE SILENT` that became the join identity: a 440-operator filter body
  answered every row unfiltered. The serializer now brackets only where precedence
  and associativity require it, writes `UNION` chains flat and
  `OPTIONAL`/`MINUS`/`BIND`/`UNFOLD` chains unbraced, writes a `FILTER EXISTS` or
  `FILTER NOT EXISTS` constraint without brackets, and never double-braces a
  sub-`SELECT`. The evaluator no longer forces a brace per group around a one-row
  `VALUES` block it joins beside a group's filters. The forwarded text of every
  admitted body re-parses. Remote endpoints may therefore receive different, and
  shorter, query text for the same `SERVICE` clause.

- **sparql-algebra:** a `BIND` or `UNFOLD` after a braced group containing a
  `FILTER` was serialized unbraced, so on re-parse the `FILTER` moved above the
  `BIND` and the forwarded query meant something else.

- **sparql-eval:** `SERVICE SILENT ?e` swallowed the engine's own refusal of an
  endpoint variable no solution bound. The clause became the join identity: the
  query answered the left rows alone, asked no endpoint, and looked complete. That
  refusal is now an `EvalError::Unsupported` (`SERVICE ?e with no endpoint: …`)
  under `SILENT` too, because no invocation is made for `SILENT` to absorb. Its
  message names the shapes that evaluate and the rewrite.

- **sparql-eval:** a query refused for a variable endpoint some solution could not
  name still contacted a remote first. `?s ?p ?o OPTIONAL { ?s ex:ep ?e } SERVICE ?e
  { … }` evaluates the clause once per left solution, so when an early solution bound
  `?e` and a later one left it unbound (or, without `SILENT`, bound it to a literal),
  the request for the
  early one — with any credentials the host attaches — went out before the refusal,
  and whether it did depended on row order. Every left solution is now checked before
  the clause is evaluated for any of them, for each `SERVICE ?e` whose variable
  nothing else in the right operand mentions; the refusal is the one the per-solution
  evaluation would have reached, and a query it admits evaluates as before.

- **sparql-eval:** `SERVICE ?e` was refused wherever `?e` was bound by the left side
  of an `OPTIONAL`, a `MINUS` or a group join rather than by a pattern earlier in
  the same group, although `{ ?g ex:endpoint ?e } { SERVICE ?e { … } }` is the same
  join as the flat form that answered. Those shapes now evaluate: the right side is
  still evaluated on its own, and the clause is sent once to each distinct IRI the
  left side binds `?e` to, each answer's rows carrying that `?e`. SPARQL 1.1
  Federated Query §4 describes `SERVICE` with a variable as one invocation per
  binding, combined by union, with the endpoints to try allowed to come from
  evaluation order. The result is exact, because a row from any other endpoint
  matches no left row. A left row whose endpoint answers nothing keeps its bindings
  under `OPTIONAL` and is not removed under `MINUS`. Under `SILENT` a failing
  endpoint is the join identity for its own left rows alone: under a group join or
  `OPTIONAL` it contributes one row binding only `?e`, so no other endpoint's rows
  change; under `MINUS` the left rows are partitioned by endpoint, the right side is
  evaluated once per endpoint with that endpoint alone listed, and each partition is
  subtracted by its own result, so a failing endpoint removes none of its rows while
  every answering endpoint still removes its matches. Still one request per endpoint.
  A clause is still refused where `?e` is unbound in some left solution, or where a
  further `OPTIONAL` or `MINUS` right side, an `EXISTS`, a `LIMIT`/`OFFSET`, an
  aggregate not grouped by `?e`, or a sub-`SELECT` not projecting `?e` sits between
  the binding and the clause.

- **sparql-eval:** `{ SERVICE ?e { … } ?s ex:endpoint ?e }` and `{ SERVICE ?e { … }
  VALUES ?e { … } }` were refused, although a join is commutative and the mirrored
  `{ ?s ex:endpoint ?e } { SERVICE ?e { … } }` answered. A group join whose left
  operand holds a variable-endpoint `SERVICE` and whose right operand may bind its
  variable now evaluates the right operand first and answers the clause over the
  endpoints it binds, then joins left against right as written: the same rows and
  the same requests, one per distinct endpoint, as the left-bound form, with `SILENT`
  per endpoint as there. The exactness argument is the left-bound one with the sides
  exchanged. `OPTIONAL` and `MINUS` do not commute and keep their endpoints on the
  left, so `{ SERVICE ?e { … } OPTIONAL { ?s ex:endpoint ?e } }` stays refused, as
  does a right operand that leaves `?e` unbound in some solution; a clause an
  enclosing operator already lists endpoints for keeps that list.

- **shapes, datalog, core:** a SHACL shape rule (linked to a shape, executed once per
  focus node) re-executed EVERY focus node every iteration, so a rule minting one new
  focus node per iteration cost one execution per focus node so far each time: the
  corpus's `err-diverging-fresh-term` rule was stopped only by the join-step limit
  (about 7 s at the default), and with that limit raised to 2^28 it ran for minutes
  instead of reaching the term limits it is documented to meet. A shape rule is now
  re-executed only for the focus nodes that are new or that a triple the previous
  iteration added is about, as the rule's read set says (`srl::reads`: the triple
  patterns, property paths and node-expression paths it reads, each with the positions
  its constants and `$this` fix). A triple it reads a join step away from `$this`
  re-executes every focus node; a rule whose answer is not repeatable (a template or
  `BNODE()` blank node, `RAND()`, `NOW()`, `UUID()`, `STRUUID()`, `LIMIT`/`OFFSET`,
  `SAMPLE`, `GROUP_CONCAT`, `FOLD`, a function the analysis does not read) is executed
  for every focus node every iteration. For a rule with no condition whose shape's
  targets only grow (`sh:targetClass`, `sh:targetSubjectsOf`, `sh:targetObjectsOf`,
  `sh:targetNode`, an implicit class), the new focus nodes are found from the added
  triples without resolving the targets again. The graph the rules read is extended by
  each iteration's triples (a delta over the last compacted view, compacted by a
  rent-or-buy rule in term bytes) rather than rebuilt from the whole store. The
  inference is unchanged: the inferred triples, their blank-node labels and the proof
  are byte-identical to executing every focus node every iteration over a rebuilt
  graph, which unit tests compare on the rules corpus, on a 60-link discovery chain and
  on 256 randomised rule sets each run. A per-focus rule minting a counter IRI per
  iteration is now refused by the term-generating round limit (16,385 rounds) in about
  2.5 s, and `err-diverging-fresh-term`, whose IRI grows a character per iteration, by
  the fixed 16 MiB term-arena ceiling in about 2.5 s, both with the join-step limit at
  its default and at 2^28 (before: join-step refusal after about 7 s, and no refusal
  within 150 s at 2^28). `RelationStore::rows_from` reads the rows a store gained since
  a row count in time proportional to them; `DeltaDatasetView::added_term_ids` lists a
  snapshot's own terms without walking its base, and a SHACL view over a snapshot
  numbers its base terms arithmetically. The `rules_divergence` bench gains
  `refuse/per_focus_counter` and `complete/per_focus_chain`, and `srl_closure` gains a
  per-focus closure. The native join-step default stays 2^20 (see above): with the
  divergent rules no longer needing it, the reason left is memory.

- **shapes, cli, python, wasm, capi (BREAKING for Rust):** an `unreached-import` refusal for a table entry that
  an `owl:imports` triple DOES name — on a subject that is no anchor, so the triple is
  data — now says so: it names the triple's object, says the subject is not anchored, and
  points at the shapes lint's `unanchored-imports` section (`purrdf shapes lint` on the
  command line). The command line used to say "the shapes graph has no owl:imports at all"
  of such a graph; it now says the shapes graph imports nothing (no `owl:imports` of it is
  anchored). `ShapesImportError::Unreached` gained `unanchored`, the entries such a triple
  names; every host renders the same sentence (`UnanchoredNote`).

- **validate, cli, python, wasm, capi:** a SARIF log whose run found nothing now carries
  `"results": []`; it used to omit `results`. SARIF 2.1.0 §3.14.23: "In all other
  circumstances, results SHALL be present and SHALL contain all results detected by the
  tool. If the tool did not detect any results, results SHALL be an empty array. If
  results is absent, it SHALL default to null" — and `null` is reserved for a tool that
  failed to start or to begin its analysis. A conforming validation and a clean parse
  therefore serialize one more member, on every host.

- **core, shapes, entail:** `<G> a sh:ShapesGraph ; owl:imports <lib>` was silently not
  an import: validation ran without `<lib>`'s shapes, and entailment without its axioms,
  with no refusal. It is now an import on every host (see Changed). The implicit
  SHACL-SPARQL prefix collection and the import rule now read one classifier, so a node
  whose `sh:declare` supplies a query's prefixes is classified exactly as the import rule
  classifies it.

- **shapes:** the `README.md` example of a shapes graph with an import used an
  `owl:imports` on a node that is no anchor, so the table entry it supplied would have
  been refused as unreached. It declares the node a `sh:ShapesGraph` now.

- **shapes:** the JSON Schema compiler projects `sh:someValue`, `sh:node`,
  `sh:and`, `sh:or`, `sh:xone` and `sh:not` on a property shape, instead of
  dropping them. Each shape becomes one value's schema, combined with
  `contains`, `allOf`, `anyOf`, `oneOf` or `not`. `sh:xone` and `sh:not` are
  emitted only over shapes whose value schema is exact, and are recorded
  otherwise. A shape's property shapes, which judge the value's own node, are
  recorded. A multi-valued property's single-value alternative now rejects an
  array, so an array of values can no longer bypass a per-value constraint
  (`sh:pattern`, a length, `sh:not`) or `sh:maxCount`. The Pydantic emitter
  enforces `allOf`, `oneOf` and `contains` with its runtime check (the new
  `_purrdf_requires` helper) where that check evaluates them. The LinkML
  emitter states `contains` as a `has_member` carrying the whole value
  expression, and the LinkML importer reads a `has_member` back as `contains`.
  Each emitter oracle runs a value-shape fixture.
- **validate, shapes, python, wasm, capi, cli:** a SPARQL 1.2 RL rule set's
  `IMPORTS` now resolve from the rules tool's import table on every host. The
  Python `apply_rules(srl=..., imports=...)`, WebAssembly `shaclApplyRules` and
  C `purrdf_shacl_apply_rules` entry points used to refuse any import. One
  route, `RuleSetDocument::resolve_import_table`, is shared by the command line
  and the `purrdf-validate` boundary. An import that no entry supplies, and an
  entry that nothing imports, are refused with the same message on every host
  (the new `SrlError::UnreachedImports` covers the second case).
  `RulesRequest::shapes_imports` is renamed `RulesRequest::imports`, because
  the table now serves either rule source.
- **shapes, validate:** a validation report no longer fuses a shapes-graph
  blank node with a data-graph blank node that has the same label in its own
  document. The report graph (every RDF syntax) and the SARIF projection write
  data-graph blank nodes as `_:dg{n}` and shapes-graph blank nodes as
  `_:sg{n}`, so distinct nodes keep distinct labels and one node keeps one
  label. The labels no longer depend on the parser that read the documents.
  `ValidationReport::with_report_blank_labels` returns the relabelled report
  and a `ReportBlankLabels` map back to each node's graph and original label.
  Report bytes that carried blank nodes change.
- **cli:** a shapes document in TriG or RDF/XML now keeps the prefixes and base
  its codec reports, just as a Turtle document does. Its SHACL-SPARQL queries
  can use the document's prefixes, and an `owl:imports` of its own `@base` or
  `xml:base` resolves. `shacl pack` gains `--shapes-from`, so it can read the
  shapes document in any RDF syntax.
- **shapes:** a SELECT-based validator of a SPARQL-based constraint component
  on a node shape reports the focus node as `sh:value` when its solution does
  not bind `?value`, as for a SPARQL-based constraint ("The value node"); the
  result had no value. The W3C SHACL suite's `sht:proposed`
  `sparql/component/nodeValidator-001`, which no manifest includes, is graded
  under its own category and passes.
- **xsd:** the `xsd:dateTime`, `xsd:date` and `xsd:time` parsers reject a
  signed field (`+2020-01-01`, `+1:00:00`, a `+-1:00` timezone) and a seconds
  field that is not two digits (`00:00:5`). `from_str` had read the sign.
- **rdf, shapes, shex:** a JSON number read through `serde_json` could become the
  neighbour of the binary64 its decimal spells. Without its `float_roundtrip` feature
  `serde_json` scales a `u64` significand by a binary64 power of ten, rounding at each
  step and dropping every digit past the nineteenth, so JSON-LD wrote
  `122.416294033786585` as `"1.224162940337866E2"^^xsd:double` instead of
  `"1.2241629403378658E2"`, and the same misreading reached CSVW literals and datatype
  bounds, OKF rdf:JSON literals (whose writer then refused as non-canonical a literal
  its reader had produced), research-object record rows, JSON Schema bounds imported
  as SHACL, compiled-schema catalogs and ShExJ numeric facets. Every JSON number is
  now read by `purrdf_lex::json`, which keeps its lexeme, and its conversion to
  binary64 (`Number::as_f64`) is correctly rounded. On the x87 a fast path can still
  round twice (`8.64759627780072e32` read as its successor), so the RDF codecs'
  conversion (`json_number::binary64`) runs under the binary64 precision scope;
  elsewhere the scope is empty. A non-integral JSON Schema number imported under a decimal carrier
  was written in `serde_json`'s exponent form (`2.2e-230`), outside the
  `xsd:decimal` lexical space; it is now written positionally.

- **sparql-eval:** `SUM`/`AVG` over a group of more than 1024 values added chunk
  partial sums together, so an `xsd:float`/`xsd:double` total could be a value no
  SPARQL 1.1 §18.5.1.3 chain of single additions gives: over {−3, −2^53, −1, −0.7}
  every chain answers −9007199254740996 and the chunked fold answered
  −9007199254740998. A decimal total could likewise miss an overflow the chain hits.
  The parallel fold now merges chunk partials only where the merge equals the chain:
  integer partials, and decimal or duration partials whose magnitudes cannot overflow.
  From the first float or double value on, the values are added one at a time in
  row order. Parallel and sequential `SUM`/`AVG` now give the same bits, and integer
  and decimal groups still fold in parallel.

- **xsd:** `BigInt::to_f64` folded its base-10^9 limbs through a `mul_add` loop that
  rounded at every limb, so an integer sum beyond `i128` promoted into an
  `xsd:double` sum could be one ulp off. `xsd:float` went through `f64` first and
  rounded twice. Both conversions are now correctly rounded, ties to even, with
  `±INF` past the largest finite value (`BigInt::to_f32` is new). Adding decimals of
  different scales scaled the lower-scale mantissa without an overflow check, so
  `1e30 + 0.000000000000000001` panicked in debug builds and wrapped to a wrong
  sum in release. That case is now the same out-of-range error as any other decimal
  overflow.

- **xsd:** `Decimal::to_f64` computed `mantissa as f64 / 10^scale`, which rounded in
  the cast once the mantissa passed 2^53 and again in the division, so a decimal
  promoted to `xsd:double` could be one ulp off: `72922151633738826.80` became
  `7.292215163373882e16` instead of `7.292215163373883e16`, and `=` against the
  correctly rounded double was false. `xsd:float` promotion went through `f64` first
  and rounded twice. Both conversions now round the exact decimal once, ties to even
  (`Decimal::to_f32` is new), and they serve every promotion, comparison and cast.
  The SPARQL cast of a decimal to `xsd:integer` or a derived integer type went
  through `f64` too, so `xsd:integer("12345678901234567.5"^^xsd:decimal)` gave
  `12345678901234568`. It now truncates exactly, and an integer or decimal cast to
  `xsd:float` rounds once.

- **core:** on a build whose binary64 unit is the x87 (`i586`, or `i686` without
  SSE2), PURREMB's deterministic L2 norm and the division of a projection by it
  rounded each result twice -- to the register's 64-bit significand and again to
  binary64 -- so the normalized projection bytes and their digest could differ from
  every other target's. The norm fold and the division now compute under the same
  precision guard as the distance kernels, each operation correctly rounded, so the
  bytes are the same on every target.

- **slice:** the DSL statistics emitter, pinned byte-for-byte to Python's
  `json.dumps`, escaped only `"` and `\` in set file names, so a control character
  produced invalid JSON and a non-ASCII name diverged from the Python output. It now
  uses the `Ascii` spelling of the shared escape law and matches `json.dumps`
  exactly; the committed `generated/mappings/dsl-stats.json` is unchanged.

- **sparql-results:** the SPARQL-JSON reader accepted raw control characters
  U+0000 to U+001F inside strings, including in skipped members. RFC 8259 §7
  forbids them. The reader now refuses them with a named error. Escaped controls
  and raw DEL still parse.

- **hnsw:** `HnswIndex::search_batch` reused one row-keyed distance memo across
  queries, so later queries saw the distances of earlier ones. Each query now
  gets its own memo.

- **retrieval:** the renderer kept its own copies of the IRI and canonical
  literal escape laws, because the kernel's version was private. It now
  delegates to `purrdf_core::iri_escape` and
  `purrdf_core::ir::canon::write_literal_escaped`, and so does entail. The canonical
  N-Quads writer, the Turtle writer and the native serializer also delegate IRI
  escaping to `iri_escape`. The native serializer's literal law, which also
  escapes C1, and the Turtle literal law remain separate laws. Every writer's
  bytes are unchanged.

- **sparql-algebra:** a `GROUP BY (expr AS ?v)` condition whose `?v` is already in
  scope — bound in the `WHERE` clause, or by an earlier condition — is refused as a
  syntax error, as the same rebinding by `BIND` or a `SELECT` expression already was.
  It was parsed and lowered to an `Extend` over a variable its operand bound, which
  the algebra leaves undefined and which the evaluator answered by overwriting the
  column. A fresh target, a plain key over the variable, and a target a sub-select
  hides still parse.

- **sparql-eval:** a property-function call inside an `OPTIONAL`'s right arm was
  admitted at prepare as though the variables bound to its left were bound for it,
  but that arm is evaluated on its own and matched afterwards, so the relation was
  invoked with those positions free and refused on every run. It is now refused
  once, at prepare. A call written into the group itself is still driven by the
  rows before it.

- **sparql-eval:** a literal, blank-node or quoted-triple value reaching a
  property-function call through correlated substitution — an `EXISTS` or
  `NOT EXISTS` body, a `LATERAL`'s right side below other operators, an `OPTIONAL`
  inside a `LATERAL`, a sub-`SELECT` receiving a projected variable — was never
  written into the call's arguments, so the relation was invoked with that
  position free and a relation serving only the bound mode refused the call on
  every row, though the plan admitted it; one serving both answered from its whole
  extent. It now arrives as the term it is: an IRI or a literal written into the
  argument, a blank node or a quoted triple driven into the call by a one-row
  `VALUES`, including a variable nested inside a quoted-triple argument.

- **sparql-eval:** a property function fed from a `LATERAL`'s right side is now
  admitted when its input is certainly bound there: a `BIND`, `VALUES`, triple or
  `FILTER` inside `LATERAL { … }` is judged with the left side's bindings in hand,
  so `?s ?p ?v LATERAL { BIND(?v AS ?q) } ?q <rel> ?out` invokes a bound-only
  relation with each `?v` instead of being refused at prepare; a sub-`SELECT` sees
  the enclosing bindings it projects.

- **sparql-eval:** a property function's input could be fed only by a triple pattern. A
  `VALUES` table or a `BIND` written in the same group — `{ VALUES ?q { "alpha beta" } ?doc
  ex:search (?q …) }`, `{ BIND("alpha beta" AS ?q) ?doc ex:search (?q …) }` — and a nested
  group, a sub-`SELECT` projecting the variable, or a `UNION` binding it in both branches
  were all refused at prepare with "no feasible evaluation order", so a relation serving
  only a bound input could not take a computed or tabled needle. A group's joined operands
  are now planned as one chain, and a `VALUES` column with no `UNDEF` and a `BIND` whose
  expression reads only bound variables count as binding their variable; a row whose
  `BIND` expression errors is refused by the evaluator's per-row access-pattern check
  rather than invoked free, and an `UNDEF` cell, an `OPTIONAL` arm or a `BIND` over one
  still does not count. A `LATERAL` written after a call is also no longer re-planned as
  an independent join, which had evaluated its right side without the call's rows.

- **sparql-eval:** a prepared execution's parameters now count as bound when its
  property-function calls are admitted, wherever a run's rewrite really binds them,
  and a run writes each parameter's value into the calls it reaches — including a
  call written after another atom — so a relation is invoked in the bound mode it
  declared for that argument rather than scanned and filtered by a join.

- **sparql-eval:** a prepared-execution parameter bound to a blank node — through
  `bind_id` or by value — never reached a property-function call's arguments, so a
  relation serving only the bound mode refused the run, and a fused retrieval whose
  exclusion lookup was asked about a blank-node candidate failed the whole request. A
  blank node is still never written into a pattern, where it would be an anonymous
  variable; the call is instead driven by a one-row `VALUES` carrying the bound blank
  node as the term it is, so the relation is invoked with that argument bound.

- **sparql-eval, shapes:** a SHACL constraint body could not call a relation that
  serves only a bound `$this` from an `OPTIONAL` arm, a sub-`SELECT` beside another
  atom, or an `EXISTS` below the top of its pattern. The SHACL pre-binding rewrite
  binds `$this` in every call, but the execution was admitted as though it bound
  `$this` only where the ordinary rewrite does, so the constraint was refused before
  it ran, whatever kind of term the focus node was. A blank-node focus node also never
  reached those calls at run time. A prepared execution is now admitted under the
  rewrite its runs apply (`QueryOptions::prebinding` at prepare), and SHACL prepares
  its handles that way. A handle admitted for the SHACL rewrite refuses to run under
  the ordinary one. The SHACL rewrite now passes a blank-node or quoted-triple value
  to every call through a one-row `VALUES`, so the relation receives it bound.

- **retrieval:** a fused top-`k` narrowed its read depth for a whole request or not
  at all, so one stratum declaring allowed duplicates, or one intersecting pair
  anywhere in the request, made every stratum read at the maximum depth — including
  a stratum whose declared blocks met no other's. The depth is now licensed per
  stratum: a unique stratum whose blocks meet no other surviving stratum's keeps its
  prefix of `k`, whatever the others declare.

- **retrieval:** a candidate literal carrying a language tag that is not a
  `LANGTAG`, or a base direction with no tag, was named without its tag or
  direction — the spelling of a different term, the plain literal of the same
  lexical form. Such a literal is not well-formed RDF; it is now refused, naming the
  row, as a failure of the stratum read that produced it. Tagged, directional and
  nested-blank-node candidates are named and read back as before.

- **text:** a search invocation with its document bound declared a row bound of one
  and then ranked every partition that document appears in. It now answers whether
  the document holds a posting under any needle term by binary searches over the
  term dictionary and that term's postings, and ranks only a document that does.

- **hnsw:** `HnswSpace::from_index` ignored its guard's candidate bound, which it is
  documented to refuse at construction. A space with more rows than
  `max_candidates` is now refused with `EvalError::Config`; a bound equal to the row
  count is still admitted.

- **cli:** a failed write could unlink a symlinked output path, destroying the link
  and leaving the half-written bytes in its target — the exact loss the guard's own
  comment described preventing. The guard asked the descriptor, which `File::create`
  had already resolved through the link; it now asks the path.

- **python:** `serialize(output=…)` called `write` once and discarded the returned
  count, silently truncating the document whenever a file-like object accepted less
  than it was given.

- **build:** three hygiene gates, each wired into both `make check` and CI because the
  first of them exists to make that pairing checkable.
  `scripts/check-gate-parity.py` takes the AGREEMENT between `make check` and the
  pull-request workflows as its subject: CI does not run `make check`, it enumerates each
  gate as a named step, so the two lists encode one rule and nothing compared them. It
  found three pre-existing divergences on its first run -- `check-terminal-predicates.py`
  and its `--self-test` ran locally and in no workflow at all, and
  `check-toolchain-pin.py --self-test` ran in CI and not locally -- and a fourth that was
  live behind a workflow `make` step. Seven one-sided gates are registered with their
  reasons -- two determinism checks needing the wasm toolchain, the book render needing
  mdbook, the conformance matrix needing tens of minutes, two `uv`-driven emitter
  oracles, and the SIMD asm evidence run needing the wasm32 and aarch64 standard
  libraries -- under a register that may only shrink and whose size is pinned, so growth is
  a visible edit rather than the silent one that left this count stale.
  `scripts/check-stream-chunk.py` refuses a streamed read whose chunk size is written out
  instead of named; six copies of that number lived under two names across five files,
  two already drifted to a quarter and a sixty-fourth of the shared size, and because every
  chunk size produces a correct digest nothing reported it.
  `scripts/check-tracked-paths.py` refuses a tracked path that misrepresents itself to the
  tools that read it -- a component beginning with `-`, which a glob hands to a command as
  a FLAG, or a character that does not render as what it is. A flag-shaped artifact had
  been committed at the repository root and swept past roughly thirty hygiene scripts,
  because they all walk a file list rather than a glob.

- **license:** MulanPSL-2.0 is offered as a third option alongside MIT and
  Apache-2.0, at the user's choice. `LICENSE-MULAN` and
  `LICENSES/MulanPSL-2.0.txt` carry the text, pinned by SHA-256 in
  `scripts/check-licenses.py` because the license's own section 6 makes its
  Chinese text controlling -- a silently drifted copy would change the governing
  terms. `scripts/check-licenses.py` also now refuses a first-party file whose
  SPDX identifier is not the expression `Cargo.toml` declares, reading that field
  rather than restating it, so the next license change cannot leave a file behind
  at the old offer. `docs/book/book.toml` is registered as deliberately CC-BY-4.0
  with its reason, under a register that only shrinks.
- **build:** `scripts/check-python-binding-tests.py`, wired into `make check`,
  `make pytest`, `make python-binding-hygiene` and CI. It fails if a `test`
  predicate appears in any `cfg` invocation, or a `#[test]` attribute anywhere,
  under `bindings/python/src`. That crate's manifest sets `test = false` because
  the library is a PyO3 `extension-module`: it leaves the CPython API unresolved
  for the interpreter to supply at `dlopen` time, which is what makes the `abi3`
  manylinux wheel portable, so an ordinary test executable has no interpreter and
  fails at link. A Rust test module there is consequently compiled by nothing and
  run by nothing while looking exactly like coverage in a diff. Neither of the
  textbook remedies is available -- a Cargo feature gating `extension-module` is
  forbidden here, and dropping the attribute would link libpython into the
  `cdylib` -- so the gate names the one route that works: the coverage belongs in
  `bindings/python/tests`. `--self-test` proves it fires on both shapes and, just
  as importantly, that it does not fire on prose describing them, so this crate's
  own source can keep explaining the rule.

- **retrieval:** A new publishable crate, `purrdf-retrieval`: the composition
  layer over the ranked property-function producers. One request becomes one
  answer across them through four stages -- a pure planner returning an
  inspectable `Plan` with a canonical BLAKE3 identity, a semantic admission waist
  that emits independently executable SPARQL per stratum, an executor that
  isolates each stratum's failure in its own status, and an exact fixed-point
  reciprocal-rank fusion over a verified ranked-stream protocol. Producers,
  strata and weights are caller-supplied configuration with no fabricated
  default. Reachable three ways: the crate directly, `purrdf::retrieval` on the
  umbrella, and `purrdf_native.retrieval` from Python.
- **retrieval:** A resolution algebra on the fusion law.
  `FusionProfile::class_width` reports how many consecutive ranks a profile
  cannot tell apart at a given depth, `deepest_rank_within_width` inverts it, and
  `DecayRule::weight_for_depth` inverts the whole relation -- name the depth, get
  the smallest weight that buys it. Reaching a depth is not monotone in the
  weight, so the answer is not bisected: each adjacent-rank constraint names the
  next weight that could satisfy it, and the search walks those candidates
  without ever skipping one, so the weight it returns is the true minimum rather
  than whichever side of an oscillation a probe happened to land on.
  `MonotoneDepth` spells the separating depth's saturation point as a
  distinct case so it cannot be mistaken for a measured depth, `ToleratedDepth`
  does the same for the depth a tolerance buys, and `ClassWidth` does the same
  for a class that never ends inside the range a plan can express. The same
  surface is exposed to Python as `retrieval.weight_for_depth`,
  `retrieval.class_width` and `retrieval.deepest_rank_within_width`.

  Its five refusals are five separate facts and carry five separate variants.
  `FusionError::InvalidWidth` means the tolerance was zero, which describes no
  class at all because a class always contains its own rank.
  `FusionError::DepthUnreachable` means the decay rule itself stopped separating
  adjacent ranks at any weight, and it reports the exact depth it does reach --
  the deepest any weight reaches, not the depth of one particular weight, and
  only the truncated rule can raise it. `FusionError::DepthBeyondPlanRange`
  means the depth is deeper than a plan can record, a plan carrying a
  per-stratum depth as a 32-bit rank; that is a limit of the encoding and not of
  the arithmetic, so the message names the encoding and the folded rule still
  answers at the deepest depth a plan can hold. A depth of zero names no rank
  and is refused as `FusionError::InvalidRank` rather than answered with the
  lightest weight there is. And a smoothing constant of zero describes no law at
  all: all three functions refuse it as `FusionError::InvalidK` before they read
  the question they were asked, so the refusal no longer depends on the other
  argument -- a depth of one, or a tolerance of one, previously answered from a
  short-circuit and quoted a real number under a rule that cannot be evaluated,
  while one step further along either axis reported the decay rule as having
  saturated at depth one. A malformed law is not a saturated rule, and telling
  it as one sent a caller to a remedy -- switch decay rules -- that cannot help.
- **retrieval:** `DecayRule::class_width`, the same resolution curve
  `FusionProfile::class_width` reports but asked of a weight rather than of a
  stratum. A width is a property of the rule, its smoothing constant, the weight
  and the rank and of nothing else, so a caller holding only arithmetic -- a
  language binding, or a profile author sizing a weight before any stratum
  exists -- asks the rule directly instead of building a throwaway one-stratum
  profile to ask through. `DecayRule::weight_for_depth` already sat at that
  altitude; the width now sits beside it. The profile-level call remains, is
  unchanged for callers with a real stratum in hand, and now reaches the same
  arithmetic through it rather than through a second path that could drift.
- **retrieval:** `DecayRule::deepest_rank_within_width`, the inverse of
  `DecayRule::class_width` asked at the same altitude: name the tolerance, get
  the deepest depth that stays inside it. `FusionProfile::deepest_rank_within_width`
  now reaches this rather than a private function of its own, so the two
  arithmetic-only entry points -- `class_width` and its inverse -- sit beside
  `weight_for_depth` the same way on `DecayRule`, and a caller holding only a
  weight and a tolerance, with no stratum to name, asks here. Bound to Python
  as `retrieval.deepest_rank_within_width`, alongside `retrieval.class_width`
  and `retrieval.weight_for_depth`: it takes the same required `decay` keyword
  they do, with no default rule, and raises `ValueError` rather than answering
  where the arithmetic could not.
- **retrieval:** Rank-resolution evidence on the answer. `CompiledRetrieval`
  carries a `PlannedResolution` per weighted stratum, so the cost of a planned
  depth is knowable before executing anything, and `FusionTrailer` carries a
  `StratumResolution` for every weighted stratum it was handed a stream for --
  where the profile stops separating ranks, how deep this run reached (zero for
  a stream that ended without emitting a row, which was still pulled from), and
  how many adjacent ranks its score could not separate, counted by direct
  observation rather than inferred.
  The trailer also reports whether the last row in a top-k beat a *settled*
  rival it tied with exactly, which is the case where the final place was
  decided by the declared tie-break rather than by relevance. Only rivals
  already final when that row was emitted are counted, so a `false` there means
  "no settled rival tied with it" and not "the cut fell on a strict score
  difference" -- settling every live rival would mean reading past the top-k,
  which would move the ranks-pulled evidence in the same trailer.

  Both altitudes are readable from every entry point, and kept apart by name.
  `SearchResult::planned_resolution` carries the compiled plan's own map onto the
  fused answer, so the one call that plans and executes together is not the one
  call that cannot see what it was about to pay; `FusionTrailer::resolution`
  beside it is what the rows really cost. From Python the same pair is
  `"planned_resolution"` and `"observed_resolution"` on the `search` answer, and
  `retrieval.compile` now takes the `weights` and `k` that name a fusion law and
  answers `"planned_resolution"` for it -- per weighted stratum, the depth the
  law still separates, the depth the plan recorded, and whether every rank the
  plan reads is still ordered by score alone -- with nothing executed. Omitting
  both leaves the map empty rather than measuring against an invented law, and
  naming one without the other is a `ValueError`.
- **bench:** A new unpublished tooling crate, `purrdf-bench`, and its
  `bench-corpus` binary: the deterministic, shardable scale-corpus generator
  behind the `purrdf-scale-mixed-v1` profile. Every IRI is minted purely from
  its index under a fixed seed, across five deliberately adversarial classes
  (front-codable plain, long zero-padded numerics beyond machine integer widths,
  raw-Han Chinese, host-scattered irregular with reserved-octet escapes, and
  very-long), so no single dictionary trick can flatter a capacity claim. The
  row mix pins a share for every row kind and spans the RDF 1.2 term space the
  profile targets — reifier rows binding triple terms, `xsd:`-typed literals
  whose lexical forms are valid for their datatype, language-tagged literals,
  and blank nodes in both subject and object position — so term-kind coverage is
  a property of the profile rather than an accident of it. Index-pure minting
  makes generation shardable with no coordination between shards: shard `k` of
  `n` emits exactly its slice, and concatenating every shard is byte-identical
  to one whole run, pinned by a golden digest. `make scale-corpus` is the lane
  that drives it across shards, in streaming, piped, or opt-in file modes.
- **bench:** Two comparison lanes against the workloads the RDF literature
  publishes against, `make lubm` and `make watdiv`. Both are REPORT-ONLY, neither
  is a gate, and neither vendors a byte: every artifact is fetched by digest into
  an ignored cache under `target/` at the moment of use, because the LUBM
  generator is GPL-2.0-or-later and WatDiv is citation-ware. `make lubm`
  generates LUBM(N), converts it to N-Quads through the `purrdf` CLI itself and
  answers the 14 published queries, printing the entailment regime and the
  dataset rung every row was answered under — eleven of the fourteen have no
  answers at all without inference, so a row without its regime is not
  comparable with anything. `make watdiv` consumes upstream's digest-pinned
  frozen 10M dataset (WatDiv's own generator is time-seeded and has no seed
  flag, so a dataset is reproducible only as a frozen output) and instantiates
  the 20 published templates deterministically from it, publishing a query-set
  digest: the same dataset and the same seed reproduce the workload byte for
  byte, and a different seed is a different workload rather than a re-run. All
  three lanes share one implementation of the laws that make their numbers
  evidence — `scripts/lane-common.sh` — including the rule that a certificate
  (a manifest, a reuse stamp, a published digest) is never written for output
  that was not produced and never outlives the run that wrote it.
- **envelope-probe:** A new unpublished tooling crate,
  `purrdf-envelope-probe`: the capture side of the micro-hardware validation
  envelope. A fixed, deterministic workload set runs per named profile over the
  public APIs and the keystone fixture corpus, so a release can demonstrate that
  a constrained deployment class still fits its pinned ceilings. Pass criteria
  are completion and memory; wall time is recorded evidence, never a gate.
- **hnsw:** A new publishable crate, `purrdf-hnsw`: a deterministic HNSW
  approximate nearest-neighbour index over a PURREMB embedding matrix, registered
  on the evaluator's property-function seam under a caller-supplied predicate IRI.
  Levels come from a splitmix64 hash of the stable row index rather than from an
  RNG, the build is round-structured against a frozen snapshot, and the canonical
  byte image is identical across rayon worker counts and across
  `wasm32-unknown-unknown`. It joins the release set as the 24th crate.
- **purrdf:** The umbrella re-exports the new crate as `purrdf::hnsw`, on the same
  seam `purrdf::geo` and `purrdf::text` use, so a consumer can name `HnswIndex`,
  `HnswSpace`, `Params` and the relation while depending on `purrdf` alone.
- **sparql-eval:** `knn::Kernel::distance_bounded` with `knn::Bound` and
  `knn::Bounded`. Squared-euclidean partial sums are non-decreasing, so a caller
  that only needs to know whether a distance clears a threshold can stop early.
  It shares one fold with `Kernel::distance`, so the two cannot drift, and a
  candidate that is not abandoned is scored bit-for-bit as before.
- **sparql-eval:** `knn::Scalar`, a stored scalar that widens to binary64 exactly.
  PURREMB stores matrices at either width, and widening `f32` at load costs twice
  the resident memory while changing no arithmetic; the kernels now accept either
  width and widen per component inside the fold.
- **retrieval:** `ProducerStatus::DepthReached` and `ProducerReceipt::DepthReached`,
  a read ending authored by the producer and stated in **rank** space: ranks one
  through `rank` were read, and the rows did not run out -- the planned depth did.
  It is deliberately not `CeilingReached`, which is fusion's ending and whose
  stopping point is a contribution in the profile's fixed-point space that the
  producer was never given. The two name different knobs -- re-plan deeper, or
  certify further rows against the same streams -- and neither number converts
  into the other. Fusion checks `rank` against the rows it actually pulled and
  refuses a disagreement as `ProtocolError::ForgedReceipt`, exactly as it checks
  an exhaustion count: the depth is a licence to stop reading, never a licence to
  misreport. `Exhausted` is now the only ending that names no stopper, and every
  other ending names one. That is a fact about the read rather than about what
  exists: a producer emitted every row its search produced, which is why a
  status is read beside the stratum's declared fidelity and never instead of it.
- **retrieval:** `FusionTrailer::attestations`, a per-stratum record of what the
  index behind each stream attested -- which generation answered, and the
  verbatim reason if that index declared itself short. It is read from
  `RankedStream::attestation` in `FusionStream::new`, **before any row is
  pulled**, because a generation is pinned when a cursor opens. That ordering is
  load-bearing rather than tidy: a terminal receipt is overwritten by a bounded
  stop -- a stream a top-k stopped never returns a receipt at all -- so an
  incompleteness held terminally would be destroyed exactly in the runs where the
  bound mattered. Held as an attestation, a stratum that was both stopped and
  short reports both facts. The map keys only the streams the fusion was handed; a
  stratum whose unit never ran is absent rather than filled with "declared
  nothing", which would report a producer that was never asked as one that
  declined to answer.
- **retrieval:** `ScoreExactness` on the trailer. A stratum serving from a short
  index omits whatever its missing shard held, so a candidate that shard would
  have named is summed one contribution light; labelling that "exact" would be a
  bound on the read presented as a value. `Exact` says the narrower true thing --
  no handed stream declared itself degraded -- and is never a certificate that
  every index was whole and every search exhaustive, because most producers
  attest nothing and there is no variant with which to attest wholeness.
  `Estimated` carries the error in BOTH directions, because this layer scores by
  rank and nothing else: a stratum that fails to name a row does not merely
  withhold that row's contribution, it moves every row behind the missing one up
  a rank and hands it a larger contribution than it earned. `deficit` names the
  strata that could have added to a candidate, `inflation` the strata that could
  have over-contributed to one, and `unbounded` the strata whose declared ORDER
  is perturbed, for which no finite bound exists at all -- every bound here rests
  on a named row's true rank being no better than its emitted rank, and a
  producer comparing approximated values breaks exactly that. Each stratum's
  verbatim reason is under the same key in `fidelities` or `attestations`. It is
  derived from the declarations and attestations alone, so it does not move as a
  caller certifies further rows.
- **retrieval:** `RankFidelity`, with `Completeness` and `OrderFidelity`, and
  `StreamContract::fidelity` carrying it through the ladder. What a producer
  declares about its own search, on two axes that fail independently: whether it
  names every row that was due, and whether a row it does name arrives at a rank
  no better than it earned. It is declared rather than observed because a
  consumer cannot tell the difference -- a stream that ran out of rows and a
  stream whose search merely stopped finding them both simply stop yielding, and
  the ranks are contiguous either way. There is no `Default`: `RankFidelity::EXACT`
  is the top of the lattice, so defaulting to it would put the strongest claim in
  the mouth of a producer that said nothing, which is the one direction a default
  must never go. `RankedDeclaration` therefore carries `fidelity` as a required
  field, and `StreamContract::new` takes it as its second argument.
- **retrieval:** `FusionTrailer::fidelities`, a per-stratum record of what each
  producer declared, populated in `FusionStream::new` before a row is pulled, so
  a fused answer distinguishes an approximate stratum from an exact one without
  consulting the registry. The producer's own evidence string reaches it
  verbatim: the same `Arc<str>` the producer published, never parsed and never
  re-worded. A stratum whose stream never opened is absent rather than reported
  exact, so the map is three-valued where it needs to be and a consumer never
  reads a missing key as a claim.
- **retrieval:** `FusedRow::interval` and `ScoreInterval`, bounding each row's own
  error rather than the answer's. `Bounded` carries `deficit` and `inflation` in
  the profile's fixed-point space, narrowed per candidate by the same `Dom(x)`
  reasoning the certification bound uses: a stream whose declared domains cannot
  reach a candidate withheld nothing from it and is not charged. `Unbounded`
  names the perturbed strata instead of reporting a number, because there is no
  number and reporting one would be the fabrication this channel exists to
  prevent.
- **retrieval:** `FusionTrailer::certain_prefix`, how many leading rows keep
  their places whatever the degraded strata did or did not find. It is what a
  caller with a completeness obligation can still act on, since the alternative
  is to downgrade a whole answer over one degraded stratum. It claims membership
  and never absence: a row past the prefix is possible rather than excluded.
- **retrieval:** `FusionTrailer::unemitted_ceiling`, the bound the prefix above
  rests on: the most any candidate OUTSIDE the answer could be worth. It counts
  two populations, and both are needed for the prefix to be a claim about the
  answer rather than about the ranking -- the candidates no stream ever named,
  charged each degraded stratum's rank-one contribution because a row such a
  stratum missed could have been due at any rank, and the candidates a bounded
  read named and abandoned, which a degraded stratum could still owe a
  contribution on top of what they had already accumulated. It is `None` where a
  stratum declared a perturbed order: that breaks the one inequality every bound
  here rests on, so no finite ceiling exists and `certain_prefix` is zero. It
  speaks for the reads this trailer describes; a producer stopped at its plan
  depth, or one that declined its terms, states that shortfall in `statuses`.
- **hnsw:** `HnswRelation` declares its own `RankFidelity`, so the workspace's
  one approximate producer states what it is to a consumer of composed rows
  instead of being indistinguishable from an exhaustive one. The evidence is the
  profile's `IndexLossContract` loss evidence, carried verbatim rather than
  re-worded here.
- **text:** `TextSearchRelation::ranked_declaration` takes the fidelity the host
  declares. BM25 over the index this relation holds is exhaustive and ranks by
  exact scores; whether that index covers what the host means by its corpus is a
  fact the relation cannot see, so the term is the host's to supply for the same
  reason `domains` is.
- **sparql-eval:** `EmbeddingKnnRelation::ranked_declaration` takes that same
  fidelity term, in the same position, for the same reason. The relation is the
  exact oracle -- it scans every row of its space, prunes nothing and exits early
  nowhere -- so `RankFidelity::EXACT` is a true statement about its *search* and
  it used to assert exactly that. It is not a statement about whether the vectors
  it searched are the whole of a host's corpus, and a host that embedded a sample
  had nowhere to say so: the answer certified that every stratum was exhaustive
  and whole while a document the whole space would have ranked was silently
  absent. Breaking, in the same way and at the same seam as the text relation
  above.
- **hnsw:** `HnswRelation::ranked_declaration` and `HnswRelation::fidelity` take
  an `OrderFidelity` describing what the
  host did to its vectors **before** `HnswIndex::build` saw them. A host that
  quantizes its embeddings and then builds a graph over the codes has an
  order-perturbed producer, and no loss contract reachable from the index records
  it -- the profile's contract describes what the build did, not what reached it.
  The new term composes with the derived axis through `composed_order_fidelity`,
  which takes the worse of the two, so a host can degrade the axis and never
  upgrade it. The completeness axis stays the relation's: it is `Lossy` over
  every space on every request, so no silence there can be read as completeness,
  and the profile's own evidence keeps the axis and keeps reaching a consumer
  byte for byte. Breaking.
- **hnsw:** `register_ranked_hnsw_relation` takes the five facts a host states
  about its own corpus and pipeline as one `RankedHnswRegistration` rather than
  loose: they are one statement made at one moment about one space, and the new
  disclosure would otherwise have made the call eight positional arguments of
  which five were the same argument. A bare-field struct with no builder and no
  `Default`, like every other declaration in this workspace. Breaking.
- **python:** A `text_producers` value may carry a sixth `(completeness, order)`
  position, each member a `str` or `None`, shaped like the attestation position
  beside it and read on the same terms -- `None` is silence on that axis, a
  string is that axis declared degraded with the host's own words carried
  verbatim. `search` reports `"fidelities"`, `"certain_prefix"`,
  `"unemitted_ceiling"` and a per-row
  `"interval"` beside the existing keys, and `"exactness"` gains `"deficit"`,
  `"inflation"` and `"unbounded"` in place of `"lower_bounds_for"`.
- **retrieval:** `EvidenceId`, the third identity a fused answer carries, on both
  `FusionTrailer` and `SearchResult`. `PlanId` names the question that was asked
  and `FusionProfileId` names the law the rows were fused under, and neither moves
  when an index is rebuilt underneath a running system -- both are derived from
  configuration, which is exactly what a rebuild does not change. `EvidenceId` is
  the content identity of the attestation map, so one equality comparison over the
  triple decides whether two answers are comparable at all.
- **retrieval:** Candidate domains reach fusion. `StreamContract` carries the
  producer's `CandidateDomains` beside its duplicate policy, `StratumUnit` and
  `StratumStream` carry it through, and `FusionTrailer::domains` reports what each
  handed stream fused under, so an answer can be audited against the declarations
  that decided which streams fusion was allowed to skip. `ProtocolError::OutsideDeclaredDomain`
  refuses a stream that names a candidate its declaration cannot reach, carrying
  three fields because each answers a different question: the item says what, the
  stratum says who broke it, and the third names the stratum whose own declaration
  -- already applied -- put the candidate out of reach. The answer is not silently
  widened instead, because the declaration has already been used: fusion certified
  candidates early on the strength of it, so an earlier row may already have been
  emitted on the assumption this stream would never name the candidate.
- **retrieval:** `PRODUCER-CONTRACT.md`, published with the crate and rendered in
  its API documentation as the doc-only `producer_contract` module. Fifteen
  obligations a ranked producer owes this layer, each stating the obligation, the
  failure it prevents, and who enforces it -- the layer, where a breach is a named
  refusal, or the producer, where a breach is a wrong answer and the entry names
  the test that proves the shipped producers keep the promise, or says that none
  does. Three of the fifteen are one doctrine wearing three hats, because "I
  stopped early" and "I am exhausted" are the same empty cursor: the engine
  withholds a ceiling it cannot account for, the executor reads one row past the
  depth it recorded, and the producer declares the shortfall only it can know.
- **sparql-eval:** `PfCursor::generation` and `PfCursor::service_level`, both
  defaulted to an honest absence, through which a relation's cursor attests the
  two facts about an invocation that nothing else can see: which generation of its
  index answered, and whether that index was whole. The generation is read
  immediately after `open`, where the snapshot is pinned and the claim is true of
  every row that follows; the service level is read when the invocation **ends**,
  so a relation that discovers a missing shard on its four-hundredth pull still
  has somewhere to say so. There is deliberately no variant for wholeness and
  never will be: a relation that stopped at the engine's ceiling licence is not
  incomplete and could not honestly certify completeness either, so the seam asks
  only the narrow question it has an honest answer to on every path. `Undeclared`
  is silence, never a certificate.
- **sparql-eval:** `RelationWitness` and `RelationAttestations`, the per-query
  ledger those declarations accumulate into, reachable on the governed receipt
  through `RelationIdentity::witness`. Every field is a set or a count and never a
  sequence, because a query can invoke one relation thousands of times across
  several forked workers in an order the evaluator is free to choose, and an
  ordered log would describe the schedule as much as the index. The record is
  owned per context and merged at every fork join rather than shared behind a
  lock; set union and a saturating count make the merge commutative and
  associative, so the result is a function of what was attested rather than of who
  finished first. It rides the receipt beside the governor evidence already there,
  because an attestation describes an outcome rather than being one.
- **sparql-eval:** `EvalError::RelationIncomplete`, raised where a relation
  declares its index short and the entry point has nowhere to record it. A short
  bag whose receipt nobody can read is precisely what the hard-fail doctrine
  exists to prevent.
- **sparql-eval:** `CandidateDomains` and `DomainTag`, the second promise a ranked
  producer makes about its own rows, declared where it declares its duplicate
  handling. A consumer fusing several ranked streams has exactly one way to learn
  that a stream will not name a candidate -- read that stream to its end -- and
  over strata whose candidate sets do not overlap that is every row of every
  stream, however small the caller's top-k. `Unrestricted` is the wider promise
  rather than the weaker one: it says the producer may name anything, it is
  today's behaviour exactly, and a fusion whose every stream declares it computes
  precisely the numbers it computed before this existed. Nothing is defaulted from
  a stratum or a graph, because the host is the only party that knows whether its
  text index and its vector index name the same entities, and a wrong guess is a
  wrong answer. An empty restriction is refused at `register_ranked`, where the
  declaration is committed: a promise to name nothing describes a producer that
  should not be registered.
- **retrieval:** Every ranked row now says which block of the candidate universe it
  was drawn from, so the axiom the declared-domain arithmetic rests on is verified
  rather than trusted. `RankedStream::next` yields a named `RankedRow` -- rank,
  contribution, item and `RowBlock` -- and `RowBlock::Undeclared` is a first-class
  absence beside `IndexGeneration::Undeclared` rather than an `Option` a reader
  could unwrap into a claim. A `CandidateDomains::Within` stream owes a block on
  every row, and owes one its own declaration admits; an `Unrestricted` stream owes
  none, because it restricts no arithmetic at all, and a block it volunteers is
  still honoured as evidence about the candidate. Three refusals, each a separate
  fact: `ProtocolError::UnbackedDomainDeclaration` -- a restricted stream's row
  names no block, so nothing backs the restriction, and fusion has already used it;
  `ProtocolError::BlockOutsideDeclaredDomain` -- a row names a block its own
  declaration excludes, which is a stream contradicting itself and needs no second
  stream to witness it; and `ProtocolError::CandidateInTwoBlocks`, naming the item,
  both strata and both blocks, because two rows that place one candidate in two
  blocks falsify the partition the threshold's per-block maximum depends on and
  either producer may be the one that tagged wrongly. That last case is the one
  `OutsideDeclaredDomain` cannot see: it compares declarations, and two declarations
  can overlap while the rows disagree -- which is exactly where the bound
  under-counts, since the streams that reach one block and the streams that reach
  the other are different sets. A row a permissive duplicate policy discards is
  checked too: a repeat may be dropped, its claim about the candidate may not.
  `compute_threshold` keeps the largest per-block sum of open heads, unweakened; a
  tagging that violates the axiom now fails loudly instead of returning a plausible
  order, as far as the rows pulled reach and no further.
- **sparql-eval, retrieval:** `RankedDeclaration::block_position`, the argument
  position a producer's rows carry their block in. A declaration naming exactly one
  block entails every row's block and needs no column -- the common configuration,
  one producer per block, costs a host nothing. A declaration naming several
  entails nothing about any one row, so a producer that can say declares the
  position its rows name it from, and one that cannot leaves it unset and is held to
  the consequence rather than believed. `purrdf-retrieval` projects the column
  beside `?candidate` for exactly the producers that declare it and reads it back by
  name, so a unit for a producer that declares none is byte-identical to before. The
  position is refused at registration when it falls outside the relation's arity or
  collides with the candidate, a term placement or the depth, and it reaches the
  registry's content fingerprint -- two wirings that verify differently may not
  share a digest -- so that fingerprint and the plan identities over it move.
  Neither shipped producer declares one: a text index answers with documents and a
  vector index with neighbours, and neither holds any notion of a host's partition.
- **text, sparql-eval:** Both shipped ranked producers attest a content-derived
  generation for the index that answered. The text relation declares its index
  fingerprint, which closes over the documents, the term dictionary, every
  posting, the partition statistics, the configured predicates and the ranking
  law; the two neighbouring digests were rejected against the rule that a
  generation must move exactly when the answerable rows move, and the rejections
  are pinned as tests -- the digest of the source rows does not move when the same
  rows are re-ranked under a different law, though every emitted score does, and
  the analyzer digest holds no document at all. The embedding relation cannot
  declare its matrix alone, because the map from a row to the RDF term it stands
  for is a host argument: PURREMB allows a target to be disclosed by digest alone,
  so two spaces over byte-identical artifacts with different bindings return a
  different term at every position. Its declared value folds the projection digest
  (rather than the matrix digest, because a prefix policy lets two spaces share
  one stored matrix and differ in the prefix taken), the family contract that
  names the metric, and every bound term in row order. The bound on work is
  excluded: it decides how hard a search tries, never which rows exist or how they
  rank. Both values are computed once where the snapshot is pinned, out of any
  per-row path.
- **python:** The retrieval answer carries the evidence the Rust surface does.
  `"attestations"` maps a stratum to `{"generation": str | None, "incomplete":
  str | None}`, with the two axes independently absent because a silent producer
  is making no claim in either direction; `"exactness"` is `{"exact": bool,
  "deficit": list[str], "inflation": list[str], "unbounded": list[str]}`, naming
  the strata whose declarations make every score an estimate rather than an exact
  sum, on each side the error runs; `"domains"` reports the
  candidate-domain declaration each stream fused under, so an answer can be
  audited against its own inputs; and `"evidence_id"` sits beside `"plan_id"` and
  `"profile_id"` in the same 64-character lowercase hex spelling, so one
  comparison over the three decides whether two answers are comparable.
- **python:** `retrieval.search`'s `text_producers` value may carry a fifth
  `(generation, incompleteness)` position -- each member a string or `None`, recorded
  verbatim -- declaring what the host knows about the index behind that producer. A
  declared incompleteness is reported under
  `answer["attestations"][stratum]["incomplete"]` and names that stratum under both
  `answer["exactness"]["deficit"]` and `["inflation"]`, which was previously
  unreachable from Python: no shipped producer can know what was missing from the
  document it was handed, so the surface was structurally present and could never
  carry a value. A declared generation is reported and is not a shortfall; it
  replaces the content digest the shipped text relation attests, because one
  generation is pinned per invocation, and a generation that does not move when the
  host's corpus does will defeat the evidence identity. Declaring nothing is silence,
  never a claim that the index was whole, and a value without the position behaves
  exactly as before. The position is FIFTH -- after an explicitly written `domains`
  -- because a fourth-position sequence is already a domains list and the two would
  be indistinguishable: `("a", "b")` is a well-formed two-tag restriction and a
  well-formed attestation at once, and guessing would report a domain tag back to an
  operator as an index generation.
- **python:** A governed outcome carries `relation_witness`, the record of what each
  relation attested about itself during the run: per relation IRI, how many times it
  was invoked, which index generations answered, and the verbatim reason wherever one
  declared its index incomplete. It is read off the governed receipt on both arms, so
  a query whose governor tripped still reports what the relations attested before it
  did. The mapping is always present and may be empty -- a governed query that invoked
  no relation reports `{}`, which is a fact about the run rather than an absence -- and
  `None` inside `"generations"` is an invocation that attested nothing, kept as a member
  of the set rather than dropped because otherwise "declared one generation every time"
  and "declared it sometimes and said nothing the rest" would read identically. Keys
  and both lists are emitted in the engine's own sorted order, so two runs over one
  snapshot compare byte for byte.

  This is the other half of the refusal beside it. A relation that declares itself
  incomplete is refused on any lane with nowhere to record the declaration, and the
  governed lane is the sanctioned destination -- so a surface that refused on one lane
  and could not show the receipt on the other left the caller with no honest route at
  all, which is the state the hard-fail doctrine exists to prevent.
- **python:** Every relation declaration accepts one trailing position,
  `(generation, incompleteness)`, each a string or `None` and each recorded verbatim,
  so a host-registered relation can attest the two facts only its own cursor knows.
  Declaring neither is the default and means the relation said nothing, which is
  silence rather than a claim that its index was whole. The position reaches all three
  relation kinds and every query, update and entailment entry on both `Store` and
  `MutableDataset`. A trailing value that is not a two-member sequence reports the
  declaration's accepted shapes, and a string is refused explicitly rather than
  destructured -- `"ab"` would otherwise extract as a well-formed attestation of
  `("a", "b")`.
- **python:** A host declares a producer's candidate domains where it declares the
  rest of that producer: the ranked-producer tuple takes an optional fourth
  element, a list of domain-tag IRI strings, with `None` -- and omission -- meaning
  "may name anything". An empty list is refused by name before it reaches
  registration, because a promise to name nothing is not a restriction, and
  because the refusal on the far side of the boundary is a panic that must never
  cross it.
- **python:** A compiled retrieval unit carries `"declared_rows"` beside its
  `"stratum"`, `"sparql"` and `"depth"`: the row count the registry declared for
  that stratum's one producer, or `None` where the producer declared no access mode
  and therefore declared no row count at all. Rust callers have read it off
  `StratumUnit::declared_rows()` all along, and the depth alone does not say which
  of two situations a host is in -- a depth BELOW the declaration leaves rows under
  the read, while a depth EQUAL to it means the producer has already promised there
  is nothing further and the probe row is what checks that promise rather than
  taking it. Neither is recoverable from `"depth"`, from the emitted text, or from
  the plan, so a host reading `"depth"` to know how many rows it may report has the
  same claim on the declaration that `retrieval.search` does. "Declared nothing"
  and "declared zero" stay different facts across the boundary: an absent
  declaration can refuse nothing, while a zero is a measurement of the producer's
  data, so the absence arrives as `None` rather than as a number nobody took.
- **sparql-algebra:** `SparqlParser::parse_query_split` and the `QuerySplit` it answers,
  which parse a query exactly as `parse_query_with` does and also report where the two
  clauses only a WHOLE query may write are written in the text: the byte offset its
  prologue ends at, and the byte range its `FROM` / `FROM NAMED` run occupies. A caller
  wrapping a supplied query in a sub-select has to *move* both, because
  `SubSelect ::= SelectClause WhereClause SolutionModifier ValuesClause` carries neither,
  and neither position is derivable from the algebra -- a prefixed name is resolved away
  at parse time, and re-serialising the body would rewrite surface spellings the caller's
  next reader depends on. Positional only: both numbers are offsets the one parse was
  already standing at, so every piece a caller cuts out is the caller's own bytes and the
  algebra beside them is unchanged. The dataset range ends at the token after the last
  clause rather than at its last IRI, so excising it leaves a query that still parses.
- **python:** `MutableDataset` answers the native validation snapshot protocol, so
  `Shapes.validate_store` accepts one for real: both quad containers on this
  surface hold a frozen dataset behind a copy-on-write overlay, and validation
  borrows that snapshot instead of serialising to N-Triples and parsing it back.
  Either container validated yields the one answer the triples deserve, and the
  snapshot rule holds on both -- a report already produced is a statement about the
  data as it was. A value that answers no such protocol is now refused with a
  `TypeError` naming the type that arrived and the three things accepted (a
  `Store`, a `MutableDataset`, or `validate_nt` for text a caller holds), rather
  than escaping as an `AttributeError` about a private attribute the caller never
  wrote.

- **sparql-eval, retrieval:** a needle-driven exclusion lookup now drives a call inside a sub-`SELECT` that a `LATERAL` injects into: the driving pattern carries in the enclosing frames for exactly the variables the sub-`SELECT` projects, rebuilt as `{ SELECT carried… } LATERAL { … }`, and a `GRAPH` variable the sub-`SELECT` does not project is read under a fresh name in every named graph. Before, a piece reading an injected variable was dropped even when it was the only binder of the call's input, and the lookup asked the relation in a mode it never declared. A lookup is now derived only where the relation declares a mode serving the access pattern it asks in; a call whose input the text does not drive no longer qualifies, and the refusal names the call, the mode and the undriven position.
- **shapes, sparql-eval:** a `sh:sparql` constraint whose `FILTER EXISTS` or `FILTER NOT EXISTS` body calls a registered relation failed validation outright for every blank-node or quoted-triple focus node while it validated an IRI one: the value was driven into the call by a one-row `VALUES` that bound `$this` again on a row that already had it, which the evaluator refuses as a rebinding. Inside an `EXISTS` body the call is now driven in a scope of its own: it is invoked bound to the focus node exactly as before and its output does not carry `$this`, which is also what an IRI focus node gets.
- **sparql-eval:** a query request's substitutions are now admitted as bound, the same way a prepared execution's declared parameters are. `SELECT ?q ?out WHERE { ?q <rel> ?out }` with `?q` substituted was refused against a relation serving only the bound mode ("reachable only as `ff`") for every term kind, an IRI included, on every request entry point — ungoverned, interned, governed, operation-scoped and fallible. The rewrite lane is part of the admission, so a substitution the ordinary rewrite does not carry to the call, such as one inside an `OPTIONAL` arm, is still refused, while the SHACL pre-binding rewrite, which does reach that arm, admits it.

- **shapes:** a shapes graph that merged the W3C SHACL 1.2 vocabularies failed to
  load with `custom node-expression function <sh:SPARQLExprExpression> declares 0
  sh:bodyExpression values`. Every bodiless `sh:NamedParameterExpressionFunction` and
  `sh:ListParameterExpressionFunction` declaration, including the specification's own
  declarations of `sh:SPARQLExprExpression`, the `shnex:` library and the `sparql:`
  functions, was indexed as a user-defined function. A declaration of a built-in now
  binds to the native implementation on both the fresh-parse and the prepared-product
  restore path and adds nothing to the custom-function index, and merging the
  vocabularies leaves every report byte-identical. A bodiless function the engine
  does not implement is still refused, in `sh:` as in any other namespace.

- **shapes:** a native constraint component IRI declared with user validators was
  skipped without a word; it is now a duplicate-definition load error. A custom
  function keyed by a built-in's key parameter is refused, since the key parameters
  of all node expression functions must be disjoint. `sparql:plus` and
  `sparql:encode`, the spellings `shnex-sparql.ttl` declares, are accepted beside
  `sparql:add` and `sparql:encodeForUri`. The prepared-product writer refused a
  custom list function reached only from SPARQL text; restore now rebuilds it.

- **shapes:** the shapes parser dropped what it did not understand: a misspelled
  parameter, a literal where an IRI is required, a non-boolean flag compared as the
  string "true", a second `sh:flags`, a non-literal `sh:pattern`, a list where one
  value is expected. Each such shape validated as if the constraint were absent. An
  unknown term or an ill-typed value on a shape or node-expression node is now
  refused at load, each refusal tested beside a valid neighbour. `sh:deactivated` on
  a SPARQL or expression constraint node was ignored and is now honoured.

- **shapes:** the nodes of SHACL-SPARQL were not checked at all. A SPARQL-based
  constraint, a validator and a `sh:SPARQLTarget` loaded whatever else they carried:
  a `sh:resultAnnotation` was dropped, and so were an `sh:ask` beside a constraint's
  `sh:select`, an `sh:update` and a misspelled `sh:mesage`. The annotations are now
  evaluated. Any other term such a node carries, beyond what its specification
  gives it, is refused at load, and an ASK validator that also carries an
  `sh:select` (or a SELECT validator an `sh:ask`) is refused. `sh:describe` and
  `sh:update`, which no SHACL specification executes, are refused wherever the
  loader reads, with that reason, and a resource that is only such an executable
  loads.

- **python:** the `.pyi` type declarations gave `MutableDataset.__init__` as
  returning the prefix list that only `load` and `bulk_load` return; it returns
  `None`. The `shapes.entail` documentation, in the `.pyi` file and the binding,
  said rules run "to a fixpoint"; it now describes the layered SHACL 1.2
  Inference Rules execution the engine performs.

- **shapes:** a custom component parameter whose local name is a SPARQL variable
  name outside ASCII (`ex:größe`) or starting with a digit (`ex:2d`) was refused as
  an invalid variable name. The test is now the SPARQL grammar's `VARNAME`
  production.

- **shapes:** all but one `sh:message` was dropped and the language tag of the one
  kept was lost. Every message is reported, each keeping its language tag, direction
  and datatype, and `rdf:HTML` messages are accepted.

- **shapes:** `sh:reifierShape` reported the triple term as `sh:value`, once per
  result of the inner shape, and `sh:reificationRequired` reported the triple term
  too. SHACL 1.2 Core 7.8.5's textual definition names both the triple term and the
  reifier `t`; the approved W3C tests `core/property/reifierShape-001` and `-002`
  expect the value node, and both results now carry the value node as `sh:value`.
  There is one result per non-conforming reifier, carrying the reifier's own
  validation results (the reifier as focus node) as `sh:detail`. `sh:uniqueLang` (7.4.6) groups values by language tag and
  base direction, so `"1"@ar`, `"1"@ar--ltr` and `"1"@ar--rtl` no longer collide.

- **entail, validate, cli:** an `owl:imports` of an ontology already in the graph was
  treated as unresolved. A shapes graph that merged the W3C vocabularies imports
  `<http://www.w3.org/ns/shacl#>` while containing it, and the CLI warned (or refused
  once any `--import` was given), while the prepared-product path behind the
  WebAssembly and C hosts refused any `owl:imports` at all. An import is now resolved
  when it names a document already loaded, an `owl:Ontology` in the graph or a
  version IRI in the graph, transitively over the closure, and the CLI, the product
  packer and entailment all take their verdict from that one rule.

- **core, shapes, entail:** every `owl:imports` triple was read as an import, whatever
  its subject. OWL 2 reads a document's imports off its ontology header (Mapping to RDF
  Graphs §3.1.2, Table 4) and SHACL 1.2 follows them from the shapes graph's own IRI
  along `^owl:versionIRI?/owl:imports`, so an `owl:imports` on any other node imports
  nothing. The approved W3C `sparql/node/prefixes-001` tests (SHACL 1.0 and 1.2) write
  `ex:TestPrefixes owl:imports <…>` as a `sh:prefixes/owl:imports*/sh:declare` prefix
  edge, and `sparql/component/validator-001` writes `owl:imports
  <http://datashapes.org/dash>` on a node that is neither the document's IRI nor an
  `owl:Ontology`; every host refused both as unresolved imports. An `owl:imports` is now
  an import only on an IRI its document was loaded under, a subject typed
  `owl:Ontology`, or a subject naming either as its `owl:versionIRI`; any other is data,
  kept in the graph as written. Both tests validate as written with no import table, and
  entailment reads a premise's imports by the same rule.

- **shapes, rdf, python:** prefixes were recovered by scanning text. The SHACL-AF
  document-prefix fallback scanned the shapes document, so a `PREFIX` line inside one
  constraint's query literal leaked into every other constraint's header; statement
  error recovery and the Python rdflib-compatible `Graph` scanned Turtle, SPARQL or
  RDF/XML text the same way. Every caller now takes the prefixes the parser records;
  the RDF/XML codec reports its `xmlns` declarations, excluding those inside
  `rdf:parseType="Literal"` values; and error recovery no longer ends a statement at
  a decimal point.

- **shapes:** SHACL-SPARQL prefixes follow SHACL 1.2 SPARQL Extensions. `sh:prefixes`
  now follows `owl:imports` and `owl:versionIRI` to its `sh:declare` values; a query
  with no `sh:prefixes` uses the `sh:declare` values of SHACL instances of
  `owl:Ontology`, `sh:DataGraph`, `sh:ShapesGraph` and `sh:RulesGraph`; the document
  `@prefix` fallback only fills labels those leave unbound; and two namespaces for
  one prefix, or a malformed declaration, reached by a query fail the load.

- **shapes:** node expressions were almost all set-shaped: outputs were sorted
  canonically and deduplicated. Each kind now keeps the order and multiplicity its
  SHACL 1.2 Node Expressions clause defines, held to a clause-by-clause reference
  interpreter. `filterShape` keeps input order and duplicates, `distinct` keeps first
  occurrences, and `orderBy` sorts an unbound key first instead of failing; `sh:if`
  and `shnex:if` take the then branch only when the condition is the list `( true )`
  (4.1.6), with no effective-boolean coercion; a `sparql:` argument that produces no
  node reaches SPARQL unbound, so `BOUND` and `COALESCE` behave; `findFirst`,
  `matchAll` and `filterShape` accept the empty shape `[]`; and `shnex:instancesOf`
  takes a node expression.

- **shapes:** rule output kept only plain quads: a reifier or annotation a CONSTRUCT
  or triple rule produced was lost or stored as a plain triple. Rule-derived
  reifications and annotations now land in the RDF 1.2 statement layer.

- **shapes, validate:** the schema projections were unsound. `sh:pattern`,
  `sh:minLength` and `sh:maxLength` checked only bare strings, not a typed or
  language-tagged literal's lexical form, and `sh:flags "i"` failed the whole
  compile; several value-type constraints on one property were unioned instead of
  conjoined, and several `sh:in` lists unioned instead of intersected; `sh:datatype`,
  `sh:nodeKind`, `sh:hasValue`, `sh:languageIn` and numeric range bounds accepted
  values SHACL rejects or rejected values it accepts; triple terms were projected as
  strings; property pairs, node-level value constraints, property-level shape
  constraints, nested and non-predicate-path property shapes, reifier shapes and the
  SHACL 1.2 components were dropped without a trace; and deactivated property shapes
  and non-disallowed severities were enforced. Every construct now reaches the
  TypeScript, Pydantic, GraphQL and LinkML emitters as a projection whose verdict
  matches SHACL on the same data, checked with a JSON Schema validator, or as a
  declared loss, and the JSON Schema importer reads every new form back.

- **shapes:** extension-usage reporting missed the queries of custom-component
  validators and SPARQL inside inline nested shapes.

### Fixed

- **shapes:** a SHACL Advanced Features 1.1 path expression with an input,
  `[ sh:path P ; sh:nodes N ]`, was refused for carrying `sh:nodes`. It now evaluates
  as the specification defines it, the values of P from every node N produces, which
  is SHACL 1.2's `shnex:flatMap` of the path over N. One that also carries
  `shnex:focusNode` is refused.

- **shapes:** a custom constraint component that is also a shape (it carries a
  target, for example) was refused for carrying `sh:parameter` and its validators,
  which the component registry reads. Both roles now load and run; a shape that is
  not a component still may not carry them.

- **sparql-eval:** The forked row loop's per-chunk harvest no longer allocates below
  the parallel threshold. Harvesting a worker's relation witness came back as a `Vec`
  of one element on the sequential path — a heap allocation per `FILTER` or `BIND`
  evaluation whose whole content was one, almost always empty, witness. On the
  per-focus-node SHACL path, whose allocation count per focus node is pinned exactly,
  that was one to two allocations per focus node over the pin; the harvest now rides
  inline in a one-slot small vector and the pins hold again.

- **sparql-eval, shapes:** The borrowed governed lane — the per-focus-node entry SHACL
  validation drives — carries the relation witness, and a validation over an index
  that declared itself not whole is refused. Two governed egresses build their own
  context and resolve their own verdict, and only one of them armed witnessing and
  moved the witness onto its receipt; the other handed back a receipt whose ledger
  said nothing about the relations the run had invoked. Both now share one context
  builder and one resolution, so the witness is filled in one place for both. That
  makes the borrowed lane RECORD a relation declaring a shortfall rather than refuse
  it at the seam the way the ungoverned lane does -- and SHACL validation reads only
  the rows out of that lane, so the record was where a shortfall would have been
  silently dropped: "this focus node has no violating solution" over an index that
  was not whole reads exactly like the same sentence over the whole index. The
  validation now reads the receipt and refuses by name, quoting the relation and its
  own reason, exactly as it refuses a truncated solution bag; the same relation
  declaring nothing validates to a report.

- **retrieval:** The declared row bound is read at the mode the producer is actually
  invoked in. `rows_per_invocation` is a function of the mode, and the layer had been
  taking the maximum across every mode a producer declared -- so a depth was admitted
  that the invoked mode had declared it could not serve, a producer beating its invoked
  mode's bound went unrefused whenever another mode declared a larger number, and the
  number handed to a self-bounding producer was capped against the wrong mode, so a
  producer guarding its own bound lost its whole stratum. The bound is now the tightest
  declared under any mode that subsumes the invocation -- the same lattice rule
  placement admits the call by, and a producer serving through a subsuming mode emits
  at most that mode's rows, since the extra bindings only filter. There is one function
  computing it, called from the planner and the waist alike, where there were two.
  Every fixture in the suite had declared a single mode and ignored the parameter,
  which is why the difference was unobservable; one now answers a different number per
  mode.

  Both refusals that name a row bound say which mode it was read at, because for the
  multi-mode producers the seam is built for that mode is routinely not the invoked one.
  A coarser mode declares fewer bindings, so its tuples cover a finer mode's and its
  count bounds the finer read too: a producer promising a hundred rows with its needle
  bound and three with it free has over-declared the bound case, three is the sound
  bound, and the figure appears nowhere in the declaration the call was made at.
  `ExecutionError::RowBoundBreached` and `AdmissionError::DepthBoundViolation` therefore
  carry `BoundMode`, which renders as the mode the number came from and, where that is
  not the invoked one, as the call it serves -- "under mode `ff`, which serves this call
  under mode `fb`". A bundle a caller assembled itself records a count and no mode, and
  says that rather than attributing the caller's own number to a registry read that
  never happened.
- **retrieval:** A query text a caller supplies is wrapped rather than appended to, and
  the prologue it was written with is hoisted above that wrapper. The layer's bound was
  written after the caller's text, so a text carrying a top-level bound of its own
  produced two bound clauses, of which the parser kept the last -- the caller's
  vanished, three rows came back where two were asked for, and the ending named the
  caller's text as the stopper of a read it had not stopped. The text is now a
  sub-select under the layer's bound, so both stand: the caller's applies to the pattern
  it was written against and the layer's to whatever that resolves to.

  Wrapping alone was not enough, and the first attempt at it broke a strictly larger
  class than it fixed. A sub-select carries no prologue in the grammar -- `PREFIX` and
  `BASE` are `Prologue`, which appears once, at the front of a whole query -- so a text
  declaring either, which is how essentially all SPARQL is written, stopped parsing the
  moment it was wrapped, and the caller was handed a syntax error at a byte offset of a
  query the layer wrote. That included the very case the wrap existed for, whenever the
  text was prefixed. So `StratumUnit::new` now reads the text once, with the front end
  the executor runs, and emits the caller's directives *in front of* the wrapping
  `SELECT` with their query form inside it. It is the text that moves and nothing that
  is re-rendered: a prefixed name is resolved away at parse time, so the prologue is not
  recoverable from the algebra, and re-serialising the body would rewrite the argument
  lists a relation call is spelled with into the blank-node chains a registry-unaware
  parse lowers them to.

  That parse is also the refusal the wrap was said to be an alternative to. The earlier
  reasoning -- that refusing a text would mean parsing it, which this layer does not do
  -- was a false choice twice over: the wrap imposed a sub-select grammar constraint
  without parsing anything, and the parser the executor runs is a direct dependency. A
  text that is not a query is now refused at construction by name
  (`UnitError::NotAQuery`), carrying the parser's own diagnostic, instead of surfacing as
  one stratum's `ExecutionFailed` after a bundle was assembled and its other strata were
  read. The parse judges grammar and nothing else -- it runs with no relation registry,
  so a registered predicate is an ordinary triple pattern to it, and the registry-aware
  parse at execution stays the authority on the seam, with its refusals still reported
  as that stratum's own status. `ProducerStatus::ExecutionFailed` for an empty supplied
  text is gone with the condition: an empty text is not a query, so it cannot reach a
  bundle.

  The same parse names the query form, and a form the wrapper cannot hold is refused by
  that name (`UnitError::NotASelect { form }`). An `ASK`, `CONSTRUCT` or `DESCRIBE`
  supplied to the seam used to build a unit and fail at execution with the same
  byte-offset diagnostic a prologue produced -- the grammar admits only a `SELECT`
  inside a sub-select -- and none of the three yields a solution row to rank, so no
  text of those forms could ever have run and nothing valid is refused. Every `SELECT`
  is still admitted whatever it carries: a dataset clause, a trailing `VALUES` and a
  `VERSION` directive are each executed beside the refusal, over a dataset where the
  clause selects different rows from the one the store would have answered with.
- **retrieval:** A supplied query's dataset clause reads the graphs it names. The wrap is
  a sub-select, `SubSelect ::= SelectClause WhereClause SolutionModifier ValuesClause`
  has no `DatasetClause` in it, and the clause was being carried inside the wrapper --
  where the parser read it and then discarded it. So a caller writing
  `FROM <a-graph-that-does-not-exist>` got rows, read out of the very default graph the
  clause excluded, under an ordinary `SuppliedQueryEnded` ending with no refusal and no
  diagnostic anywhere. A wrong answer is worse than a broken one, and this one was
  invisible to a suite whose supplied-text fixtures all ran over an empty dataset
  against a registry-driven relation, where which graphs a clause selects cannot change
  a row.

  The clause is now written onto the wrapper's own `SELECT`, which is the one position
  the grammar leaves for it and the one that scopes the body the caller wrote it around,
  and it is excised from the body. That excision is the only edit the wrap makes to a
  caller's bytes: it moves as *text*, split at the range the parse reported, for the
  reason the prologue does -- re-rendering the body would rewrite a relation call's
  argument lists into the blank-node chains they lower to, and the registry-aware parse
  at execution would no longer see a call. A text carrying neither clause emits the bytes
  it always emitted, at every depth.
- **sparql-algebra:** A dataset clause inside a sub-select is refused instead of parsed
  and discarded. `SubSelect` has no `DatasetClause`, so a `FROM` there is not a
  production; this parser read one anyway -- one function serves both `SELECT`
  positions -- and the sub-select site then unwrapped the `Query` with `..`, dropping the
  clause along with the base IRI and the version. The clause is now refused as a
  `ParseError::Syntax` at its own `FROM` keyword, naming that a dataset clause is written
  on a whole query because that is the scope it applies to, and the site destructures
  every field explicitly so a field added later cannot start being dropped silently.
  Nothing valid is caught: a sub-select without the clause, a whole query with it, and a
  whole query with it that also contains a sub-select are each executed beside the
  refusal.
- **retrieval:** A compiled bundle is checked against the set it was assembled with
  before any unit runs (`ExecutionError::UnitsNotAsAssembled`). The unit list and each
  unit's stratum were writable, so a unit removed from the bundle yielded a narrower
  answer under the genuine plan identity, and two units' strata swapped attached each
  producer's evidence to the other. The bundle now records, privately, which stratum
  each position was assembled under; a count that moved or a stratum that moved is
  refused by name, with the count reported first because a removal shifts every
  position after it.
- **retrieval:** A producer declaring no rows that returns one is refused. The breach
  check sat inside the depth-cut arm on the reasoning that the emitted bound never
  asks for a second row past the declaration, which is false at a declared zero: the
  floored depth of one is emitted one row deeper like any other, so the first row
  already breaches and was being reported as an exhaustion of one row. The check runs
  first now, and a declared zero over an index holding anything is
  `ExecutionError::RowBoundBreached` like a wrong declaration of any other size.
- **retrieval:** A bounded request narrows a stratum's depth to `k` only where that
  stratum also declared `DuplicatePolicy::Unique`. The narrowing rested on the
  candidate-domain declarations alone, and the merge argument behind it counts
  ranks: a candidate ranked past `k` is beaten by the `k` candidates above it in
  its own stratum. That step reads a count of ranks as a count of candidates, which
  is true of a `Unique` stream and false of an `Allowed` one -- a repeat there is
  validated, charged to the producer and then discarded, which is precisely what
  that declaration asks a consumer to do. A depth-`k` prefix of such a stream
  therefore carries `k` rows and can carry fewer than `k` candidates, so it is no
  longer a superset of the top `k`: over one stratum the answer came back short a
  row, and with a second stratum to fill the gap it came back the right length with
  the wrong row in it, reported as exact with nothing in the trailer to distinguish
  it. An `Allowed` stratum now keeps the declared-or-measured depth it always read
  and answers exactly as the same request answers with no declaration at all;
  `Unique` keeps the bounded read unchanged, which is what makes the condition a
  premise rather than a retreat. No shipped producer declares `Allowed`, so no
  released answer moved; the seam publishes the declaration, `register_ranked`
  accepts it, and the fusion layer pays for it, so a host's own producer could
  reach this.

- **geo:** A GeoSPARQL index can now be built before the geometries it will hold
  have landed. `GeoIndex::from_dataset` refused outright when a
  `GraphSelector::Named` graph was not interned in the dataset, on the argument
  that a configuration pointing at an absent graph is a wiring mistake. A graph
  IRI is interned only once a quad is in that graph, so the check made a
  graph-scoped index unbuildable until its data arrived -- and an index standing
  ready before the load is an ordinary operating state. The same function already
  read an absent serialization property as "an ordinary empty match, not a
  configuration error", so the two halves of one condition were answered two
  different ways. Graph resolution is now infallible and an absent graph yields
  the empty index, which is the posture `purrdf-text` takes for the identical
  selector, so a host wiring both crates from one configuration no longer gets an
  index from one and a refusal from the other.

  The empty index is a complete index, built through the ordinary steps rather
  than a second path: no entries, one empty asserted vector per spatial relation
  so every relation stays answerable, and a `source_fingerprint` from the same
  digest call the populated projection uses. The configuration is digested before
  any content, so two empty indexes under different configurations still differ,
  and the value moves the moment the first geometry lands. `verify_binding` is
  untouched and still compares digests over the rows actually projected.

  What is not relaxed: an empty serialization list is still refused. That is a
  configuration with no subject rather than a corpus with no rows, and this
  toolkit mints no vocabulary to guess one. A `GraphSelector::Named` holding a
  non-IRI is still refused at configuration time.

- **text:** The case-folding skew is measured per standard-library Unicode vintage
  instead of against one. The crate carries a fold table (`caseless`, 16.0.0)
  that trails the standard library's case-mapping tables, and pins the exact set
  of code points the two disagree on so that a table moving is seen rather than
  absorbed -- but the standard library's tables move with the toolchain, which
  this repository floats, and the pin named one vintage. The day the nightly
  picked up Unicode 18.0.0 the skew grew from 57 code points to 98 (four IPA and
  Latin Extended-E letters that gained capitals, their capitals, sixteen new Latin
  Extended-G case pairs and one new ligature) and the suite went red on a table
  the crate had measured nothing about. The skew test and the version pin now key
  on `char::UNICODE_VERSION`: 17.0.0 and 18.0.0 are each pinned as an exact set, a
  vintage outside them fails by name, and every failure prints the runs it
  measured so one run on a new toolchain is the measurement. The guarantee the
  skew rests on is restated precisely: a text containing no character the
  standard-library release itself introduced analyzes to the token vector it
  always did -- the four pre-existing lowercase letters still fold to themselves,
  and only their newly minted capitals fail to reach them.

- **text:** A text index can now be built before the documents it will hold have
  landed. A configured predicate the dataset has not interned contributes no rows
  instead of failing the build, and so does a `GraphSelector::Named` graph the
  dataset has not interned. The limiting case is what decided it: an empty dataset
  interns no term at all, so the presence check made an index over an empty corpus
  impossible -- and it made the recommended single-partition configuration (one
  named graph) the hardest one to start from, because a graph IRI is interned only
  once something is in that graph. It also put the shipped text producer
  permanently out of reach of the state the ranked-retrieval contract is written
  for: a producer whose declared row bound is zero is invoked anyway and reports
  its own exhaustion, so emptiness arrives as the producer's receipt rather than as
  a verdict reached without asking it.

  An empty index is a complete index. It holds zero documents, zero terms and zero
  partitions -- a partition carries at least one document, so BM25's average
  document length is never divided by a zero that does not exist -- and it still
  attests a generation, because the configuration, the ranking law and the
  analyzer's Unicode versions are digested before any content. Two empty indexes
  under different configurations are therefore distinguishable, and the value moves
  the moment the first document lands. Every relation measured over it declares a
  row bound of zero in every mode, `ranked_declaration` serves it (the rank law
  holds over a stream with no rows in it), and a search answers with zero rows
  through the ordinary cursor path.

  What the relaxation costs is a mistyped predicate IRI's share of the corpus, and
  that cost is paid by a detector rather than absorbed: see
  `TextIndex::source_coverage` below. A presence check was never the detector -- it
  accepted any IRI the dataset interned anywhere, including in an unrelated
  position, and it condemned a correctly spelled predicate whose objects are all
  IRIs, which contributes no text and has never raised anything. The
  multi-partition refusal in `ranked_declaration` is untouched.

- **text:** Letting an index build over a predicate the dataset carries nothing
  for traded a hard failure for a silent partial corpus, and named a detector that
  could not detect it. `verify_binding` recomputes the source digest under the
  *same* configuration the index was built under, so a mistyped predicate agreed
  with itself: five configured predicates with one document each and one character
  wrong in one IRI gave `document_count = 4` and a clean verdict. The other signals
  -- a zero document count, a declared row bound of zero -- fire only when *every*
  configured predicate is wrong, not the one-of-five case.

  `TextIndex::source_coverage` now reports what the walk found, because the two
  empty states are distinguishable and only one of them is a mistake. A dataset
  holding no statement in any of its three layers is an index standing ready before
  its documents land: every configured predicate is unrepresented for that one
  reason, `SourceCoverage::shortfall` is `None`, and nothing complains -- the
  capability the relaxation was made for is unchanged, generation and all. A
  dataset that holds statements and carries none under a configured predicate is a
  shortfall, and `shortfall` names the predicates. A `GraphSelector::Named` graph
  the dataset does not hold lands there too, because it leaves every configured
  predicate with nothing in scope. `verify_binding` checks the shortfall against
  the dataset in hand after it checks the digest, and names the predicates in its
  message.

  Representation is counted per **statement**, in either RDF 1.2 layer and inside
  the configured graph scope -- not per literal row, and not by the predicate IRI
  being interned somewhere. A predicate whose objects are all IRIs is therefore
  found rather than reported, and a predicate carried only by the annotation side
  table is found rather than reported, which a coverage taken from the asserted
  table alone would have got exactly backwards for this crate's headline case. The
  dataset is probed for a single statement only when something came up
  unrepresented, and each probe stops at the first row.

  One case is reported that is not a mistake, and it is reported deliberately: a
  host loading one predicate's data before another's is the same observation as a
  typo -- a configured predicate with no statement, in a dataset holding other
  things -- and nothing in the data separates them. So this is a report and never a
  refusal at construction: the index builds, answers and attests its generation
  either way, and a host that means it reads the coverage instead of asking for a
  verdict. The coverage is in neither fingerprint, because it cannot change an
  answer: two datasets whose literal rows agree answer alike whether or not one
  also holds a non-literal statement under a configured predicate.

- **retrieval:** A stratum whose planned depth already equalled its producer's
  declared row bound was reported `ProducerStatus::Exhausted` -- the one ending
  that names no stopper -- for a read that bound had cut, with
  nothing anywhere saying so. The depth probe is the row that tells a read which
  ran out from a read which was stopped, and it was emitted at
  `min(depth + 1, declared)`: at that one depth the `min` selected the
  declaration, the unit was emitted at exactly its own depth, and there was no
  probe slot left to answer the question. It is now `depth + 1`, at every depth and
  against every declaration -- the declared row bound does not cap the emitted bound
  at all, because admission has already refused a depth above that declaration, so a
  `min` over the two selects the depth in every case a unit can be emitted for. Only
  the emitted `LIMIT` moves; the recorded depth is what admission holds a plan to and
  is unchanged, as are every plan field, identity and planned-resolution number
  keyed to it.

  A declared row bound of **zero** was the one arm where the two numbers parted, and
  it was the arm the `min` got wrong: the planner floors that depth at one, and a
  bound capped to the declaration was then `LIMIT 1`, a bound *equal* to its own
  depth. No row past it could arrive, so the stratum was certified `Exhausted`
  whatever the index turned out to hold -- an index that really was empty and one
  holding nine rows produced byte-identical trailers. A zero declaration is read
  rather than obeyed everywhere else in this layer, so it is read here too. An empty
  index now reports `Exhausted { rows_emitted: 0 }` as a verified claim, and an index
  that turns out to hold rows breaches its declaration by name exactly as a wrong
  declaration of any other size does.

  A row arriving in that slot is past the declaration rather than merely past the
  depth, which means the producer yielded a row it promised did not exist. That
  is refused by name -- a new `ExecutionError::RowBoundBreached` carrying the
  stratum, the declared bound and the count actually returned -- rather than
  truncated and certified as exhaustion. It is a whole-run refusal and not a
  per-stratum status, because the broken number ordered that call against the
  other operators of its group and admitted every depth in the plan, and because
  `ProducerStatus::ExecutionFailed` says the producer could not run while this
  one ran and returned rows. An honest producer pays nothing for the slot: it
  returns the rows it declared, the slot comes back empty, and its exhaustion is
  now verified rather than believed.

  The depth *argument* handed to a producer that declares a depth placement keeps
  the older `max(1, min(depth + 1, declared))`, and that split is the point: a
  `LIMIT` is a ceiling the evaluator applies to a cursor the producer never hears
  about, while the argument is a request the producer reads and checks. Asking
  for `declared + 1` there asks a producer to exceed its own registration, and
  the nearest-neighbour relation correctly refuses a `k` above its configured
  guard -- so probing on the argument would have turned a valid query into a
  refused one. The unit's own bound still reaches one row past the declaration,
  so a self-bounding producer that returns more rows than it declared is still
  caught; it is simply never asked to.

  `StratumUnit` carries the registry's declaration for the stratum, readable as
  `declared_rows()`, which is what lets the executor tell the two kinds of extra row
  apart. `None` there is a registry that declared no access mode and therefore no
  bound, which promises nothing for a row to breach.

- **retrieval:** At the deepest depth a plan can express, that probe row vanished
  again and `ProducerStatus::Exhausted` was minted from a bounded read. The emitted
  bound is the depth plus one row, and the addition saturated -- so at a depth of
  `u32::MAX` the emitted `LIMIT` *equalled* the depth, no row could ever arrive
  past it, and every such read was reported with the one ending that names no
  stopper however many rows the relation still held. That is the fault the
  probe row exists to close, surviving at the one depth where the mitigation was
  dropped: a saturating operator looked like arithmetic hygiene and was a silent
  completeness claim.

  Both ends of the depth range are refused by name now, rather than one floored and
  the other saturated. The admission waist refuses a depth whose probe row is
  inexpressible as `AdmissionError::DepthWithoutProbe`, the mirror of
  `AdmissionError::ZeroDepth` and enforced beside it, and it hands the compiler an
  admitted depth as a type that cannot carry the refused value -- so a unit whose
  `LIMIT` equals its own depth is unwritable rather than merely unwritten, and the
  row past the depth is added with exact arithmetic.

  The planner no longer truncates a derived bound to `u32::MAX` either, and the two
  sides of that ceiling are now handled differently because they are two different
  kinds of number. A *declared* row bound past the ceiling is recorded **at** the
  ceiling: the truncation's real defect was not the clamp but that it recorded a depth
  below the bound it claimed to serve with nothing anywhere reporting the difference,
  and that at `u32::MAX` exactly it also left no room for the probe row. At the
  readable ceiling the probe row fits, so a read this ceiling cuts arrives with a row
  past the depth and ends `ProducerStatus::DepthReached`, which names the planned
  depth as the stopper -- the comparison the truncation lacked. A *requested* bound
  past the ceiling is refused, as `PlanError::ReadBoundBeyondDepthRange`, once at the
  request itself rather than wherever it happens to bind: that number is the caller's
  own, and deferred it was served silently against a registry whose declarations were
  smaller and truncated against one whose were not.

  Declaring more rows per invocation than a read can be taken to is therefore served
  rather than refused, and it had to be. An honest declaration of a ten-billion-row
  index read for a top-ten answer is an ordinary request, and it is ordinary for
  exactly the shapes that cannot narrow a depth to that answer's bound -- a producer
  whose rows are not its candidates (`DuplicatePolicy::Allowed`), or one that
  restricts no block of the candidate universe (`CandidateDomains::Unrestricted`,
  which is the shipped nearest-neighbour relation's own documented default). Refusing
  those left a host two ways out and both were dishonest: under-declare
  `rows_per_invocation`, or fabricate a cardinality statistic.

  `PlanError::ReadBoundBeyondDepthRange`'s ceiling is the deepest *readable* depth
  rather than `u32::MAX`, so the sentence it prints is true: a bound of exactly the
  number it names plans, records that depth and is emitted with its probe row, while
  the number it used to name was then refused where it bound.

  Nothing an ordinary request reaches moves. Both boundaries begin at a read of four
  billion rows from one producer per invocation; the deepest depth below them
  still plans, admits and compiles, with its probe row present and its emitted
  bound exactly where it was, and no plan identity, recorded depth or emitted
  `LIMIT` changes anywhere else.

- **retrieval:** One class of producer had its exhaustion minted from a
  declaration rather than read off the data, and it is the shipped
  nearest-neighbour relation's own shape. A producer that declares a depth
  *placement* is handed the number instead of being bounded by a `LIMIT`, and that
  argument is never raised past the row count it registered -- asking for more asks
  the relation to contradict its own registration, which a conforming relation
  refuses. So at a depth already sitting on that declaration the read is asked for
  exactly `depth` rows, returns at most `depth` rows, and the slot past the depth can
  never be filled however many rows the index holds. The stratum was reported
  `ProducerStatus::Exhausted` anyway, which made an index of a thousand rows and an
  index of exactly `depth` rows indistinguishable in every field of the answer. The
  depth cannot rise to go looking, either: the derived depth is bounded by the
  declaration, so no plan asks for more.

  How that read ended is genuinely unobservable, and neither existing ending was
  true of it -- `DepthReached` would blame a planned depth that cut nothing, and
  `Exhausted` would claim the rows ran out when nobody could know. So there is a
  sixth ending, named for the stopper it actually had:
  `ProducerReceipt::RowBoundReached`, `ProducerStatus::RowBoundReached` and
  `StreamEnding::RowBoundReached`, all carrying the rank the read stopped at, spelled
  `"row_bound_reached"` in the Python answer's `"statuses"` beside its `"rank"`.
  `Exhausted` remains the only ending that names no stopper, and a consumer
  that wants this read taken further has one honest move, different from either
  neighbour's: raise the producer's declared row bound.

  It is reported only where the ending really is unobservable. A producer the
  evaluator bounds always receives the probe row and is unaffected. A self-bounding
  producer planned *below* its declaration receives the probe too and still reports
  `DepthReached` or `Exhausted`. One that returned fewer rows than it was allowed is
  `Exhausted`, verified, because it stopped before anything stopped it. And one that
  returns more rows than it declared is still caught by the unit's own bound and still
  refused as `ExecutionError::RowBoundBreached`.

- **retrieval:** `StratumUnit`'s depth was a plain public `u32`, which re-opened at
  the compile/execute boundary the exact hole the admission waist closes one stage
  earlier. A bundle whose depth was raised past the range its emitted bound can probe
  reported `Exhausted` for a read the `LIMIT` cut, and one whose declared row bound
  was lowered below its depth bypassed the waist's `DepthBoundViolation` dimension --
  on the one number all of this is about. Admission refuses a hand-edited *plan* on
  both of those, for the reason every dimension is re-derived at the waist; trusting a
  hand-edited *bundle* on the same two was the same fault with one stage skipped.

  The depth and the declared row bound are now private, read through
  `StratumUnit::depth()` and `StratumUnit::declared_rows()`, and reachable only
  through a checked constructor: `StratumUnit::new` takes both numbers and refuses a
  zero depth, a depth whose probe row is inexpressible, and a depth above the declared
  bound as variants of a new `UnitError` -- joined, per the entry above, by a supplied
  text the parser refuses. Who applies the depth -- the
  evaluator as a `LIMIT`, or a producer handed it as an argument -- is not an input
  beside them: it is read off the query the compiler assembled, because it is the same
  fact. The seam stays open, because handing the executor a query of one's own is what
  it is for. The entry below carries that half the rest of the way: no bound the ending
  depends on is text a caller can write, and a caller's own text is never certified.

- **retrieval:** A stratum's ending was decided from four things and only three of
  them were checked. The fourth was the bound written in the unit's own query text,
  which was a public, writable `String`, and the failure was the natural off-by-one: a
  caller assembling a bundle by hand writes `LIMIT <depth>`, because the depth is the
  number this layer reasons about everywhere. That text leaves no slot for the probe
  row, `execute` writes `DepthReached` only when a row arrives *past* the depth, so an
  evaluator-bounded `Unique` producer holding nine real rows read at depth three
  reported `Exhausted { rows_emitted: 3 }` -- the one ending that names no stopper,
  for a read with six rows behind it. Nothing downstream could catch it
  either: the rows emitted equalled the rows pulled, so the fused trailer above it read
  `Exact`.

  The first fix rendered the unit's *outer* bound from the depth instead of storing it,
  and the entry below is why that was not enough: the bound moved inward rather than
  out of reach. The refused alternative was inspecting the trailing `LIMIT` and
  comparing it, which re-reads a number the layer already holds and can only ever
  refuse a caller for writing what the layer writes itself.

- **retrieval:** The bound the read is taken under was pulled out of one writable
  string and left inside another, so the same false completeness claim came back with
  the same numbers. A `StratumUnit` carried a public `body` and rendered only the
  *outer* `LIMIT` from the depth -- but every emitted body carries a bound of its own:
  `LIMIT depth + 1` on the branch of a producer the evaluator bounds, or the rendered
  depth *argument* of one that bounds itself. Where an inner bound and an outer one
  disagree the inner one decides the read. Lowering the branch's `LIMIT` from four to
  three on a bundle compiled for a nine-row producer at depth three returned
  `Exhausted { rows_emitted: 3 }` where the same bundle unedited reported
  `DepthReached { rank: 3 }`, and lowering the depth argument of a self-bounding
  producer did the same -- verbatim the defect two earlier fixes each closed one copy
  of.

  No number the ending depends on is held as text now. A compiled unit carries its
  query as the parts it was assembled from -- the producer IRI, the argument slots the
  request placed, the positions the candidate and block columns are read from -- and
  `StratumUnit::sparql()` renders the whole query on every read, with the branch's row
  ceiling and the unit's own bound both computed from the one proved depth. The branch
  bound is not decoration and is not deleted: it is the row ceiling the evaluator
  pushes down to the relation, so it is rendered rather than written. The compiled text
  is byte-identical to what it was, at every depth and for both producer shapes.

  Driving the executor over a query of one's own stays open through
  `StratumUnit::new`, and such a unit is now a different kind of unit rather than a
  differently-spelled one. Its query form reaches the evaluator byte for byte -- except
  that a dataset clause, which the sub-select grammar has no place for, is moved to the
  wrapper, where it scopes the same body -- this
  layer bounds only its outside, and what the text bounds inside itself is no part of
  what this layer reads of it -- so that read is never certified `Exhausted`. It reports the new ending
  `StreamEnding::SuppliedQueryEnded`, surfaced as `ProducerReceipt::SuppliedQueryEnded`
  and `ProducerStatus::SuppliedQueryEnded`, which names the caller's own text as the
  stopper and claims nothing about what lies below the rank it reached. `Exhausted`
  remains the only ending that names no stopper, in a vocabulary that now has seven
  spellings rather than six.

  The refusal is exactly as narrow as the observation. A caller's query still runs,
  still yields its rows in rank order, still reports `DepthReached` when a row past the
  depth really did arrive -- that is an observation whatever bounded the text -- still
  reports its parse failure as that stratum's status when it cannot be prepared, and
  still trips `ExecutionError::RowBoundBreached` when the producer beats its own
  declaration. Refusing to run such a text instead would have been the over-refusal:
  most of those queries are perfectly good, and what cannot be done honestly is certify
  a completeness claim from one. `DepthApplication` is gone with the field it was
  needed beside.

- **retrieval:** The top-k narrowing was withheld from a single-stratum plan whose
  producer declares `CandidateDomains::Unrestricted`, where the disjointness premise it
  was withheld for is vacuous. Disjointness is a statement about pairs; with one
  surviving stratum there is no pair, every candidate the answer can hold was named by
  that one stream, and its rank order *is* the fused order -- so a `k`-row prefix is `k`
  candidates under `DuplicatePolicy::Unique` alone, with no domain declaration needed.
  The cost fell on the read rather than on the answer, which is why it was quiet:
  identical rows, identical scores, and a top-five over a declared ten-billion-row index
  recording a depth of 4294967294 and emitting `LIMIT 4294967295` where the same answer
  came from five rows. Neither shipped ranked relation declares a domain, so this was
  the ordinary single-index configuration rather than an exotic one. `licensed_prefix`
  now returns the bound for exactly one surviving stratum whatever its domains; the
  `Unique` condition still applies, and a second surviving stratum restores the pairwise
  rule unchanged, re-derived per request from the registry in hand. Proved by a
  differential through `search` at three bounds -- the narrowed answer is the
  un-narrowed answer's prefix, row for row, score for score and stratum rank for
  stratum rank.

- **retrieval:** A producer declaring the genuinely unbounded `u64::MAX` rows per
  invocation, with no cardinality statistic and no licensed prefix, was refused, while
  the same producer declaring ten billion was served at the deepest readable depth and
  reported `DepthReached`. Both reads are cut at the same depth by the same bound with
  the same probe row, so the refusal separated a declaration from its own neighbour --
  `u64::MAX` refused, `u64::MAX - 1` served -- and bought nothing the ending does not
  already report. The refusal predated the clamp that made it obsolete: it existed
  because recording `u32::MAX` claimed a bound no producer declared *and* left the
  compiler no room for the probe row, and recording the read ceiling instead fixed both.
  Such a stratum is now recorded at that ceiling like any other oversized declaration,
  with its probe row one past it, so a read the ceiling cuts ends `DepthReached` and
  claims nothing about the rows below it. The neighbours are executed rather than
  reasoned about: the unbounded declaration, the one below it and an ordinary
  declaration a read can reach all plan, and the last is untouched.

- **retrieval:** A fusion test counted rank collisions in a fixture that cannot
  collide. It walked the profile's curve over the ranks its bounded read pulled and
  required the trailer's collision counter to equal that walk, "not an estimate from the
  profile's bound" -- but at the fixture's weight of `Fixed::ONE` the first colliding
  rank is 1000941, so the walk was provably zero over a read of seven ranks and the
  assertion was `0 == 0`. It would have passed with the counter emptied, and with the
  estimate its own message forbids. It now runs at the weight whose decay collides from
  rank two, which is the weight its two sibling tests use to enter that regime, and
  carries the non-vacuity guard those siblings carry: the pulled ranks must contain a
  collision before the count over them is asserted. The separation half of the test,
  which was never vacuous, is unchanged.

- **python:** A ranked producer declared with more than one candidate-domain tag
  failed at the wrong time. One tag entails where every row of that producer
  lies, so a consumer reads the block off the declaration; several tags say only
  that the rows lie somewhere in the set, which obliges the producer to name each
  row's own block -- and both ranked relations this binding can build project a
  candidate and a score and declare no such column, because a tag describes how a
  host's corpora partition and only the host knows that. The declaration was
  therefore unsatisfiable by construction, and the fusion said so at the first row
  it pulled, after the plan, the compile and the first read had all been paid for.
  It is refused at registration now, where the caller can act on it, naming the
  producer, quoting the blocks in canonical order and naming the three exits that
  work: one tag, one producer per block, or `domains=None`. A list that repeats
  one tag names one block and still registers, and single-tag declarations are
  untouched -- including the shorter read they buy.

- **python:** `MutableDataset._store_capsule` is declared in the type stub. The method
  went live so `Shapes.validate_store` could reach a mutable dataset's frozen snapshot
  by name, and the stub never said so — a member the stub omits is one a checked
  caller cannot see at all, including to see that it is private. The stub-parity
  gate is what caught it.

- **python:** Two `text_producers` entries claiming one stratum are refused with a
  `ValueError` naming both producers and the stratum. The registry underneath
  enforces one-stratum-one-producer with a panic, which is the right shape for Rust
  code assembling a registry and the wrong one at this boundary: it crossed into
  Python as `PanicException`, which derives from `BaseException` and slipped past a
  host's `except Exception`, taking the process down with a thread dump on stderr
  where every neighbouring misconfiguration on the same surface raises by name. The
  scan runs after the declarations are sorted, so the two names reported are a
  function of what was declared and not of the dict's insertion order, and the
  message carries the same guidance the registry's own refusal does: shards whose
  scores are comparable belong inside one producer, producers scoring by different
  laws belong in two strata. The same two producers under two strata fuse as before.

- **python:** A host that ran a compiled retrieval unit's SPARQL itself had no way
  to learn how many of its rows it was allowed to report. The compile stage emits
  the text at most one row deeper than the plan reads, and that last row is a
  probe that exists only to tell an exhausted producer from a depth-cut read: it
  is read and never reported. Rust callers have carried the reportable bound on
  the unit all along; the Python unit dict exposed only `"stratum"` and
  `"sparql"`, so the text's `LIMIT` was the only number in reach and it is the
  wrong one. Each unit now carries `"depth"` beside its text -- the bound the
  plan itself recorded, not a number re-derived from the emitted `LIMIT` -- and the
  surface states the obligation: keep at most `"depth"` rows. The emitted `LIMIT`
  reaches one row past the depth at every depth a plan can carry -- including a
  depth that already sits on the producer's declared row bound -- so the text's own
  number is never the reportable one. `"planned_resolution"` was no fallback
  either: it is empty unless the call names a fusion law.
- **python:** Two binding tests over the compiled unit claimed coverage they did not
  have. The one for a probe row emitted where the producer's declaration leaves no
  room asserted only that the emitted bound is one past the depth -- which holds for
  every unit -- so it was its own sibling under a second name, and it could not
  detect a bound wrongly capped at the declaration, the single regression it exists
  for, because it never checked that the depth had reached the declaration. Both
  tests now assert the configuration they rest on, read off the unit's
  `"declared_rows"`: equal to the depth in the one, strictly above it in the other.
- **python:** The test over the six terminal status spellings asserted them against
  `retrieval.search`'s docstring -- the binding suite's only assertion on a
  `__doc__`. A docstring that contains a string proves nothing about which string
  the mapping emits, and that test would have passed with the mapping deleted or
  emitting the wrong word. It now pins the three endings this surface can actually
  produce (`"exhausted"`, `"depth_reached"`, `"ceiling_reached"`) and says which
  three it cannot, with the reason recorded beside the refusals in the binding's own
  header: `"row_bound_reached"` needs a self-bounding producer -- one whose
  declaration places the depth as an argument the producer reads -- and the one
  relation this surface registers places none; `"terms_rejected"` is a receipt a
  producer writes for itself; and `"execution_failed"` needs a unit whose text could
  not be prepared or run. All three remain live for a host driving the Rust surface
  with a bundle of its own, and all six stay spelled and mapped.
- **python:** The stub-signature sweep held three engines to the built extension and
  not the fourth. Its own docstring explained that the sweep runs over each engine's
  whole surface so a future entry point is covered without anyone remembering to add
  it, while the engine list was a hand-written triple that `retrieval` was missing
  from -- so the entire `class retrieval:` stub shipped with nothing mechanically
  holding it to the PyO3 signatures that mypy approves callers against. `retrieval`
  is in the sweep and its six entry points match their bindings. The vacuity guard
  is now per engine as well as overall, because a total floor cannot tell a sweep
  that visited every engine from one whose stub block stopped parsing.
- **python:** The `retrieval.compile` stub claimed one exception to the emitted
  bound: that a producer declaring no rows at all is read with a `LIMIT` equal to
  its `"depth"`. The text carries `depth + 1` unconditionally, and the number a
  self-bounding producer is *asked* for is the one its declaration caps -- two
  different numbers -- so the sentence contradicted the paragraph two above it and
  told a host running the text itself to expect a bound it will never see.
- **retrieval:** A fused answer could contain the same entity twice. Certifying a
  candidate removes it from the frontier, and the check that held a stream to its
  declared uniqueness read only the frontier, so a stream naming that entity again
  afterwards started a fresh candidate and the answer carried it a second time --
  with a score summed from one stratum instead of all of them. The invariant a
  consumer needs is unconditional, for any stream set, any declared policy and any
  bound, so it is now enforced against every arrival rather than against the window
  that happened to be open: a candidate that leaves the frontier by certification
  leaves behind the set of streams that named it, and a stream that names it again
  is refused by name. A stream declaring that repeats happen is unaffected -- its
  repeat is dropped before it becomes a head, which is what that declaration asks
  the consumer to do. The cost is charged against emissions rather than pulls, so a
  bounded call holds at most as many entries as rows it returns however long the
  streams are, and what a uniqueness declaration buys its way out of is still
  bought: there is no per-row identity set per stream.
- **retrieval:** A fused top-k drained every stream. Certification asks whether any
  open stream could still name a candidate, and with nothing to answer that
  question it had to assume every open stream could -- so over strata whose
  candidate sets do not overlap, no candidate was ever final while another stream
  remained open, and a top-ten over two million-row strata read two million rows
  and grew a frontier to match. Weakening the test was not available: the engine
  has no random access, so the only way to learn that a stream does not name a
  candidate is to read it to its end, and certifying sooner would emit a score
  missing a contribution and call it exact. Exact scores and a bounded read are
  jointly reachable only if fusion is told which candidates a stream can name, so a
  producer now declares its candidate domains and the finality test keeps its
  meaning while gaining a smaller quantifier. Two thousand-row disjoint strata at a
  bound of five read four ranks each where they previously read a thousand, and a
  stratum that names everything keeps the bound for its neighbours instead of
  collapsing it. The answer is unchanged: rows, scores and provenance are identical
  to the draining run and to an independent oracle across hundreds of
  configurations, and the ranks read never rise as a declaration is refined.

  What the bound bounds is stated exactly, because the number above invites a wider
  reading than it earns: it is the ranks **fusion pulls from a stream**, and the
  frontier it therefore has to hold. It is not the producer's work. Each stratum's
  rows are materialized by the evaluator up to the depth the plan recorded before
  fusion pulls anything, so a stratum planned a thousand deep is read a thousand
  deep whatever the bound later turns out to need — the evaluator's egress model is
  a complete answer, with no cursor surface for a consumer's bound to reach back
  through. A ranked producer's own cursor is lazy and stays lazy; what is not lazy
  is the boundary between it and this layer.
- **retrieval:** Fusion no longer refuses a well-formed producer stream when the
  profile's own fixed-point decay gives two adjacent ranks one contribution. A
  producer's ordering declaration is a claim about **ranks**, and the check was
  applied to **contributions** -- a value the consumer computes from the decay
  rule, `K`, the stratum weight and the rank, re-derives on arrival and refuses
  on mismatch, and which the producer supplies no term of. Ranks are separately
  held contiguous and ascending for every stream, so an equal adjacent pair only
  ever meant the arithmetic had stopped separating those ranks at that depth. A
  conforming stream read deep enough was rejected for the consumer's own
  quantization: at a weight of `10^-6` this began at rank 973, and no weight at
  all postpones it past about a million ranks under the truncated rule. The
  condition is now measured and reported rather than refused; past that depth the
  declared tie-break is total, so the answer stays correct and deterministic at a
  coarser rank resolution.
- **sparql-algebra:** A repeated `LIMIT` or `OFFSET` is refused instead of
  overwriting the bound the caller already wrote.
  `LimitOffsetClauses ::= LimitClause OffsetClause? | OffsetClause LimitClause?`
  admits at most one of each, in either order, but the parser read them in an
  unbounded loop that reassigned the field every pass -- so `LIMIT 2 LIMIT 13`
  parsed, the bound of two vanished, and a query asking for two rows returned
  thirteen. A silent drop of the caller's own bound is the mirror of an
  over-refusal, and the loop made it reachable from every SPARQL entry point at
  once: the same parse backs `SELECT`, `CONSTRUCT`, `DESCRIBE`, `ASK` and the
  sub-select. Accepting it was not leniency anyone could rely on either, because
  the query means one thing to this engine and another to a conforming
  processor. The refusal is a typed syntax error naming the clause that repeated
  and pointing at that repeat's keyword, and the reading it replaced is the only
  one that moved: both clause orders, either clause alone, neither clause,
  `LIMIT 0` as a real zero-row bound, and a bound past any plausible row count
  all parse exactly as before. No other solution modifier had the overwrite
  shape -- each of the others is read by a single conditional, so a repeated
  `GROUP BY`, `HAVING`, `ORDER BY` or `VALUES` was already refused, and that is
  now pinned alongside.

- **sparql-eval:** a property-function call that is the whole right-hand side of a `LATERAL` (`?s ?p ?o LATERAL { ?q <rel> ?out }`) is admitted with a request substitution or prepared-execution parameter bound, as the rewrite invokes it, where it was refused as "reachable only as `ff`" against a relation serving only the bound mode; admission and the rewrite share one definition of that position.

- **sparql-eval:** a `BIND` reading a promised parameter makes its target a source for a following call — everywhere under the SHACL pre-binding rewrite, above the core pattern under the ordinary one — so `BIND($this AS ?x) ?x <rel> ?why` is no longer refused.

- **sparql-eval, shapes:** under SHACL pre-binding, a `BIND`, `FILTER`, `HAVING`, `ORDER BY` key, `SELECT` expression, `UNFOLD`, `OPTIONAL` condition or aggregate argument reading a blank-node or quoted-triple focus node sees that node wherever it sits: beneath the core pattern, above a `GROUP BY`, and above a sub-`SELECT` whose projection drops `$this`. Beneath the core it saw an unbound variable, so a relation could be invoked with its input free and every node it approved was reported; above a `GROUP BY` or such a sub-`SELECT` the column holding the focus node was hidden, so `SELECT ?v WHERE { ?x ex:tag ?v } GROUP BY ?v HAVING(SAMPLE(?x) = $this)` reported a violation for an IRI focus node and conformed for a blank one with the same data, through `sh:sparql` and `sh:SPARQLSelectValidator` alike. The expression now reads the focus node through a variable of its own that no query can name, bound by a one-row `VALUES` beside the node and projected away above it, so it reads exactly the term an IRI or a literal focus node is written in as. An `EXISTS` in such an expression whose body names `$this` — `HAVING EXISTS { ?r ex:about $this }` — is now matched against rows carrying the focus node for every kind of focus node, an IRI included; it had matched a free `$this`, so every group passed.

- **sparql-eval:** an aggregate's output can feed a relation serving only the bound mode. `COUNT`, `SUM`, `AVG`, `GROUP_CONCAT` and `FOLD` answer a value over no values (`0`, `0`, `0`, `""`, the empty list), so they count with or without `GROUP BY`; `SAMPLE`, `MIN`, `MAX` and a custom aggregate count under `GROUP BY` over arguments reading only certainly-bound variables, and not without it, since the one implicit group over an empty input hands them no value. A grouping key is a source only where every grouped row binds it.

- **sparql-eval:** a `FILTER` makes certain every variable its condition requires bound to be true, so `GROUP BY ?q` or a sub-`SELECT` of `?q` after `OPTIONAL { … ?q }` feeds a relation serving only the bound mode when a `FILTER(BOUND(?q))`, `FILTER(sameTerm(?q, ?o))`, `FILTER(isLiteral(?q))` or a conjunction holding one of them passes only rows binding `?q`; such a key had been refused since the grouping-key rule above. A disjunction makes certain only what both of its sides do, and `FILTER(!BOUND(?q))` nothing. A built-in function has no value when an argument it is strict in is unbound, so `FILTER(REGEX(STR(?q), "."))`, `FILTER(STRLEN(STR(?q)) > 0)` and `FILTER(-(STRLEN(STR(?q))) <= 0)` make `?q` certain too, where they had been refused as though a function call could be true without its arguments; which argument positions each built-in is strict in is read off the evaluator and held to it by a test that evaluates every built-in with each argument unbound — `REGEX`'s and `REPLACE`'s flags, `SUBSTR`'s length, the type tests, `cdt:List`, `cdt:Map` and `cdt:put`'s value are not strict, and a custom function, which the host registers, is taken to require nothing. `IF(c, t, e)` requires what its condition needs for a value and what either the condition's truth and `t`'s, or its falsity and `e`'s, require, and a constant that is never true drops its branch, so `FILTER(IF(BOUND(?q), ?q = ?q, false))` makes `?q` certain while `FILTER(IF(BOUND(?q), true, true))` and `FILTER(COALESCE(STR(?q), "x") != "")` make nothing certain. An aggregate follows the rule a `BIND` does: it counts even where its argument or its fold can fail on the data — `MAX(STR(?q))` and `SAMPLE(IRI(STR(?q)))` exactly as `BIND(IRI(STR(?q)) AS ?y)` followed by `SAMPLE(?y)`, `SUM` over a string, `GROUP_CONCAT` over a blank node — and a group whose aggregate failed reaches the call with its input unbound, where the evaluator refuses that row with a typed access-pattern error for a relation serving only the bound mode and invokes one that also serves the free mode free, as it does for a row whose `BIND` erred. A relation is never invoked free unless it declares the free mode.

- **sparql-eval:** a request substitution or prepared-execution parameter now reaches a property-function call anywhere in a `LATERAL`'s right side where writing it there is the same as joining it on above — beside a `BIND`, a `VALUES`, a triple or a `FILTER`, in a nested `LATERAL`, a `UNION`, a `GRAPH`, or a sub-`SELECT` that projects it (`SELECT *`, `DISTINCT` and `ORDER BY` included), and in such a sub-`SELECT` joined anywhere else — so a relation serving only the bound mode is admitted there and invoked with the value, where it was refused as "reachable only as `ff`" although the same text with the value written into a `VALUES` block was admitted with the same rows. It reaches too beneath a `GROUP BY` the variable is a key of — `{ SELECT ?q (COUNT(?out) AS ?n) WHERE { ?q <rel> ?out } GROUP BY ?q }`, joined, in a `LATERAL`'s right side, or grouping a `UNION` whose other arm leaves `?q` unbound — since the rows that writing it there removes are whole groups keyed by other values, whose rows the substitution's seed drops anyway; those shapes had been refused while the same text with the value written into a `VALUES` block was admitted with the same rows. A call in an `OPTIONAL` or `MINUS` arm inside that right side, in a sub-`SELECT` that does not project the variable, beneath a `LIMIT`, or beneath a `GROUP BY` whose keys do not include the variable — one only an aggregate or an expression key such as `(STR(?q) AS ?k)` reads — is still refused, and a relation serving both modes is invoked free there. Admission and the rewrite still share one definition of where the value is written, held shape by shape against each other.

- **sparql-eval, retrieval:** `register_ranked` admits a declared `ExclusionBasis::Membership` only against a point mode an exclusion lookup can be invoked in — binding the candidate, leaving any `DepthPlacement` position free, with a row bound of one — because every lookup frees the depth: asked with a depth the producer answers "is this candidate among your best n", and absence from that is not an exclusion. A producer declaring `[fbb, bbb]` with its depth at position 2 was admitted and then failed every stratum's lookup at prepare; it is refused at registration, naming the relation, its modes and why. The lookup's shape is derived once, `RankedDeclaration::exclusion_lookup_mode`, which registration and the retrieval compiler both ask.

- **retrieval:** a stratum this layer renders no longer fails at search when its producer's only candidate-bound point mode binds an argument no request facet fills: `compile` checks the rendered lookup's mode and compiles such a unit declaring `ExclusionBasis::Unavailable`, so the stratum still ranks and its contract and the fused trailer's `exclusion_bases` say no lookup was available.

### Removed

- **retrieval:** `PlanError::StatisticsUnavailable`. It was the refusal of an unbounded
  row-count declaration that no statistic narrowed, and nothing raises it any more: such
  a stratum is recorded at the deepest depth a read can be taken to, exactly as every
  other declaration larger than a read can reach already was, and the read's own ending
  names the planned depth as the stopper. Leaving the variant in place would have left a
  public error whose documentation described a plan this planner no longer refuses.
  `PlanError` is `#[non_exhaustive]`, so a caller matching on it already carries a
  wildcard arm; one matching this variant by name now matches a refusal that cannot
  arrive.

- **sparql-eval:** `RelationWitness::canonical_bytes`, and the encoding version tag
  behind it. It was a second canonical encoding of "what the indexes attested",
  and the only one nothing shipped: every caller was a determinism test comparing
  it against itself. The encoding an answer is actually compared by lives in
  `purrdf-retrieval`, which collapses the ledger per stratum and digests the result
  into its `EvidenceId` -- and the ledger could not have been that encoding's
  source, because it is keyed by relation IRI rather than by stratum, holds sets
  where an answer's evidence holds one generation and one service level, and counts
  invocations, a quantity that follows the evaluator's chunking of driving rows
  rather than anything an index said. An evidence identity derived from it would
  have moved between two runs over one unchanged index. The ledger's own
  determinism is now pinned as what it is -- an ordered value whose declarations are
  identical across repeated runs and across the fork -- and the shipped digest is
  pinned through the shipped path, including that it does not move with the
  invocation count.

- **python:** Every Rust test module under `bindings/python/src` -- roughly
  fifteen hundred lines across ten files, holding fifty-six `#[test]` functions
  that no gate has ever built. The crate sets `test = false` for a sound and
  documented reason (see the new hygiene gate above), so those modules were
  compiled by nothing and run by nothing; one of them had silently accumulated a
  shadowing error that no gate could have reported. Every property each asserted
  is now asserted where it runs. Most were already covered by the pytest suite or
  by a live test in the crate that owns the logic; the rest are covered by new
  pytest tests -- the whole `purrdf.shex` surface (which had none at all), the
  native term model's own identity and RDF 1.2 refusals, blank-node scoping across
  and within a `Store.load`, the validation snapshot seam behind
  `Shapes.validate_store`, codec fidelity for private-use language tags and
  non-canonical lexical forms, the eight-format egress registry, RDFC-1.0
  determinism over isomorphic graphs, the per-call SPARQL engine configuration,
  `RdfDataset`'s layer classification, and seven further properties of the ranked
  retrieval surface.

- **retrieval:** `ProtocolError::RepeatedContribution` and
  `AdmissionError::DepthBeyondMonotoneRange`, the two refusals above, at the
  fusion boundary and at the admission waist respectively. The plan depth the
  second refused is now recorded as evidence on the compiled value instead.
- **retrieval, sparql-eval:** The rank-ordering declaration, in both places it
  stood: `StreamContract::ordering` on the consumer side and
  `RankedDeclaration::ordering` with its `RankOrdering` enum on the producer
  side. Its only reader in the workspace was the removed check, and a two-valued
  declaration nothing consults is a knob with no behaviour. Rank order is one
  law, not a choice: ranks are 1-based, contiguous and ascending for every ranked
  stream, and fusion checks every row against the next rank it expects from that
  stream -- a lower rank is `ProtocolError::OutOfOrderRanks`, a higher one
  `ProtocolError::NonContiguousRanks`. Producers no longer state the field;
  `TextSearchRelation::ranked_declaration` and
  `EmbeddingKnnRelation::ranked_declaration` build one field fewer.

  A registry's `content_fingerprint` covers a ranked declaration field by field,
  so dropping that field changes the fingerprint of every registry holding a
  ranked producer. A plan records the fingerprint it was admitted against, so
  plans pinned under an earlier build no longer match a registry built by this
  one and must be re-planned. Nothing else moved: a fusion profile's identity is
  a function of the fusion law alone and is byte-for-byte unchanged.
- **retrieval:** `ProtocolError::NonMonotoneContribution`, and with it the
  per-row ordering comparison that raised it. Contributions still must not rise
  with rank -- the threshold summed over the stream heads is an upper bound only
  while they do not -- but that has stopped being a fact a stream can get wrong
  on its own. Fusion re-derives every row's contribution from the decay rule,
  `K`, the stratum weight and the rank and refuses a disagreement as
  `ProtocolError::ContributionMismatch`, over ranks already held contiguous and
  ascending, and the profile's own curve never rises, because a profile refuses a
  weight at or below zero both when it is constructed and when it is decoded from
  canonical bytes. A rising value is therefore necessarily a value the profile
  did not compute, and it is refused as the wrong number it is rather than
  reported as a shape of the stream -- so nothing conforming or hostile reached
  the removed variant, in either direction. Non-increase is now stated where it
  is enforced, and proven where it is true: as a property of the decay rule's
  arithmetic over the weights a profile admits.
- **retrieval:** `FusionError::CeilingExceeded`, and the per-row comparison of a
  candidate's running score against `FusionProfile::ceiling()`. The ceiling is
  still the profile's admitted maximum and `ceiling()` still reports it; it is
  now enforced by construction rather than by testing each sum against it. A
  candidate receives at most one contribution per stratum, which fusion does
  check, and `K >= 1` with a 1-based rank caps every reciprocal at one half, so
  every contribution is at most half its stratum's weight and the largest sum a
  fusion can reach is exactly half the ceiling. The one configuration whose raw
  arithmetic lands on the ceiling exactly needs two contributions under a
  one-stratum profile, so the contribution count refuses it first --
  `CeilingExceeded` was never observed for it, or for anything else.
- **retrieval:** `FusionProfile::new`. It supplied a default decay rule while the
  same type documents that neither rule is a default, and the one it chose has a
  depth ceiling no weight can lift. Call sites name `with_decay` explicitly, which
  preserves every previously computed profile identity byte for byte.

  Every removal above, including the ordering declaration, touches no released
  API: `RankOrdering`, `RankedDeclaration::ordering` and the producer-side field
  they gave `purrdf-sparql-eval` were themselves added earlier in this same
  unreleased cycle and never reached a release. What the ordering declaration's
  removal does change is the registry content fingerprint, within this cycle: a
  plan pinned against an intermediate build of it no longer matches a registry
  built by this one and must be re-planned.

### Changed

- **BREAKING** **cdt, geo:** composite and geometry nesting is bounded by memory alone.
  `purrdf_cdt::MAX_NESTING_DEPTH` and `CdtError::DepthExceeded` are removed; a
  composite is bounded by `MAX_ELEMENTS` and `MAX_LEXICAL_BYTES`, and every level is
  one element. `CdtValue` and `CdtTripleTerm` implement `Drop` iteratively (so a
  `CdtTripleTerm` is no longer destructured by value), `CdtTerm`'s `Clone` and `Debug`
  are iterative with byte-identical output, equality and ordering own the values they
  resolve out of nested `cdt:`-typed literals instead of re-entering the comparator,
  and `canonical_lexical_len` reads a length every value carries. `purrdf_geo` reads
  and writes nested geometry collections over explicit stacks, its `Geometry` drops,
  clones, compares and prints iteratively, and the 64-deep WKT nesting cap is gone; its
  GeoJSON reader and writer, its JSON reader and writer (`purrdf_geo::json::MAX_DEPTH`
  and the 128-container cap are removed), and its measure, boundary, location and
  relation walks run over explicit stacks.

- **wasm, build:** `purrdf_wasm::interleaving` is the ledger of every `thread_local!`
  under `crates/` the asynchronous lane can interleave, each with the reason it is safe
  under suspension (swapped per job as one `JobAmbient`, per call, or never spanning a
  suspension), and `scripts/check-thread-locals.py` holds the ledger and the tree equal
  in both directions in `make check` and CI. Whether an operation must run
  sequentially is a fact on the evaluation context, not a thread-local.

- **BREAKING** **sparql-eval:** `MAX_HOPS_CAP` is removed and `PathLimits::new`
  accepts any `max_hops` a `u32` holds. The path-relation traversal keeps every piece
  of per-depth state on the heap, so the cap that stood in for a stack budget names
  nothing; the two resource guards bound the work a walk does.

- **BREAKING** **sparql-eval, sparql-algebra, wasm:** an unsupported request no longer
  reads as a development stage or as a server fault. `EvalError::Unsupported` renders
  as `unsupported: …` (it was `unsupported in sparql-eval (S6 scope): …`) and
  `ParseError::Unsupported` as `unsupported SPARQL construct: …` (it was
  `… (purrdf S5 scope): …`). An unclassified `EvalError::Unsupported` carries its own code at the
  engine boundary, `native-sparql-unsupported` (`EvalError::UNSUPPORTED_CODE`), where it
  used to carry `native-sparql-query-eval` or `native-sparql-update-eval` like an
  evaluation that failed; without `SILENT`, a `SERVICE ?e` bound to a literal or a
  blank node is now that refusal too, not a federation error. The Cloudflare adapter's `handleSparqlRequest`
  answers a request the engine refuses to evaluate as written
  (`native-sparql-unsupported`, `native-sparql-custom-function`,
  `native-sparql-quoted-triple-term-variable`, `native-sparql-host-stack-exhausted`)
  with a `400` whose `code` is that diagnostic code and whose `detail` is the refusal,
  where it answered `500 Internal Server Error`; a host fault is still the sanitized
  `500`.

- **BREAKING** **sparql-eval, wasm:** `SERVICE SILENT` follows SPARQL 1.1 Federated
  Query §3.2, which answers an invocation that does not succeed with Ω0 under
  `SILENT` and with an error without it, whatever the reason it did not succeed. A
  catalog denial (`EvalError::ServiceDenied` in 2.0.2) and a host's refusal are now
  the join identity under `SILENT`, like a transport failure, an undecodable
  response, a disabled source and a source that reaches no such endpoint; each is
  recorded on the evidence (see Added). A `LATERAL` clause and a custom scalar
  function call inside a `SERVICE SILENT` body are forwarded as written, where 2.0.2
  refused them: an endpoint that rejects them fails the invocation, which `SILENT`
  answers with Ω0. A variable endpoint bound to a term that is not an IRI is such a
  failure too. This engine's own governors — a ceiling, a cancellation, a deadline —
  and its stack refusals are not invocation failures and still truncate or fail the
  query whether or not `SILENT` is written; so do the refusals of a property-function
  call or a custom aggregate inside a forwarded body. Without `SILENT` every outcome
  is the error it was.

- **BREAKING** **sparql-eval, wasm:** `GraphResolver::resolve` returns a typed
  `LoadError` — `Transport`, `Decode`, `Denied` (a `ServiceDenial`), `HostDenied`,
  `Fault` or `Governed` (the request's own stop signal) — where it returned an
  `RdfDiagnostic`; `LoadError::code` is the diagnostic code a `LOAD` without
  `SILENT` fails with (`native-sparql-load-failed`, `native-sparql-load-decode`,
  `native-sparql-load-denied` for the catalog's refusal,
  `native-sparql-load-host-denied` for the host's own policy,
  `native-sparql-load-fault`, `native-sparql-load-stopped`), and the message is
  `LOAD <iri>: ` followed by the error. An implementation maps its failure onto a
  variant instead of choosing a code. `LOAD SILENT` follows SPARQL 1.1 Update
  §3.1.4, under which the operation "will still return success" when it fails:
  every `LoadError` but `Governed`, and a missing resolver, is a success with nothing
  loaded, recorded on the update's evidence as a `SilencedInvocation` naming the
  source. That is 2.0.2's behaviour for an unreachable source and a missing
  resolver, now extended to a refusal. `Governed` is reported as the governor trip,
  `SILENT` or not, on a governed update.

- **BREAKING** **sparql-eval:** each `SERVICE` outcome carries its own code at the
  engine boundary, where every one used to carry `native-sparql-query-eval` or
  `native-sparql-update-eval` like an evaluation that failed.
  `EvalError::ServiceDenied` carries `native-sparql-service-denied`
  (`EvalError::SERVICE_DENIED_CODE`), `EvalError::ServiceHostDenied`
  `native-sparql-service-host-denied`, and `EvalError::Remote`, an endpoint that was
  asked and gave no usable answer, `native-sparql-service-failed`. A `SERVICE` with
  no source that reaches its endpoint is the new `EvalError::ServiceUnconfigured`,
  where it was `EvalError::Remote`, and carries
  `native-sparql-service-unconfigured`. Its message is unchanged, and under
  `SERVICE SILENT` it is the join identity, as it was. A host can now tell a refusal to ask
  an endpoint from an endpoint that failed, and both from a host that had no way to
  ask, without reading message text.

- **BREAKING** **sparql-eval:** `UnsupportedKind::GraphPatternDepthExceeded` and its
  code `native-sparql-graph-pattern-depth-exceeded` are removed (`UnsupportedKind::ALL`
  has three entries). The `wasm32` graph-pattern depth limit it reported is the
  host-stack budget, not a construct deferred in scope: both wasm lanes keep a
  request's evaluation within a 640 KiB budget under V8's call stack, and a plan past
  it — graph patterns nested past 284 levels, a tree taller than 2 048 levels plus
  eight per nested group, expressions and paths nested past 2 304 levels — is
  `EvalError::HostStackExhausted` (`native-sparql-host-stack-exhausted`) before it
  runs, on either lane. Parsing spends none of that stack, so nesting that builds no
  node — brackets, a group around a single element, a bracketed path — is not
  limited. A host that matched the removed code matches
  `native-sparql-host-stack-exhausted`; the remedy is a request nested less deeply. On
  `wasm32` the `native-sparql-evaluation-stack-exhausted` message names no remedy,
  since a JavaScript caller cannot choose a thread's stack; natively it says to run
  the request on a thread with a larger stack.

- **release:** under this suite's full-semver rule, the breaking changes below
  make the next release a MAJOR version. Several of them change surfaces that no
  release has shipped yet: `purrdf-hnsw`, `purrdf_core::distance`,
  `RankedDeclaration` and `Scalar`. They are listed so that a consumer of an
  intermediate build can see every break. The exact-kNN fold order, the
  float-environment refusal and the MSRV change released behaviour.
- **gts:** gzip now runs on `purrdf-deflate`, and `flate2` (with `miniz_oxide`,
  `crc32fast`, `adler2` and `simd-adler32`) left the dependency graph. Decoding a
  gzip transform, a `.gz` transport stream or a gzip tar stream now decodes
  **every** member and refuses bytes after the last member that do not begin
  another; before, only the first member was decoded and anything after it was
  ignored. The `gzip` transform and gzip tar output are still deterministic
  (`MTIME` 0) but their compressed bytes differ from earlier releases (the header
  is now `XFL` 0, `OS` 255, and the encoder is a different one); the decoded bytes,
  and so content identities over them, are unchanged.
- **gts:** the zstd transport decoder reads frame by frame: every frame is
  decoded, skippable frames are skipped wherever they occur (a leading one was
  refused before), and bytes after the last frame that do not begin another are
  refused.

- **BREAKING** **sparql-eval:** `QueryOptions` has two new public fields, `remote`
  and `load`, and is now `#[non_exhaustive]`: a struct literal (with or without
  `..QueryOptions::EMPTY`) no longer compiles from outside this crate, so a field
  added in a future release cannot silently reopen this same break. Construct with
  `QueryOptions::new()` (identical to `QueryOptions::EMPTY`/`Default::default`) and
  a `with_<field>` builder method per field — `QueryOptions::new().with_env(&env)`
  — which is `#[must_use]` and `const fn` where the field type allows it. The
  fields stay ordinary `pub` and remain readable, matchable and directly
  assignable on a `mut` value from outside the crate; only the struct-literal
  construction form is restricted.

- **BREAKING** **sparql-algebra:** an operator chain is one n-ary algebra node.
  `Expression::Or` and `Expression::And` hold their operands as a `Chain` of two or
  more. `Expression::Add`, `Subtract`, `Multiply` and `Divide` are replaced by
  `Expression::Arithmetic(first, steps)`, whose steps — a `NonEmpty` list — pair the
  new `ArithmeticOperator` with an operand. `GraphPattern::Union` holds `arms`, a
  `Chain`, in place of `left` and `right`. `Expression::or`, `Expression::and`,
  `Expression::arithmetic` and `GraphPattern::union` extend a chain the way the
  parser does. Each node is the left fold of the binary operator it replaces:
  every operand is evaluated left to right, `||` and `&&` keep SPARQL's
  three-valued errors, arithmetic keeps its type promotion, rounding and errors
  step by step, and a union's rows and columns come in arm order. Charged one
  level per operator, a generated `FILTER` of 513 `||` alternatives and a
  600-term `+` chain were refused as nesting, and a 600-branch `UNION` was
  refused by the evaluator's graph-pattern depth guard. A chain of any length now
  parses and answers, and a `UNION` is as tall as its tallest arm. The serializer
  writes each chain flat, so a `SERVICE` body holding
  one is forwarded as text that re-parses. A left operand in brackets extends the
  chain: `(a + b) * c` is one node. A `UNION` of three or more arms is one plan
  node, so the `EXPLAIN` ledger lists fewer nodes for it.
  `PropertyPathExpression::Sequence` and `PropertyPathExpression::Alternative`
  hold their elements as a `Chain` in place of two boxed operands, and
  `PropertyPathExpression::sequence` and `PropertyPathExpression::alternative`
  extend a path chain the way the parser does. A sequence is the left-nested chain
  of `/` it replaces: the same pairs, and on a path with no repetition operator the
  same multiplicity for each, one per chain of matching triples. An alternative is
  the bag union of its elements in order. Charged one level per operator, a
  generated 512-step `p1/p2/…` path or a 512-way `p1|p2|…` alternative was refused
  as nesting; a path chain of any length now parses and answers, and a `SERVICE`
  body holding one is forwarded flat. A bracketed left element of the same operator
  extends the chain: `(a/b)/c` is one node. A chain of fewer than two nodes, or an
  arithmetic chain with no step, is not representable: `Chain::new` takes the first
  two nodes, `NonEmpty::new` the first step, and `try_from(Vec)` hands a shorter list
  back.

- **BREAKING** **sparql-algebra, core:** every whole-tree operation over the query
  algebra and over `TermValue` runs without recursion, so the machine stack it needs
  is the same however deep the tree is: a tree a million levels deep is copied,
  compared, hashed, formatted, serialized and dropped on a thread with a 128 KiB
  stack. The algebra's owning edges are new types in `purrdf_sparql_algebra::tree`,
  re-exported at the crate root:
  - `Child<T>` replaces `Box<T>` for every boxed operand, inner pattern, `EXISTS`
    body and quoted triple (`TermPattern::Triple`, `GroundTerm::Triple`). It
    dereferences like a `Box`, is built with `Child::new` or `.into()` (from a value
    or a `Box`) and is unboxed with `into_inner()`;
  - `Chain<T>` holds two or more nodes (the operands of `Or`/`And`, the arms of
    `Union`, the elements of a path `Sequence`/`Alternative`), `NonEmpty<T>` one or
    more (the steps of `Arithmetic`), and `Args<T>` any number (the lists of
    `FunctionCall`, `Coalesce` and `In`, which may be empty). `Chain` and `NonEmpty`
    dereference to a slice and are rebuilt with `map`, `try_map`, `map_ref` and
    `try_map_ref`; `Args` dereferences to its `Vec` and converts from one.

  The edges own the drop, which takes a subtree apart over a work list, so the node
  enums implement no `Drop` and still destructure by value. `Clone`, `==`, `Hash` and
  `Debug` on `GraphPattern`, `Expression`, `PropertyPathExpression`, `TermPattern` and
  `GroundTerm` are hand-written over work lists: `Debug` writes exactly what the
  derive wrote, in both `{:?}` and `{:#?}`, while `Hash` feeds a different — still
  injective — sequence than the derive did. `purrdf_sparql_algebra::walk` (`NodeRef`,
  `walk_pre_post`, `fold_post_order`) is the one enumeration of a node's children
  these walks, validation and the retained-size count share. The serializer and
  `PropertyPathExpression`'s `Display` are one loop over a work list with unchanged
  output.
  `Query::retained_size_bytes` charges a tree of any height in full, where it
  answered `usize::MAX` past 256 nested containers. In `purrdf-core`,
  `TermValue::Triple`'s components are the new `TermBox` in place of `Box<TermValue>`
  (re-exported by `purrdf-rdf` and `purrdf`), and `TermValue`'s `Clone`, `==`, `Ord`,
  `Hash` (feeding the same sequence as before), `Debug`, `canonical_bytes` and drop
  walk a work list. A shallow tree's walk keeps its work list in the walk's own frame,
  so it allocates nothing beyond what the derived traits allocated.

- **BREAKING** **sparql-algebra, sparql-eval:** the SPARQL parser runs without
  recursion, so how deeply a request nests is bounded by memory alone, the same on
  every host: every construct of the query and update grammars written a hundred
  thousand levels deep parses on a thread with a 128 KiB stack, and the tree it
  builds is dropped there too. Group graph patterns, sub-`SELECT`s, solution modifiers
  and expressions are read by one pushdown machine over heap-allocated stacks, with
  expressions by operator precedence; triples (blank-node property lists,
  collections, triple terms, reifying triples, annotation blocks), property paths,
  quoted triples and `VALUES` triple terms by loops over stacks of their own. The
  algebra, the error kinds, the byte offsets and the messages the parser produces are
  unchanged: the snapshot of every in-repository request parses to a byte-identical
  golden. Nothing is refused for its nesting any more: `MAX_GRAPH_PATTERN_DEPTH` and
  `MAX_GRAPH_PATTERN_NODES` are removed, and `Query::validate` no longer refuses a
  tree for its height. The
  evaluator admits a plan's height itself, iteratively and at the same per-level
  charge, before its recursive passes — at preparation and on every evaluation — so
  a plan too tall for the evaluating thread is `EvalError::StackExhausted` naming
  `"query algebra"` (`native-sparql-evaluation-stack-exhausted`; on `wasm32`, past the
  host-stack bounds, `EvalError::HostStackExhausted`,
  `native-sparql-host-stack-exhausted`). `EvalError::from` a
  `ParseError` is always `EvalError::Parse`, a parse diagnostic always carries the
  query or update parse code, and an in-process `SERVICE` body that fails to re-parse
  is a decode failure. A caller that matched the removed constants or a parse-time
  nesting refusal drops that handling; a caller that needs a ceiling on nesting
  applies its own.

- **BREAKING** **datalog, shapes, entail, validate, cli, python, wasm, capi:** the
  stored-fact and join-step ceilings are no longer constants. `MAX_STORED_FACTS`
  and `MAX_JOIN_STEPS` are removed; the limits are `EvalOptions` parameters with
  per-target defaults (`DEFAULT_MAX_STORED_FACTS`, `DEFAULT_MAX_JOIN_STEPS`,
  `WASM_DEFAULT_*`, `NATIVE_DEFAULT_*`). `BudgetReport` carries the limits a run
  was governed by (`join_step_limit`, `stored_fact_limit` and their `_stated`
  twins, `governed_by`). `EvalError::BudgetExhausted` and
  `ChaseError::BudgetExhausted` render as "evaluation exceeded the stored-fact
  limit: N facts observed, M permitted (…); raise it with …" rather than "the
  fixed … ceiling". `LimitKnobs::new` takes four knob names, `RuleLimit` gains
  `StoredFacts` and `JoinSteps`, and `RulesRequest` gains `max_stored_facts` and
  `max_join_steps`. The contract hash folds the EFFECTIVE limits into every
  program's digest, so every native contract hash moves (the `wasm32` digests
  are the previous values) and every entailment report's `contract-hash` line
  moves with it; the entailment golden corpus, the tri-host regime vectors and
  the pinned calculus hashes are regenerated. The regime vectors are checked
  under the native defaults stated (`REGIME_GOLDEN_VECTOR_LIMITS`), so a
  `wasm32` host reproduces them byte for byte. The C functions
  `purrdf_shacl_apply_rules` and `purrdf_entail_materialize_to_nquads` gain two
  nullable parameters, riding the unshipped ABI 0.8.0 bump; the WebAssembly
  functions gain two trailing optional arguments.

- **BREAKING** **shapes:** the JSON-LD instance projection
  (`instance::project_graph`, `project_subject`) changes shape so that it drops
  nothing a constraint judges. A well-formed RDF list is now the JSON-LD list
  object `{"@list": [...]}`, and its cells are no longer `@graph` nodes;
  `rdf:nil` is `{"@list": []}`. The list conversion of JSON-LD 1.1 Processing
  Algorithms and API section 8.4.2 decides which lists convert, read strictly so
  that no triple is dropped. A member list carries its head cell's label as
  `@index`. An `@id` is now the full IRI, never a compact IRI; keys and `@type`
  stay compacted. A bare JSON scalar now appears only for a canonical
  `xsd:integer` within 64 bits and for `xsd:boolean` `true` or `false`. Every
  other numeric literal, `xsd:decimal` and `xsd:double` included, keeps its
  `{"@value", "@type"}` object. An `rdf:dirLangString` literal carries
  `@direction`. Value-vocabulary enum members are `{"@id": <full IRI>}` to
  match. The JSON Schema compiler changes in lock-step, and a consumer that
  reads projected documents must read the new forms.

- **BREAKING** **shapes:** a built-in constraint component's declaration that
  carries validators binds natively. SHACL 1.2 SPARQL Extensions selects "one of the
  values" of `sh:nodeValidator`, `sh:propertyValidator` or `sh:validator` as a
  constraint's validator, so each declared validator is an alternative implementation
  of the same component; the native implementation is the one that runs, and the
  declared ones are checked against the syntax rules (type, query form and grammar)
  and never executed, so their queries may call functions the engine does not have.
  A pre-binding violation in one refuses nothing, because it never executes; the lint
  report lists it under `unexecuted` (see below). Such
  a declaration used to be refused as a duplicate definition. A body, an `sh:ask` or
  an `sh:select` stated on the component itself is still a duplicate definition, a
  contradicting signature is still a mismatch, and a validator that is not a
  well-formed SPARQL validator of its attachment — an untyped node, an ASK validator
  under `sh:nodeValidator` or `sh:propertyValidator`, a SELECT validator under
  `sh:validator`, an unparsable query, a SHACL-JS `sh:JSValidator` under any
  attachment — is refused. Newly refused: an `sh:`
  statement on a built-in's declaration other than its signature, its validators,
  `sh:message`, `sh:labelTemplate` or a non-validating characteristic (`sh:severity`
  on `sh:MinCountConstraintComponent`, for one), which the native implementation
  would not honour.

- **BREAKING** **shapes, validate, cli, python, wasm, capi:** a SHACL-SPARQL or SHACL-AF
  declaration that violates a syntax rule refuses the load whether or not any shape
  reaches it. SHACL 1.2 Core, "Handling of Ill-formed Shapes Graphs", says "A SHACL
  processor SHOULD produce a failure in this case" with no reachability qualifier.
  Refused: a non-SELECT value of `sh:nodeValidator` or `sh:propertyValidator` and a
  non-ASK value of `sh:validator`, on a built-in or a custom component
  (`nodeValidator-class`, `propertyValidator-class`, `validator-class`); a validator
  without exactly one `xsd:string` query, or with a query that does not parse to its
  form (`ask-count`, `ask-datatype`, `ask-sparql`, `SPARQLSelectValidator-select-count`,
  `select-query-valid`); an ill-formed result annotation or prefix declaration on a
  validator; a component parameter named `this`, `path`, `PATH` or `value`
  (`parameter-name-not-in`) and the other parameter rules; a `sh:SPARQLFunction`
  parameter named one of those or `shapesGraph` or `currentShape`, which SHACL
  Advanced Features takes from the SHACL-SPARQL parameter rules; a `sh:SPARQLFunction`
  without exactly one `sh:ask` or `sh:select`, with an unparsable body, or with a
  SELECT body that does not project exactly one variable (`SPARQLFunction-query`).
  The refusal is the new `ShapesError::IllFormed(IllFormedShapesGraph)`, which lists
  every violation in the graph as an `IllFormedDeclaration` naming the declaration and
  the rule id (`[syntax rule nodeValidator-class]` in the message).
  A pre-binding violation (a `MINUS`, a `VALUES`, an `AS ?var` for a pre-bound
  variable) is not a syntax violation: SHACL 1.2 SPARQL Extensions, Appendix A,
  requires a failure for a query "executed with pre-bound variables". It refuses the
  load, as the new `ShapesError::Prebinding(PrebindingViolation)`, only where a query
  executes: the validator a use of a custom component selects, or a
  `sh:SPARQLFunction` that a node expression or reachable SPARQL calls, directly or
  through another function's body. A function body is now checked against Appendix
  A's three rules over its parameter variables. A function with no parameters binds
  nothing, so none of them applies to it. A validator of a built-in component never
  executes, and neither does a validator no use selects or a function nothing calls.
  Those load, and the lint report gains a fifth section, `unexecuted N`
  (`unexecuted unavailable` over a refused graph), with one `violation DECLARATION`
  line and its `error` lines for each. Each is a finding.
  `LintReport::unexecuted` carries them, and Python's `lint_shapes` dict gains
  `"unexecuted"`. SHACL-JS reachability is unchanged. A shapes graph that imports a
  library whose unused declarations violate syntax rules, as DASH's do, is refused
  until those declarations are repaired.

- **BREAKING** **shapes, validate, cli, python, wasm, capi:** the lint report gains a
  fourth section, `validators N` (`validators unavailable` over a refused graph), with
  one `alternative <COMPONENT> <ATTACHMENT> VALIDATOR LANGUAGE superseded-by-native`
  line per validator declared for a built-in component; never a finding.
  `LintReport::alternative_validators` and the new
  `purrdf_shapes::validator_alternatives` module (`AlternativeValidator`,
  `ValidatorLanguage`) carry it, `LinkedDeclarations` gains `alternative_validators`,
  and Python's `lint_shapes` dict gains `"alternatives"`.

- **BREAKING** **core, shapes, entail, validate, cli, python, wasm, capi:** one import
  rule reads OWL headers and SHACL shapes-graph roles in every engine. An `owl:imports`
  on EVERY SHACL instance of `sh:ShapesGraph` — typed `sh:ShapesGraph` or
  `sh:RulesGraph`, or typed a class the document declares `rdfs:subClassOf*`
  `sh:ShapesGraph` — is now an import (SHACL 1.2 Core §6.1), in validation, rules,
  node expressions, lint, shapes products and entailment alike: unsupplied it is refused
  by name, supplied it is merged. Such a triple was data before. OWL 2's `owl:Ontology`
  header is read through `rdfs:subClassOf*` too. A node whose only graph role is
  `sh:DataGraph` still imports nothing (SHACL 1.2 Core §6.2, "owl:imports in the data
  graph is not enacted"), and the data graph's own `owl:imports` are never enacted
  whatever they sit on. An import of `<X>` is now also resolved in place when the closure
  declares `<X> a sh:ShapesGraph`. The kernel's module documentation no longer claims to
  name no vocabulary beyond OWL's (`docs/SUPERSEDED-CLAIMS.md`).

- **BREAKING** **shapes, validate, cli, python, wasm, capi:** the lint report text gains
  the `unanchored-imports N` section between `unexecuted` and `findings` on every host,
  so a consumer that matched the report's tail sees one more section.

- **BREAKING** **toolchain:** the MSRV is now 1.98, raised from 1.96.
  `Reassociated` uses `f64::algebraic_*`, which was stabilized as
  `float_algebraic` in Rust 1.98.0. A 1.97 compiler rejects the crate with
  E0658. Cargo, the CI msrv job, `clippy.toml`, the READMEs, AGENTS,
  CONTRIBUTING and the book all say 1.98.

- **BREAKING** **sparql-eval/hnsw:** the exact kNN scan and every HNSW distance
  site now fold in the `Exact` 16-lane tree order instead of sequentially.
  Distances can differ in the last bits, so the order of near-tied exact kNN
  answers can change. This supersedes the earlier entry in this section that
  said the accumulation order of `knn::Kernel::distance` was unchanged. Every
  dispatch path and target returns the same bits, and a scalar reference model
  of the fold order proves this in the tests. `knn::norm` delegates to the single
  normative PURREMB norm fold.

- **BREAKING** **sparql-eval:** the float-environment refusal. kNN checks the
  calling thread's floating-point environment when an embedding space is built
  from an artifact and on every search, exact or reassociated. It refuses an
  environment that flushes subnormals to zero, treats denormals as zero, or
  rounds other than to nearest, ties to even. The check is behavioural, so it
  runs on every target and refuses only an environment observed to depart; no
  target is refused for having a control register this build does not read. The
  refusal is the new `EvalError::FloatEnvironment`. `EvalError` is
  `#[non_exhaustive]`, so the variant itself breaks no match, but a query that
  used to run under such an environment now fails by name.

- **BREAKING** **core:** `FloatEnvironmentError::FlushToZero` and
  `FloatEnvironmentError::RoundingMode` carry one field, `evidence`, of the new
  `#[non_exhaustive]` `FloatEnvironmentEvidence`, in place of `register` and
  `bits`. A pattern that named `register: "MXCSR"` now names
  `evidence: FloatEnvironmentEvidence::Register { name: "MXCSR", .. }`. A
  refusal on a target whose register is not read carries
  `FloatEnvironmentEvidence::Probe`.

- **BREAKING** **hnsw:** the image and index version is now 2 (`INDEX_VERSION`,
  `profile::PAYLOAD_VERSION`). The header's reserved word becomes the arithmetic
  field, and zero names no arithmetic. A version-1 image, whose distances were
  folded sequentially, is refused with `HnswError::VersionMismatch`. Rebuild the
  index from its vectors. The implementation id is now `hnsw-v2`
  (`IMPLEMENTATION_ID`), `hnsw-reassociated-v2` is added beside it, and the
  profile declaration binds the arithmetic id.

- **BREAKING** **hnsw:** `HnswIndex<A: Arithmetic = Exact>`, and likewise
  `HnswSpace<A>` and `HnswRelation<A>`. `build`, `decode`, `load` and
  `from_artifact` are unchanged and exact. `HnswError` is not
  `#[non_exhaustive]`, and it gains three variants, so an exhaustive `match`
  stops compiling:
  - `ArithmeticMismatch`, when a payload records another arithmetic's code;
  - `ArithmeticPathUnavailable`, when a payload records a dispatch path this
    process cannot run. `available` is the widest path the process runs;
  - `FloatEnvironment(FloatEnvironmentError)`, raised by every build, rebuild
    and search entry point under a flush-to-zero or non-nearest environment.

- **BREAKING** **hnsw:** a reassociated image records the build that computed it,
  not only the dispatch path. Two builds recording one path could compute
  different bits, and a mismatched pair used to pass the path check and then
  answer `verify_rebuild` with a bare `Ok(false)`, which reads as tampering.
  - The header of a reassociated image (codes 2 to 8) carries the build shape
    (`purrdf_core::distance::BuildShape`, layout 2) right after the arithmetic
    code: a `u64` of target architecture and feature bits, then the `u64`
    digest of the build's `BuildIdentity`. Exact images carry neither, so their
    bytes do not change and `GOLDEN_DIGEST` and `GOLDEN_SERIAL_DIGEST` do not
    move. No reassociated golden is pinned. An image from an intermediate build
    of this cycle, with no shape or a layout-1 shape, is refused.
  - `HnswError` gains `ArithmeticBuildMismatch { recorded, here }`. Decode,
    `guard::load_reassociated`, `HnswIndex::verify_rebuild` and
    `guard::verify_rebuild` raise it for an image recorded by a build of another
    shape: other feature bits, or another compiler, target CPU, optimisation
    level, debug-assertion state or codegen flags. Its message lists both feature
    sets and both identities, and says which half differs.
  - Under an equal path and shape the rebuild compiles to the code that built
    the image, so a rebuild that produces another image is `Ok(false)` from both
    `verify_rebuild`s (`None` from `verify_bytes_against`), the same tamper
    evidence an exact image gives.
  - The reassociated profile declaration ends with `build-shape=<bits>` and
    `build-identity=<digest>` lines, so the implementation digest binds the
    build. The evidence revision now says the image is reproducible only by a
    build of the shape that made it, on the same dispatch path, and that a build
    of another shape refuses it.

- **BREAKING** **sparql-eval:** `Scalar` is sealed and implemented for `f32` and
  `f64` only. `RankedDeclaration` gains the public `arithmetic` field, a
  `RankArithmetic`, so a struct literal must state the ranking arithmetic in
  every case. `EmbeddingKnnRelation` gains a type parameter,
  `EmbeddingKnnRelation<A: Arithmetic = Exact>`, and `new` is unchanged and
  exact.

- **BREAKING** **core:** `Arithmetic` exposes `IMAGE_CODES` and
  `image_code(path)`, and `Path` gains the reassociated variants.

- **BREAKING** **sparql-eval/hnsw/core:** every public distance entry point takes
  the resolved handle that checked the float environment, so no distance can be
  computed on a thread that flushes subnormals or rounds other than to nearest.
  Before, the batch scans refused such a thread by name while the per-pair entry
  points computed on it and returned different bits.
  - `knn::Kernel::distance` and `knn::Kernel::distance_bounded` take a
    `Resolved<Exact>` as their first argument after `self`:
    `kernel.distance(Exact::resolve()?, query, query_norm, candidate, candidate_norm)`.
    `knn` now re-exports `Exact` and `Arithmetic` beside `Reassociated` and
    `Resolved`, so a caller resolves through the same path it names the kernel by.
    Resolve once per call site and pass the `Copy` handle to every pair.
  - `purrdf_hnsw::VectorMatrix::distance`, `distance_from_query` and
    `distance_bounded` take a `Resolved<A>` for either arithmetic as their first
    argument, before the `Kernel`. The unresolved forms are gone.
  - `purrdf_core::distance::Exact::distance` and `Exact::distance_bounded`, the
    handle-free pair functions, are removed; `Resolved::distance` and
    `Resolved::distance_bounded` are the per-pair forms.
  - The L2 norm a cosine kernel divides by follows the same law, because the
    norm fold is arithmetic too: under flush-to-zero a row with a subnormal norm
    folded to `+0`. `purrdf_core::distance::norm` and `knn::norm` are removed;
    the norm is `Resolved::<Exact>::norm(vector)`, a method of the exact handle
    only, since PURREMB §13.2 gives the fold one written order and no
    reassociated form. A caller holding another arithmetic's handle obtains the
    exact one with the new `Resolved::exact()`, which carries the environment
    that handle already proved: `arithmetic.exact().norm(query)`.
  - `purrdf_hnsw::VectorMatrix::norm_of_row(row)` becomes
    `norm_of_row(arithmetic, row)` with a `Resolved<Exact>`.
  - PURREMB's deterministic-L2 projection is the same fold and a division, so
    `purrdf_core::EffectiveMatrixView::f32_row` and `f64_row` take a
    `Resolved<Exact>` after the row (exact stored bytes stay readable without one
    through `raw_prefix_bytes` and `native_f32_row`/`native_f64_row`), and
    `purrdf_hnsw::guard::read_effective_matrix` takes one after the view. The
    writer (`EmbeddingBuilder::build`, `EmbeddingStreamWriter`) and
    `verify_embedding` resolve it themselves, once, where a normalized projection
    is present, and refuse a flushing thread with the new
    `EmbeddingError::FloatEnvironment` rather than sealing a digest no IEEE reader
    recomputes or reporting an honest artifact as a digest mismatch; an artifact
    with only raw projections involves no arithmetic and is still written and
    verified on any thread. `HnswError` maps that variant to its own
    `FloatEnvironment`, and `HnswSpace::from_artifact` now resolves before it
    verifies, so the refusal keeps its name.
  - The handle cannot be carried to another thread either. Before, `Resolved<A>`
    was `Send + Sync`, so a handle resolved on a clean thread could be copied to
    one that flushes subnormals and every kernel then ran there unchecked;
    `HnswIndex` stored one and shared it with the rayon workers of
    `search_batch`, and the reassociated kNN relation stored one for every
    search. `Resolved<A>` is now `!Send` and `!Sync` (still `Copy`); a structure
    that outlives a thread stores the new `Selected<A>` and resolves it on the
    thread that computes. `HnswIndex::arithmetic()` returns a `Selected<A>`
    instead of a `Resolved<A>` (its `path`, `image_code`, `evidence` and
    `build_shape` are unchanged; call `.resolve()?` for a handle).
    `EmbeddingKnnRelation::resolved()` is replaced by
    `EmbeddingKnnRelation::selected()`, returning `Option<Selected<A>>`, and
    `knn` re-exports `Selected`. Every HNSW search, `row_distance`,
    `verify_rebuild` and every kNN scan and membership lookup resolves on the
    calling thread; `search_batch` and the build's parallel proposals resolve
    once inside each rayon worker. A worker that flushes subnormals is refused
    with `HnswError::FloatEnvironment` or `EvalError::FloatEnvironment` by name,
    whichever thread built the index or relation.

- **hnsw:** goldens that moved, re-pinned by hand. Distances now fold in the
  16-lane tree order, and the image header carries the arithmetic field.
  - `GOLDEN_DIGEST`: `0x0c71_b169_ebb4_4d7e` → `0xa367_d6c5_8963_1389`.
  - `GOLDEN_SERIAL_DIGEST`: `0x7e11_7799_b79a_b829` → `0xf0b2_fd33_0bcc_fcc7`.

  The `knn_wasm_determinism` expectation did not move, because its
  6-dimension fixture only reaches the sequential tail. New 70-dimension
  fixtures pin the lane path natively, on wasm32 and on wasm32+simd128.

- **build:** `make wasm-test` and `make hnsw-determinism` also run a +simd128
  build. The HNSW script reads its module path from cargo's artifact messages.
  The maintainer binaries `capture_sparql_goldens`, `gen_dict_vectors` and
  `gen_streamable_vectors` are renamed `capture-sparql-goldens`,
  `gen-dict-vectors` and `gen-streamable-vectors`. Their source paths are
  unchanged.

- **BREAKING** **retrieval, sparql-eval:** `RankedStream` gains a required
  `exclusion(&mut self, candidate: &Term)` method, and defaulted `rows_materialised`
  and `settle` methods; a hand-written stream that declares no basis answers
  `exclusion` with `ProtocolError::ExclusionUnavailable`. `StreamContract::new` takes
  the stream's `ExclusionBasis` as a fourth argument and `StreamContract` carries it
  as `exclusion`, and `RankedDeclaration` gains the required field `exclusion`: there
  is no default, because `Unavailable` would discard a capability a producer has and
  `Membership` would claim one it may not. The basis joins the ranked declaration's
  canonical description, so the registry content fingerprint moves and a plan pinned
  against a registry built before this change must be re-planned.

- **BREAKING** **retrieval:** a stream now carries its prepared exclusion lookup and a
  borrow of the dataset, so `RankedStreamImpl`, `StratumStream`, `ExecutionResult`
  and `RankedStreamAdapter` gain a lifetime parameter and `execute` returns an
  `ExecutionResult<'d>` borrowing its dataset. `StratumResolution` gains the public
  fields `exclusion_lookups` and `rows_materialised`, `FusionTrailer` gains
  `exclusion_bases`, and `PlannedResolution` gains `sharing_weights`, so none of
  them can be built by struct literal from an older field list; `PlannedResolution`
  is no longer `Copy`, and `PlannedResolution::fully_separated` takes `&self`.

- **BREAKING** **retrieval:** The read bound moved into `RetrievalRequest`, so a
  bounded answer costs a bounded *read*. `RetrievalRequest` gains a `bound` field
  of the new `ReadBound` -- a total enum over the bounded case and the complete
  one, because "give me the top five" and "give me everything these strata hold"
  are both things a caller asks for and neither is the absence of the other. `plan`
  derives each stratum's depth from it, `Plan` records it and digests it into
  `Plan::id`, and `search` reads it from the request instead of taking a separate
  `top_k`. The bound used to arrive at `fuse`, four stages after every depth had
  been chosen: a fused top-five over two strata whose producers declare disjoint
  candidate blocks walked a handful of ranks and reported so, while the compiled
  unit was still `LIMIT <corpus>` -- so the elapsed time grew with the corpus while
  the instrument said it had not. Only the measurement had moved.

  When the bound narrows a depth is decided from the producers' own declarations
  and from nothing else, with no caller hint and no mode. Where every stratum
  declares a block set, no two of those sets meet, and every one of those strata
  declares `DuplicatePolicy::Unique`, each candidate has exactly one naming stratum
  and each of that stratum's ranks names a different candidate, so its fused score
  is one weighted contribution that falls with rank and the global top `k` is a
  merge of per-stratum prefixes: nothing below per-stratum rank `k` can enter it,
  even where the decay has saturated and the scores tie, because the tie-break's
  next key is the stratum rank those candidates win on. The depth is therefore
  `min(declared, statistics-narrowed, k)` and it is exact rather than merely
  smaller. Any overlap between two declarations, any `Unrestricted` stratum, and
  any stratum declaring `DuplicatePolicy::Allowed`, and the declared-or-measured
  bound stands exactly as before -- scores sum across strata in the first two cases
  and a discarded repeat makes a count of rows larger than the count of candidates
  in the third, so the merge argument has no premise to run on. Rows, scores and
  provenance are identical either way.

  A bound also gives a finite depth to a producer that declares unboundedly many
  rows, where previously only a measured cardinality could: such a read, taken for
  an answer that provably cannot use more than `k` rows, is a read of `k` rows.
  The same declaration asked for everything is not refused: it is recorded at the
  deepest depth a read can be taken to, and the read's own ending names that depth
  as the stopper. `PlanError::StatisticsUnavailable`, which used to refuse it, is
  removed in this same release.

  The probe row is untouched: the emitted bound is still the depth plus one
  wherever the declaration leaves room, and a depth *argument* is still never
  raised past the producer's own registration. It matters more at a tight depth
  than at a loose one.

- **BREAKING** **retrieval:** `fuse` refuses a bound the streams were not planned
  for, as `FusionError::ReadBoundMismatch`. `CompiledRetrieval::fused_bound`
  resolves a plan's `ReadBound` once into the row count a fusion of its units must
  run at, `execute` tags every `StratumStream` with it, and `RankedStream` gains a
  defaulted `fused_bound` so a stream assembled outside the ladder still fuses at
  whatever its caller names. It is a sibling of `PlanIdMismatch` rather than a case
  of it: that one is a disagreement among the streams about their provenance, this
  one is a disagreement between the streams and the caller's own argument, and the
  repairs differ. It closes a latent defect -- a plan could be fused at any bound,
  including one its depths could not honestly serve, with nothing catching it.

- **BREAKING** **retrieval:** `PLAN_VERSION` is 4. A plan now records **every
  input each stratum's depth was derived from** — the registry's declared row
  bound, the reported cardinality, the selectivity that was actually applied
  together with the request terms it aggregates over, and whether the request's
  row bound was licensed to bound that stratum — in a new `stratum_derivations`
  field. `Plan::certify` recomputes each depth from the inputs beside it through
  the same arithmetic the planner ran (`depth_from`, also public) and refuses a
  plan the two disagree about; `Plan::explain_depth` names which input bound a
  depth, which distinguishes the four roads to a depth of one that were
  previously indistinguishable. Both are cold paths: admission does not call
  them.

  Certifying is the whole coherence question rather than the arithmetic alone.
  Beyond `DepthNotDerivable` it refuses a depth with no derivation and a
  derivation with no depth, a stratum the snapshot names nowhere
  (`DerivationWithoutStatisticsEntry`), a snapshot row that says something else
  than the derivation beside it (`StatisticsEntryContradictsDerivation`, naming
  the dimension that moved), and a recorded selectivity domain that indexes a
  term the request it was planned for does not carry
  (`SelectivityTermOutOfRange`). Which stratum a refusal names is a function of
  the plan: every walk is over sorted keys, so two processes refusing one forged
  plan name the same one.

  Version 3 appended the request's read bound after the per-term unserved
  evidence because a plan that did not record it "recorded depths whose
  derivation could not be reconstructed". That bound is what the caller asked
  for, and whether it was *allowed* to bound a given stratum is decided
  separately, from the shape of the surviving declarations — so two plans could
  agree on every recorded field and still have derived their depths from
  different numbers. Version 4 closes that, along with the declared row bound,
  which no plan recorded at all.

  `StatisticsEntry.cardinality` is now `Option<u64>`, absent where the provider
  reported none, under the same presence discriminator its selectivity already
  used. A provider that reported only a selectivity narrowed a planned depth and
  was then dropped from the snapshot entirely, so the plan was built against
  evidence it did not record. `StatisticsEntry` also carries
  `selectivity_terms`, the request-term indices its aggregate came from: the
  aggregate is a sum, so a provider moving the same total onto a different term
  previously left a byte-identical plan describing a different measurement. That
  domain is a strictly ascending set of indices into the request a plan records,
  and a plan is held to it: a run out of order is `NonAscendingSelectivityTerms`
  and a repeated index is `DuplicateSelectivityTerm`, both at decode, where the
  fact is decidable from the run alone; an index addressing no term of the
  request is `SelectivityTermOutOfRange`, at `Plan::certify`, where the request
  is. An empty run is legal and is the common case — it is what a subject no
  selectivity was reported for records.

  The snapshot's entries name **every subject planning consulted** — each stratum
  a depth was derived for, and each predicate the request names. A stratum's row
  is a projection of its `DepthInputs` rather than a second consultation, which
  is what `StatisticsEntryContradictsDerivation` holds up; a request predicate's
  row derives nothing and is context alone. A subject nothing consulted is absent
  rather than recorded as empty, and both halves of that are checked: a stratum
  named nowhere is `DerivationWithoutStatisticsEntry`, and a row naming anything
  outside those two kinds is `UnconsultedStatisticsSubject`. Enforcing only the
  first would have left a plan able to *add* evidence — a row reads back as a
  consultation whether or not one happened.

  Their order is the value's law and not the encoder's.
  `StatisticsSnapshot.entries` is a `StatisticsEntries`, which establishes the
  ascending order on construction and refuses a repeated subject by name
  (`DuplicateStatisticsSubject`) on every path in, serde's included. A sort at
  the encoder would have made the bytes a pure function of the entries while
  leaving the value order-sensitive, so a descending snapshot and its ascending
  twin would have shared an identity and compared unequal.

  A canonical document must arrive in the order the encoder writes. Every keyed
  section — the depths, the derivations and the snapshot's entries — is required
  to ascend at decode, as `NonAscendingCanonicalKeys` carrying a typed
  `CanonicalSection`, and a repeat in each is refused by that section's own name:
  `DuplicateStratumDepth`, `DuplicateStratumDerivation`,
  `DuplicateStatisticsSubject`. A decoder that accepted any order would have
  admitted as many documents for one plan as its sections have permutations, each
  digesting to that plan's single id.

  Planning gains one refusal of its own: `PlanError::UndeclaredRowBound`, raised
  by `retrieval::plan` and by nothing else -- it reaches a caller of `plan`, never
  a caller of `compile` -- for a producer placed on a stratum whose declaration
  states no row bound at the mode it is invoked under. Placement and the row-bound
  read then disagree about one snapshot of the registry, so it ends the whole plan
  where a placement failure rejects only the producer it is a fact about:
  continuing would have derived every other stratum's depth from the same broken
  reading.

  A version-3 plan's bytes lie at different offsets under this layout, so the
  decoder refuses the old version by name instead of misreading it. Every plan
  identity moves, as does the plan document's JSON, which now carries
  `"stratum_derivations"` and `"selectivity_terms"`.

- **python:** A plan can leave the process and be checked on the way back in.
  `retrieval.plan` returns that plan's canonical, length-framed encoding under
  `"canonical_bytes"` — the bytes `"plan_id"` is the digest of — and
  `retrieval.certify_plan` reads one back, refusing it or returning it rendered
  exactly as `plan` renders it. `retrieval.explain_depth` answers which input
  bound one stratum's depth in a received document, from the same closed
  vocabulary `plan` renders under each derivation's `"cause"`. The plan dict also
  carries `"stratum_derivations"`, one entry per stratum with every input its
  depth was derived from.

  Every refusal from that boundary raises `retrieval.PlanDocumentError`, a
  `ValueError` subclass carrying a pinned kebab-case `.refusal` name — branch on
  that, never on the message. The names are the engine's own and the class
  documents all of them. A host that has not certified a document it received is
  reading a depth nothing checked.

- **BREAKING** **python:** `retrieval.plan` and `retrieval.compile` take the
  `top_k` keyword `retrieval.search` already took, and all three require it. The
  row bound is a planning input, so a `plan` or `compile` call without one would
  report a depth, a `LIMIT` and a `plan_id` for a read nobody asked for.

  The whole ranked-retrieval declaration surface postdates the last release, so
  every change above moves an API no published version carries.

- **retrieval:** A stratum depth is floored at one row, whether the zero came from
  a statistics provider or from the registry's own declaration. A bound narrows a
  read; it never eliminates one. A provider reporting a selectivity of zero parts
  per million, or a cardinality of zero, scaled a stratum's depth to zero: the
  compiled unit read nothing and the trailer still reported exhaustion with zero
  rows, which is the one ending that names no stopper, minted for a query that
  was never run. A tiny non-zero selectivity was already safe through
  ceiling division; zero was the one input that escaped it, and it arrives by three
  roads -- an honest `selectivity_ppm` of zero, a measured cardinality of zero,
  which lands in the bound before the ratio is applied, and a producer whose every
  declared access mode promises zero rows per invocation. Emptiness is now reported
  by the producer's own receipt against rows fusion verified rather than by a plan
  that declined to ask.
- **retrieval:** A producer whose every declared mode promises no rows is selected,
  bound and planned at that floored row, so it runs and reports its own
  `Exhausted { rows_emitted: 0 }`. That declaration describes the producer's data
  -- a text index built before its documents land, or one over a predicate no
  triple carries yet, declares exactly it -- and the producer is perfectly
  invocable. Dropping it instead bound it nowhere, and where it was the registry's
  only producer, which is the shape of a host with one index, the whole plan then
  failed with `PlanError::NoApplicableProducers`: "no registered producer accepts
  any term of the request", about a producer that accepts the term. It also threw
  away the only receipt that could have made the emptiness the producer's claim.
  "Declared no rows" and "declared nothing" still stay distinct -- a producer that
  declared no access mode admits no invocation, so placement refuses it and its
  stratum bounds no depth, and inventing a zero for it would refuse a plan the
  registry never spoke against.
- **retrieval:** Admission admits a depth of one against a declared row bound of
  zero, and refuses every depth past it. The one row is the probe that lets the
  producer speak; a stratum no ranked producer emits under is still refused at
  every depth, because there is no producer there to hand a row to.
- **retrieval:** A compiled unit's emitted bound is floored at one row, so a
  producer declaring zero rows is bounded at `LIMIT 1` rather than at `LIMIT 0`.
  For every declared bound of one or more this changes nothing: an admitted depth
  is at least one, so the probe is at least two and the minimum was already at
  least one.
- **retrieval:** A recorded stratum depth of zero is refused at the admission waist
  as `AdmissionError::ZeroDepth`. Given the floors above, a zero can now only come
  from an edited plan; admitted, it would emit `LIMIT 0`, which hands back no row
  whatever the relation holds, and report the stratum exhausted with nothing -- a
  completeness claim about the bound rather than about the data, indistinguishable
  afterwards from an honest empty answer. A stratum that is to read nothing carries
  no depth entry at all.
- **retrieval:** A compiled unit is emitted one row deeper than its stratum reads,
  bounded by whatever row count the producer declared, and the executor hands on
  only the rows the depth allows. The extra row is read and never reported: it
  decides whether the stream ended because the producer ran out or because the
  plan stopped it, and it appears in no plan field, no identity and no resolution
  number. Where the depth already equals the producer's declared bound there is
  nothing further to promise, so no probe is emitted and exhaustion is honest by
  contract. A stratum read to its planned depth over a larger answer now says so,
  where it previously claimed the strongest completeness the vocabulary has for a
  read the plan itself had cut. The executor also now runs each unit through the
  governed entry with every ceiling declined, so it can read the producer's
  attestation off the receipt that already carries the run's evidence; a witness
  that does not describe exactly one relation, one generation and at most one
  incompleteness means the snapshot moved underneath the query and is refused as
  `ExecutionError::InconsistentWitness`.
- **retrieval:** `ProtocolError::DuplicateItem` now names the stratum whose stream
  repeated the item, beside the item itself. A repeated item names *what* went
  wrong and the stratum names *who*, and a consumer fusing several producers can
  act on the pair and on neither half alone: the item does not say which of five
  strata to go and fix, and the stratum does not say which of its rows to look at.
- **sparql-eval:** `RankedDeclaration` gains a `domains` field
  carrying the producer's `CandidateDomains`, declared beside its duplicate policy
  because the two are the same kind of fact -- a promise the producer makes about
  its own rows that a consumer holds it to. It reaches the registry's content
  fingerprint through `RankedDeclaration::canonical_description`, and so reaches a
  plan's identity and is verified at admission rather than taken on faith: two
  registries that differ only in what their producers may name fuse differently
  and must not share a digest. A host that does not restrict its candidates writes
  `CandidateDomains::Unrestricted`. The whole ranked-retrieval declaration surface
  postdates the last release, so this widens a type no published version carries.
- **BREAKING** **sparql-eval:** `RelationIdentity` gains a `witness` field. The
  fingerprint covers everything a registry *declares*, which is exactly what the
  planner reads -- and a relation's index can be rebuilt underneath it without any
  declaration changing, so two governed runs of one query over one dataset snapshot
  could carry byte-identical identities and different rows with nothing on the
  receipt to say why. The identity says which relations could have been asked; the
  witness says what the ones that were asked reported about themselves. All three
  parts are independently empty, and an empty witness is never a claim that an
  index was whole.
- **sparql-eval:** A query whose relation declares its index incomplete is refused
  at an entry point that cannot record the declaration, rather than returning the
  short bag. The governed lane, which has a receipt to carry the witness, answers
  and records it; the ungoverned lane and `UPDATE` refuse, and the update writes
  nothing. A relation that declares nothing short is unaffected on every lane.
- **text, sparql-eval:** `TextSearchRelation::ranked_declaration` and
  `EmbeddingKnnRelation::ranked_declaration` take the producer's `CandidateDomains`
  as a further argument, passed through into the declaration unchanged. Neither
  producer supplies one of its own, and neither could: the tags describe how a
  host's corpora partition, which is knowledge only the host has. A host that does
  not restrict its candidates passes `CandidateDomains::Unrestricted`, which is
  the behaviour both had before.
- **retrieval:** `DecayRule::class_width` and `FusionProfile::class_width`
  answer with the new `ClassWidth` rather than a bare `u64`, and the Python
  `retrieval.class_width` answers `int | None` rather than `int`. The search for
  a class's far end stops at the deepest rank a plan can express, so a class
  still running there has no counted end -- and it now says that, as
  `ClassWidth::ExceedsAnyPlan` and as `None`, rather than handing back
  `2**32 - 1` as though it were a width somebody measured. Raw weights of one
  and fifty are fifty times apart and both saturate under either rule, because
  every contribution has truncated to the same value; the bare number reported
  them as the identical width `4294967295`, a number a caller can log, plot or
  divide by, quoted precisely where nothing was counted. It also contradicted
  the function's own stated meaning, which is that a width of `w` is `w`
  consecutive ranks the fused score treats as equal. `ClassWidth` is a third
  type rather than a reuse of `MonotoneDepth` or `ToleratedDepth` because a
  width is a count of ranks and neither of those cases is: `SeparatesTo` asserts
  that every adjacent pair up to a depth is distinct and `ReadsTo` asserts that
  a read stopping at a depth stays inside a tolerance, and a width establishes
  neither. Its saturating case is also the opposite polarity -- a class with no
  end is inside no tolerance, where a depth that never collides is inside every
  one -- which `ClassWidth::fits_within` spells out beside `covers`. Confined to
  `purrdf-retrieval` and its binding, which have not yet been published, so no
  released API changes.
- **retrieval:** The documented relationship between a tolerance and the class
  at the depth it buys no longer claims an equality that does not hold. Four
  places -- `DecayRule::deepest_rank_within_width`,
  `FusionProfile::deepest_rank_within_width`, the Python docstring and
  `__init__.pyi` -- said the width there is "at least `max_width + 1`, two at a
  tolerance of one". The bound is right; the parenthetical is not. Under the
  truncated rule with `k` of 60 at a raw weight of `10^2` a tolerance of one
  lands on depth one, whose class is **forty** ranks wide, and at `10^2 + 21` it
  is sixty. Equality holds only where the run that ends the walk is one rank
  longer than the tolerance, which is the smooth case and is exactly the regime
  the two accompanying tests pinned -- a raw weight of `10^6` in Rust and
  `1000 * SCALE` in Python -- so neither could fail on it. The four sites now
  state only the bound, and a light-weight case is executed at both Rust
  altitudes and on the Python surface so that the corrected claim is held by a
  test that can fail.
- **retrieval:** `DecayRule::deepest_rank_within_width` and
  `FusionProfile::deepest_rank_within_width` answer with the new
  `ToleratedDepth` rather than a bare `u64`, and the Python
  `retrieval.deepest_rank_within_width` answers `int | None` rather than `int`.
  A plan records a per-stratum depth as a 32-bit rank, so a walk that runs to
  that ceiling has found no bound inside any plan's reach -- and it now says
  that, as `ToleratedDepth::ReadsBeyondAnyPlan` and as `None`, rather than
  handing back `2**32 - 1` as though it were a depth somebody measured. Two
  weights fifty times apart both reach the ceiling, and the bare number said
  they read to the same depth: a number a caller can log, plot or divide by,
  quoted precisely where no bound exists. `MonotoneDepth` had already drawn that
  line for the separating depth; the tolerated depth is a separate type because
  its cases claim something different -- above a tolerance of one the ranks it
  reports do share contributions, just never more than the tolerance of them
  within the read, so carrying it in `MonotoneDepth::SeparatesTo` would attach a
  separation claim to a depth measured under no such claim. The Python rendering
  matches what a `search` answer already does with `"separates_to"`, which is
  `None` for the same wall. Confined to `purrdf-retrieval` and its binding,
  which have not yet been published, so no released API changes.
- **retrieval:** A `max_width` of zero is refused as the new
  `FusionError::InvalidWidth` -- "a tolerance of zero is not a tolerance,
  because a class always contains its own rank" -- from `DecayRule`,
  `FusionProfile` and `retrieval.deepest_rank_within_width` alike, instead of
  being silently read as one. It is the only zero operand on this surface that
  did not refuse: a rank of zero and a smoothing constant of zero already did,
  and a tolerance of zero is the same shape as a constant of zero, a question
  with no evaluable content. Reading it as one answered the narrowest real
  tolerance in its place, which is the deepest fully-separated depth this
  algebra can report -- the most favourable answer there is, returned precisely
  where nothing was asked. It is a separate variant from
  `FusionError::InvalidRank` because a tolerance is a count of ranks measured
  across the 1-based axis rather than a position on it, and "rank must be at
  least 1" would send a caller to inspect an argument that was never at fault.
  The normalisation had also been documented only on the private implementation:
  neither public entry point's `# Errors` section, nor the `.pyi` stub,
  mentioned it. Confined to `purrdf-retrieval` and its binding, which have not
  yet been published, so no released API changes.
- **retrieval:** The documented meaning of a `max_width` of one now says what
  the code does. It had claimed to report "the deepest rank still separated from
  both its neighbours", and the branch's own tests assert the opposite: the
  answer is the deepest depth a *read* can stop at with every rank it actually
  read separated, and `class_width` at that rank is never one. `class_width`
  measures the unbounded curve, which also looks at the one rank the bounded
  read never reaches, so it reports at least `max_width + 1` there -- exactly
  `max_width + 1` where the run that ends the walk is one rank longer than the
  tolerance, and wider where that run is longer still, which is measured under
  the truncated rule at a raw weight of `10^6` with a tolerance of fifty. The
  two functions agree in all of those cases; they are answering a depth question
  and a rank question. The corrected relationship is carried into
  `DecayRule::deepest_rank_within_width`,
  `FusionProfile::deepest_rank_within_width`, the Python docstring and
  `__init__.pyi`, and is asserted rather than described.
- **retrieval:** Every Python entry point that takes a smoothing constant now
  takes the decay rule that constant belongs to, and none of them defaults it.
  `retrieval.search`, `retrieval.weight_for_depth` and `retrieval.class_width`
  take a required `decay` keyword, and `retrieval.compile` takes it as the third
  part of the fusion law beside `weights` and `k`. It is spelled the way every
  other closed set on that surface is -- `"reciprocal_rank"` or
  `"weighted_reciprocal_rank"`, alongside a request term's `metric` and a
  producer's `graph` -- and an unknown spelling raises `ValueError` naming both.

  Before this, the Python surface hardwired the truncated rule everywhere it
  named one, so a Python caller could not build, search under, or ask any
  question about a folded-rule law. That mattered most where
  `weight_for_depth` refused: its message says the remedy for a depth past the
  truncated rule's wall is to name the folded rule, and Python had no way to
  name it, so the surface handed out a diagnosis with no cure. The folded rule
  now reaches every number in an answer -- contributions, both resolution maps
  and the `"profile_id"` the law names itself by -- rather than only the
  profile's constructor.

  A `compile` call naming some of `weights`, `k` and `decay` but not the rest is
  a `ValueError` that says which part arrived and which did not; naming none of
  them still compiles without a law and reports no resolution. Confined to
  `purrdf-retrieval` and its binding, which have not yet been published, so no
  released API changes.
- **retrieval:** The Python `search` answer spells the trailer's measured rank
  resolution `"observed_resolution"` rather than `"resolution"`. The answer now
  reports two resolutions -- what the plan was going to cost and what the rows
  actually cost -- and an unqualified name beside a qualified one reads as the
  general case of it, which these are not: a top-k that certifies early never
  reaches its planned depth, so the two differ by design. Confined to
  `purrdf-retrieval` and its binding, which have not yet been published, so no
  released API changes.
- **retrieval:** `FusionProfile::class_width` and
  `FusionProfile::deepest_rank_within_width` answer with
  `Result<Option<u64>, FusionError>` rather than `Option<u64>`, so the two facts
  they carry stay two facts. `Ok(None)` is a stratum the profile declares no
  weight for -- an absence, not a failure -- while an operand the decay rule
  cannot evaluate is now the refusal it is. A rank of zero is the reachable one:
  ranks are 1-based, so there is no rank zero for a class to form around, and
  such a call previously came back as a width of **one** -- the claim that the
  rank is perfectly separated from both its neighbours, which is the most
  favourable thing the resolution algebra can say, returned precisely where it
  had measured nothing. The same call from Python, `retrieval.class_width`,
  raises `ValueError` there instead of returning a number. Confined to
  `purrdf-retrieval`, which has not yet been published, so no released API
  changes.
- **sparql-eval:** `knn::Kernel::distance` and `knn::norm` are generic over
  `knn::Scalar`. This is **source-breaking for inference-dependent callers**: an
  expression whose operand type the compiler previously inferred may now need an
  annotation (`norm::<f64>(&[])` where `norm(&[])` sufficed). Every operand type
  that worked before still works, and no numeric result changes -- widening is
  exact and the accumulation order is unchanged. Classified as additive plus
  source-breaking rather than behaviour-breaking; it warrants a MINOR bump under
  this suite's rule, not a MAJOR one, because no existing call can compile to a
  different answer.

- **BREAKING** **shapes:** `Constraint` (not `#[non_exhaustive]`): `Class`,
  `Datatype` and `NodeKind` hold a `Vec` (a SHACL list is a disjunction); `Equals`,
  `Disjoint`, `LessThan` and `LessThanOrEquals` hold a `Path` instead of a
  `NamedNode`; `Closed` gains `mode: ClosedMode`; `Sparql`, `Expression`,
  `NodeByExpression` and `Component` replace `message: Option<String>` with
  `messages: Vec<Literal>`; `Sparql` and `Component` gain `annotations:
  Vec<ResultAnnotation>`; and the variants listed under Added are new, so an
  exhaustive match must handle them.

- **BREAKING** **shapes:** `Target` (not `#[non_exhaustive]`) gains `NodeExpression`
  and `Where`; `NodeKindValue` (not `#[non_exhaustive]`) gains `TripleTerm`;
  `Severity` (not `#[non_exhaustive]`) gains `Debug` and `Trace`, ordered after
  `Info` and before `Other`.

- **BREAKING** **shapes:** the report types, none `#[non_exhaustive]`, all with
  public fields. `ValidationResult` replaces `message: Option<String>` with
  `messages: Vec<Literal>` and gains `details` and `annotations`;
  `ValidationReport` gains `conformance_disallows`, so build one with
  `ValidationReport::from_results`. `sparql::eval_sparql_constraint` takes the
  constraint's result annotations (`&[ResultAnnotation]`) after its messages.

- **BREAKING** **shapes:** the shapes model, none `#[non_exhaustive]`. `Shape` and
  `PropertyShape` replace `message` with `messages: Vec<Literal>` and gain
  `constraint_annotations`; `PropertyShape` gains `values` and `default_value`;
  `Shapes` gains `rules`, and `Shapes::node_shapes` also holds every shape a
  data-graph `sh:shape` could name. `NodeExpr::InstancesOf` holds a node expression
  instead of a `NamedNode`.

- **BREAKING** **shapes:** the rules model, none `#[non_exhaustive]`. `Rule` replaces
  `schedule: RuleSchedule` with `layer`, `run_once` and `processors` and gains
  `expected_predicates`; `RuleBody::Triple`'s fields are `Option<NodeExpr>`;
  `RuleBody::Sparql` gains `parameters`. `RuleSchedule`,
  `construct_template_mints_blank` and `node_expr_mints_blank` are removed. SHACL
  rules now run as SHACL 1.2 Inference Rules specifies: `sh:layer` defines the strata
  and `sh:order` no longer does; only `sh:runOnce` makes a rule run-once, so a rule
  minting blank nodes on every pass without it is stopped by the term-generating
  round limit; a triple rule's missing `sh:subject`, `sh:predicate` or `sh:object`
  defaults to the focus node and an ill-formed derived triple is skipped rather than
  an error; and an untyped rule node, an unknown rule term or an unregistered
  `sh:ruleProcessor` fails.

- **BREAKING** **shapes:** validation answers change. A shapes graph that relied on a
  silently dropped term is refused at load, on a SHACL-SPARQL constraint, validator
  or target node as on a shape; results of a SPARQL-based constraint or validator
  that declares `sh:resultAnnotation` carry its annotations; `sh:reifierShape` and
  `sh:reificationRequired` results carry the value node as `sh:value`, one
  `sh:reifierShape` result per non-conforming reifier with the reifier's own results
  as `sh:detail`; `sh:uniqueLang` no longer
  reports values that differ only in base direction; `sh:defaultValue` on a property
  shape now changes results; a node typed `rdfs:Class` only through its parameters no
  longer gets an implicit class target; and a SHACL-SPARQL query without
  `sh:prefixes` uses the implicit declarations, while conflicting or malformed
  declarations it reaches fail the load.

- **BREAKING** **shapes:** node-expression answers change: `filterShape`, `distinct`
  and `orderBy` output order; `sh:if` no longer coerces its condition; and a
  `sparql:` call with an argument producing several nodes is an evaluation failure.

- **BREAKING** **shapes:** `text_ingest::extract_prefixes` is removed; take the
  prefixes from `parse_turtle_document`. The prepared-product stage id covers the
  spec table and the new model, so a product written by an earlier build is refused
  and must be rebuilt.

- **BREAKING** **shapes, rdf-core:** JSON Schema output changes for every construct
  listed under Fixed; the instance projector emits triple terms as JSON-LD-star
  embedded nodes; `sh:pattern` with the `i` flag compiles with a recorded loss
  instead of failing with `SchemaCompileError::Pattern`; and the SHACL to JSON Schema
  loss profile gains and rewords codes, with the transcode loss matrix regenerated.

- **BREAKING** **rdf:** `ParseOutcome` (not `#[non_exhaustive]`, public fields) gains
  `document_prefixes`, so a struct literal must name it.

- **BREAKING** **validate:** `SarifOptions` (not `#[non_exhaustive]`) gains
  `validation`, and `SarifResult` (not `#[non_exhaustive]`) gains `properties` and
  `kind`, so a struct literal must name them (`..Default::default()` suffices for
  `SarifOptions`). `regime::certain_answers_to_string`, `graph_entails_to_string` and
  `verify_entailment_to_string` take `premise_iris: &[&str]`, the IRIs the premise
  document was read from.

- **BREAKING** **cli:** `purrdf validate --shapes` and `purrdf shacl pack` refuse an
  unresolved `owl:imports` (exit 1), naming each IRI and the `--import` or
  `--shapes-base` remedy, instead of warning and validating against the shapes graph
  alone.

- **BREAKING** **python:** SHACL result dicts carry `messages`, a list of dicts with
  `text` and optional `language`, `direction` and `datatype`, instead of `message`.
  `entail.certain_answers`, `entail.graph_entails` and `entail.verify_entailment`
  take a required `premise_iris` argument after `imports`.

- **BREAKING** **wasm:** `entailCertainAnswers`, `entailGraphEntails` and
  `entailVerifyEntailment` take a required `premiseIris` argument after
  `importDocuments`.

- **BREAKING** **capi:** `purrdf_shacl_validate_to_sarif` gains
  `conformance_disallows` and `conformance_disallows_count` between `data_nt` and
  `out_buffer`, and `purrdf_entail_certain_answers`, `purrdf_entail_graph_entails`
  and `purrdf_entail_verify_entailment` gain `premise_iris` and `premise_iri_count`
  between `import_count` and `out_answer`. All four change within the unreleased 0.8
  ABI, and a host built against 0.7 must recompile.

- **BREAKING** **shapes:** a shapes graph's `owl:imports` closure is resolved or
  refused by every shapes-graph entry point, not by the command line and the
  product packer alone. Before, the same shapes graph was refused by
  `purrdf validate`, validated by the engine API, Python, WebAssembly and C against
  the importing document alone, given an empty inference graph by `apply_rules`,
  and certified clean by `lint_shapes`. Every `Shapes` constructor now resolves the
  closure through `resolve_shapes_imports` before reading a shape, merges the
  supplied documents (their prefix maps join the fallback environment), and refuses
  an import nothing resolves — and a table entry nothing imports — with
  `ShapesError::Imports`. A caller whose shapes graph imports a document it does not
  contain must now supply it, or declare the ontology in place. The constructors
  and the engine's text entry points (`parse_shapes`, `parse_shapes_with_config`,
  `validate_graphs`, `validate_graphs_with_options`, `validate_graphs_with_config`,
  `validate_dataset_graphs`, `entail_graphs`, `free_expression::evaluate`,
  `lint::lint`) return `ShapesError` instead of `String`;
  `from_dataset_with_base`, `from_dataset_with_node_expressions`,
  `parse_shapes_with_config`, `validate_graphs_with_options`,
  `validate_graphs_with_config`, `validate_dataset_graphs`, `entail_graphs` and
  `lint::lint` take a `&ShapesImports`, and `FreeExpression` gains `imports`. `lint`
  certifies the merged closure and refuses an incomplete one rather than reporting
  it in the `load` section.

- **BREAKING** **validate:** `validate_to_sarif_string`,
  `validate_changes_to_sarif_string`, `entail_to_ntriples_string`,
  `lint_shapes_ttl` and `pack_shapes_product` take a `ShapesImportList` of
  `(IRI, Turtle)` pairs and return `ShapesError` where they returned `String`;
  `pack_shapes_product_from_dataset` takes a `&ShapesImports`; `RulesRequest` gains
  `shapes_imports` and `NodeExprRequest` gains `imports`.
  `ShapesProductRefusal::Shapes` carries a `ShapesError`, an unresolved import is
  that variant (with `import_error()`) rather than an `unsupported-capability`
  admission refusal, and `ShapesProductRefusal::message` returns a `Cow<str>`.

- **BREAKING** **entail:** `ImportMap::rif_resolver(&self)` is the free function
  `rif_resolver(&ImportMap)`: `ImportMap` is now a `purrdf-core` type.

- **BREAKING** **capi:** `purrdf_shacl_validate_to_sarif`,
  `purrdf_shacl_validate_changes_to_sarif`, `purrdf_shacl_entail_to_ntriples`,
  `purrdf_shacl_apply_rules`, `purrdf_shacl_eval_node_expr`,
  `purrdf_shacl_lint_shapes` and `purrdf_shapes_product_encode` gain `import_iris`,
  `import_documents` and `import_count` before their out-parameters, within the
  unreleased 0.8 ABI; a host built against 0.7 must recompile. An unresolved import
  is `PURRDF_STATUS_SHAPES_IMPORT_ERROR`, where `purrdf_shapes_product_encode`
  returned `PURRDF_STATUS_SHAPES_PRODUCT_ERROR` and the other six validated the
  importing document alone.

- **datalog:** `BudgetResource` gains `TermGeneratingRounds`, `EvalError` gains
  `Guard`, `ModelReadingGuard`, `NonStratifiableRules`, `MalformedSchedule` and
  `LayerHook`, `ChaseError` gains `GuardedClause`, and `ProofError` gains
  `GuardedRule`. All four enums are `#[non_exhaustive]`, so no existing match breaks;
  the variants are the refusals the guarded and scheduled evaluation adds.

### Features

- **shapes:** Prepared SHACL products. `PreparedShapes::to_product` writes a
  parsed shapes graph out as a deterministic, versioned, authenticated byte
  artifact carrying the declarative model, the shapes dataset it was derived
  from, and the binding of every input it was compiled against; a later process
  restores a prepared validator instead of re-parsing Turtle. The bytes come
  back untrusted, so decoding is admission rather than parsing: the reader has
  two entry points at one boundary — `admit`, the common path, which re-derives
  nothing expensive, and `rebuild`, which ignores the model memo and re-derives
  the shapes from the carried dataset when the preparation stage is one this
  build does not know. `rebuild` parses no RDF text and reads no file. The
  writer has one path and always emits every section. The preparation stage
  identity is a content-derived digest over the declarative model and the tables
  its meaning depends on, never a hand-incremented counter. The shipped profile
  is `purrdf-shacl-core-v1`, named explicitly with no default and no fallback.
  Targets are deliberately not carried: they are data-dependent and resolved per
  bound dataset.
- **shapes:** `ShapesProduct::certify` independently corroborates a product's
  shapes dataset against the canonical identity its binding claims. It is a cold
  path and is unreachable from either restore seam by construction, because
  canonicalizing a shapes graph's blank nodes can cost more than the shapes
  parse a prepared product exists to eliminate.
- **shapes:** `ProductDimension`, a closed set of twenty admission refusal
  dimensions ordered from the outside of the container inward, each with a
  stable kebab-case label and a prescriptive message naming the fix. A caller
  branches on the dimension; the label set is a pinned contract recorded by a
  frozen corpus, and matching on message text is not supported.
- **core:** A generic authenticated artifact envelope
  (`purrdf_core::artifact`): one fixed-layout, self-verifying container that a
  prepared-product codec instantiates with a magic, a format version and a
  section count. Fixed header, section directory in canonical kind order with
  per-section SHA-256, zero-verified alignment padding, a decodable identity
  region under its own digest, and a sealed trailer restating the total length.
  The reader fails closed at the first inconsistency. The section directory is
  total: every declared kind is present in every artifact, possibly
  zero-length.
- **shapes:** `Shapes` retains its parse provenance — the base, the document
  prefix map, the box-role vocabulary and the `sh:shapesGraph` IRI the parse
  actually used — so a shapes graph in hand can answer what it was parsed from
  rather than relying on a caller to remember.
- **sparql-eval:** Content-only fingerprints for the user-function, custom
  aggregate and property-function registries, with the user-function table
  reported per population so a product can state the declarations it rebuilds
  separately from the bindings only a host can wire.
- **validate:** A shared prepared-product boundary (`pack_shapes_product`,
  `admit_shapes_product`, `rebuild_shapes_product`, `certify_shapes_product`,
  `explain_shapes_product`, `validate_with_shapes_product`) that the CLI,
  Python, WebAssembly and C surfaces all route through, so those sequences exist
  once. `ShapesProductRefusal` keeps a refusal's dimension where there is one
  and reports `None` for a shapes document that never reached the admission
  boundary.
- **cli:** `purrdf shacl pack`, `purrdf shacl verify` and `purrdf shacl explain`,
  plus `purrdf validate --shapes-product`, which is mutually exclusive with
  `--shapes`. A refusal writes `shacl dimension <label>` to stderr and exits 1.
  The shapes-parse flags `--shapes-from`, `--shapes-graph` and `--import` are
  refused by name against a product rather than accepted and ignored.
- **python:** `PreparedShapes.to_product()` and a `ShapesProduct` class with
  `open`, `explain`, `format_version`, `stage_id`, `stage_known`,
  `identity_digest`, `identity_components`, `admit`, `rebuild` and `certify`.
  Refusals raise `ShapesProductError`, whose `.dimension` carries the label.
- **wasm:** `shaclPackProduct`, `shaclProductExplain`, `shaclProductCertify` and
  `shaclProductValidateToSarif`, rejecting with a refusal that carries its
  dimension.
- **capi:** `purrdf_shapes_product_encode`, `purrdf_shapes_product_open`,
  `purrdf_shapes_product_admit`, `purrdf_shapes_product_certify` and
  `purrdf_shapes_product_error_dimension`.
- **shapes/validate/cli/python/wasm/capi:** A restore can now be BOUND to the
  product the consumer meant. Every other admission check asks about the
  executing process — its build, its registries, its class analysis — and none
  of them asks whether the bytes in hand are the ones the caller wanted, because
  nothing in a product states which product was meant; an unbound restore of the
  wrong artifact therefore succeeded and returned a well-formed report about a
  shapes graph nobody asked about. `ShapesProductView::admit_expecting` takes the
  32-byte digest of the input binding the caller requires and refuses on
  `shapes-graph` when the product carries another, ahead of every other check and
  before anything is decoded; `admit` is the unbound case of the same body.
  `purrdf-validate` exposes `admit_shapes_product_expecting`,
  `validate_with_shapes_product_expecting` and `parse_identity_digest`, and every
  surface routes through it: `purrdf validate --shapes-product FILE
  --expect-identity HEX` on the command line, `ShapesProduct.admit_expecting` in
  Python, `shaclProductValidateToSarifExpecting` in JavaScript, and
  `purrdf_shapes_product_admit_expecting` in C. The selector is the 64
  hexadecimal digits `shacl explain` prints on its `identity-digest` line and
  `shacl verify` prints on stdout, accepted back unchanged; a satisfied
  expectation produces the byte-identical report the unbound call produces.

### Performance

Each site below is stated with its measured vector-instruction evidence from
`make simd-asm`. Every rewrite is proven equal to its previous implementation,
which is kept as a test oracle, and no emitted byte changes.

- **core/sparql-eval/hnsw:** the `Exact` fold. Its 16 lanes pack into
  `addpd`/`mulpd` on x86_64, `vaddpd`/`vmulpd` on the AVX2 path, `fadd .2d`/`fmul .2d`
  on NEON and `f64x2.add`/`f64x2.mul` on wasm simd128. It uses no FMA and no
  `relaxed_` op, and the same order runs scalar on the baseline. The `Reassociated`
  fold uses `vfmadd231pd` on avx2+fma (`%ymm`) and avx512f (`%zmm`), and `fmla .2d`
  on NEON. On wasm simd128 it uses `f64x2` lanes with no FMA, because relaxed SIMD
  is never enabled. The HNSW search and graph build call these kernels through
  function pointers set by non-generic constructors, so both arithmetics are
  compiled inside `purrdf-hnsw` and measured there.

- **iri/sparql-algebra/xsd:** the four byte-class scanners use packed byte
  compares and a mask: `pcmpeqb`+`pmovmskb` on x86_64, `vpcmpeqb`+`vpmovmskb` on
  x86-64-v3, mask-register compares (`vpcmpeqb %k`, `vpcmpltub %k`) on x86-64-v4,
  `cmeq`/`cmhi .16b` on NEON and `i8x16.eq`/`i8x16.lt_u` on simd128. On the baseline wasm build they run as straight-line scalar lanes. The
  SPARQL lexer's trivia skip and IRI body now make one pass over them, and
  `cur`/`peek` gain an ASCII fast path. IRI component validation gains an 8-byte
  clean-run precheck, packed on every SIMD configuration, alongside the
  `i32x4.lt_u` range test of the `ucschar` arm on simd128. XSD whitespace replace
  and collapse gain chunked prechecks, which are `i8x16` compares with
  `v128.any_true` on simd128.

- **core/rdf/entail/retrieval/sparql-results/json/markdown:** escape and string
  scans. These are the canonical IRI and literal escapes, the native serializer's
  IRI escape, `xml_escape::push_into` (which now validates and finds replacements
  in one pass, and still writes nothing for a refused value), CSV quoting, the
  SPARQL-JSON string writer, the `purrdf-json` string parser and the markdown
  line splitter. Each scan is packed byte compares (`pcmpeqb`+`pmovmskb` on
  x86_64, `cmeq .16b` on NEON, `i8x16.eq` on simd128). The drivers around them
  stay scalar, and non-ASCII runs are copied in bulk. Markdown gains no
  dependency.

- **core:** pack, dataset, hex and embedding kernels.
  - The pack dictionary's `common_prefix_len` compares 8-byte words by XOR and
    finds the first differing byte with a trailing-zero count (`rep bsfq` or
    `tzcntq` on x86_64, `rbit`+`clz` on aarch64, `i64.ctz` on wasm).
  - `select_in_word` is a loop-free broadword select. It computes SWAR byte
    popcounts and a multiply prefix sum, then compares and counts to find the
    byte, then reads a const in-byte select table (`imulq`/`popcntq`,
    `madd`/`cnt`, `i64.mul`/`i64.popcnt`).
  - The dataset's sequential pattern scans filter eight rows at a time with a
    branchless key-and-mask compare over four `u32` columns, and emit matches in
    row order (`pcmpeqd`+`movmskps` on x86_64, `vptestnmd` on x86-64-v4,
    `cmeq`/`cmtst` on NEON, `i32x4.eq` with an `i16x8.bitmask` row mask on
    simd128). The
    owned `QuadPatternCursor` shares that one match law.
  - `hex::lower` writes compare-selected digits into a buffer sized up front
    (`pcmpgtb`+`paddb` on x86_64, `cmhi`+`add` on NEON, `i8x16.gt_u`,
    `i8x16.add` and `i8x16.shuffle` on simd128). Content-id hex decoding
    classifies 16 digits at a time with a vertical rejection accumulator
    (`pcmpeqb`/`pminub`/`pmovmskb` on x86_64, `cmhi`/`cmhs` on NEON,
    `i8x16.lt_u`/`i8x16.gt_u` and `i8x16.shuffle` on simd128), and
    accepts and refuses exactly the inputs it did before.
  - PURREMB f32 rows get a bulk finite check and decode (`pcmpeqd`+`pmovmskb`
    on x86_64, `cmeq` on NEON, `i32x4.eq` with `v128.any_true` on simd128).
  - The sorted triples intersect is left as it is, with the fixture's measured
    list lengths recorded.

- **datalog:** a relation's mutable tail is held as structure-of-arrays columns
  of subjects, objects and row ids. The duplicate probe on insert OR-folds
  `(s == subject) & (o == object)` over the two key columns, with no exit on a
  hit. Over the old `(subject, object, row)` tuples the same fold compiled to a
  scalar `xor`/`sete`/`orb` loop, because consecutive keys sat three words apart.
  Over the columns it packs on every SIMD configuration measured:
  `pcmpeqd`+`movmskps` on x86_64, `vpcmpeqd %k` on x86-64-v4, `cmeq .4s`+`addp`
  on NEON, SVE `cmpeq` on neoverse-v1, and `i32x4.eq` answered by
  `v128.any_true` on simd128. The baseline wasm build runs a scalar
  loop with no exit. The cursors read the tail in insertion order, and sealing
  drains it in that order, so the batches built from it are unchanged.

- **shapes:** the SHACL path frontier's linear dedup stage (fewer than 16
  admitted ids) tests every id with no exit on a hit, four `u32` lanes at a time.
  The lanes are OR-ed into an accumulator that is folded once. This is
  `pcmpeqd`+`por`, folded by `movmskps`, on x86_64, `vpcmpeqd %k` on x86-64-v4,
  `cmeq .4s`+`addv` on NEON and `i32x4.eq` with `v128.any_true` on simd128. The baseline wasm build uses straight-line scalar
  compares.

- **columnar:** the PLAIN `INT64` codec. BYTE_ARRAY values keep their loop.
  - Encode and decode are out-of-line functions. A count of the present rows
    sizes the output exactly on encode. On decode it fixes the body's length
    before any word is read, and the `Truncated` and trailing-bytes `Malformed`
    answers stay those of the per-value loop.
  - A null-mask pass then runs eight rows at a time. Runs of null-free chunks go
    through one counted copy, and chunks holding a null go value by value.
  - The encode copy reads each payload only under its discriminant, so it
    vectorizes only where masked loads exist: x86-64-v4 (`vptestmd` masks,
    masked `vpgatherqq`) and neoverse-v1 SVE (`ld2d`, with a `cmpne`-predicated
    payload load).
  - The decode copy vectorizes with 256-bit or wider vectors (`vpermq` with
    `vpunpckhqdq` on x86-64-v3, `vpermt2q` on x86-64-v4, SVE `st2d`).
  - On SSE2, NEON and wasm simd128, both copies stay scalar, and the only vector
    op is the presence count (`i32x4.add` on simd128).

- **retrieval:** fused selection reads one key per signature group instead of
  walking the whole frontier on every pass, so a read through a plateau of equal
  contributions costs work linear in the rows pulled rather than quadratic (a
  collided-weight drain of 8,000 candidates read 150,985,757 frontier states and
  now reads 61,910 index entries); every emitted row, its order, its score interval
  and the trailer are unchanged.

- **sparql-eval/text:** Attesting an index generation is a refcount bump instead of
  a string copy, and an entry point that cannot carry the answer no longer asks the
  question. `IndexGeneration::Declared` holds a shared `Arc<str>`, so a producer over
  a frozen index -- both text relations, the kNN cursor -- renders its generation once
  at construction and every invocation clones a pointer, where each one previously
  copied 64 hex characters into a fresh `String` in a seam entered once per driving
  row. On a lane whose return type has no witness slot, the generation is not read
  and the ledger entry is not built at all: the value could only have been dropped
  with the context unread. The service-level read is deliberately not conditional,
  because the refusal an unwitnessed lane owes a relation that declares its index
  short depends on it. A relation over a frozen index therefore attests at no
  per-invocation allocation, and one that genuinely computes a generation per
  invocation pays for it only where somebody can read it --
  `benches/relation_attestation_alloc.rs` reports the counts per invocation for both
  shapes on both lanes (report-only, no threshold).
  `IndexGeneration::declared` builds the variant from a `&str`, a `String` or an
  `Arc<str>`.

- **core/iri:** Restoring a dataset pack allocates 21 times for the prepared
  product fixture's 3.8 KB section, down from 523, and requests 43,411 bytes
  down from 104,527. The largest single cause was a double parse across a crate
  boundary: every dictionary IRI was parsed once to check absoluteness during
  decode and again at the builder's store-once boundary. The IRI parser is now
  an allocation-free scan plus owned materialization, which benefits every
  intern miss in the workspace. Dictionary records decode into a borrowed view,
  front-coding buffers are hoisted and swapped, reserves are exact and clamped
  by buffer length so a hostile header cannot over-reserve, and replay is sized
  from the source's own counts. No emitted bytes change; every frozen pack
  vector and the frozen product golden are unaffected.

### Documentation

- **design:** `docs/design/purrdf-simd.md` records the stable-channel
  ceiling, the three float regimes, and the contract law for separate fast
  functions. It inventories every hot site with its class, blocker, verdict and
  reason, including the sites that are left alone. Each site has measured
  vector-op counts on all seven configurations. The document also maps each
  bench to its sites and gives a crate coverage table. `make simd-asm` runs
  with `--doc`, which holds it to the measurements. Measurement corrected one planned verdict:
  `json_escape_body` was expected to be covered, but it had no vector scan, so it
  became a rewrite. A comment in the wasm package that claimed a blake3 simd128
  backend is corrected, because that backend is not enabled.

- **sparql-eval/book:** `RelationAttestations::invocations` says, where a host reads
  it, that it is a fact about the schedule rather than about the index: under a
  `FILTER EXISTS` the parallel row loop evaluates each chunk of driving rows on a
  worker whose `EXISTS` memo starts cold, so the relation inside it is re-entered
  once per chunk and the count follows the input size and the worker count. The
  declaration sets beside it do not move with any of that, which is why the
  per-stratum conformance rule and an answer's evidence identity are keyed on them
  alone. The two readings the count does support -- ran at all, and a rough
  magnitude -- are named, and comparing it between two receipts is named as the one
  thing it cannot be used for. The querying chapter carries the same correction,
  which previously promised that two runs over one snapshot compare byte for byte
  across the whole mapping.

- **design:** `docs/design/purrdf-prepared-products.md` records the decisions
  behind the prepared-product surface — admission rather than parsing, why there
  are three seams instead of one flag, the derived stage identity, the census
  closure, the pinned refusal label set, the bounded guarantee that excludes
  targets, the standing tension of three authenticated containers in one
  workspace, and the measured allocation profile.
- **book:** A `Prepared Shapes Products` chapter under Validation covering
  producing, shipping, restoring, corroborating and explaining a product, what
  each refusal dimension means and how to answer it, and the command-line verbs.

### Tests

- **shapes:** A product-model census reads the declarative model out of the
  crate sources and checks it against the transitive closure reachable from
  `Shapes`, so the covered set cannot go stale in either direction; the closure
  found the `sh:SPARQLTargetType` declaration types and the SHACL-AF
  `Rule`/`RuleBody`/`RuleSchedule` family that a hand-written enumeration had
  missed. The preparation stage identity is derived from that census. Self-tests
  prove the scan is not asleep and that a reworded doc comment does not move the
  identity.
- **shapes:** The refusal matrix executes every admission dimension alongside a
  neighbouring valid case, because over-refusal is the mirror of a silent drop
  and hides behind tests that all pass. Determinism, RDF 1.2 term identity
  across a round trip, and the whole product lifecycle on
  `wasm32-unknown-unknown` against a golden written by a native build are pinned
  separately. `open` is proved not to certify: a product whose stored canonical
  digest is tampered with must admit and must fail certification.
- **retrieval, sparql-eval, text:** Five assertions offered as coverage that no
  implementation could fail now assert the property their message names, and each
  was confirmed by mutating the implementation until it went red. A compiled
  unit's emitted `LIMIT` is pinned at the depth plus the one probe row instead of
  accepting either value, so the row bound collapsing back onto the depth is a
  failure rather than a tolerated spelling. A domain tag is checked against the
  three respellings generic URI normalisation would change -- an uppercased
  scheme and authority, a dot segment, a case-flipped percent-escape -- so
  neither constructing a tag nor reading one can canonicalise a host's own
  spelling, where the previous check was reflexivity of a derived `PartialEq`.
  The relation witness's invocation count is asserted exactly, and against the
  forced-sequential lane's count over the same query: a `FILTER EXISTS` re-enters
  evaluation once per driving row, so the fork-join total has to add back up to
  the same number, and a join that kept one worker's ledger and dropped the rest
  now fails instead of passing a `>= 1` floor. An empty text index's attested
  generation is checked for being a digest that was computed -- not the all-zeros
  placeholder -- and for distinguishing that index from an equally empty one
  under a different configuration, which is the pair emptiness leaves
  indistinguishable to a digest over content alone. And the refusal that replaced
  a bare `AttributeError` about a private protocol method is checked for naming
  the type that actually arrived, over two different arriving types, so a
  constant spelled into the message cannot satisfy it.

### Added

- **sparql-eval:** `NativeSparqlEngine::prepare_execution` returns a `PreparedExecution`: a
  query parsed and admitted once, then bound and run many times without re-parsing or
  re-admitting. `PreparedExecution::bind` sets a parameter by its declared slot index and
  `bind_named` by its declared name; `NativeSparqlEngine::execute` runs the current bindings
  against a dataset. A parameter reaches inside `OPTIONAL`, `MINUS`, `EXISTS` and sub-`SELECT`s
  by ordinary correlation, the same as a `query` substitution. Running with a declared parameter
  left unbound is refused, because treating it as unrestricted would silently widen the answer
  to every subject; binding an undeclared name is refused; declaring one parameter twice is
  refused. `bind`, `bind_named` and `execute` take `&mut PreparedExecution`, so the type system
  rejects a program that would hand a re-entrant query body (a SHACL-AF `sh:expression` function
  call, for example) the very tree an outer call is mid-evaluation over.

- **python:** `Store.prepare(query, *, parameters=[...], ...)` returns a `PreparedQuery` whose
  `run(**bindings)` binds every declared parameter by keyword and returns results exactly as
  `Store.query` does. `prepare` accepts the same engine-configuration keywords `query` does —
  `extension_namespaces`, `property_fn_namespaces`, `standpoint_predicates`, `relations`,
  `relations_from_graph`, `path_relations` and `aggregate_namespace` — except `substitutions`,
  whose role a prepared query's per-run parameter bindings now fill; the returned `PreparedQuery`
  carries those registries, so every `run` evaluates under the same ones the plan was admitted
  against. Each `run` re-reads the owning store's current contents rather than a snapshot taken
  at prepare time, because what is prepared is the plan and not the data — the motivating caller
  is a row-driven loop such as SHACL validation or a rule fixpoint, where the store changes
  between runs. A `run` with a declared parameter left unbound is refused, binding an undeclared
  name is refused, and declaring one parameter twice at `prepare` time is refused.

### Changed

- **BREAKING** **sparql-eval:** `PreparedQuery`'s parsed algebra, formerly the public mutable
  field `query`, is now private. Read it through the new `PreparedQuery::query(&self) -> &Query`
  accessor. Admission — the algebra soundness walk and the graph-depth guard — is plan-invariant
  and now runs once when a query is prepared rather than being re-checked on every run, so there
  is no longer a way to swap an admitted plan's algebra after the fact; supply the algebra you
  want at construction, where it is admitted.

### Fixed

- **sparql-eval:** A prepared execution's `execute` skipped the check that a run's registries
  (relations, aggregates) agree with the ones the plan was admitted under. Preparing under one
  registry configuration and running under another used to evaluate silently — a registered
  relation prepared with no registry in scope lowers to an ordinary triple pattern and answers
  the empty bag with no error, and two registries can resolve one IRI to two different
  accumulators of identical declared arity — and it is now refused.

- **python:** `Store.prepare` ignored every one of the engine-configuration keywords `Store.query`
  accepts, so a prepared query naming a registered relation had that relation silently lowered to
  an ordinary triple pattern with no way for a caller to prevent it. `prepare` now takes and
  honours the same configuration `query` does, as described above.

- **python:** `PreparedQuery.run(**bindings)` used to leave every parameter not named in a given
  call holding the value from the previous call, so a later call that omitted a parameter
  silently reused it instead of being refused. Every slot is now returned to unbound before a
  call's keyword bindings are applied, so a run is total in its own arguments and a parameter
  omitted this call is refused regardless of what an earlier call supplied.

### Performance

Allocation count per focus node, from the deterministic counting allocator rather than timings,
pinned as the exact slope of a closed form measured at two focus-node populations, across four
SHACL surfaces: an `sh:sparql` constraint, a custom `sh:ask` component, a custom `sh:select`
component, and an `sh:expression` function call.

- The SHACL change path now runs each of those surfaces on a prepared execution instead of
  re-parsing and re-admitting a query per focus node, and the substituted algebra a parameter
  binding writes into is memoized and rewritten in place rather than rebuilt from scratch on
  every run. Combined with retaining the evaluator's scratch interner across runs and deciding
  once, rather than separately at each call site, what a pre-bound value may be used for, the
  per-focus-node allocation cost fell from 96 / 214 / 116 / 194 to 49 / 112 / 62 / 123 across the
  four surfaces respectively; the evaluation's height check allocates no traversal vector per
  expression.

- CONSTRUCT template instantiation and SPARQL Update's insert/delete/graph-slot templates
  resolved every variable position by lookup again on every output row; the resolution now
  happens once per template, ahead of the row loop.

## [2.0.2] - 2026-09-14

### Bug Fixes

- **core:** Certified embedding source verification accepts one RDF 1.2
  reifier bound to multiple distinct statements, including citations projected
  from Markdown concordance rows with several anchors. Annotation source
  ordinals verify against the exact statement binding in the same graph;
  altered annotations, mismatched bindings, and stale ordinals remain rejected.

### Performance

- **gts:** Private digest indexes remove repeated blob and metadata scans from
  streaming reads, materialized reads, and segment union. Ordered replacement,
  inherited metadata, lazy payloads, and segment isolation retain their existing
  behavior. Tables of up to 16 digests avoid index allocation.
- **gts:** Standalone and streaming COSE decryption borrow fields from definite
  envelopes and allocate only the plaintext buffer and authentication data.
  Other accepted CBOR forms retain the complete decoder. For a 1 MiB plaintext,
  measured cumulative allocation requests fall by approximately 75% standalone
  and 37% through streaming, preserving authentication and error ordering.

### Tests

- **core/markdown:** Cover multi-anchor certified embedding sources, multiple
  statement bindings, graph separation, altered annotations, and stale ordinals.
- **gts:** Expand decryption compatibility and limit-boundary coverage, verify
  ordered blob replacement across snapshots and segments, and measure reader
  scaling and decryption allocation traffic.

## [2.0.1] - 2026-09-14

### Bug Fixes

- **gts:** Restore the public `cose::decrypt0` API for standalone encrypted
  objects. The original signature delegates to the bounded authenticated
  decryptor used by the GTS reader, preserving existing error behavior and
  compatibility with the frozen encryption vector.

## [2.0.0] - 2026-09-14

### Breaking Changes

- **BREAKING** **text:** Ranking now uses one bounded BM25F arithmetic law,
  including the single-field case. Intermediate rounding can change existing
  scores, and index fingerprints use the `index/v2` domain. Rebuild cached
  rankings and pin the complete named ranking profile; the exported 56-bit
  score width derives from its exact inclusive bound.
- **BREAKING** **shapes:** `json_schema::compile` and
  `compile_with_value_vocab` return `Result` and report unsafe pattern or
  namespace emission as typed errors. Callers must handle compilation failure.
  JSON Schema patterns target Unicode ECMA-262. XPath case-insensitive flags
  are refused because simple Unicode case folding does not preserve their
  semantics; unsupported Pydantic and reverse-import patterns also refuse
  rather than installing a constraint with a different meaning.
- **BREAKING** **core:** `Canonicalized` now reports the presentation that
  produced it in `presentation: CanonPresentation` — the fourth coordinate of
  the canonicalization pin `(profile, version, presentation, hash)`, readable
  directly off a result in hand. Rust callers constructing a `Canonicalized`
  struct literal or destructuring it exhaustively must supply or bind that
  field; callers receiving results from the canonicalization entry points are
  unaffected. This requires a major release under the suite's versioning
  policy.
- **BREAKING** **shapes:** `PropertyShape` now carries its declaring RDF node
  in `id: Term`. Rust callers constructing a property-shape struct literal must
  supply that identity; callers using `from_dataset` or `parse_shapes` receive
  it automatically. This requires a major release under the suite's versioning
  policy. The field preserves correct `sh:sourceShape` reports and
  SHACL-SPARQL `$currentShape` bindings even when property shapes share a path,
  are nested, or are cloned and validated independently.

### Bug Fixes

- **rdf/core/results:** XML egress shares one XML 1.0 character law across
  RDF/XML, TriX, SPARQL XML results, projections and SVG. Carriage returns use
  character references; attribute tabs and line feeds do too, preserving their
  values through XML normalization. Forbidden scalars produce an error naming
  the scalar. Dynamic SVG attributes and XMLLiteral normalization follow the
  same rule. These repairs deliberately change emitted bytes; apostrophes stay
  literal inside double-quoted attributes. Frozen conformance vectors are
  unchanged.
- **iri:** Bracketed hosts must satisfy the IPv6 or IPvFuture grammar;
  character membership alone no longer admits malformed IP literals. Generic
  ports accept arbitrary ASCII digit strings as RFC 3986 requires, including
  values above 65535 and leading zeros. Valid lexical spellings remain intact.
- **core/rdf:** Located duplicate quads keep their source locations on the
  deduplicated row during owned insertion, row remapping and GTS import.
  Unrealized location handles cannot attach to a later unrelated row, and
  validated append safely ignores unmatched handles. `push_quad_with_handle`
  returns the actual row
  handle for callers attaching locations; existing `push_quad` calls remain valid.
- **core:** Mutation suppression and reinsertion apply to ordinary quads,
  reifiers and annotations, including overlapping records. Statement-layer
  classification uses the reifier's graph as part of its identity. Snapshots and
  compaction preserve annotation-only rows and declaration-only named graphs.
  Independent dataset imports reserve explicitly interned blank scopes, including
  those referenced only inside composite literals.
- **shapes:** Borrowed statement projections deduplicate metadata overlapping
  ordinary rows, preserving graph-set semantics in SPARQL counts and validation.
  Disabled statement projection skips metadata reads, and bound subject probes
  use the source's metadata indexes. Property-pair constraints read shared views
  without materializing them, and validation shares one class index when Core
  and SPARQL use the same data view.
- **rdf/viz:** Properties of a known reifier render as annotation relations even
  when their graph differs from the reification declaration. Every relation keeps
  its original graph, and parsed and incrementally built datasets produce the
  same visual model. Corrected cross-graph visual models change newly generated
  visualization JSON, SVG and model hashes; RDF carrier records are unchanged.
- **sparql:** Compiler-built, rewritten and caller-mutated prepared algebra now
  passes structural and registry validation before execution. Malformed binding
  rows and excessively deep execution plans return diagnostics instead of
  panicking or overflowing the stack. Rewrites that need a different property
  function plan must be admitted again before execution.
- **sparql:** Repeated grouping variables use the same normalized columns as
  their result schema, preventing an aggregate after duplicate `GROUP BY` keys
  from indexing outside its output row. Repeated bare projection variables retain
  their existing normalization behavior.
- **gts:** Snapshot composition preserves the graph identity of reifiers and
  annotations during ingestion, canonicalization, deduplication and emission.
  Explicit default-graph relocation applies to all three RDF record tables.
  Named-graph metadata uses the existing graph fields in the wire format;
  default-graph record encodings and frozen vectors are unchanged.
- **core:** Directional language-tagged literals now intern with
  `rdf:dirLangString`, as required by RDF 1.2. Previously the builder used
  `rdf:langString`, so prepared SPARQL constants could not find those terms.
  The corrected datatype can change newly emitted carrier bytes and content
  identities for datasets containing directional literals. Regenerate derived
  artifacts from canonical inputs; previously authenticated bytes remain their
  original artifacts and must not be rewritten under an old identity.
- **core/bindings:** Native validation, pack and embedding readers, and C/Python
  literal inputs reject inconsistent datatype, language and direction fields.
  Python native literal equality and hashing distinguish opposite base directions
  and compare language tags without ASCII case sensitivity, including inside
  triple and quad keys. Length-framed keys preserve embedded control characters.
  Typed Python store operations and query prebindings normalize language tags
  consistently. Pack admission rejects noncanonical language tags, duplicate
  terms and unordered dictionaries before exposing lookup indexes.
- **shapes:** Repeated values of single-parameter constraint components apply
  independently and conjunctively. Importing standard SHACL component
  declarations no longer rejects legal repeated properties or executes native
  constraints twice. Multi-parameter components and native singleton parameters
  reject distinct competing values; identical statements in multiple graphs
  count once. Parameter declarations and validator attachments are checked
  without discarding malformed values.
- **shapes:** Optional target parameters remain unbound when omitted, and target
  instances missing mandatory parameters contribute no focus nodes. Subjects of
  `sh:target` are discovered as shapes even without explicit node-shape typing,
  including standalone property shapes. Scoped
  component validators take precedence over generic ASK validators. Property
  reports name their declaring shape, and reifier-constraint results use the
  enclosing property's severity. First-party report goldens deliberately correct
  34 source-shape references and one severity; conformance outcomes are unchanged.
- **core:** `PipelineBundle::accumulate_named_graph` refuses a contribution that
  carries a quad, a reifier row, an annotation row or a graph declaration outside
  the named graph it is being folded into. Such a contribution was previously
  admitted in silence and its stray rows joined the carrier under graphs the caller
  never named, so the carrier's per-graph digests then answered for content those
  graphs did not hold. This changes the behaviour of an existing entry point: a
  call that used to succeed now fails with `PipelineBundleError::GraphContainment`.
  A refused accumulation leaves the carrier exactly as it was, on the flat carrier
  and the view carrier alike — the union, the per-graph digest memo and the new
  handle are installed together, only after every check has passed, so there is no
  partially folded state for a reader to observe.
- **gts:** The snapshot builder refuses two distinct blank-node intern keys that
  encode onto one wire value. The frozen `"{scope}-{label}"` encoding is not
  injective over `(scope, label)` — `(Some("a"), "b-c")` and `(Some("a-b"), "c")`
  both spell `a-b-c` — and both keys previously interned onto the SAME term row, so
  two distinguishable blank nodes were published as one and every row naming either
  was repointed at the survivor. This changes the behaviour of an existing entry
  point: `add_dataset_scoped`, and the Python producers that call it, now refuse
  such a pair instead of merging it. The encoding itself is unchanged, so no input
  that did not collide moves a byte.
- **gts:** A failed ingestion can no longer be published. `emit_gts` refuses a
  builder that an earlier ingestion poisoned, and the ingestion that failed is
  rolled back: every row it had already interned is taken back out, so the
  infallible `snapshot_content_id` and `snapshot_payload` accessors describe the
  last fully accepted state rather than a truncated interior. Previously a caller
  that carried on past an ingestion error could emit a container holding whatever
  subset happened to intern before the refusal, which answers a question nobody
  asked.

### Features

- **json:** New core-only runtime crate `purrdf-json`, also available through
  `purrdf::json`, carries ordered JSON as RDF 1.2 and reconstructs the original
  bytes. Member order, duplicate names, whitespace, escapes, exact number
  spellings and empty containers survive production RDF serialization and
  parsing. Value occurrences expose paths and parent links, containers expose
  their sizes, and structural runs cover syntax bytes. Decoding requires an
  explicit document and profile, validates ownership, metadata, byte cover and
  digest, then reparses the source to verify every structural assertion before
  returning it.
- **text:** Immutable ranking profiles configure up to sixteen BM25F fields.
  Retained predicate-level token facts support field remapping and reweighting
  without tokenization. Corpus-bound prepared queries compute IDFs once and
  share the same scorer across ranking, explanations and heap ceilings. A
  short independent integer reference reproduces the exact conformance vectors
  executed on native and wasm targets.
- **core:** Canonicalization is idempotent over its own output, and the
  `purrdf-rdfc12` profile version moves from 1 to 2 to say so. A quad written in
  exactly one of the two shapes the RDF 1.2 overlay lowers into — a reifier row
  under `urn:purrdf:rdfc:reifies` over a triple term, or an annotation row in the
  lone `urn:purrdf:rdfc:annotation` graph slot — is folded back into the statement
  layer instead of being refused, because such a quad is that row written out and
  carries identical content. Re-parsing a canonical document and canonicalizing it
  again now returns it byte for byte; the graph-scoped entry points are idempotent
  without qualification, while a named-graph annotation still emits a five-token
  line no quad can carry. Every other use of the reserved namespace refuses exactly
  as before, including a reserved IRI in any slot of a folded row, and no input the
  previous version admitted changes bytes. Consumers pinning
  `(CANON_PROFILE_ID, CANON_PROFILE_VERSION, CANON_CORPUS_DIGEST)` must re-pin the
  latter two; two normative corpus cases move from refusal to golden.
- **sparql:** Prepared-query and join-order caches have deterministic entry and
  byte limits, configurable independently through additive policy APIs. Existing
  constructors use finite defaults. Cache counters expose retention and eviction;
  `PlanMemoryObserver` separately tracks admitted allocations still held by
  callers after eviction or cache destruction. These payload estimates exclude
  allocator overhead and do not claim to measure process memory.
- **sparql:** Immutable prepared plans can execute under a shared operation
  governor, including fallible dataset views and federated sources. Typed
  substitutions, registry checks, cancellation, completeness and operational
  failure precedence retain the existing evaluator's behavior. Evaluation state
  stays local to each worker.
- **core:** Typed dataset import memoizes source terms and streams flat quads;
  canonical relabeling avoids building an unused text representation. Existing
  scope, metadata and deterministic output contracts are preserved.
- **core:** Immutable composite and mutation views retain native source
  dictionaries and indexes. Independent-document composition standardizes blank
  scopes apart, including nested triple and composite-literal references; an
  explicit shared-scope constructor preserves already-established identities.
  Graph placement covers all RDF record tables and graph declarations. Finite
  retention limits and copy/freeze/materialization counters make ownership costs
  observable without changing deterministic RDF identities. Composite, delta and
  SHACL adapters reuse prepared physical probe plans across bindings, accounting
  for graph placement and union projection.
- **shapes:** `PreparedShapes` shares immutable shape and class-reference analysis
  across exact dataset bindings. Borrowed native, composite and delta views avoid
  rebuilding a base dataset for constraint, path and target evaluation. Each
  binding resolves its own dataset IDs and targets; concrete dataset compatibility
  getters materialize lazily.
- **sparql:** Typed prepared CONSTRUCT methods stage and validate graph results
  directly into a destination builder, with destination-aware fresh blank nodes
  and explicit copy counters. Shared-governor and fallible-view variants withhold
  publication after errors, cancellation or exhausted budgets. UPDATE WHERE
  evaluation reads mutation snapshots without compacting the whole base.
- **markdown:** New crate `purrdf-markdown`, a structural Markdown-to-RDF 1.2
  slicer. A document becomes a graph of its own headings, verses and paragraphs
  over verbatim byte spans of the source, and the resulting nodes carry
  content-addressed identities that two independent runs of the same law agree
  on. The law is published, not implied: `SPEC.md` ships inside the crate and
  states the dialect grammar, the split law, the concordance law, the three
  identities and their verification law, ordering, conformance and the emission
  law, and the crate's vectors are read against that document. The vocabulary is
  caller-supplied: `Vocabulary::under(base)` derives the whole term set from one
  base, the term set and not merely the base is inside the contract identity,
  and no term is written in two roles. `Vocabulary::standard()` offers one
  designated namespace, `https://w3id.org/purrdf/markdown#`, by name rather than
  on a caller's behalf, for deployments that want a shared one; it is a stable
  identifier that does not dereference today, a redirect for it is being
  registered, and nothing rests on that because RDF asks no IRI to resolve.
  Beside the IRIs derived from the caller's own vocabulary base — its terms and
  the node identities minted under it — an emitted graph carries no IRI but
  these: five of the standard's — `rdf:type`, `rdf:reifies`, `xsd:integer`,
  `xsd:hexBinary`, and the `xsd:string` that the graph's plain literals — a
  unit's text, a heading's words — have in the abstract syntax and that no
  serializer writes — the caller's own source id, and, where a concordance
  lifts under a declared canon base, the anchors it mints.
- **markdown:** The slicer is a codec. The emission covers every byte of the
  source: a section carries its own heading or movement line as a typed
  `verbatim` literal over that line's span beside its heading's words as the
  section's one plain literal, and every maximal run of bytes neither a unit
  span nor a heading line covers — blank runs, rules, table rows, the newline
  a split cut lands on — is a `Structure` node carrying its bytes the same
  way. Plain means content and typed means bytes, normatively: the only plain
  literals in a claim are a unit's text and a heading's words. The vocabulary
  grows `Structure`, `verbatim`, `verbatimStart`, `verbatimEnd` and
  `verbatimText`; every contract id re-mints and every chunking id — and so
  every embedding addressed by one — stands still. `decode_document` is the
  graph half of the new decode law (`SPEC.md` §11.3) and `analyze` holds every
  admitted document against it in every build, refusing a defective cover as
  `CoverDefect` rather than shipping a graph nothing can rebuild. `ClaimKind`
  gains `Structure` and stays exhaustive on purpose: a consumer's match
  breaking loudly on a new claim kind is the correct failure.
- **core:** New module `purrdf_core::cover`: the cover law — verbatim byte
  spans back into the document they cover, byte for byte — as the kernel's
  own, format-neutral surface. `reconstruct` writes each span at its offset,
  requires the cover whole, admits an overlap only where a `continues`
  declaration names a strictly earlier piece whose shared bytes agree, and
  proves the result against the stated source digest, with eight typed
  refusals and allocation bounded by input. `purrdf-markdown` re-exports it as
  the law's first emitter; the next ordered codec costs an emitter and
  nothing else.
- **purrdf:** The umbrella exposes the slicer as `purrdf::markdown`, so a
  consumer slices a document without naming `purrdf-markdown` as a separate
  dependency.
- **core:** The IRI re-export widens from `IriError` alone to `BaseIri`, `Iri`
  and `parse_iri` beside it. A producer that mints IRIs for the kernel can now
  refuse up front exactly what the kernel would refuse at intern time, asking
  the same question of the same law rather than reimplementing it or taking its
  own dependency on `purrdf-iri`.
- **core:** `PipelineViewBundle<H>`, the view-backed pipeline carrier: the same
  out-of-band material, typed-handle lane and content answers `PipelineBundle`
  carries, over a composed `CompositeDatasetView` instead of an owned dataset.
  Folding a named graph in appends a retained source rather than copying rows, and
  freezing happens exactly once, at an ownership boundary the caller asks for. The
  two carriers are interchangeable by content: equal content yields equal
  per-carrier and per-graph digests and an equal `pipeline_root`, the
  domain-separated fold over a carrier's whole surface that both carriers now
  answer. A view carrier holds caller-supplied sources, so its digests run through
  the fallible canonicalization entry points and report a refusal rather than
  panicking; the bytes agree with the flat carrier's on success.
- **core:** `CompositeDatasetView::extend` composes one more source onto an
  existing view, aliasing only the new contribution against the identity space the
  retained sources already settled. The result is the view a from-scratch
  composition of the same source list would have built — the same rows, canonical
  identity, named graphs and retention — without paying that whole composition
  again at each step. Each retained source also carries its own `ScopeBinding`, so
  one composition can standardize some sources' blank scopes apart while retaining
  others' established identities, decided per source rather than per view.
- **core:** `RetentionLedger`, with `RetentionGuard`, `RetentionSnapshot`,
  `RetainedCharge`, `OwnerKey`, `OwnerMutability` and `ViewAccountingReport`,
  reports what several carriers jointly hold resident: a base is charged once
  however many carriers share it, and released when its last reader drops. The
  ledger admits, refuses and resizes nothing — `ViewLimits` remains the sole
  admission gate and remains per view — and `ViewAccountingReport` pairs the
  deduplicated ledger figure with one view's own incremental charge so that no byte
  is counted in both.
- **core:** Canonicalization has view-generic entry points: `canonicalize_view`,
  `try_canonicalize_view`, `canonicalize_graph_view`, `try_canonicalize_graph_view`,
  `graph_digest_view`, `try_graph_digest_view`, `check_admissible_view` and
  `blank_count_view` all take any `DatasetView` — the frozen dataset, composite
  views and delta views alike — so a composed surface is canonicalized without
  being materialized first. The existing dataset-shaped entry points delegate to
  them and are unchanged in behaviour and in bytes.
- **core:** `datasets_isomorphic` and `dataset_diff` are view-generic with the two
  sides INDEPENDENTLY typed, so a composite view, a delta view and a frozen dataset
  compare against each other in any combination without either side being
  materialized; identity is still decided from the canonical bytes, which carry no
  view-local ids. Ordinary `&RdfDataset` call sites are the dataset instantiation
  and keep compiling unchanged. Compatibility caveat: a generic function has no
  single function type, so a caller that stored either of these in a function
  pointer or passed it where a concrete `fn` was expected must now name the
  instantiation it means.
- **core:** `CompositeSource::from_selection` retains chosen graphs of an
  existing `Arc<CompositeDatasetView>` as one composable source. A single
  selection filters ordinary quads, reifier rows, annotation rows and
  declaration membership together, keeps the retained composite's owners and
  canonical blank scopes rather than copying or re-scoping anything, admits
  under the same view limits as every other source, and composes with
  `with_graph_placement` and `with_scope_binding` unchanged. Selecting a graph
  the composite does not hold is the typed `view-graph-selection` refusal, and
  a carrier assembled over a selection keeps the selection's underlying owners
  registered with the retention ledger, transitively.
- **core:** `PackBuilder::build_view_bytes` writes the existing pack format
  from any `FallibleDatasetView` — composite, delta or graph selection —
  through the one encoder; `build_bytes` over a frozen dataset is now a
  delegation through it, so flat and view output are byte-identical by
  construction. The view's operational status is checkpointed before and after
  the drain, and a view that faults mid-read yields no pack bytes at all.
- **gts:** `SnapshotBuilder::add_view` and `add_view_scoped` ingest any
  `FallibleDatasetView` into a snapshot directly — no temporary dataset, no text
  round trip, no per-row owned term reconstruction — with the same
  graph-assignment and blank-scope hooks the flat surface exposes. They return an
  `IngestReport`: rows consumed, terms minted, peak scratch bytes, and the
  declaration-only graph names the ingestion deliberately did NOT intern, so that
  omission is stated rather than silently taken. `ingest_totals` reads the
  cumulative figures off a builder, and every ingestion refusal is the typed
  `GtsIngestError`. The frozen `add_dataset` / `add_dataset_scoped` surface now
  delegates to the same ingestion core, unchanged in signature and in bytes.
- **python:** `compile_gts_with_report` returns a GTS container together with the
  ingestion receipt for the very build that minted it, from ONE compile — a dict
  with `snapshot_bytes` and `ingest_report`, where the bytes are identical to
  `compile_gts_native`'s for the same sources. `gts_ingest_report` remains the
  accessor for a caller who wants the receipt and no bytes: it takes the compiler's
  ingest-half arguments and returns `rows_consumed`, `terms_interned`,
  `declarations_omitted` and `scratch_bytes`. Both are additive; every existing
  producer entry point keeps its signature and its bytes.

## [1.1.0] - 2026-09-04

The first release after 1.0.0. Two reported bugs, the release fallout 1.0.0 left
behind, and a data-conflation bug in the GTS carrier found while coordinating
with the upstream wire-format freeze.

Additive: no published API changes shape. A `TermRow` widening that would have
forced a major bump was reworked into a parallel column before release — RDF 1.2
base direction is now `purrdf_rdf::gts_view::term_directions()` and a
`directions` key on the Python projection dict, so every 1.0.0 caller keeps
working.

### Bug Fixes

- **shacl:** `sh:message` templates are substituted on the `sh:sparql` path.
  `{$path}`/`{$value}` shipped as literal braces because the constraint's
  message was resolved once and cloned into every result row; it is now rendered
  per solution, from that solution's own bindings. Both `{?var}` and `{$var}`
  spellings, and `{$this}` whether or not the SELECT projects it. An unbound
  placeholder is still left verbatim rather than blanked.
- **cli:** `purrdf validate` resolves a shapes graph's `owl:imports` from
  `--import IRI=FILE`, transitively and cycle-safely. Previously they were
  ignored in silence, so a shapes graph whose shapes lived in its imports
  reported `conforms true` against no shapes at all. PurRDF fetches nothing: an
  unresolved import with no `--import` given is reported on stderr, and with a
  table given is refused by name.
- **gts:** RDF 1.2 literal base direction is part of a term's identity in the
  snapshot composer. It was absent from the intern key, so `"Cat"@en--ltr` and
  `"Cat"@en--rtl` merged into ONE term and every quad was repointed at the
  survivor — a different graph, not a missing column. Emitted bytes are
  unchanged for any input without directional literals.
- **release:** The crates.io bootstrap script packages and publishes its PLAN
  rather than the whole ledger; a deferred crate no longer reaches `cargo
  package`. Its self-test asserts the arguments handed to the irreversible step,
  and the arm that had been failing since the ledger emptied is fixed — that arm
  runs before `cargo test` in `make check`, so it had been failing the gate for
  every contributor.

### Features

- **python:** `gts_to_sqlite`, `gts_to_duckdb` and `gts_to_parquet` are
  implemented. They previously raised unconditionally. Five tables in the
  projection's own row order, so the same container exports to the same content
  twice. SQLite needs only the standard library; the other two take the
  `[duckdb]` / `[parquet]` extras.
- **rdf:** `gts_view::term_directions()` exposes RDF 1.2 base direction from the
  relational projection, which previously dropped it.
- **entail:** `entails::imports::imported_iris()` is public, so a consumer can
  read a document's `owl:imports` without re-deriving which objects count.

### Documentation

- **pack:** The pack identity digest is no longer captioned "RDFC-1.0". It is
  computed through the `purrdf-rdfc12` profile, which agrees with RDFC-1.0 byte
  for byte only on the RDF 1.1 subset. Labelling only — no digest bytes change.

### Build

- **ci:** Benchmarks moved off the per-push path to a weekly schedule plus
  `workflow_dispatch`, and its `uv` installer is pinned.
- **make:** `make doctor` reports which build pins the local machine actually
  enforces, and the wasm gate distinguishes "rustup absent" from "target not
  installed" instead of printing the same line for both.
- **python:** `bench = false` on the binding lib, so `cargo bench --workspace`
  links.

## [1.0.0] - 2026-09-02

The first release under full semantic versioning. The tree is the 0.13.0 tree:
0.13.0 was published only to create the crates.io records for `purrdf-cdt`,
`purrdf-geo` and `purrdf-text` — Trusted Publishing cannot create a crate that
does not exist — and 1.0.0 is the same code republished through Trusted
Publishing across all 21 crates, PyPI and npm. There is no functional change
between the two.

### Documentation

- **release:** From 1.0.0 a breaking change bumps the major version, a minor
  bump is additive, and a patch bump is bugfix-only; the changelog's
  **BREAKING** markers name each one. The C ABI (`purrdf.h`,
  `PURRDF_ABI_MAJOR.PURRDF_ABI_MINOR` = 0.7) is versioned separately and
  remains 0.x. The changelog header, its `cliff.toml` template and the release
  docs now state that policy instead of the pre-1.0 one.
- **release:** `make bump` now regenerates `purrdf.h`, because cbindgen derives
  `PURRDF_MINOR` from the crate version and the 0.13.0 bump left the committed
  header one integer behind, failing `capi-check` in CI.

## [0.13.0] - 2026-09-02

This release re-founds the aggregate algebra on the SPARQL specification's own shape, adds a
caller-extensible aggregate registry (with a first-party statistical set), retains and enforces
the `VERSION` declaration, adds RDF 1.2's `ADJUST` and the underlying F&O temporal operation
table, corrects several results-format spellings, adds `LATERAL` (SEP-0006) surface syntax
alongside a corrected correlated-evaluation substitution, and rebuilds `EXISTS`/`NOT EXISTS` on
SEP-0007's defensible substitution semantics (one definition, two proven-equivalent strategies,
and the Part 3 assignment restriction). It carries a large number of breaking surfaces; each is
called out below with what a consumer must do.

### Bug Fixes
- **BREAKING** **core:** `check_provenance` now measures the sidecar against the dataset in BOTH
  directions, and an empty quad set means "the dataset is empty", not "check nothing". Rule 3
  (every dataset quad has at least one occurrence) previously ran only when the handle slice was
  non-empty, so a caller that forgot to collect its handles — or passed `&[]` to mean "skip" —
  got an `Ok(())` indistinguishable from a real pass. The parameter is now the dataset's
  complete quad-handle set, rule 3 runs unconditionally, and a new rule 4 refuses every
  occurrence whose quad is not in that set with
  `ProvenanceError::DanglingQuad { occurrence_index, quad_index }` — the quad-axis twin of
  `UnknownUnit` / `UnknownArtifact`. An empty sidecar for an empty dataset still passes (every
  rule ran over zero elements, which is a checked pass); a non-empty sidecar checked against
  `&[]` now fails, as does an occurrence for a quad outside a non-empty set. A caller that passed
  a subset of its quads, or `&[]` to run rules 1–2 alone, must now pass the full set. The
  signature is unchanged and `ProvenanceError` is `#[non_exhaustive]`, so the new variant is
  not itself a source break; the accepted-input set is what changed.
- **sparql-algebra:** A language tag's base direction is exactly `ltr` or `rtl`, lower case, and
  anything else is a syntax error. SPARQL 1.2 §2.3.1: "The base direction is restricted to
  either `ltr` or `rtl`. Unlike a language tag, it is always lower case." The parser SILENTLY
  DROPPED an unrecognised `--` suffix — `"x"@en--foo` parsed as `"x"@en`, and `"x"@en--LTR` as
  `"x"@en--ltr` — where the W3C rdf-tests pin both spellings as negative syntax ("undefined base
  direction", "upper case LTR"), and the pre-release sweep had folded the comparison to
  `eq_ignore_ascii_case`, which the specification forbids. The language half is now held to the
  `LANG_DIR` production `[a-zA-Z]+ ('-' [a-zA-Z0-9]+)*` at the same site, so `@en-`, `@en--`,
  `@1en` and `@en--x--ltr` are refused too, while `@en`, `@en-US`, `@zh-Hant-TW`, `@x-klingon`,
  `@en--ltr`, `@ar--rtl`, `@en-US--rtl` and `@EN--ltr` (only the DIRECTION is case-restricted)
  all still parse. The vendored `lang-basedir/langdir-literal-invalid.rq` could not catch this:
  it spells its projection `AS v`, which is a syntax error on its own, so the harness refused it
  for the wrong reason.
- **core:** The `pack_query` dictionary benchmark measures again. Its literal-heavy fixture
  (added by the pre-release sweep) asserted a quoted triple term as a quad's SUBJECT, which
  RDF 1.2 does not admit and the freeze gate refuses (`rdf-ir-triple-subject`), so the fixture
  panicked and the report-only `benchmarks` CI job had been red on `main` since `b4f99093`. The
  triple term is now asserted in the object position (`s q <<s p plain>>`), the one place the
  model puts it, and the dictionary closure still resolves one triple term per row.
- **core:** `MutableDataset` no longer fabricates a literal datatype. When a base literal's
  datatype id resolved to something other than an IRI, `base_value_of` rendered that term's
  `Debug` form and used it as the datatype IRI, where `RdfDataset::term_value` states the same
  invariant with `unreachable!`. The fabricated value could not fail at the site; it would
  surface later as an `IriError` about a string nobody wrote. The path is unreachable from the
  public API (the builder interns every datatype through `intern_iri`, and the pack decoder
  refuses a non-IRI datatype entry before a pack becomes a dataset), so the two sites now agree
  on `unreachable!` with the invariant stated, and a test pins that `base_value_of` and
  `term_value` agree on every literal shape.
- **BREAKING** **sparql-eval,geo:** A host function registered through
  `UserFunctionRegistry::register_native` can now raise a SPARQL **expression error** for one
  solution instead of failing the whole query. `NativeFnBody` returns
  `Result<Option<TermValue>, EvalError>` rather than `Result<TermValue, EvalError>` — the same
  three-exit channel `register_expr`'s `ExprFnBody` already carried — so `Ok(None)` means "this
  call has no value for this solution" and `Err` stays reserved for a query-fatal condition. The
  evaluator, not the closure, then applies the outcome the calling context requires: a `FILTER`
  eliminates that solution (SPARQL 1.1 §17), while a `BIND` or `SELECT` expression leaves the
  variable unbound and continues (§10; algebra §18.5 `Extend`). Previously the seam had no
  `Ok(None)` exit at all, so every domain refusal — a malformed literal, an out-of-range index, a
  type mismatch — had to be spelled `Err` and aborted the query; one bad geometry anywhere in a
  dataset failed every query that scanned past it. This was found while merging `purrdf-geo` and
  affected every function on the seam, not just the `geof:` family. Callers with a
  `register_native` body must wrap their success value in `Some` and should move argument-level
  refusals from `Err` to `Ok(None)`.
- **BREAKING** **geo:** `functions::evaluate` returns `Result<Option<TermValue>, EvalError>` (the
  seam shape above) and maps `GeoError::Literal`/`GeoError::Domain` onto the per-solution
  `Ok(None)`; `GeoError::Unsupported`, `GeoError::Config` and the new `GeoError::Arity` stay
  query-fatal, because each holds for every solution alike and answering "no value" would empty a
  result set and present that as the answer. `GeoError` gains an `Arity` variant (a wrong argument
  count is nobody else's mistake — not the data's, not the wiring's) and a
  `GeoError::is_expression_error` predicate that is the single site deciding how far a refusal
  travels. A caller that needs the refusal itself — with its message and kind intact, which a
  SPARQL expression error by construction cannot carry — calls the new `functions::compute`,
  which answers in `Result<TermValue, GeoError>`.
- **shapes:** A SHACL validation report no longer FUSES a blank node it mints with one it
  carries. The report invents `_:report`, `_:r0`, `_:r1`, … and the interior nodes of a
  complex `sh:path`; blank-node labels arriving from the data or shapes graph are opaque
  strings that pass through the IR verbatim, so a data graph containing `_:r0` produced
  `_:r0 a sh:ValidationResult ; sh:focusNode _:r0` — the validation result and the node it
  reports on silently became ONE node, with the report asserting that a
  `sh:ValidationResult` was an instance of the data's own class. Nothing was dropped and no
  error was raised. The minted nodes now take a reserved label prefix whenever, and only
  whenever, the report actually carries a colliding label, so a report with no collision is
  byte-identical to before (the byte-frozen first-party corpus reports are unchanged).
- **entail:** OWL-Direct now DECIDES the `SHOIQ` nominal / inverse-role / qualified-number-restriction
  corner. Both decision cores implement the nominal-introduction rule — Horrocks & Sattler's `NN`-rule
  in the `cfg(test)` concept-tree reference and Motik–Shearer–Horrocks' Table 5 `NI`-rule in the
  production hypertableau — so an ontology with an at-most over an inverse role (an
  `owl:InverseFunctionalProperty`, or the vendored W3C spy-point `webont-description-logic-035`) is
  decided rather than answered `consistent-within-boundaries`; `webont-description-logic-035` now
  decides **inconsistent**, matching its published verdict, and is graded on every conformance run.
- **entail:** **Removed** the `counting-on-inverse` completeness boundary
  (`report::Construct::CountingOnInverse` and its `"counting-on-inverse"` certificate line, plus the
  `decided-within-boundaries` completeness it forced there). The corner is now decided, so a
  reasoning report over it no longer carries that boundary; a consumer that matched the
  `"counting-on-inverse"` boundary name or expected `decided-within-boundaries` there will instead
  see a plain `decided` verdict (or, past the counting ceiling, an honest `budget-exhausted`).
- **BREAKING** **sparql:** The `VERSION "1.2-basic"` declaration is now actually enforced as the
  SPARQL 1.2 Basic profile (full 1.2 syntax minus RDF 1.2 triple terms), not merely retained and
  round-tripped. Evaluation admission now refuses a triple term in any triple/quad pattern or path
  endpoint, a ground triple term in `VALUES`, and the "Functions on Triple Terms" builtins, naming
  the offending construct — for an update, with no mutation applied. Callers that declared
  `1.2-basic` and relied on it silently running the full engine must drop the declaration or
  remove those constructs from the request.
- **BREAKING** **sparql-eval:** An `UPDATE` prologue declaring an unrecognized `VERSION` (anything
  other than `"1.2"`/`"1.2-basic"`) now refuses at admission instead of mutating the store — the
  byte-identical read-only query form was already refused. Callers issuing such requests must
  stop, declare a recognized version, or omit the declaration.
- **BREAKING** **sparql-algebra:** `'*'` is refused for every aggregate but `COUNT` (it was
  previously accepted everywhere and silently answered the group's row count for `SUM(*)`,
  `AVG(*)`, `MIN(*)`, `MAX(*)`, `SAMPLE(*)`, and `GROUP_CONCAT(*)`). `AggregateExpression::new` is
  now the sole, checked constructor — it returns a `Result` and refuses `*`/an empty argument list
  for any aggregate but `COUNT` — and `args` is no longer a public field; callers that built the
  node with struct-literal syntax or read `args` directly must switch to `AggregateExpression::new`
  and the `args()`/`into_parts()` accessors.
- **BREAKING** **sparql-eval:** The aggregate accumulator trait gained a required `into_any`
  downcast (used to merge partial fold states by concrete type instead of recovering only the
  finished term) and its `combine` method now returns `Result<(), EvalError>` instead of `()`, so
  a host contract violation (a partial state of the wrong concrete type) is a typed refusal rather
  than a panic — which matters on `wasm32-unknown-unknown`, where a panic aborts the whole
  instance. Every implementor of `AggregateAccumulator`, including any host-registered
  `CustomAggregate`, must add `into_any` and update `combine`'s return type and propagate the
  downcast helper's error.
- **BREAKING** **sparql-eval:** A prepared plan's aggregate/property-function admission now keys
  on registry INSTANCE identity (a process-monotonic `RegistryId`), not declared metadata alone —
  two independently built registries that declare identically for a shared IRI but resolve it to
  different implementations previously produced the same plan fingerprint, so a plan prepared
  against one registry could execute unrefused against the other. A caller relying on two
  distinctly constructed registries with identical declarations being interchangeable at execution
  time now gets a typed refusal instead of a silently wrong answer; cloning a registry still
  shares its source's identity.
- **BREAKING** **sparql-eval:** Planner admission failures are now attributed to the extension
  seam that actually raised them. An unregistered custom aggregate or an aggregate arity violation
  previously reported the property-function diagnostic code; callers matching on the documented
  aggregate diagnostic code must now handle those failures there instead of under the
  property-function code.
- **BREAKING** **sparql-eval:** The within-group parallel aggregate fold now sizes its chunks from
  the group's row count alone instead of the live host's thread count, so governed outcomes for
  large aggregate folds no longer vary with worker-pool size. Governed outcomes for large
  within-group aggregate folds change on any host whose worker count differs from the new fixed
  reference parallelism; a consumer pinning `GOVERNOR_CORPUS_DIGEST` or `GOVERNOR_PROFILE_DIGEST`
  must re-pin both.
- **BREAKING** **xsd,sparql-eval:** Integer `SUM`/`AVG` now accumulate at arbitrary precision
  instead of a fixed-width accumulator, so a running total that used to overflow into an unbound
  answer now answers exactly (for example, a large positive, a one, and the matching large
  negative now sum to `1` instead of unbound). This changes only the answering direction — a query
  that previously received `unbound` for an overflowing integer `SUM`/`AVG` now receives a value —
  and needs no caller action beyond expecting an answer where one is now owed.
- **BREAKING** **shapes:** `Shapes` gains a public `aggregates: Arc<AggregateRegistry>` field,
  installed at every SHACL-SPARQL validation entry point (including the parallel focus-node chunk
  fork, which previously dropped the aggregate scope across the thread boundary, making a
  registered aggregate's resolution depend on the number of focus nodes). Callers constructing
  `Shapes` via struct literal must now supply `aggregates`, or use `Shapes::default()` / the
  parser's constructor, both of which populate it with an empty registry.
- **BREAKING** **cli,python,purrdf:** A dataset-derived property function combined with an
  entailment regime returned a SHORT answer, reported complete, at a success exit and with no
  diagnostic. The registry is built by the caller, before the call, and therefore before the
  closure exists — so a `--path-relation` walk (or a `path_relations` / `relations_from_graph`
  registration) read the SOURCE data while every other pattern in the same query read the
  closure. Over `ex:sub rdfs:subPropertyOf ex:p . ex:a ex:p ex:b . ex:b ex:sub ex:c .` under
  `rdfs`, `SELECT ?end WHERE { ex:a ex:p+ ?end }` answered `ex:b, ex:c` and the equivalent walk
  answered `ex:b` alone. Both entry points now materialize the closure FIRST and register the
  relations against it, so the two halves of one query read one dataset: `query_with_entailment`
  and `query_with_entailment_governed` take a new `relations: &ClosureRelations<'_>` argument
  (after `options`, before `governors`). Rust callers whose relations are dataset-independent —
  an in-memory table, an empty registry — pass `ClosureRelations::NONE` and keep their present
  behaviour byte for byte; a caller with a dataset-derived relation passes
  `ClosureRelations::rebuilt_by(&f)`, where `f` is handed the materialized closure and returns
  the registry to answer with. The CLI and Python surfaces are unchanged in shape and now supply
  the rebuilder themselves; the C ABI and WebAssembly surfaces register no relation and pass
  `NONE`. One pairing is refused rather than answered: a rebuilder combined with an OWL
  Direct-Semantics run whose restricted chase MINTED existential witnesses, because a walk over
  that closure could return a minted blank node as an observable binding and the regime's witness
  filtration cannot reach a property function's output. It carries the stable code
  `reasoning-closure-relation-witness` (exit 2 from the CLI, `ValueError` from Python) and names
  the regimes that accept the pairing; an `owl-direct` run that mints no witness is not refused.
- **BREAKING** **iri,rdf,cli:** A relative IRI reference with no base IRI in scope is now a hard
  error instead of being interned verbatim. Documents that previously "worked" this way were
  emitting N-Triples no conformant parser accepts, so the failure surfaces an existing defect
  rather than introducing one. Reference resolution is now a single layer, `purrdf-iri`, shared by
  every codec: the RFC 3986 §5.1 precedence chain is an in-document directive
  (`@base`/`BASE`/`xml:base`/`@context.@base`), else a caller-supplied base, else the document's
  retrieval IRI, else the §5.1.4 failure. The stable codes are `iri-relative-no-base` (fixable by
  supplying a base), `iri-not-absolute-by-grammar` (N-Triples, N-Quads, TriX and HexTuples admit no
  relative reference at all, so a base cannot help) and `iri-non-absolute-base` (the supplied base
  has no scheme). Three surfaces have a retrieval IRI, all of them ones that opened the file
  themselves: `purrdf-slice` derives it (the workspace's single RFC 8089 `file://` derivation),
  and `purrdf-shapes`' shape-union loader and `purrdf-cli` consume that derivation rather than
  repeating it — so a file input needs no flag on any of the three. Every surface handed BYTES —
  the `purrdf-rdf`/`purrdf-iri` library APIs, wasm, the C ABI, Python and CLI stdin — has no
  retrieval IRI and hard-fails as §5.1.4 specifies. Callers on
  those surfaces must give the document a base directive or pass one to the API. On the way out,
  a syntax that can express a base (Turtle, TriG, RDF/XML, JSON-LD, YAML-LD) now emits it and
  relativizes against a supplied base; one that cannot (N-Triples, N-Quads, TriX, HexTuples) keeps
  writing absolute IRIs. See "Base IRIs & Relative References" in The PurRDF Book.
- **BREAKING** **rdf:** `serialize_dataset_base_only` is **removed**, and `serialize_dataset_with`
  is added as the one serialization seam the rest of the family is now expressed through. The
  split family could not state a document base together with a graph selection or the RDF 1.2
  statement layer: `serialize_dataset` took the selection and the layer but no base, while
  `serialize_dataset_to_format` took a base but forced `SerializeGraph::Dataset` and the transcode
  projection — so asking for a base on RDF/XML silently traded away reifier and annotation rows
  the RDF/XML emitter can in fact render. `serialize_dataset_with(dataset, format, base_iri,
  &SerializeOptions { selection, statement_layer, jsonld_options })` states all four axes, and the
  new `StatementLayer` enum makes the third an explicit choice — `Emit` (render it, or fail closed
  where there is no surface for it), `Project` (drop it and REPORT the count), or
  `PerFormatCapability` (the registry's `carries_star()` decision, which is what every
  `*_to_format` spelling applies). `serialize_dataset`, `serialize_dataset_with_jsonld_options`,
  `serialize_dataset_to_format` and `serialize_dataset_to_format_with_jsonld_options` keep their
  signatures and behaviour and are one-expression delegations, so there is no second code path.
  Replace `serialize_dataset_base_only(d, media_type, selection)` with `serialize_dataset_with`
  under `StatementLayer::Project`, which additionally hands back the dropped-row count instead of
  leaving the caller to recompute it.
- **BREAKING** **capi:** The C ABI moves `0.6.0` → `0.7.0`, an **incompatible** bump.
  `purrdf_shacl_validate_to_sarif` and `purrdf_shacl_entail_to_ntriples` each gained a
  `shapes_base_iri` parameter **in the middle** of the existing list, between `shapes_ttl` and
  `data_nt` — a host compiled against `0.6.x` and run against `0.7.0` without recompiling passes
  `data_nt` into the `shapes_base_iri` slot and its `PurrdfBuffer **` out-pointer into `data_nt`,
  which the boundary then reads as a NUL-terminated C string. That silent, unguardable misread is
  the whole reason the version moved; the parameter is positional rather than appended because it
  belongs beside the document it qualifies. `purrdf_serialize_jsonld_configured` likewise gained
  `base_iri` after `media_type`, the slot it holds on `purrdf_serialize`. Both breaks ride the one
  bump because `0.7.0` is unreleased, so a consumer recompiles once rather than twice for one
  reason. Every C host must recompile against the new `purrdf.h`. Signature drift is now caught at
  test time: `crates/rdf-capi/tests/abi_signatures.rs` pins the complete exported prototype list
  against a committed snapshot and against the version triple, so a future incompatible change
  cannot reach a release without an author deliberately moving the version.
- **BREAKING** **shex,cli:** A shape map naming a shape label the schema does not declare — and
  `START` against a schema that declares no start shape — is now a hard refusal
  (`ShexError::UnknownShape`; CLI exit **1**) instead of a `"status":"nonconformant"` result at
  exit **0**.
  Scripts that parsed the JSON result and ignored the exit code will now see a failure where they
  previously saw a definite negative about the data; that is the point, since the old answer spent
  the format's one word for a finding about the DATA on a mistake the data had no part in — a typo
  in a shell's own argument read back as a validation verdict. Labels reachable through the import
  closure count as declared. The refusal happens before selector expansion, so a selector matching
  no node is refused identically to one matching many. The ShEx specification's ShapeMap status
  vocabulary has no value meaning "not evaluated", so this was resolved on the project's
  hard-fail doctrine rather than on anything the specification requires.
- **BREAKING** **cli:** `--base` is now refused by name when NEITHER leg of the operation can
  spend it, instead of being accepted and silently never read. A base is spent on parse (the
  source syntax admits a relative reference) or on serialize (the target syntax can write a base
  directive); `convert --from ntriples --to ntriples --base http://example.org/` satisfies
  neither and previously exited 0 having done nothing and said nothing. It is now a usage error
  (exit **2**) naming each leg and why it cannot take the value. A base ANY leg can spend is still
  honoured, so `--base X --to ntriples` continues to resolve the input. The same refusal covers a
  pack `--from`/`--to`, which carries no document base at all. Scripts passing `--base`
  unconditionally across format pairs must drop it on the pairs that cannot use it.
- **BREAKING** **rdf:** `GtsFoldView::new` and `GtsFoldView::with_config` now return
  `Result<Self, RdfDiagnostic>` instead of `Self`. They refuse a graph whose term table lets a
  term resolve through itself, with the code `gts-self-reaching-term`. The view's accessors —
  `nq_token`, `public_value` and everything built on them — walk a quoted triple's resolved
  components down to the leaves, so a self-reaching term recursed without bound and aborted the
  process; the view now refuses to EXIST rather than hand back an object whose every renderer is
  a process kill (the fold-time refusal GTS-SPEC §7.3 permits, applied once at construction
  instead of as a guard inside every walk). A graph read off the wire cannot contain one — the
  reader already refuses the row that would close the loop — so this reaches only callers who
  assemble a term table themselves. Rust callers must handle or propagate the `Result`; `?` is
  usually the whole change.
- **BREAKING** **python:** `GtsFoldViewNative.from_bytes` and `GtsFoldViewNative.from_parts` now
  raise `ValueError` carrying `gts-self-reaching-term`, for the reason above. `from_parts` is the
  reachable one: it is handed a caller-assembled term table, which `from_bytes`' reader validates
  on its own. Python callers constructing a fold view from parts must handle `ValueError`.
- **BREAKING** **rdf:** The byte-reproducibility classifier for `CONSTRUCT` dataset-description
  views now refuses a custom aggregate call, a custom scalar-function call, or any `SERVICE`
  clause (including `SERVICE SILENT`), matching the registry-dependency doctrine the
  property-function arm already applied — these depend on a registry or endpoint the classifier
  cannot inspect, so a view using them is not byte-reproducible. Callers who relied on such views
  being accepted must configure them without those constructs, or accept the resulting refusal.
  Built-in aggregates and built-in functions are unaffected.
- **rdf:** The byte-reproducibility refusal above, and the planner's two admission seams, now name
  the CONSTRUCT rejection's actual cause (a custom aggregate call, a custom scalar-function call,
  or a `SERVICE` clause) instead of funnelling every rejection through one message that named only
  the nondeterministic-builtin/blank-minting causes, which none of the three later-added causes
  appears in.
- **xsd,sparql-eval:** Integer `AVG`'s arbitrary-precision quotient is now taken on the same
  arbitrary-precision path its sum already uses, so an average that used to answer nothing whenever
  the exact running total escaped `i128` — even when the quotient itself was ordinary — now
  answers exactly (for example, `AVG` of two copies of the largest representable integer now
  answers that integer, rather than unbound).
- **sparql-eval:** `SERVICE` bodies forward custom scalar-function calls again unless `SILENT` is
  present. A prior fix closed a real silent-wrong-answer hazard for `Function::Custom` calls
  inside `SERVICE`, but the refusal it added was unconditional rather than scoped to the
  hazard it described — so a plain (non-`SILENT`) `SERVICE` body containing a call to the
  endpoint's own extension function (e.g. `FILTER(<http://example.org/fn>(?x) > 0)`) now
  hard-failed even though a non-silent `SERVICE` already turns any endpoint-side failure
  into an honest error. Callers who worked around the regression by dropping `SILENT` need
  no further change; callers who still need `SILENT` and hit the refusal should read the
  error message, which now names the same workaround (drop `SILENT`) directly.
- **sparql-eval:** The `SERVICE`-forwarding `LATERAL` guard is rebuilt to close a bypass and
  correct an over-broad refusal. The bypass: the guard's `Lateral` arm recursed into a
  variable-endpoint `SERVICE ?g { … }` auto-wrap's `left` operand only, never its wrapped
  `Service::inner` — so a written `LATERAL` nested inside `SERVICE ?g { … }` (itself nested
  inside a forwarded body) reached a remote endpoint's text unrefused. The guard now walks the
  full forwardable body, including every `Service::inner` (fixed-IRI or variable-endpoint), so a
  written `LATERAL` is found no matter how deeply it is nested. The over-broad refusal: a
  `LATERAL` clause inside a forwarded body was refused unconditionally, even though the hazard —
  a `SILENT` clause swallowing the endpoint's rejection into the join identity, a result that
  looks complete and is wrong — exists only under `SERVICE SILENT`. The refusal is now scoped to
  `SILENT`, naming it as the reason; a plain, non-silent `SERVICE` body forwards its `LATERAL {
  … }` text and surfaces the endpoint's actual verdict — an answer from a `LATERAL`-capable
  endpoint (`LATERAL` is Apache Jena's own extension) or an honest `EvalError::Remote` from one
  that rejects it. Callers who need `LATERAL` federated to a `LATERAL`-capable endpoint should
  drop `SILENT`; callers relying on the previous unconditional refusal under `SILENT` see no
  change, since `SILENT` still refuses.
- **sparql:** Let aggregate partial states merge by their concrete type (see the `into_any`
  entry above for the resulting trait break).
- **BREAKING** **sparql-eval:** The three extension registries (custom aggregates, property
  functions, SHACL-AF functions) move from `Option<&Registry>` to plain `&Registry`, with a
  canonical `Registry::EMPTY` constant replacing the `None` case. `QueryOptions`'s three registry
  fields and `PlanCache::prepare_with_relations`'s registry parameters change type accordingly
  across the core engine, all four host surfaces (CLI, C ABI, wasm, Python), the shapes crate, and
  the conformance harness; callers pass `&Registry::EMPTY` where they previously passed `None`.
  Decimal division's zero-divisor guard was corrected in the same change: it now returns the
  crate's typed error in release builds instead of a debug-only assertion that could panic.
- **BREAKING** **results:** The JSON/XML results writers now spell RDF 1.2 base direction as
  `its:dir` (were `dir`/`purrdf:dir` under a namespace this crate minted for itself), and the
  always-on purrdf-branded provenance extension is gone: `to_json`/`to_xml`/`serialize` take an
  `Option<&ProvenanceNamespace>`, and emission requires a caller-supplied prefix and IRI —
  omitting one emits no extension member and reports the drop, matching the CSV/TSV contract.
  `ProvenanceNamespace` separately moves to private fields and a fallible constructor,
  `ProvenanceNamespace::new(prefix, iri)`: the prior public fields let an unvalidated `prefix`
  splice unescaped into XML element/attribute names (a markup-injection hole), so `prefix` is now
  validated as an XML Namespaces `NCName` and `iri` as an absolute IRI. Callers constructing
  `ProvenanceNamespace` via struct literal must switch to the constructor and handle the `Result`.
  The TSV writer now hard-fails (`Error::Format`) on a variable name containing a tab or line
  break instead of silently corrupting the column/record structure.
- **BREAKING** **results:** The XML writer now declares the `its:` namespace once on the document
  root (with an `its:version` attribute) when any directional literal appears anywhere in the
  result set, instead of inline on every directional literal, matching the spec's worked examples;
  the JSON writer no longer emits an explicit `"datatype"` member on a plain (simple) literal, per
  the results-format's own encoding table. Both are byte-level output changes: a consumer pinning
  writer bytes must re-pin.
- **BREAKING** **sparql-results:** `ProvenanceNamespace` gained the validated, fallible
  constructor described above; unvalidated construction is no longer possible (see the results
  writer-spelling entry).
- **BREAKING** **rdf-core:** Replay delta-added quads in insertion order, not hash order. The
  copy-on-write delta layer kept its added/suppressed keys in standard hash sets (a fresh random
  seed per process), so freezing and pattern scanning walked them in per-process hash-iteration
  order rather than a reproducible one — the same query over the same data mutated the same way
  could return rows in a different order from one run to the next, which broke the documented
  ordering guarantee for `GROUP_CONCAT` and the first/last aggregates. Those sets now use the
  crate's fixed-key hasher and carry each key's insertion ordinal, so a delta replays in call
  order. The CLI was never affected (it parses straight into a builder and never uses the delta
  layer); the Python, WebAssembly, and C interfaces all wrap the delta layer directly and were all
  fixed by this one kernel change. Callers that happened to rely on the previous arbitrary order
  may observe a different, now-stable order.
- **BREAKING** **xsd:** `parse_duration` now enforces the `yearMonthDuration`/`dayTimeDuration`
  subtype pattern facets (XSD 1.1 Part 2 §3.4.26/§3.4.27) at parse time instead of accepting any
  lexical form its caller's declared tag claims: a `D`/`T` component under a `yearMonthDuration`
  tag, or a `Y`/`M` date component under a `dayTimeDuration` tag, is now a typed `InvalidLexical`
  rather than a silently accepted value that violated its own declared subtype. A caller lexical
  that relied on this laxity (e.g. `"P1D"^^xsd:yearMonthDuration`) now fails to parse instead of
  succeeding with a value its own datatype's pattern facet forbids.
- **BREAKING** **xsd:** A `Duration` whose months and seconds components carry opposing signs
  (e.g. `+12` months against `-1` day) is no longer constructible — XSD 1.1 Part 2 §3.3.6 puts
  mixed-sign values outside the lexical mapping's range, so there is no correct string to emit for
  one. The guard now sits in the single smart constructor every construction site — parsing and
  arithmetic alike — routes through, so it cannot be reached through one door (subtraction) while
  missed through another (addition of an already-negated operand). A caller combining a
  `yearMonthDuration` and a `dayTimeDuration` of opposing sign now gets a typed `OutOfRange`
  instead of a value that could never round-trip through its own canonical lexical form.
- **BREAKING** **xsd:** `duration =` (`op:duration-equal`) is now total, matching F&O: two
  durations with equal months and equal seconds compare equal regardless of declared subtype,
  where a cross-subtype comparison previously fell through to an incomparable/type-mismatched
  result — the reading `<`/`>` correctly keeps, since F&O defines ordering only for the
  `yearMonthDuration`/`dayTimeDuration` subtypes, not for the general type. A caller that treated
  duration equality as raising an error must now expect a plain `bool`.
- **xsd:** Two further `Duration` defects, both reachable only through extreme inputs, are closed
  alongside the arithmetic surface below: month accumulation during duration parsing used
  unchecked `i64` arithmetic (`"P9223372036854775807Y"` silently wrapped) and now reports a typed
  `OutOfRange`; and a zero-valued `yearMonthDuration`'s canonical lexical form is now the
  subtype-correct `"P0M"` rather than `"PT0S"`.
- **xsd:** An unreachable branch in exact decimal division — a scale-down path that could fire
  only if the crate-wide `scale <= 18` invariant were already broken, and whose own comment
  incorrectly called that "unusual but possible" — is now a build-surviving `unreachable!()` in
  place of a debug-only assertion, so a future violation of that invariant cannot ship a silent
  truncation in a release build. `xsd:duration ÷ xsd:duration` still reports a typed `OutOfRange`
  for the case that actually is reachable: scaling one operand's mantissa past `i128::MAX`.
- **BREAKING** **sparql-algebra,rdf:** The serializer rendered a join's right operand bare
  whenever it began with its own bare left, so a re-parse of the emitted text re-associated an
  `OPTIONAL`/`MINUS`/`FILTER`/`BIND`/`LATERAL` right operand into a semantically different tree —
  and this text is the `SERVICE` federation wire format, so a remote could receive a different
  query than the plan it was chosen for. Every re-absorbable right operand is now braced, decided
  by an exhaustive predicate; a plain join's right operand stays bare, since join associativity
  makes the re-association semantics-preserving. A variable-endpoint `SERVICE` under `LATERAL` is
  no longer double-wrapped in the keyword its own re-parse would re-wrap. The corpus round-trip
  sweep that caught this also surfaced and fixed five further serializer defects, none of them
  `LATERAL`-dependent: a multi-condition `HAVING` chain silently dropped its aggregate
  reconstruction, a projection-less aggregate emitted an illegal `SELECT *` over `GROUP BY`, a
  `FILTER` flattened as a left operand lost its group, property paths failed to parenthesize by
  precedence (alternation under sequence), and a trailing `VALUES` failed to absorb into its body
  group. A caller comparing serialized query bytes against a previous release should expect these
  five constructs, and the right-operand-braced ones above, to serialize differently — and
  correctly.
- **BREAKING** **sparql-eval:** Correlated evaluation (`LATERAL`, and `EXISTS`/`NOT EXISTS`
  correlated through an expression) substituted outer bindings by rewriting terms in place, which
  could not place a literal or blank-node binding into a triple position, silently skipped path
  and predicate positions, flipped `MINUS` into its disjoint-domain case by erasing the shared
  variables that make the two sides comparable, and crossed sub-select projection boundaries —
  correlating a variable the SEP-0006 scope example says is explicitly NOT correlated.
  Substitution now joins each pattern leaf with a one-row `VALUES` table carrying that leaf's own
  bindings, narrowed at every projection boundary to the variables it actually projects; an
  expression position keeps direct value substitution for an IRI or literal binding, and a
  blank-node or quoted-triple binding referenced ONLY in an expression position (no leaf
  occurrence for the leaf join above to carry it) is now carried the same way — by joining the
  expression's own owning pattern node against a one-row `VALUES` table — since no SPARQL
  expression syntax can spell either term kind as a rewritten constant; `BOUND` in particular now
  answers correctly for a bound variable of ANY term kind rather than only IRI/literal ones. This
  is a strictly corrective behavior change: `MINUS` inside a correlated `LATERAL`/`EXISTS` now
  answers correctly instead of a domain-flipped wrong answer, a `LATERAL`-bearing pattern is now
  refused rather than silently forwarded to a `SERVICE` endpoint (a remote rejecting the extension
  under `SILENT` would otherwise have contributed the identity table as a silent wrong answer),
  and a blank-node or quoted-triple outer binding reachable ONLY through an expression inside a
  `LATERAL` right-hand side no longer silently drops the row.
- **BREAKING** **sparql-algebra:** SEP-0007 Part 3's assignment restriction is now enforced at
  parse time: a `BIND`/a sub-`SELECT`'s `(expr AS ?v)` projection target/a `GROUP BY (expr AS ?v)`
  grouping target, or a `VALUES` column, inside an `EXISTS`/`NOT EXISTS` body — both polarities
  share the same grammar production, so both are covered identically, including a nested
  `EXISTS`'s own body checked against its immediately enclosing `EXISTS`'s scope — that rebinds a
  variable already in scope on the row being filtered is now a typed `ParseError` naming the
  variable and the introducing construct, instead of being silently accepted and evaluated. A
  rebinding confined to a `MINUS` right operand inside the body stays legal at any depth, since
  such an introduction never escapes it to become observable. A caller whose query relied on the
  previously accepted (and ambiguous) rebinding must rename the colliding variable.
- **BREAKING** **sparql-eval:** Three `EXISTS`/`NOT EXISTS` answer defects are corrected. A
  `GRAPH ?g { … }` body correlated through the row being filtered left the graph name unresolved
  against that row — the substitution walk skipped it because only one of its two callers ran the
  compatibility merge the name needed — so an existence filter could accept rows bound to a graph
  that does not actually hold the pattern; the name now resolves to the row's bound IRI for
  indexed selection. A correlation reaching a nested `EXISTS`'s body only through a triple position
  (never that inner's own expression positions) went undetected by the variable walk feeding the
  correlation decision, so that inner ran unconstrained instead of per-row; the walk now agrees
  with the one substitution itself uses. And a bare `OPTIONAL` at the top of a correlated body was
  evaluated as though its right side and join condition mattered to the existence test, when
  `OPTIONAL` pads every left row unconditionally and never removes one — `FILTER EXISTS { OPTIONAL
  { P } }` is always `true` (and its `NOT EXISTS` twin always `false`) regardless of whether `P`
  matches, which Existential Normal Form's spine-top `LeftJoin` erasure now decides directly. A
  query that depended on any of the three previous wrong answers now gets the correct one.

### Features
- **shapes:** New `ValidationReport::to_dataset()` returns the report graph as a frozen
  `Arc<RdfDataset>` — the report's PRIMAL RDF form. Rendering a report in any syntax other
  than N-Triples previously forced a `to_ntriples()` → `parse_dataset()` round-trip; that
  parse was pure waste, because the report was already being materialized as IR quads and
  the N-Triples text was only ever a serialization of them. `to_ntriples()` is now defined
  as "serialize `to_dataset()`", so the two are the same graph by construction rather than
  by coincidence, and the direct path carries every RDF 1.2 term the report holds (a
  triple-term focus node or `sh:value`, and blank-node labels the text grammar can only
  carry escaped) instead of whatever survives a text grammar and a parser's relabelling.
  Equivalence is proven canonically (RDFC-1.0) over a report spanning all four severity
  kinds, IRI/blank/triple-term focus nodes, a complex `sh:path` shared by two results, and
  typed/language-tagged/blank/triple-term values. Rust surface only: no Python, JS/wasm, or
  C ABI equivalent is added.
- **cli:** `purrdf validate --format <rdf-syntax>` no longer serializes the report to
  N-Triples and re-parses that text; it hands the report's own dataset to the shared sink.
  Identical output, one fewer full parse of the report per invocation.
- **cdt:** New crate `purrdf-cdt` implementing SEP-0009 SPARQL Composite Datatypes
  (`cdt:List` / `cdt:Map`) as a closed leaf over `purrdf-iri` + `purrdf-xsd` only. The
  function library is the spec's fifteen — `cdt:List`, `concat`, `contains`, `get`, `head`,
  `tail`, `reverse`, `size`, `subseq`, `cdt:Map`, `containsKey`, `keys`, `merge`, `put`,
  `remove` — and the set is CLOSED: there is no registry to configure and no way for a
  caller to shadow a spec function, so the same query means the same thing on every host.
  Nesting is fully ITERATIVE under three bounds (depth 64, 2²⁰ elements, 64 MiB); a
  million-deep input exits cleanly rather than overflowing the stack, which would abort the
  process rather than raise. PurRDF mints no vocabulary here: the SEP-0009 namespace is the
  spec's own fixed string, recognized and never invented.
- **sparql:** Evaluate SEP-0009 end to end. The fifteen functions are recognized at parse
  time (with arity enforced there) and dispatched by the evaluator; `FOLD` rides the
  aggregate ACCUMULATOR seam as a keyword aggregate carrying its own `ORDER BY`; `UNFOLD` is
  its own `GraphPatternNotTriples` alternative over an expression — structurally where
  `LATERAL` sits — rather than a property function, because the property-function registry
  keys on a predicate IRI and no `UNFOLD` predicate IRI exists to key on. `ORDER BY`, `MIN`
  and `MAX` order composite literals by the value they denote. Blank-node labels written
  inside a composite lexical form bind through the SAME ingress rule as bare `_:` tokens, on
  every codec path, and participate in canonicalization and skolemization — so `_:b` written
  as a subject and `_:b` written inside a `cdt:List` in the same document are one node.
- **BREAKING** **sparql-algebra:** `GraphPattern` gains an `Unfold` variant and
  `Function` gains a `Cdt` variant. Both enums are matched exhaustively across the
  workspace; a downstream consumer matching on either without a wildcard arm must add the
  new arm. There is no Cargo feature to opt out — CDT is unconditional, like every other
  part of the engine.
- **conformance:** The vendored SEP-0009 suite (`vectors/sparql-cdt/`, `awslabs/SPARQL-CDTs`
  at commit `e0a7465`, 658 cases across six groups) is run and reports its own scoreboard
  row: **658 / 658, 0 ledgered**. Note the divergence that number cannot express, stated in
  full in [`docs/CONFORMANCE.md`](docs/CONFORMANCE.md): PurRDF's reader accepts two element
  forms the published lexical space does not — an RDF 1.2 triple term and a directional
  language-tagged literal — because refusing an RDF 1.2 term type is not an admissible
  outcome for this toolkit. **A conformant SEP-0009 reader handed one of those literals will
  call it ill-formed.** The mitigation is executed rather than argued: a scan grades every
  composite literal in every corpus this workspace ships and proves not one of them needs
  either form, with its counts pinned as equalities so it cannot pass vacuously.
- **BREAKING** **sparql-eval:** Generalize the `SERVICE` seam into a per-service-context
  `ServiceResolver`. The trait `RemoteQuerySource` is renamed `ServiceResolver` and its method
  is renamed `resolve`, taking the whole request as one `ServiceRequest` value (endpoint,
  forwarded query text, the `SILENT` flag, stop signal, intermediate-cell ceiling) instead of
  four positional arguments; `LocalRemoteQuerySource` is renamed `InProcessServiceResolver` and
  moves to the new `purrdf_sparql_eval::service` module (re-exported at the crate root).
  Implementors must rename the trait and method and destructure `ServiceRequest`; callers must
  rename the two types. `HttpRequest` gains a `headers` field carrying the per-service headers
  and credential — a transport built with struct-literal syntax must add it, and a transport
  that receives but ignores it will issue an *unauthenticated* request for a service configured
  as credentialed, whose rejection `SERVICE SILENT` is entitled to swallow. `HttpTransport`
  itself is unchanged, and a source with no catalog sends the same bytes it always did.
- **sparql-eval:** Add per-service policy for `SERVICE` federation: a `ServiceCatalog` maps a
  service IRI to a `ServiceProfile` carrying extra headers, a redacting `ServiceCredential`
  (bearer / RFC 7617 basic / arbitrary header), timeout and User-Agent overrides, and an
  explicit `ServiceCapabilities` grant set (`Query`, `Network`, `Credentials`). Context lives on
  the resolver keyed by endpoint, never in the service IRI — which would put credentials into
  the query text, plans, and receipts. Catalogs deny by default and are opt-in: a resolver with
  no catalog behaves exactly as before, and gating a service adds no header its profile does not
  carry. Withholding `Network` makes an in-process façade provable rather than promised —
  `InProcessServiceResolver` holds a dataset map and no transport of any kind — and the new
  `ServiceRouter` composes in-process and network resolvers with the routing table, not the
  query text, deciding which answers what. The catalog is consulted on every resolution,
  including one nested inside a forwarded body. The `SILENT` contract is now stated in full:
  `SILENT` swallows an unreachable or undecodable endpoint to the join identity, and never
  swallows a capability denial or a governor trip, both of which are decisions taken on this
  side of the seam. There is deliberately no knob softening that — a host wanting a blocked
  service to read as unreachable returns a transport error from its own resolver. The
  denial holds at every nesting depth: `EvalError` gains a structured `ServiceDenied`
  variant (the enum is `#[non_exhaustive]`, so this is additive) so that a denial raised by
  a `SERVICE` nested inside a forwarded body is re-raised as a denial rather than decaying
  into a silenceable endpoint failure that an enclosing `SERVICE SILENT` would swallow to
  the join identity. A credential is also validated when it is attached rather than when it
  is rendered — CR/LF/NUL in a bearer token or an arbitrary credential header is refused at
  configuration time, with the credential withheld from the message, while a Basic password
  may still contain any byte because it is base64-encoded before it reaches the wire.
- **sparql-eval:** Add path-WITNESS property functions, which answer the derivation question the
  core grammar's property paths cannot: `?s ex:p+ ?o` reports that some route exists and binds only
  the endpoint pair, while a call to `?start <caller-iri> ( ?end ?pathId ?len ?step ?node ?edge )`
  binds the route itself — one row per hop, with `?edge` the traversed STATEMENT as a first-class
  RDF 1.2 term that joins straight back into the dataset by an ordinary basic graph pattern.
  `GROUP BY ?pathId` with `ORDER BY ?step` reassembles a whole walk inside the query language, so a
  caller can weight, filter, or re-join a route without host code and without a list term. Two
  relations, not one with a mode flag, because the planner reads cardinality off the registration:
  `PathWitnessRelation` enumerates every simple-prefix walk (exponential in the worst case) and
  `ShortestPathWitnessRelation` yields one shortest witness per reachable pair (polynomial).
  Enumeration terminates structurally on cyclic input, and its endpoint projection equals `p+`.
- **cli:** Add `purrdf query --path-relation` and `purrdf update --path-relation`, the binary's
  first property-function registration surface — before it, `QueryOptions::property_functions`
  stayed empty on every call. Repeatable; the value is semicolon-separated `key=value` pairs
  (`iri`, repeatable `forward`/`inverse`, `min-hops`, `max-hops`, `max-paths-per-seed`,
  `max-expansions`, `mode=walk|shortest`). Every key is mandatory and none has a default: PurRDF
  mints no vocabulary IRIs, so the relation IRI is caller-supplied with no default namespace, and
  a traversal envelope the binary invented would be a limit the operator never read. Each
  malformed spelling names the offending token. The flag reaches the ungoverned, governed,
  `--explain`, and `--entailment` lanes of `query` and the `WHERE` clause of `update`; the
  `--explain` receipt's `relations` block now names what was registered.
- **python:** Add the `path_relations` keyword beside `relations` / `relations_from_graph` on
  every `Store` and `MutableDataset` query and update entry, registering a path-witness relation
  over the store's own edges as `{iri: (steps, min_hops, max_hops, max_paths_per_seed,
  max_expansions_per_invocation, mode)}`. It crosses the boundary as pure data — a specification
  of which directed predicates a hop may follow, never a Python callable — so the evaluation still
  runs with the GIL released. Every envelope field is mandatory; an unknown direction or mode
  string, an empty or duplicated step alternation, a non-IRI predicate, and an unbuildable
  envelope each raise `ValueError` carrying the engine's own diagnostic.
- **xsd:** Implement the XPath Functions & Operators section 9 temporal operation table:
  timezone adjustment for `dateTime`/`date`/`time`, `yearMonthDuration`/`dayTimeDuration`
  arithmetic with month-end clamping, instant subtraction, and duration add/subtract/
  multiply/divide computed in exact `Decimal`. The existing partial order is unchanged; parsing
  and one canonical form are, per the `xsd` Bug Fixes entries above — subtype pattern facets are
  now enforced at parse time, and a zero-valued `yearMonthDuration` now canonicalizes to `"P0M"`
  instead of `"PT0S"`.
- **sparql:** Add the `ADJUST` builtin over `dateTime`, `date`, and `time` (SEP-0002's
  two-argument signature over the new F&O adjust-to-timezone family): shifts a timezoned value,
  annotates an untimezoned one, and treats the empty simple literal as timezone removal.
- **BREAKING** **sparql:** Retain the `VERSION` declaration as a typed value. `Query` and
  `Update` gain a `version` field (`SparqlVersion`) on every variant, exposed via a new
  `version()` accessor beside `dataset()`/`base_iri()`; construction sites using struct-literal
  syntax without struct-update (`..`) must add the field. Evaluation admits only `"1.2"` and
  `"1.2-basic"`; anything else is refused at the evaluation chokepoint before any work is spent,
  naming the declared string, while parsing itself stays syntax-only.
- **BREAKING** **sparql:** Re-found the aggregate algebra on the specification's own shape:
  `AggregateExpression` is a struct (`function`, `args`, `scalarvals`, `distinct`) rather than a
  lossy simplification, `CountStar` is gone (`COUNT(*)` is the empty argument list), and
  `GroupConcat` carries no separator payload (the separator is the `"separator"` scalarval). See
  the matching `sparql-algebra` bug-fix entry above for the resulting constructor break.
- **sparql:** Evaluate custom aggregates through a fold-algebra registry: a caller registers an
  `init`/`step`/`combine`/`finish` accumulator under an IRI, reached from query text as
  `AGG(<iri>, [DISTINCT] arg, arg, …)`; an unregistered IRI or wrong-arity call is refused at
  prepare time, before any budget is spent, and the prepared plan carries the registry's
  fingerprint (see the registry-instance-identity bug-fix entry above).
- **BREAKING** **sparql:** Price the aggregate fold in the governor profile. Profile v6 adds two
  charge points — `aggregate-invocation` (once per group per aggregate expression) and
  `aggregate-accumulation` (once per value inspected) — shared by built-in and custom aggregates.
  `GOVERNOR_PROFILE_VERSION` is 6 and the profile/corpus digests a consumer pins have moved.
- **BREAKING** **sparql-eval,xsd:** Charge the aggregate fold's retained per-group row buffer to
  the scratch-bytes governor as it is buffered, on both the built-in and registered-aggregate
  paths; that real, group-size-proportional memory was previously unpriced by any resource
  dimension. Only the scratch-bytes figures move — fuel is byte-identical, so
  `GOVERNOR_PROFILE_VERSION` and its digest correctly stay put — but a governed query near a
  scratch-bytes ceiling may now be refused where it previously completed, and a consumer pinning
  the frozen governor corpus's byte-frozen expectations must re-pin against the new figures.
- **sparql:** Fold single large groups in parallel: rows fold in chunks whose partial states
  combine strictly in chunk order, byte-identical to the sequential fold for every algebraic
  class. `GROUP_CONCAT`'s row order is now pinned by exact strings (see the SPARQL querying book
  chapter's "GROUP_CONCAT ordering" section for the guaranteed reading), and a blank node or
  triple term in its input now poisons the fold to unbound — the same reading `SUM`/`AVG` already
  use for a non-numeric running total — where it was previously silently dropped. This is a
  behavior change to `GROUP_CONCAT` over non-literal input, not an API break: a query that used to
  get a partial concatenation silently omitting a blank-node/triple-term value now gets unbound.
- **sparql:** Ship a statistical aggregate set under caller configuration: ten exact statistical
  aggregates (`MEDIAN`, `PERCENTILE`, `STDDEV`, `STDDEV_POP`, `VARIANCE`, `VAR_POP`, `MODE`,
  `FIRST`, `LAST`, `TOPK`) register as fold instances under a namespace the caller supplies (no
  default), reached one call away via `AggregateRegistry::register_statistical_aggregates`.
- **BREAKING** **sparql:** Thread an aggregate namespace through every host surface — a keyword
  argument on the Python query/update entry points, a flag on the CLI query/update subcommands, a
  parameter on the governed wasm entry points, and a nullable string on the governed C ABI entry
  points — so the statistical aggregate set is reachable from every binding, not only the embedded
  Rust engine. The C ABI's version moves `0.3.0` -> `0.4.0` to reflect the additive surface, and
  its header is regenerated; at this point in the series, the entailment and explain CLI lanes,
  and the ungoverned/entailment wasm calls, refuse the parameter outright since they structurally
  cannot honour it — closed by the entry below, which carries the C ABI to `0.6.0`.
- **BREAKING** **sparql-eval,purrdf:** The entailment-aware query lanes
  (`purrdf::query_with_entailment`/`query_with_entailment_governed`) hardcoded empty query
  options, so no scalar-function, property-function, or aggregate registry could reach a query
  evaluated over an entailed closure — `AGG(<{NS}MEDIAN>, …)` over an inferred closure was simply
  refused. Both lanes now take a `QueryOptions` and thread it through closure parsing, the
  witness-restriction rewrite, and evaluation. `QueryExplanation` gains an `aggregates()` accessor
  and a rendered block naming each resolved aggregate with its arity, volatility, algebraic class,
  state bound, and scalar parameters, mirroring how resolved relations are already reported. The
  CLI's prior refusal of `--aggregate-namespace` beside `--entailment` is removed. This closes the
  gap at the Rust engine layer; the C ABI, wasm, and Python bindings did not yet expose the
  parameter on their entailment-aware entries until the entry below.
- **sparql,capi,wasm:** Accept the aggregate namespace on the entailment-aware governed query lane
  everywhere it previously took no `QueryOptions` seam at all: the C interface, the WebAssembly
  binding, and the Python binding gain the same namespace parameter their ordinary governed
  entries already had, so `AGG(<{NS}MEDIAN>, ?x)` resolves over an entailed closure exactly as it
  resolves over a raw view. The C ABI's version moves `0.4.0` -> `0.6.0` (`0.5.0` is skipped —
  one commit carries both the host-surface change and the version bump) and its header is
  regenerated.
- **BREAKING** **capi:** `purrdf_serialize` gains `out_directional_literals_dropped` and
  `out_named_graph_rows_dropped` beside the existing `out_statement_rows_dropped`, so the whole
  realized loss of one serialization is partitioned by cause and no row is charged twice: a
  star-capable single-graph target (Turtle, N-Triples) previously reported `0` while silently
  discarding every named graph it was handed. Each count stays independently nullable. This
  transcode lane flattens and counts rather than refusing the way the query lane does, so a
  dataset whose every row is graph-scoped serializes to a single-graph syntax as a well-formed
  EMPTY document with status `OK` and the whole loss in `out_named_graph_rows_dropped` — pinned
  from C in the smoke test. The C ABI's version moves `0.6.0` -> `0.7.0` and its header is
  regenerated; the minor number tracks the exported signatures, so an additive parameter bumps it
  too, and every C caller must widen the call.
- **BREAKING** **sparql-eval,cli:** Give the engine one options-carrying explain entry,
  `NativeSparqlEngine::explain_query_with_options`/`_view`, that carries the SHACL-AF function,
  property-function, and aggregate registries together, and remove the narrower single-registry
  explain and query entries (`explain_query_with_aggregates`, `explain_query_with_property_functions`,
  `query_with_property_functions`, `query_with_user_functions`, and their `_view` twins). A query
  needing a registered relation and a registered aggregate together previously got a receipt (or
  an answer) for a different, narrower query through a narrower entry — a silent wrong report
  rather than a refusal — because an entry that could not be handed every registry in scope has no
  registry-independent way to know a call it did not recognize was ever meant to resolve against
  one it was not given. A caller of any removed entry now calls
  `explain_query_with_options`/`_view` or `query_with_options_view` with the same registry set on
  `QueryOptions`; the CLI's `--explain`, its ordinary query/update lanes, and every other in-tree
  caller already went through the options-carrying entries and need no change. `--aggregate-namespace`
  with `--entailment` or `--explain` is no longer refused (see the two entries above); `--explain`
  with `--aggregate-namespace` now prints the plan with the registered aggregates named in the
  receipt's `aggregates` block.
- **sparql-conformance:** Respell the conformance harness's manifest-extension predicate namespace
  under `example.org`; it was minted under this suite's own project-branded namespace, the same
  mistake a prior change fixed for the SPARQL-XML results writer. A new hygiene test
  (`no_purrdf_dev_iri_is_minted_outside_the_closed_exemption_list`) fails on any occurrence of
  that branded namespace found in the tracked tree outside a closed, stale-checked allowlist of
  two reader-tolerance fixtures. A sibling manifest fixture proves the guard's negative case is
  triggered by the missing description specifically, not by some other structural defect.
- **BREAKING** **sparql:** Accept named scalar-value parameters on aggregate calls: `AGG(<iri>,
  …)` now admits trailing `; NAME=value` clauses, generalizing `GROUP_CONCAT`'s own
  `; SEPARATOR="…"` clause to any custom aggregate (e.g. `AGG(<{NS}PERCENTILE>, ?x; P=0.95)`).
  `CustomAggregate::init` now takes the call site's resolved named scalar-value parameters
  (`&[(String, TermValue)]`) alongside `self`; every implementor of the trait must add the
  parameter (an aggregate declaring no scalar parameters via the new default
  `CustomAggregate::scalarvals` may ignore it). The first-party `PERCENTILE` and `TOPK`
  aggregates now take their fraction/bound through the named clause instead of as trailing
  positional arguments; callers passing them positionally must move them to named form.
- **sparql-algebra:** `parse_literal` — the grammar behind an `AGG(<iri>, …; NAME=value)`
  scalarval, a `VALUES` ground term, and a triple pattern's literal object — now accepts the
  full SPARQL literal grammar it always claimed to: the signed halves of the numeric tower
  (`Q=-1`, `P=+0.5`) and the boolean literals (`B=true`), not only unsigned numerals and
  strings. `VALUES ?x { -1 true }` and `?s :p -3` parse for the same reason: both routed
  through the same unsigned-only `parse_literal`, so the gap was one production, not one call
  site.
- **cli:** `purrdf query --explain` refuses `--results-format`, `--loss-ledger`, and
  `--jsonld-options` by name instead of accepting and silently ignoring them — `--explain`
  returns before any serializer or loss-ledger surface runs, so a named `--results-format`
  never selected a serialization, a named `--loss-ledger` never had a transcode to report, and
  a configured `--jsonld-options` document never reached a serializer. `--results-format` is
  now `Option<QueryFormat>` (defaulting to `json` only when the flag is genuinely absent) so
  "not named" and "named `json`" are distinguishable, which is what the refusal needs.
- **cli:** `purrdf convert --canonical` refuses `--to` by name instead of silently overriding
  it — canonical output is always RDFC-1.0 N-Quads, so a `--to` naming a different target
  format was accepted and never read. `--to` may still be omitted under `--canonical`, exactly
  as before.
- **BREAKING** **xsd:** Add a value-space arithmetic operator surface — `value_add`/`value_sub`/
  `value_mul`/`value_div`/`value_unary_minus` — dispatching, in one call, over the full numeric
  tower plus `xsd:dateTime`/`xsd:date`/`xsd:time`/`xsd:duration` (and its two subtypes) and the
  five Gregorian partial-date types (`xsd:gYearMonth`/`xsd:gYear`/`xsd:gMonth`/`xsd:gMonthDay`/
  `xsd:gDay`) ± duration arithmetic, covering SEP-0002's full temporal operator table plus
  Gregorian ± duration, which has no SEP-0002 row of its own but matches the permissive reading
  of another SPARQL engine's own duration handling everywhere the answer does not depend on a
  fabricated calendar field — for `xsd:gMonthDay` specifically, "does not depend on a fabricated
  field" is decided by anchoring the complete months-then-days computation at every year in one
  full 400-year Gregorian period (the calendar's leap rule is exactly periodic at that length) and
  requiring every anchor to agree on the finished `(month, day)`, not on either component alone
  (the book's SPARQL querying chapter carries the full table and that divergence's record).
  `numeric_add`/`numeric_sub`/`numeric_mul`/`numeric_div` remain public but
  are now documented as the narrower numeric-tier operators the value-space surface delegates to
  for numeric operands, not as the SPARQL-facing entry point — a caller that depended on them
  accepting a temporal operand and returning a type error there should switch to the `value_*`
  surface, which accepts it and returns a value.
- **BREAKING** **sparql-eval:** `+`, `-`, `*`, `/`, and unary `-` in `FILTER`/`BIND` now evaluate
  over `xsd:dateTime`/`xsd:date`/`xsd:time`/`xsd:duration` (and its subtypes) and the five
  Gregorian partial-date types through the new value-space operator surface, where they previously
  fell through a numeric-only dispatch and folded every such operand pair to unbound. A query that
  relied on a temporal arithmetic expression silently answering unbound now receives the computed
  value instead; the result's datatype tag follows the operands' own declared tags (documented in
  the book's SPARQL querying chapter), never the computed component values.
- **sparql-eval:** `SUM`/`AVG` accept a group of `xsd:duration` values (any subtype) alongside
  their existing numeric acceptance, summing componentwise in the duration group and rounding
  `AVG`'s months component to the nearest whole month (ties toward positive infinity) — a PurRDF
  extension, since SPARQL 1.1 §18.5.1.3 defines `SUM` over the numeric tower only. A group mixing
  numeric and duration values still folds to unbound; this widens acceptance, it does not narrow
  the existing numeric one.
- **xsd:** Add unary minus on `xsd:duration` — `-(?duration)` negates both components together,
  so it can never produce the mixed-sign value the type cannot represent — a PurRDF extension,
  since F&O's unary minus (§4.2.8) is numeric-only and defines no duration form. Unary plus
  deliberately stays numeric-only, so `+(?duration)` remains a type error while `-(?duration)`
  is not.
- **xsd:** `xsd:duration ÷ xsd:duration` now also accepts the general `xsd:duration` type on
  either or both sides, not only the matching-subtype pairs F&O defines
  (`op:divide-yearMonthDuration-by-yearMonthDuration`,
  `op:divide-dayTimeDuration-by-dayTimeDuration`), dispatching on the operands' VALUE
  commensurability — both purely months, or both purely seconds — rather than their declared
  tags, so a `dayTimeDuration` and a general `xsd:duration` that happens to be purely day-shaped
  still divide. Two values whose components are not commensurable, even under matching declared
  tags, are a typed error rather than an arbitrary answer.
- **sparql-algebra:** Add `LATERAL { GroupGraphPattern }` surface syntax (SEP-0006, implemented in
  Apache Jena 4.7.0 — the SPARQL 1.2 Query specification's own text defines no `LATERAL`
  production). The parser enforces the SEP's scope restriction: no variable introduced by a
  `BIND`, a sub-`SELECT` projection expression, a `GROUP BY` aggregate output, or `VALUES` at the
  right-hand side's own scope level may collide with a variable already visible on the left;
  correlated USE of a left-hand variable, and a sub-`SELECT`'s legitimate shadowing, both stay
  legal. `LATERAL` is also now legal (and scope-checked) inside `INSERT`/`DELETE … WHERE` and
  `WITH … WHERE`, while a `DELETE WHERE` quad template refuses it by name instead of misparsing it
  as a subject term.
- **BREAKING** **sparql-eval:** `EXISTS`/`NOT EXISTS` now rests on one stated semantics — SEP-0007's
  `Replace`/`PrjMap` substitution (`exists(X, μ) ⟺ eval(D(G), Replace(PrjMap(X), μ))` is non-empty)
  — served by exactly two implementations chosen through a proven boundary instead of two
  heuristics with a guessed one: a memoized existence probe (evaluate the inner once, index it,
  existence-probe each row) where a prepare-time admissibility proof shows it equivalent to
  per-row substitution for every row the site can see, and the per-row definition itself (backed
  by a restriction-keyed memo and a first-witness `Slice{0, Some(1)}` stop) everywhere else.
  `--explain`'s per-algebra-node charge ledger now reports the chosen strategy and its cost
  through three new evidence counters, `exists-probe-answered`, `exists-definition-answered`, and
  `exists-inner-solutions-consumed`. `GOVERNOR_PROFILE_VERSION` moves `6` -> `7` to carry the
  three new charge points, and the frozen governor corpus is regenerated; a consumer pinning
  `GOVERNOR_PROFILE_VERSION`, `GOVERNOR_PROFILE_DIGEST`, or `GOVERNOR_CORPUS_DIGEST` must re-pin
  all three. A query without a correlated `EXISTS`/`NOT EXISTS` charges none of the three new
  points, so its fuel is unchanged in value even though the schedule and its digest moved.

### Performance
- **core:** The interner no longer mints a `String` for the datatype IRI of every untyped or
  language-tagged literal; `rdf:reifies` is interned once per builder rather than by string on
  every reifier push. RDFC-1.0 canonicalization renders blank labels and predicate IRIs by
  borrow inside the n-degree search, and issues ids with one tree descent instead of three.
  `MutableDataset::freeze` memoizes each base term's builder id (dense table, one slot per
  base id) instead of rebuilding an owned value for every one of a quad's four term
  occurrences; `quads_for_pattern` on the mutable view no longer materializes a base-sized key
  vector. No output, ordering or hashing changes.
- **iri, xsd:** RFC 3986 dot-segment removal walks a borrowed cursor (zero allocations per
  resolve, was O(segments) buffer rewrites); `XsdDatatype::from_iri` compares the namespace once;
  the `whiteSpace` facets copy clean runs in bulk; `Decimal::canonical_lexical` builds its
  output in one buffer. Each rewrite is pinned byte-for-byte against its previous
  implementation by a test.
- **sparql-eval:** `OPTIONAL { … FILTER }` is hash-indexed like the unfiltered join whenever the
  right side is fully bound on the shared columns (the same candidate rows in the same order,
  so results, padding and governor charges are unchanged); a `MINUS` whose arms share no
  variable returns the left bag by move instead of scanning every pair; `EXISTS` no longer
  rebuilds a bound-variable set per outer row; `LANGMATCHES` compares bytes without lowercasing
  three strings per row; `^path` shares its inner memo instead of deep-cloning the reach set;
  `CONSTRUCT` reuses its per-row blank-label map.
- **sparql-algebra:** The GROUP BY / HAVING / ORDER BY continuation checks and language-direction
  split no longer allocate a case-folded copy per token; ASCII lookaheads in the lexer compare
  bytes instead of decoding a `char`.
- **shapes:** `sh:nodeKind`, `sh:minLength`, `sh:maxLength` and `sh:languageIn` read the value
  node's kind, length and language from the dataset arena and materialize an owned term only
  for a violation; `sh:closed` probes borrowed predicate names.
- **rdf:** Quoted-triple terms resolve their reifier binding through a one-per-document index
  (the table scan made star-heavy documents quadratic in their statement layer, including inside
  the canonical sort's comparators); the serializer memoizes term ids so a repeated predicate
  never rebuilds its value; the RDF/XML and TriX escapers make a single pass and borrow
  untriggered input; JSON-LD expansion borrows the parent context when an object declares no
  `@context`. Every emitted byte is unchanged.
- **gts, sparql-results:** The canonical GTS writer caches its CBOR sort keys once per row
  instead of re-encoding per comparison and computes the MMR root from peaks alone (no boxed
  tree); the SRJ/SRX escapers and the SRJ string reader copy plain runs in bulk. Frozen vectors
  are byte-identical.
- **sparql-algebra:** Parsing no longer re-walks the whole accumulated pattern for every
  `BIND`/`SELECT *`/`LATERAL` scope check. The group-pattern loop maintains its in-scope variable
  set incrementally (an ordered set, not a hash, to stay a zero-dependency wasm-clean leaf),
  removing a quadratic parse-time cost on adversarial input; debug builds assert the incremental
  set against a fresh walk at every consultation.

### Refactor
- **sparql-eval:** Drive built-in aggregates through the same `AggregateAccumulator` fold trait
  as caller-registered ones — each built-in is now a concrete accumulator monomorphized through
  one generic driver, rather than a hand-rolled counter plus a per-function enum. No behavior
  change; governor charging and the frozen corpus are untouched.

### Documentation
- **sparql:** Document the aggregate seam and the SPARQL 1.2 remainder: the book's query chapter
  gains `ADJUST`, the `VERSION` declaration, the custom-aggregate seam with a worked registration
  example, and the ten statistical aggregates; the results chapter documents the `its:dir`
  spelling and the caller-named provenance extension.
- **sparql:** Correct the book's query chapter, which still described the entailment-aware query
  lane as refusing `aggregate_namespace` on every host — a paragraph an earlier fix removed from
  the Python stub and one book location but left standing in a second. It now shows the
  combination working, with a worked `--entailment`/`--aggregate-namespace` CLI example.
- **sparql:** Document `LATERAL` (SEP-0006) in the book's query chapter: the production, a
  top-1-per-group worked example, the scope restriction with the SEP's own legal/illegal pair,
  the two deliberate divergences from Jena, the `UPDATE WHERE` status, and the `SERVICE`-forwarding
  refusal. The front-end surface enumeration now names it as a SEP extension.
- **sparql:** Document `EXISTS`/`NOT EXISTS` under SEP-0007 in the book's query chapter: the
  precise points SEP-0007 repairs against SPARQL 1.1/1.2 §18.6's literal `substitute`/`evalExists`
  reading (variable-only positions, the `MINUS` domain flip, blank nodes as variables, disconnected
  variables, and the Part 3 assignment restriction), the one `Replace`/`PrjMap` definition,
  Existential Normal Form's rewrite laws, the two evaluation strategies and their `--explain`
  evidence counters, the performance characteristic naming the shapes the memoized probe cannot
  serve, and the Part 3 restriction with the SEP's own legal/illegal example pair. The front-end
  surface enumeration's prior "EXISTS decorrelation" claim — never accurate, since a correlated
  filter is answered either by proof-admitted probing or by genuine per-row substitution, never by
  a blanket decorrelation — is corrected to point at this section. The README's shipped-surface
  bullet and Direction list move `EXISTS`'s SEP-0007 semantics out of "near-term direction" and
  into what SPARQL 1.1/1.2 already ships.

- **conformance:** The embedding kNN lane (PURREMB nearest-neighbour retrieval) and the
  `purrdf-geo` GeoSPARQL 1.1 lane now have conformance-matrix rows, ratchet budgets and
  per-engine scoreboard entries. Both shipped with no matrix representation at all — the only
  trace of either was a forward reference inside the governor row — so the umbrella gate could
  not see a regression in either lane. The kNN row counts test functions rather than fixtures,
  because it grades a seam rather than a document format and has no corpus; the document says so
  rather than inventing a fixture count.

  The GeoSPARQL row counts **corpus geometries**, and the reason is recorded because the first
  version of it did not. Written as a `cargo test` tally over `purrdf-geo`'s five integration
  binaries it measured **33 on one machine and 37 on the CI runner from byte-identical source**,
  turning the doc drift-guard red for a reason unrelated to GeoSPARQL. A number that moves with
  the build environment is not a measurement — the same principle the matrix's `_no_scoreboard`
  path already states from the other direction — so the row now reports the 20 geometries of
  `purrdf_geo::determinism::CORPUS` whose serialized bytes fold into one `u64`, compared against
  the `GOLDEN_DIGEST` pinned in the test source. That comparison is an oracle rather than a
  self-report, and it is stable everywhere. The row additionally records what it does **not**
  measure: **no OGC conformance suite is vendored and none is claimed**, the crate's SHACL shapes
  being first-party `example.org` mirrors of the shipped OGC 22-047r1 validator (PurRDF mints no
  vocabulary IRIs), so the lane has an independent oracle for its determinism but none for its
  semantics, and a misreading of OGC 22-047r1 would pass.
- **release:** Correct `docs/RELEASE.md`'s outstanding-bootstrap section, which named **four**
  crates as having no crates.io record. `purrdf-datalog` has had one since 2026-07-31 and
  answers `0.12.0`; the genuinely unpublished set is `purrdf-cdt`, `purrdf-text` and
  `purrdf-geo`, and the heading, the body, the publish-order ordinals and the in-page anchor
  all said otherwise. That set is now `PURRDF_UNBOOTSTRAPPED_CRATES` in
  `scripts/release-crates.sh`, a ledger `scripts/check-crates-io-records.sh` holds to the
  registry in **both** directions — an unlisted missing crate and a listed present crate each
  fail the preflight on their own — and the prose restates the ledger under a gate. The
  bootstrap examples drop their pinned version literal in favour of the argumentless form,
  which reads the workspace version from `cargo metadata` and cannot rot. The `make doc` / CI
  "N publishable crates" comments are corrected 20 → 21.
- **BREAKING** **release:** Both publish lanes — `scripts/bootstrap-crates-io.sh` and the
  tag-driven `release-cargo.yaml` loop — now **verify** every `cargo publish` (cargo builds the
  packaged crate against the registry before the upload that cannot be undone), and
  `purrdf-geo` moves from 13th to 17th in the publish order to make that possible. The loop's `--no-verify` was load-bearing, not incidental: `purrdf-geo`
  dev-depends on `purrdf-rdf` and `purrdf-shapes`, verification resolves the packaged crate's
  whole graph including dev-dependencies, and while `purrdf-geo` was ordered before both, a
  verifying publish of the set would have failed at crate 13 after twelve irreversible
  uploads. Moving one crate removes the last forward dev-edge. The new
  `scripts/check-publish-order.py` proves on every `make check` that the order is a
  topological order of normal **and** dev-dependencies, that the release set is exactly the
  publishable members, and that the bootstrap ledger is in-set and in order; its
  `--self-test` perturbs each check and requires the refusal, and the release workflow runs it
  again in its verify step at the point of no return. `PUBLISH_NO_VERIFY=true` restores
  the old behaviour for one run. Anyone with a checked-out publish order, a pinned release
  script, or a Trusted Publisher configured by ordinal must re-read
  `scripts/release-crates.sh`.
- **release:** `PUBLISH_COOLDOWN_SECONDS` defaults to `0` (was `620`). crates.io's new-crate
  rate limit is enforced at the publish: a limited `cargo publish` exits non-zero, `set -e`
  stops the run before the next crate, and a re-run resumes because published versions are
  skipped — a visible, resumable refusal, not a corrupted release. The old default modelled the
  limit's ten-minute refill unconditionally and added about half an hour of dead time to a
  three-record run. The environment override is kept.

### Testing
- **results:** Pin its:dir precedence over legacy spellings in SRX
- **sparql,conformance:** Pin the newly-added SPARQL evaluation surface in the conformance
  corpus: the `VERSION` declaration evaluated (not merely parsed), the `AGG` call form's
  grammar, and `GROUP_CONCAT`'s row-order concatenation pinned to an exact string.
- **sparql-algebra:** Pin the whole serializer with a corpus round-trip sweep: parse, serialize,
  re-parse, and compare (modulo left-linearized join spines) over every vendored W3C, first-party,
  and doc-example query text — the empty exception ledger is the point; every disagreement it
  found is fixed above, not ledgered.
- **rdf:** Reduce the golden-capture deferred-construct classifier to the engine's actual typed
  residue — `LATERAL`, `SERVICE`, `DESCRIBE`, and property paths no longer misroute into expected
  deferral now that they are implemented.
- **sparql-conformance:** Add the `purrdf-extend` `LATERAL` manifest cases: the SEP-0006 worked
  examples (including the scoping oracle, proving Project-boundary narrowing rather than mere
  textual substitution), a shared-variable-injection case, and the SEP's own legal/illegal syntax
  pair.
- **sparql-conformance:** Add eight `purrdf-extend` SEP-0007 `EXISTS`/`NOT EXISTS` manifest cases
  through the shipped stack — the correlated graph-variable body, the `OPTIONAL`-padding tautology
  in both polarities, nested negation, a per-row `LIMIT 1` sub-select a one-shot probe would
  truncate wrongly, the `MINUS` shape whose right-operand correlation a one-shot probe would flip,
  and the Part 3 assignment restriction's own colliding-`BIND`/colliding-`VALUES` negative-syntax
  pair — bringing the suite to fifty-five cases (forty-eight evaluation, five negative-syntax).
  Each expected evaluation result was hand-derived from the `Replace`/`PrjMap` substitution
  definition before being pinned against the release binary, so a still-wrong engine could not
  have pinned itself correct.
- **sparql-eval:** Pin the probe/definition strategy boundary from both sides with a test-only
  forced-strategy seam: agreement tests run every admissible shape through both strategies and
  assert row-for-row equality, and divergence witnesses force the probe onto each refused shape
  and assert the specific wrong answer it would give. A bounded-exhaustive generator sweeps
  hundreds of inner shapes at depth two, checking memo equivalence throughout and cross-strategy
  agreement on every admitted one. Twenty-four `FILTER EXISTS`/`FILTER NOT EXISTS` shapes also run
  as real query text through the public engine end to end, including the substitution document's
  own worked examples, every solution modifier inside the body, the `HAVING`-position scope pin,
  and quoted-triple/blank-node outer bindings.

- **conformance:** Bring `scripts/conformance-baseline.json`'s free-text `note:` prose under the
  same gate as its `ledgered` integer. Only the integer was ever machine-checked, and the OWL 2
  DL note rotted a full generation behind it — claiming 261 vendored cases, 30 non-terminating
  and 12 withheld exclusions against a measured 262, 0 and 25, with every gate green the whole
  time. `scripts/check-doc-claims.py` gains `baseline_note_claim`, which checks that the
  baseline's suite names and the generated matrix block's suite names are the same set, that
  every `ledgered` budget equals its matrix row's XFail/Skip column, and that every
  matrix-derivable integer any note restates equals the column that measures it — with the DL
  note's subset/exclusion tally sourced from the same frozen `census.tsv` the three
  `docs/CONFORMANCE.md` restatements already are. A reworded note that stops matching its
  pattern fails as loudly as a wrong number, so the gate cannot be silenced by rewriting prose.
- **release:** `scripts/check-doc-claims.py` gains `outstanding_bootstrap_claim` and
  `publishable_crate_count_claim`, holding `docs/RELEASE.md`'s bootstrap heading, body crate
  count, per-crate publish-order ordinals and in-page anchor — and the `Makefile` / CI
  publishable-crate counts — to `scripts/release-crates.sh`. Membership is deliberately left to
  `scripts/check-crates-io-records.sh`, since whether a crate record exists is a fact about
  crates.io rather than about this tree.

## [0.12.0] - 2026-08-02

### Bug Fixes

- **BREAKING** **canon:** Reserve the overlay's namespace by refusal, not by assertion

### Features

- **BREAKING** Let a new enum variant stop being a breaking change
- **errors:** Let the standard chain reach the failure underneath
- **canon:** Name and version the canonicalization profile, with a frozen vector corpus

### Performance

- **datalog:** Keep the join's binding frame off the heap
- **sparql-eval:** Reject a candidate before paying to copy the row
- **rdf:** Write the text serializers into one buffer instead of many
- **rdf:** Write TriG in place, blocks and all
- **rdf:** Sort the canonical order through a comparator, not through keys
- **rdf:** Cut allocations on the hot paths; fix(canon)!: collision-safe RDF 1.2 canonicalization profile

### Refactor

- **BREAKING** **rdf:** The codec's serializer takes the caller's buffer

### Testing

- **datalog:** Give the semi-naive join a bench of its own
- **conformance:** Put the canonicalization profile on the scoreboard

## [0.11.0] - 2026-08-02

### Bug Fixes

- **entail:** Make the survey's three-way early exit reachable
- **docs:** Hold the xfail sentence to the count the matrix generates
- **wasm:** Assert an error names a term, do not compile the term into a pattern
- **BREAKING** **entail:** `?name` in any position, including the one it was refused in
- **entail:** A boundary that meant two things, and two claims about rule heads that were false
- **python:** Give each newline one way to match, not two
- **wasm:** Assert a refusal names a term exactly, by neither of the two wrong ways
- **wasm:** Pin the whole refusal, so the IRI reaches no matcher at all
- **BREAKING** **entail:** A variable is not a datatype IRI, and a withheld predicate is not a smaller question
- **BREAKING** **entail:** One IRI is one answer, and one variable name is one variable
- **gates:** Two gates that could not fail, and two guards that could not see
- **docs:** Derive which documents the overclaim ban sweeps, from the ban itself
- **docs:** Make the derived sweep total, rather than saying it is
- **docs:** Let the gate's own guards be mutated, and refuse the mutations
- **docs:** Compose the ban patterns around their markers, rather than checking they contain one
- **BREAKING** **entail:** A deep input must be an error, not a dead process
- **BREAKING** **rdf:** Bound term nesting where it is parsed, and survey every position the merge writes
- **entail:** Five entailment-diagnostic fixes — a lossy diagnostic, a split precedence, and three claims nothing checked

### Documentation

- **entail:** The doc gate is not `make check`, and it found six broken links
- **rdf:** The XML-literal walk adds no bound; something in front of it does

### Features

- **entail:** A conclusion-directed entailment service over the RL chase
- **entail:** Close the negative-conclusion lane by refutation over the chase
- **entail:** Decide a schema axiom by freezing its body and chasing the head
- **entail:** Comprehend the anonymous class expressions a conclusion names
- **entail:** Read a reflexive property's self-loops off the conclusion, not the closure
- **BREAKING** **entail:** Decide an rdfs:range axiom by datatype containment
- **entail:** Vendor the document the last unreached premise names
- **BREAKING** **entail:** Return the run that answered, not the verdict alone
- **entail:** The conclusion-directed surface reaches all four hosts
- **conformance:** Print the split an empty ledger makes trivially true
- **BREAKING** **entail:** A conclusion graph is a conjunction, and entailment is monotone over one
- **BREAKING** **entail:** A lane not run is a limit, not a silence
- **BREAKING** **entail:** The import map is the caller's, on every host that has the service
- **cli:** The binary can ask the question, not only compute the closure
- **conformance:** Print what the twenty-three negative agreements are made of
- **BREAKING** **entail:** Close the 16 ledgered W3C OWL 2 RL entailment-corpus gaps

## [0.10.0] - 2026-07-31

### Bug Fixes

- **BREAKING** **datalog:** Carry the predicate as data so meta-rules are expressible
- **entail:** Stop fabricating rdfs:Resource for a derived triple term
- **entail:** Drop the tableau's unique name assumption for nominals
- Accept D from the CLI, close the umbrella gap, correct shipped strings
- **release,docs:** Refuse a half-publish, and make documented numbers checkable
- **entail:** Make the certificate real, and grade the rules against W3C
- **entail:** Make the overclaim state unrepresentable, and surface the certificate everywhere
- **entail:** Derive the DL certificate's completeness instead of storing it
- **wasm:** Reach every reasoner service from the npm package root
- **docs:** Unbreak the rustdoc gate and name the Python suite row for what it runs
- **bindings:** Make the shipped type stub match the extension, and gate what published numbers claim
- **docs:** Gate the numbers that recurred, and stop promising a component this workspace does not have
- Make three gates inspect what they claimed to, and cover a tableau clash nothing reached
- **docs:** Correct eight published figures and gate the surfaces that carried them
- **docs:** Close three ways this pass's own gates could be satisfied without checking anything
- **entail:** Refuse explain-conclusion per conclusion, not per regime
- **BREAKING** **docs:** Name the DL fragment SHOIQ(D), date the exclusion emitters, and correct three provenance claims
- **docs:** A concept ledger over repo-wide facts, and twenty corrected figures
- **BREAKING** **entail:** Refuse the unrepresentable cardinality, bound the counting search, and state what the blocking evidence shows
- **BREAKING** **entail:** Make the combined approach reachable, sound on every result form, and honest about its fragment
- **docs:** The figure sweep — thirty corrected claims, three gate holes closed
- **hygiene:** The issue-reference ban could not see string literals or SPARQL
- **playground:** The console offered seven codecs while the engine registers nine
- **entail:** The counting/inverse limit keyed on spelling, not on meaning
- **python:** `uv run mypy` checked nothing and exited on a usage error
- **wasm:** The session handle needs Debug and Self, as the lint table requires
- **hygiene:** The wasm export gate read the export block and not the imports
- **datalog:** Make the SLG budget bound the work, not just the output
- **datalog:** Keep freshen_clause's doc on freshen_clause, and collapse the filter's ifs
- **build:** Make the wasm artifact's size independent of who built it

### CI & Build

- **wasm:** Record the session's 8,882 bytes
- **wasm:** Raise the ceiling 25% and stop failing on the exact byte count
- **npm:** Raise the package ceilings 25% and stop failing on the exact byte count

### Documentation

- **entail:** Generate the rule inventory and correct every stale claim
- Fix two intra-doc links that failed the rustdoc gate
- **conformance:** Grade the rules against W3C, and gate every number
- Date the DL exclusion tally, which is a recorded measurement rather than a live one
- **provenance:** Record the cutover as it stands, the slme port, and the revision reachability
- Published text carried internal program codes
- The session's three Python tests and its bytes reach the recorded figures
- **conformance:** The prose scoreboard row lagged the generated block
- **provenance:** Say which generated projections this repo can actually regenerate
- Say why the backward resolver has no caller, and stop claiming it has one
- State the backward check's boundary as the cost it is, with numbers that reproduce
- **validate:** The skip test's own doc still told the story the code disproved

### Features

- **BREAKING** **datalog:** Add the purrdf-datalog crate and wire every release gate
- **datalog:** Port the physical primitives — branded ids, arena, bitset, binding patterns
- **datalog:** Port the relation store, cursors, and index-selection planner
- **datalog:** Port the semi-naive evaluator with analytic goldens and hard budgets
- **datalog:** Replace the provisional rule IR with the DL-clause IR
- **entail:** Add the machine-readable rule inventory
- **datalog:** Add checkable proof terms and a contract hash
- **BREAKING** **entail:** Return a reasoning certificate from every materialize call
- **validate:** Add the shared entailment-regime string boundary
- **entail:** Seed the finite axiomatic triples and add four RDFS rules
- **python:** Expose entailment regimes as purrdf.entail
- **entail:** Add RDF-list materialization and the prp, cax and scm rules
- **wasm,capi:** Expose entailment regimes to WebAssembly and the C ABI
- **entail:** Complete OWL 2 RL — all 78 rules, and make D materializable
- **entail:** Stop dropping OWL axioms silently, and add the existential chase
- **entail:** Expose the DL reasoner services behind a certified facade
- **entail:** Dataset semantics, reifier interactions, and explanations
- **entail:** Reach every reasoner service from every host
- **entail:** Close the last W3C entailment gap, wire the plan cache, report termination
- **entail:** Bind the extension inventory on every host and gate its disclosure
- **BREAKING** **entail:** Decide OWL 2 data ranges, and check the tableau against a model-enumeration oracle
- **xsd:** Decide the rational-decimal identity exactly, and write the gmeow cutover guide
- **BREAKING** **entail:** Certain answers by the combined approach, over a ported SLG-WFS resolver
- **BREAKING** **entail:** A clause-based hypertableau is the OWL-Direct decision core
- **entail:** The nominal/inverse/counting limit is a named boundary, not buried prose
- **validate:** A reasoning session, so asking twice costs one parse
- **python:** Expose the reasoning session as `entail.Reasoner`
- **wasm:** Expose the reasoning session as `Reasoner`
- **capi:** Expose the reasoning session as `PurrdfReasoner`
- **purrdf:** Surface the reasoning session on the Rust facade, and gate all four hosts
- **entail:** Cross-check every chase explanation against backward resolution
- **entail:** Re-derive every chase explanation backward, and report the outcome
- **BREAKING** **entail:** Complete the entailment surface — 78/78 OWL 2 RL, certified runs, four language hosts

### Other

- Revert "feat(entail): cross-check every chase explanation against backward resolution"

### Performance

- **BREAKING** **entail:** Classify by one saturation instead of a tableau run per class pair
- **datalog:** Reject impossible clause/call pairs before freshening them

### Refactor

- **BREAKING** **entail:** Run the declared clause program instead of a hand-written chase
- **entail:** Split the calculus into one module per rule family
- **BREAKING** **entail:** Make materialization total over every regime

### Testing

- **entail:** Capture the chase's behaviour as a golden oracle
- **conformance:** Vendor the W3C OWL 2 suite and give entailment its own row
- **entail:** Check the OWL 2 RL closure against an independent second implementation
- **entail:** Assert the tableau is not over-permissive where that is decidable
- **entail:** Pin the owlrl divergence triples, and cover the value class that separates two language-tagged values
- **entail:** Pin the divergence triple count so a regeneration cannot absorb a regression
- Carry the per-conclusion explain contract to the remaining two hosts

## [0.9.0] - 2026-07-28

### Bug Fixes

- **gts:** Use neutral fixtures, drop an unreachable guard, surface breaking changes

### CI & Build

- **changelog:** Mark a breaking release when the squash duplicates a subject

### Documentation

- **gts:** Name the real undicted plan in the frozen-vector test

### Features

- **BREAKING** **gts:** Pin caller-supplied in-band dictionary bytes in a compaction plan

### Testing

- **gts:** Say what the mixed-plan header assertion can actually observe

## [0.8.5] - 2026-07-26

### Bug Fixes

- **slice:** Scope ownership by declared term namespaces, not the framework ns
- **slice:** Never mistake a Turtle comment for the sliceDependsOn block
- **docs:** Repair public GTS links
- **gts:** Harden dictionary append invariants

### Documentation

- **gts:** Register zstd-rsyncable level?/dct? and the dict-vector corpus

### Features

- **gts:** Multi-dictionary packs, rsyncable dict priming, and a declared zstd level
- **gts:** Support multi-dictionary rsyncable packs

### Testing

- **gts:** Freeze dictionary vector fold oracles

## [0.8.3] - 2026-07-23

### Bug Fixes

- **rdf:** Make JSON-LD byte budgets target independent
- **rdf:** Harden JSON-LD size arithmetic
- **capi:** Refresh generated package version
- **rdf:** Complete JSON-LD portability audit
- **rdf:** Make JSON-LD byte budgets portable

### CI & Build

- **release:** Gate coordinated tags on full checks
- **release:** Validate every published surface

### Other

- **shapes:** Restore canonical formatting

### Testing

- **rdf:** Use inclusive multiplicity range

## [0.8.2] - 2026-07-22

### Bug Fixes

- **shapes:** Make SHACL-AF function scope re-entrancy-safe under parallel validation
- **shapes:** Disambiguate ontology classes named after reserved JSON-Schema $def keys
- **rdf:** Raise JSON-LD carrier/document row ceilings to 2^23 for large bundles
- **rdf:** Size the JSON-LD carrier envelope for a whole-ontology bundle
- **rdf:** Raise JSON-LD output/document byte ceilings for whole-ontology bundles

## [0.8.1] - 2026-07-21

### Bug Fixes

- **wasm:** Align npm package size budgets

### CI & Build

- **wasm:** Budget shared SHACL membership view

### Documentation

- **wasm:** Record optimized membership artifact
- **conformance:** Record subclass corpus case

### Features

- **shapes:** Add subclass membership view
- **shapes:** Unify subclass membership semantics

### Other

- Unify SHACL subclass membership across native and SPARQL validation

### Performance

- **shapes:** Benchmark subclass membership hot path
- **shapes:** Prune inactive membership rows

### Testing

- **shapes:** Freeze subclass membership semantics
- **shapes:** Freeze subclass corpus hashes

## [0.8.0] - 2026-07-20

### Bug Fixes

- Harden purremb contracts and lookups
- **shapes:** Standardize schema input blanks apart
- **shapes:** Return typed schema key errors
- **shapes:** Admit identifier-only ontology ranges
- **shapes:** Retain custom datatype ranges
- **shapes:** Bound propagated schema facts
- **shapes:** Lower unsafe LinkML slots deterministically
- **shapes:** Bound schema parsing during construction
- **shapes:** Reject initializer module components
- **jsonld:** Preserve active-context option semantics
- **jsonld:** Preserve compact carrier round trips
- **jsonld:** Bound derived context validation
- **cli:** Bound JSON-LD options input
- **python:** Isolate generated namespace bindings
- **playground:** Route configured JSON-LD formats
- **capi:** Update projection example scope
- **wasm:** Update projection scope fixtures
- **csvw:** Preserve W3C RDF conversion
- **capi:** Refresh generated projection header
- **build:** Measure OKF wasm package growth
- **capi:** Close smoke fixture on seek failure
- **build:** Make Cargo target fallback safe
- **capi:** Honor active smoke-test profile
- **build:** Harden Cargo target discovery
- **release:** Deduplicate generated changelog entries
- **capi:** Regenerate header for 0.8.0

### CI & Build

- **wasm:** Rebaseline scoped projection budgets

### Documentation

- **rdf-core:** Specify the PURREMB v1 format
- **shapes:** Expose ontology schema workflow
- **shapes:** Publish LinkML slot migration contract
- **shapes:** Document rich Pydantic package emission
- **shapes:** Qualify flat byte compatibility
- **jsonld:** Document deterministic context compaction
- **conformance:** Refresh compatibility count
- **conformance:** Refresh Python parity count
- **csvw:** Guide curated terms projection
- **cli:** Enumerate liftable profiles
- **wasm:** Refresh optimized size measurement
- **cli:** Explain OKF lift rejection
- **conformance:** Account for attached parity test

### Features

- **rdf-core:** Add deterministic PURREMB writing
- **rdf-core:** Add borrowed PURREMB reading
- **rdf-core:** Add PURREMB binding verification
- **rdf-core:** Add deterministic .purremb companion format
- **sssom:** Model set-level document comments
- **sssom:** Retain parsed document envelopes
- **sssom:** Serialize typed document envelopes
- **shapes:** Define ontology schema compilation contract
- **shapes:** Derive deterministic ontology schema surface
- **shapes:** Emit ontology-complete schema carriers
- **shapes:** Define LinkML slot naming contract
- **shapes:** Verify LinkML slot reports on import
- **shapes:** Define deterministic Pydantic package topology
- **shapes:** Emit routed rich Pydantic packages
- **rdf:** Compile JSON-LD active contexts
- **rdf:** Compact JSON-LD through a typed carrier
- **rdf:** Derive deterministic JSON-LD contexts
- **cli:** Expose configured JSON-LD serialization
- **bindings:** Expose compiled JSON-LD contexts
- **lpg:** Require explicit projection scope
- **lpg:** Stream projection artifacts
- **lpg:** Expose scoped streaming hosts
- **csvw:** Define curated terms profile
- **csvw:** Project scoped curated term tables
- **projection:** Expose curated CSVW terms
- **rdf:** Define OKF terms projection contract
- **rdf:** Generate deterministic OKF term bundles
- **rdf:** Expose OKF terms across hosts
- **rdf:** Add attached RO-Crate assets
- **bindings:** Expose attached RO-Crate packaging

### Other

- Compile ontology-complete developer schema surfaces
- Make LinkML slot lowering deterministic and reversible
- Emit deterministic rich Pydantic packages
- **jsonld:** Document scoped lint exceptions
- Add deterministic context compaction
- Preserve typed SSSOM set comments
- Add scoped streaming LPG projections
- Add caller-configured curated CSVW projections
- Add deterministic caller-configured OKF term bundles
- Add deterministic attached RO-Crate payload packages
- Add native DCAT and VoID dataset descriptions
- Benchmark whole-bundle SHACL focus execution
- Optimize SHACL focus validation invariants
- Parallelize SHACL focus evaluation deterministically
- Prepare bounded SHACL validation for realtime use
- Eliminate SHACL canonical sort key allocations
- Preserve interned IDs through recursive SHACL checks
- Prove deterministic SHACL parallel execution
- Document realtime SHACL validation operations
- Optimize realtime and whole-bundle SHACL validation

### Performance

- **rdf-core:** Benchmark PURREMB access paths
- **sssom:** Streamline column selection
- **shapes:** Cache ontology row sort keys
- **shapes:** Borrow unchanged LinkML slot locals
- **shapes:** Reuse Pydantic path buffers
- **shapes:** Avoid duplicate schema limit traversal
- **shapes:** Index routed definition owners
- **jsonld:** Remove carrier hot-path allocation
- **lpg:** Measure scoped streaming carriers
- **projection:** Coalesce artifact sink writes
- **csvw:** Reuse URI expansion allocations
- **csvw:** Remove curated selection temporaries
- **csvw:** Borrow curated table memberships
- **rdf:** Remove OKF classifier scratch allocations
- **rdf:** Remove attached crate loop allocations

### Refactor

- **shapes:** Clarify routed name guard
- **jsonld:** Unify context processing

### Testing

- **rdf-core:** Harden PURREMB conformance coverage
- **shapes:** Prove ontology surface across emitters
- **shapes:** Keep namespace fixture vocabulary neutral
- **shapes:** Prove emitter-specific ownership
- **shapes:** Harden LinkML slot lowering
- **shapes:** Exercise routed Pydantic packages
- **jsonld:** Freeze expanded codec baseline
- **rdf:** Pin OKF terms cross-host parity
- **rdf:** Freeze attached crate host parity

## [0.7.0] - 2026-07-17

### Benchmarks

- **core:** Measure wavelet indexes against pack FoQ
- **shapes:** Measure LinkML imports

### Bug Fixes

- **shapes:** Record losses for non-class shape targets instead of dropping silently
- **capi:** Regenerate the ABI header for the 0.6 version bump
- **rdf:** Skip triple-term self-reifier sentinels in the JSON-LD reifier index
- **rdf:** Graph-scope reifier/annotation identity end-to-end
- **rdf:** Record TriX/HexTuples base-direction drop in the loss ledger
- **cli:** Reach reason stdin/stdout via --from/--to + fail-fast format resolve
- **cli:** Treat stdout BrokenPipe as a clean exit, not a runtime error
- **wasm,playground:** Honest size re-baseline + JSON-LD bidirectional round-trip
- **rdf-core:** Keep page planning metadata-only
- **rdf-core:** Make paged view debug inert
- **columnar:** Support published loss ledger API
- **columnar:** Bound untrusted decode allocations
- **rdf:** Scan escaped OKF link destinations
- **rdf:** Normalize exponent-form OKF decimals
- **shapes:** Enforce constrained schema unions
- **shapes:** Align Pydantic loss contracts
- **shapes:** Enforce JSON carrier fidelity
- **shapes:** Harden TypeScript reference closure
- **shapes:** Close TypeScript loss-audit gaps
- **shapes:** Bound TypeScript alias-cycle scans
- **shapes:** Describe GraphQL key validation bidirectionally
- **capi:** Restrict projection output permissions
- **rdf:** Honor CSVW record dialects
- **rdf:** Validate CSVW BCP 47 tags

### CI & Build

- **wasm:** Raise size budget for packed-dataset restoration
- **wasm:** Raise npm tarball size ceiling for packed-dataset restoration

### Documentation

- **core:** Drop stale issue-number token from loss_matrix_json doc comment
- **core:** Unlink private registry_entries from public loss_matrix_json doc
- **rdf:** Unlink classify from the private FORMATS table for rustdoc
- **cli:** Add the purrdf CLI README; fix a private intra-doc link
- **query:** Define paged completeness contract
- **shapes:** Document Pydantic projection
- **shapes:** Document LinkML projection
- **shapes:** Define TypeScript projection contract
- **shapes:** Define the GraphQL carrier boundary
- **rdf:** Complete projection adoption surface
- **conformance:** Refresh projection parity count
- Refresh conformance parity count
- **shapes:** Complete schema reverse surface
- Keep issue tracking out of provenance

### Features

- **core:** Unify the runtime loss ledger and add an enumerable codec-pair registry
- **shapes:** Record schema-projection losses on the unified LossLedger
- **core:** Add reusable ledger soundness + completeness verification helpers
- **core:** Enumerate the codec-pair registry and pin the runtime-ledger schema
- **core:** Make loss_matrix_json the enumerable codec-pair registry
- **core:** Unified loss-ledger surface for all codecs
- **rdf:** Register JSON-LD/YAML-LD as first-class native format variants
- **rdf:** Lossless JSON-LD-star triple-term encoding + orphan-reifier fix
- **rdf:** Lossless nested triple terms + reject annotations inside a @triple
- **rdf:** Unify JSON-LD/YAML-LD into the native format registry
- **rdf:** Make the native serializer generic over DatasetView
- **rdf-core:** Public DatasetView-generic pack reconstructor
- **cli:** Add the purrdf CLI crate (convert/query/reason core)
- **cli:** Convert --base/--entailment/--canonical + full matrix tests
- **cli:** Query --base/--entailment + CONSTRUCT/DESCRIBE RDF sink
- **cli:** Reason --base + per-regime boundary diagnostics + tests
- **cli:** The purrdf CLI — convert / query / reason
- **rdf:** Expose packed dataset restoration
- **rdf-core:** Certify paged provider snapshots
- **rdf-core:** Add fallible paged query views
- **sparql:** Certify complete fallible query results
- Certify fallible paged SPARQL execution
- **columnar:** Define five-table Parquet contract
- **columnar:** Implement deterministic Parquet kernel
- **columnar:** Project RDF datasets to five tables
- **columnar:** Reconstruct RDF from five tables
- **columnar:** Add deterministic bidirectional Parquet codec
- **rdf:** Define OKF loss contracts
- **rdf:** Lift OKF bundles into event sinks
- **rdf:** Write deterministic OKF bundles
- **rdf:** Add native bidirectional OKF codec
- **core:** Register Pydantic projection losses
- **shapes:** Emit Pydantic v2 packages
- **core:** Register LinkML loss profile
- **shapes:** Add canonical LinkML codec
- **shapes:** Project schemas to LinkML
- **shapes:** Add canonical LinkML 1.11 projection
- **core:** Register TypeScript projection losses
- **shapes:** Emit TypeScript declarations
- **shapes:** Emit deterministic TypeScript declarations
- **core:** Register GraphQL loss profile
- **shapes:** Emit deterministic GraphQL SDL
- **rdf:** Add projection carrier foundations
- **rdf:** Add canonical LPG mapping
- **rdf:** Add LPG CSV adapters
- **rdf:** Add LPG graph carriers
- **rdf:** Add bidirectional CSVW projections
- **rdf:** Add OBO Graphs projection
- **rdf:** Add deterministic SKOS projection
- **projections:** Expose deterministic carrier surfaces
- **rdf:** Add graph and tabular projections
- **rdf:** Add research-object semantic pivot
- **rdf:** Add Croissant 1.1 codec
- **rdf:** Add RO-Crate 1.3 codec
- **rdf:** Add DataCite 4.6 codec
- **rdf:** Add DCAT 3 codec
- **rdf:** Add Frictionless Data Package codec
- **rdf:** Expose research-object carrier surfaces
- **rdf:** Complete research-object carrier integration
- **rdf:** Add bidirectional research-object codecs
- **core:** Register schema to SHACL loss profiles
- **shapes:** Import JSON Schema as SHACL
- **shapes:** Import LinkML as SHACL
- **shapes:** Import generated schema packages
- **shapes:** Import schemas as SHACL

### Other

- Expose packed dataset restoration
- Emit caller-configured Pydantic v2 packages

### Performance

- **core:** Memoize the codec-pair loss registry behind OnceLock
- **cli:** Mmap-borrow disk pack→pack passthrough instead of heap-buffering
- **shapes:** Avoid duplicate Pydantic schema work
- **shapes:** Avoid LinkML projection allocations
- **shapes:** Avoid TypeScript render copies
- **shapes:** Avoid redundant GraphQL oracle escaping
- **rdf:** Avoid clean JSON pointer allocation
- **rdf:** Avoid DataCite XML uppercase copy
- **shapes:** Reduce schema import allocations

### Refactor

- **core:** Remove the dead RdfLoss diagnostic type
- **core:** Derive loss-entry intentional from profile membership
- **rdf:** Single FormatDescriptor table as the format metadata source of truth
- **wasm:** Route the wasm format resolver through the one core registry
- **shapes:** Share compiled schema catalog

### Testing

- **rdf:** Assert bnode-scope-flatten is an in-profile loss
- **rdf:** Production-surface tests for JSON-LD/YAML-LD + named-graph reifier fix
- **rdf:** Pin YAML-LD adversarial-scalar literals against the Norway problem
- **wasm:** Assert isomorphism on the JSON-LD/YAML-LD round-trip + fix stale docs
- **cli:** Pin --loss-ledger surfacing tri-state + universal-sink invariant
- **cli,rdf:** Pin query --entailment exit-3 boundary + dedup pack test fixture
- **sparql:** Cover fallible query guarantees
- **columnar:** Prove backend and DuckDB interoperability
- **columnar:** Cover empty files in DuckDB oracle
- **shapes:** Execute Pydantic schema oracle
- **shapes:** Exercise recursive Pydantic refs
- **shapes:** Add official LinkML oracle
- **shapes:** Add TypeScript compiler oracle
- **shapes:** Verify GraphQL coercion with GraphQL.js
- **cli:** Tolerate early stdin closure

## [0.6.0] - 2026-07-14

### Bug Fixes

- **gts:** Keep original authorship signatures bound across repacks
- **rdf:** Fail closed instead of panicking when verifying poison packs
- **rdf:** Anchor compaction projection to the provenance predicate vocabulary
- **gts:** Make the packaging signature a required compaction parameter
- **paged:** Enforce G3 quad-disjointness across the side tables
- **core:** Unify the pack dictionary to one id per term value for DatasetView compatibility
- **core:** Reject a literal datatype id that does not reference an IRI in the pack decoder
- **core:** Fail closed in verify_pack when a reconstructed dataset is structurally invalid
- **core:** Fail closed on FoQ index count-sum overflow in the pack decoder
- **shapes:** Sh:in enum members match the instance projector encoding
- **sparql-eval:** Make the fork-join parallel-safety gate registry-aware
- **gts:** Hard-fail the event bridge on a dangling term reference
- **gts:** Fire StreamingSink::frame before a frame's rows

### Documentation

- **design:** Author the PurRDF backend contract (C-clauses + paged G-clauses)
- **paged:** Fix rustdoc intra-doc link errors denied by the doc gate
- **core:** Document the pack backend + add the pack_query criterion bench
- **gts:** Fix rustdoc private-intra-doc-link errors denied by the doc gate
- **shapes:** Document the value-vocabulary enum projection
- **gts,rdf:** Demote private intra-doc links to code spans for the doc gate
- **sparql-eval:** Fix private intra-doc link denied by the doc gate
- **sparql-eval:** Broaden user_fn module doc to both function kinds
- **gts,rdf:** Demote private intra-doc links denied by the workspace doc gate
- **sparql-eval:** Drop plan-id process-flow refs from native-fn tests
- **core:** Describe the pack module by behavior, dropping plan task refs
- **core:** Reword residual plan-task phrasing in pack module docs
- **gts:** Add the §7.7 streaming-fold cross-reference and repair the rustdoc doc gate
- **gts:** Correct GtsEventSink provenance-ordering doc after the frame fix
- **gts:** Drop public-to-private intra-doc links tripping the doc gate

### Features

- **gts:** Deterministic in-band pack dictionaries for the zstd dct codec
- **gts:** In-band zstd dct codec with finalized pack dictionaries
- **gts:** Train and pin an in-band pack dictionary in streamable compaction
- **gts:** Bind detached signatures under an MMR root with a packaging head sig
- **rdf:** CompactionCertificate and verify_compaction refold-equivalence API
- **rdf:** Witness the suppression-compaction commuting square on both digests
- **gts:** Compress compaction blobs against the pinned in-band dict
- **core:** Make DatasetView an unsealed, id-agnostic read seam
- **core:** Add GlobalTermId + GlobalDictionary u64 identity layer
- **core:** Add PagedDataset — id-agnostic demand-paged DatasetView over a u64 dictionary
- **sparql-eval:** Generify the evaluator over D: DatasetView
- **sparql-eval:** Make the binding layer id-generic over D::Id
- **core:** Add freeze-refusal + deterministic compaction to PagedDataset
- **paged:** Add from_parts warm-restart constructor for PagedDataset
- **core:** Id-agnostic DatasetView seam + paged u64 backend served by the evaluator
- **gts:** Certified signature-preserving compaction with in-band dict codec
- **core:** Succinct rank/select + bit-packed IntVector primitives for the pack codec
- **core:** Four-section PFC value dictionary for the pack codec
- **core:** Graph-partitioned succinct bitmap-triples with FoQ all-pattern indexes
- **core:** RDF 1.2 reifier + annotation side-tables for the pack codec
- **core:** Deterministic pack container framing + zero-copy PackView reader
- **core:** Implement DatasetView for PackView (PackId, all-pattern query seam)
- **core:** Certified read-only projection — verify_pack recomputes the RDFC-1.0 digest
- **shapes:** Project value vocabularies to enum $defs (projection-only)
- **shapes:** Resolve sh:class / rdfs:range value-vocab refs to enum $defs
- **sparql-eval:** Native Rust-closure user-function registry + dispatch
- **sparql-eval:** Native Rust-closure user-function registry
- **gts:** Two-inventory replication diff, splice reconstruction, and diff_json
- **gts:** Surface per-frame provenance (content-id + byte range) on the streaming read path
- **gts:** Stream GTS frames into an RdfEventSink with per-frame provenance
- **gts:** Two-inventory diff/splice fetch-list + streaming RdfEventSink bridge on a shared decode core
- **core:** Read-only succinct HDTQ-style pack codec as a DatasetView backend

### Other

- **shapes:** Apply rustfmt to json_schema.rs
- **sparql-eval:** Rustfmt the native-scorer test helper

### Performance

- **paged:** Fold the G3 seal probe into a single map insert
- **paged:** Stream the paged read path instead of collecting a Vec
- **shapes:** Scan rdfs:range once per dataset for value-vocab $ref mapping
- **shapes:** Compute first_literal via single-pass running minimum
- **sparql-eval:** Lend native-fn args as &[&TermValue], drop per-call deep clone
- **gts:** Drop the streaming bridge's iri_map at each segment close
- **gts:** Hash the streaming decode maps with the fixed-key ahash policy

### Refactor

- **shapes:** Panic! directly for value-vocab enum-key twin guard
- **gts:** Hoist ByteRange to a shared model type and record FrameInventory.prev
- **gts:** Extract shared per-segment decode core and subsume the GTS import sink onto it
- **gts:** Bound the streaming decode core to one segment's memory

### Testing

- **gts:** Freeze in-band dict-compaction vectors with drift guards and docs
- **rdf:** Exercise the pack/tail seam chain across the boundary
- **gts:** Re-freeze the streamable-compacted vector to the current format
- **gts:** Assert the streamable-compacted pack pins no dct header entry
- **sparql-eval:** Prove SPARQL served directly over a multi-page PagedDataset
- **paged:** Cover property paths, aggregates, and subqueries on the paged backend
- **core:** Demonstrate mmap-able zero-copy PackView over a memory-mapped file
- **sparql-eval:** SPARQL-over-pack end-to-end parity with RdfDataset
- **shapes:** Prove value-vocab enum round-trip and open-validator decoupling
- **shapes:** Cover value-vocab class-key clash guard and multi-range tiebreak
- **sparql-eval:** Native scorer push-down + determinism (FILTER/ORDER BY/NaN/parallel)
- **gts:** Assert the streaming decode core's memory is bounded per segment
- **rdf:** Actually exercise GTS base-direction preservation on the sink path

## [0.5.0] - 2026-07-12

### Bug Fixes

- **shapes:** Key JSON-Schema $defs resolution set by def_key so cross-namespace local-name twins never dangle a $ref
- **wasm:** Free empty SELECT result handle without iteration
- **serialize:** Emit RDF 1.2 triple terms as non-asserting <<>>

### Documentation

- **conformance:** Record expanded Python parity suite
- **shapes:** Correct resolve_id doc to match variant-specific lookup

### Other

- Optimize Rust ownership and hot paths for 0.5.0

### Performance

- **core:** Remove owned lookup and freeze overhead
- **query:** Move parser tokens and stream results
- **reasoning:** Store terms once and index RIF joins
- **validation:** Cache sort keys and compile ShEx once
- **gts:** Stream deterministic CBOR without value clones
- **viz:** Linearize projection and ownership analysis
- **bindings:** Stream result ownership across FFI
- **reasoning:** Reuse RIF chase frontier index across fixpoint iterations
- **query:** Bound parser reparse fork to the braced block

### Testing

- **bench:** Cover SPARQL graph serialization and DISTINCT allocation paths
- **bench:** Cover SHACL canonical sort and ShEx prepared-shape paths

## [0.4.3] - 2026-07-10

### Bug Fixes

- **ci:** Serialize SPARQL conformance tallies

### Other

- Add semantic RDF 1.2 visualization exports

## [0.4.2] - 2026-07-10

### Other

- Harden npm wasm RDF 1.2 toolkit
- Expose entailed SPARQL and RIF parsing

## [0.4.1] - 2026-07-09

### Bug Fixes

- **shapes:** Project external object-class values to a node-ref, not a string, in JSON Schema
- **npm:** Align package-root RDFJS typings
- **capi:** Refresh generated ABI header
- **npm:** Accept null dataset inputs
- **npm:** Correct ecosystem probe evidence

### Documentation

- **npm:** Add ecosystem probe evidence

### Features

- **npm:** Add reusable SPARQL query engine

### Performance

- **wasm:** Benchmark query engine reuse

### Testing

- **npm:** Gate packed wasm package
- **npm:** Pin package gate toolchain

## [0.4.0] - 2026-07-07

### Bug Fixes

- **hygiene:** Exclude rustdoc inline-code spans from the issue-ref lint
- **makefile:** Use POSIX sed for wasm-bindgen pin extraction (macOS grep -oP)
- **makefile:** Use awk not tr to parse wc byte counts in wasm-pkg-size
- **hygiene:** Restrict issue-ref inline-code exclusion to Rust doc comments
- **playground:** Clear CodeQL alerts — structural entailment assertion + worker same-origin guard
- **shapes:** Polarity-sound sh:not projection in json_schema emitter
- **shapes:** Negate sh:not inner as a whole conjunction (De Morgan sound)
- **shapes:** Route sh:not maxCount property inner to a loss (no vacuous not)
- **shapes:** Route array-unsafe value-restriction sh:not inners to a loss
- **shapes:** Route existential sh:hasValue sh:not inner to a loss
- **shapes:** Restrict sh:not negand to exact-complement projections
- **shapes:** Polarity-sound sh:not projection (kill vacuous class negation)

### CI & Build

- **capi:** Gate the purrdf.h C-ABI header against drift
- **wasm:** Gate optimized artifact size via a pinned wasm-toolchain composite action
- **release:** Share the pinned wasm-toolchain action and enforce the size budget on release
- **wasm:** Drop unpinned twiggy source-build diagnostics step
- **docs:** Deploy the RDF-1.2 console at /playground in the Pages artifact

### Documentation

- Uplift product docs to top-tier Rust project standard
- **agents:** Document the wasm size-budget gate and deliberate-raise procedure
- Link the RDF-1.2 playground from the root and package READMEs
- **wasm:** List the shacl module in the lib.rs surface doc comment
- **shapes:** Strip issue-ref tokens from emitted schema descriptions
- Reconcile README and docs for 0.4.0

### Features

- **capi:** Make purrdf.h reproducible via cargo-c `capi` marker + regenerate canonically
- **capi:** Make purrdf.h reproducible via cargo-c `capi` marker + gate it in CI
- **wasm:** Add reproducible wasm-pkg-size budget gate (binaryen pinned)
- **wasm:** CI-gated wasm artifact size budget
- **wasm:** Expose SHACL + RDFC-1.0 canonicalize/isomorphic on the package surface
- **playground:** Standalone client-side RDF-1.2 console (engine in a Web Worker)
- **playground:** Drop the post-load wasm-size probe so the console makes zero network requests after assets load
- **playground:** Assert the SARIF 2.1.0 contract in the SHACL pane instead of echoing the engine version
- **playground:** Standalone deployed RDF-1.2 console over purrdf-wasm

### Other

- **shapes:** Satisfy fmt, clippy docs, and issue-ref hygiene gates

### Performance

- **shapes:** Cache the sort key for sh:not negand ordering

### Testing

- **shapes:** Add trusted external JSON-Schema validator harness
- **shapes:** Behavioral accept/reject tests for polarity-sound sh:not

## [0.3.3] - 2026-07-05

### Documentation

- **capi:** Regenerate purrdf.h with SHACL validate + entail declarations

### Performance

- **rdf:** Memoize the line index so parser diagnostics stay linear
- **rdf:** Memoize parser line index — fix quadratic diagnostics scan

## [0.3.2] - 2026-07-05

### Bug Fixes

- **shapes:** Reconcile SHACL-AF work with the merged 0.3.1 baseline

### Features

- **shapes:** SHACL Rules — 100% SHACL-AF coverage

## [0.3.1] - 2026-07-05

### Bug Fixes

- **shapes:** Pre-bind $shapesGraph in sh:SPARQLRule CONSTRUCT execution
- **build:** Optimize parse-hot workspace crates in dev/test profile to remove ~300x regression

### CI & Build

- **release:** Edition 2024, publish purrdf-entail, expose entail+validate, bump 0.3.1

### Documentation

- **conformance:** Add SHACL Rules scoreboard row; SHACL-AF is 100% complete
- **release:** Changelog for 0.3.1

### Features

- **shapes:** SHACL Rules engine — sh:TripleRule, sh:SPARQLRule, fixpoint entailment
- **shapes:** Cartesian-product multi-valued function-call node-expression args
- **bindings:** Expose SHACL rule entailment on Python, wasm, and C-API surfaces

### Performance

- **shapes:** Key the rules fixpoint divergence universe on Term, not String
- **shapes:** Reuse bindings buffer and hoist arg keys in function-call cartesian product

### Testing

- **shapes:** SHACL Rules conformance corpus + inferred-graph harness
- **shapes:** Audit every node-expression kind in sh:TripleRule subject/predicate/object positions
- **shapes:** Cover blank-focus blank minting and multi-round fixpoint convergence

## [0.3.0] - 2026-07-05

### Benchmarks

- **sparql-eval:** Isolate Solution row construction and join
- **rdf:** Add report-only span-tracking arm for the NoSpans zero-cost claim

### Bug Fixes

- **sparql-eval:** Correct correlated-EXISTS over address-keyed cache reuse
- **rdf:** Verify content-chain inclusion via blob/segment-head/MMR-leaf union
- **shex:** Route numeric_value through the XSD-1.0 float/double restriction
- **rdf:** Accept empty predicateObjectList item in Turtle parser
- **shex:** Fire group semantic actions only for participating groups
- **shex:** Make result-shape-map JSON fully round-trip through parse_shape_map
- **shex:** Distinguish unresolved IMPORT from conflicting redefinition
- **sparql-algebra:** Accept trailing top-level VALUES clause
- **sparql-conformance:** Dedupe named graphs by IRI + case-insensitive media-type
- **sparql-conformance:** Compare SELECT solutions up to W3C whole-set bnode isomorphism
- **sparql-eval:** XSD constructor casts emit canonical value forms
- **sparql-eval:** Correct built-in value spaces and XSD 1.1 canonical decimal
- **sparql-eval:** Scope UPDATE template blank nodes per request, not per operation
- **sparql-algebra:** Rewind trailing dot after blank-node label
- **sparql:** Exclude MINUS-right-only variables from in-scope set
- **shex:** Surface the concrete import parse error instead of swallowing it
- **shex:** Propagate concrete import cause through ImportResolver
- **conformance:** Make the byte-freeze manifest cross-platform deterministic
- **conformance:** Normalize CRLF in the matrix doc drift-check
- **conformance:** Honest matrix reporting for compile errors and first-party corpus
- **shacl-af:** Record sh:expression as a lossy JSON Schema projection
- **shacl-af:** SPARQL-value orderby, canonical set outputs, value-true is_true
- **shacl-af:** Keep sh:desc and described constant IRIs out of function-call parsing
- **conformance:** Repair --group dev gate, lock compat ratchet, refresh matrix
- **shacl-af:** Unbound mandatory sh:SPARQLFunction parameter yields no result
- **shacl-af:** Treat sh:returnType as informational, not an enforced datatype
- **shacl-af:** Reject empty or SHACL-reserved sh:SPARQLFunction parameter names
- **shacl-af:** Hard-fail malformed sh:order/sh:optional and multi-projection bodies
- **shacl-af:** Merge sh:SPARQLFunction body state back into the caller
- **shapes:** Repair broken merge — stray conflict markers and missed run_select rename
- **shapes:** Repair non-compiling SHACL-SPARQL component merge
- **shapes:** Make the validation-report sort total for byte determinism
- **entail:** Reject non-range-restricted RIF rules instead of panicking
- **entail:** Deterministic RDFS/OWL inferred-triple emission order
- **rdf:** Report located diagnostics at the offending token, not the next one
- **rdf:** Report Turtle/TriG located diagnostics at the offending token
- **rdf,validate:** Emit real byteOffset for N-Triples/N-Quads source spans
- **validate:** Wire SarifOptions::source_root_uri into the emitted SARIF
- **rdf:** Standardize blanks apart on native quad merge to stop cross-source collapse
- **release:** Stamp the pending version in the generated changelog
- **release:** Treat registry-restricted crates as publishable
- **release:** Anchor the package.json version bump to the top-level key
- **release:** Ignore commented-out crates in the publish-list parser
- **release:** Guard release-tags against a missing CHANGELOG section before tagging
- **release:** Assert per-crate version coherence in check-versions.py
- **hygiene:** Purge issue refs from python shim docstring and lint docstrings
- **rdf:** Pass the span collector in the empty-namespace turtle test
- **rdf-core:** Reject rdf:_0 and leading-zero container membership ordinals

### CI & Build

- **release-npm:** Guard binaryen --enable-simd + document SIMD baseline
- **wasm-pkg:** Hard-fail the build if the artifact carries no SIMD opcodes
- **wasm-pkg:** Append to RUSTFLAGS instead of overwriting it
- **release:** Enforce cross-registry version coherence and complete the publish list
- **release:** Pin the git-cliff version in the changelog target
- **release:** Make set-version.py rewrite every version location
- **release:** Gate internal dependency pins, at commit AND publish time

### Documentation

- **deps:** Correct memchr comment; drop issue refs from sparql-algebra
- **wasm-pkg:** Align the SIMD Node floor with the package engine (18)
- **wasm-pkg:** Describe the parse bench as report-only, not a regression gate
- **sparql-eval:** Correct fork_for_worker doc to the portable-row merge mechanism
- Describe behavior, not process, in content-addressing comments
- **rdf:** Document trust-on-first-use semantics of verify_content_chain
- **xsd:** Describe the i128/scale bound instead of a "deferred enhancement"
- Scrub GitHub issue-number references from shapes and sparql-eval comments
- **shex:** Clarify IMPORT conflict and inert-extension doctrine
- **conformance:** Reconcile rdflib LSP gate ledger scoreboard to live 62/24
- **iri:** Harden conformance-vector provenance for W3C IRI gate
- **conformance:** Finalize unified matrix at full-corpus SPARQL numbers
- **sparql-conformance:** Frame SPARQL 1.2 as a complete first-class spec
- **sparql-conformance:** Document that entailment simple1-8 are OWL-Direct, not simple-entailment
- **conformance:** Refresh SPARQL matrix counts to live harness (614 pass / 36 xfail)
- **conformance:** Correct SPARQL 1.2 provenance to zero ledgered residuals
- **sparql:** Finalize W3C SPARQL 1.1 syntax-suite provenance
- **conformance:** Reconcile the ledger and drift-guard the published matrix
- **conformance:** Distinguish normative SHACL-AF node expressions from owned extensions
- **conformance:** Correct stale SHACL first-party corpus count (64 to 69)
- **entail:** Fix misleading comment in the RIF emit path
- **validate:** Fix stale intra-doc link to a non-existent locate module
- **release:** Document MSRV and pre-1.0 semver policy
- **release:** Docs.rs metadata, front-page example, and workspace doc gate
- **ci:** Reconcile doc-target crate count to 16 (15 publishable + purrdf-entail)
- **rdf,shapes:** Fix private/broken intra-doc links failing the doc gate
- **conformance:** Regenerate matrix block for the added SPARQL fixtures
- **release:** Changelog for 0.3.0 and correct the published-crate count

### Features

- **rdf:** Memchr the parallel chunker newline split
- **rdf:** Scan-first serializer escape fast path
- **21:** Memchr/SWAR scan sweep — codec scans + IRI char-class LUT
- **sparql-eval:** Add rayon dep and deterministic two-phase parallel scaffold
- **rdf-core:** Add Blake3ContentId newtype with shared hex decode
- **rdf-core:** Add caller-supplied content-addressing config surface
- **rdf-core:** Recognize content-addressed IRIs at intern time
- **rdf-core:** Carry the content-id side table into the frozen dataset
- **rdf-core:** Add suppression-target and derivation-link traversal helpers
- **rdf-core:** Add a derived predecessor index over derivation annotations
- **rdf:** Add verify_content_chain GTS bridge over content-addressed terms
- **rdf-core:** Content-addressed term support in the IR (GTS-aligned)
- **xsd:** Add opt-in XSD-1.0 float/double lexical restriction
- **sparql-eval:** Pin xsd:float/double cast to XSD 1.0 lexicals
- **xsd:** Shared XSD-1.0 float/double lexical restriction
- **shex:** Resolve transitive cycle-tolerant IMPORT
- **shex:** Dispatch semantic actions via a Test extension registry
- **shex:** Query shape maps with FOCUS triple-pattern selectors
- **shex:** Serialize result shape maps to deterministic JSON
- **shex:** Populate SemActContext value and predicate per matched triple
- **shex:** Add validate_shape_map end-to-end entry point
- **sparql-conformance:** Harden conformance gate — no silent skips + license hygiene
- **sparql-conformance:** Support W3C UpdateEvaluationTest cases
- **sparql-eval:** LATERAL evaluation seam for variable-endpoint and nested SERVICE
- **entail:** Native wasm-clean RDFS + OWL-RL materialization reasoner
- **sparql-conformance:** Wire entailment regime into conformance harness
- **sparql:** Implement RDF-1.2 base-direction functions
- **sparql:** Parse RDF 1.2 triple terms, reifiers, and annotation blocks
- **sparql:** Complete RDF 1.2 triple-term/reifier support across parser, codec, and evaluator
- **sparql-eval:** Evaluate negated-inverse and set-repetition property paths
- **sparql:** Group-by projection check, EXISTS graph scope, GRAPH ?g over empty graphs
- **rdf:** Reifier-consistent CONSTRUCT/UPDATE emission and triple-term equality
- **rdf:** Give the RDF 1.2 reifier/annotation model a graph dimension
- **conformance:** Full W3C SPARQL 1.1/1.2 eval + native entailment + lateral SERVICE
- **shex:** Imports, Test-extension semantic actions, query shape maps
- **sparql:** Vendor W3C SPARQL 1.1 syntax-query suite
- **sparql:** Vendor W3C SPARQL 1.1 syntax-update-1/2 suites
- **sparql:** Vendor W3C SPARQL 1.1 syntax-fed conformance suite
- **sparql:** Vendor W3C SPARQL 1.1 syntax suite as parser conformance fixtures
- **conformance:** Enforce a monotone-shrink ledger ratchet in the gate
- **conformance:** SHA-256 byte-freeze the vendored conformance corpora
- **conformance:** Monotone ledger ratchet, drift-proof published matrix, and byte-freeze verification for the SHACL/shexTest gates
- **shacl-af:** Add node-expression IR skeleton and AF vocabulary
- **shacl-af:** Parse node expressions from the shapes graph
- **shacl-af:** Wire sh:ExpressionConstraintComponent end-to-end
- **shacl-af:** Evaluate built-in function-call node expressions
- **shacl-af:** Evaluate aggregation, paging, and ordering node expressions
- **shacl-af:** Evaluate filterShape and exists with cycle-safe re-entry
- **shacl-af:** Wire vectors/shacl/af seam and refresh conformance matrix
- **shacl-af:** Authority-grounded sh:orderby with sort-key expr and sh:desc
- **shacl-af:** Dispatch XPath-namespace keyword builtins in function calls
- **python:** Complete rdflib plugin entry-point discovery and acceptance matrix
- **shacl-af:** Sh:expression node constraints + node-expression evaluator
- **sparql-eval:** Dynamic SHACL-AF SPARQL function registry seam
- **shapes:** Parse sh:SPARQLFunction declarations into a function registry
- **shapes:** Resolve sh:SPARQLFunction calls in validation, remove the stub
- **shapes:** Implement SHACL-SPARQL custom constraint components
- **shacl-sparql:** Pre-binding substitution semantics and shapes-graph variables
- **shacl-af:** Sh:SPARQLFunction user-defined SPARQL functions
- **shapes:** Complete SHACL-AF validation coverage
- **core:** Expose shared FastHasher/FastMap/FastSet + smallvec primitives
- **shapes:** Id-native SHACL engine over interned TermIds
- **sparql-algebra:** Zero-copy lexer tokens borrowing the source
- **entail:** Bare-RDF axiomatic predicate-typing entailment (rdf01)
- **entail:** SHOIQ(D) OWL-Direct tableau reasoner core (concept, parser, tableau)
- **entail:** Query-directed OWL-Direct DL materialization clears 25 conformance cases
- **entail:** RIF-Core rule engine clears rif01/03/04/06 (zero entailment xfails)
- **entail:** Native OWL-DL tableau + RIF-Core engine + bare-RDF axiomatic entailment
- Close public-maturity epic
- **iri:** Add shared source-position primitive (LineIndex/Position)
- **diagnostics:** Resolve lexer byte offsets to line/column
- **codec:** Attach line/column locations to RDF text parse errors
- **codec:** Opt-in triple->source span table
- **validate:** Scaffold purrdf-validate SARIF boundary crate
- **validate:** Hand-rolled deterministic SARIF 2.1.0 model
- **validate:** Map reports and diagnostics to SARIF results
- **validate:** Source-traced SARIF physical and logical locations
- **validate:** To_sarif surface + Python binding + schema validation
- **bindings:** SARIF surfaces for WASM and C-ABI
- **validate:** SARIF rule metadata with W3C SHACL help links
- **validate:** SARIF 2.1.0 source-traced reporting
- **perf:** Id-native SHACL engine, zero-copy lexer tokens, workspace small-vec + hasher sweep
- **rdf-core:** Graph-scoped rdf:first/rest/nil + container traversal on DatasetView
- **slice:** Graph-scoped nav cursor, RDF-1.2 triple-term interiors, list/container materializer
- **release:** Generate the changelog and GitHub Release notes with git-cliff
- **release:** Single-command version bump and coherent tag cut
- **hygiene:** Extend issue-ref lint to workflow yaml and python comments
- **python:** Complete rdflib drop-in epic
- **release:** Docs.rs polish, MSRV/semver docs, version-coherence gate + changelog
- **rdf-query:** Graph-scoped nav cursor, list/container materializer, one-path blank-safe merge, FILTER/UNION regressions

### Other

- **iri,rdf:** Rustfmt the LUT/escape hot paths
- Remove old docs
- **rdf:** Fmt import order in ser_model tests
- Ignore more
- **sparql-eval:** Apply cargo fmt to expr.rs
- **shapes:** Apply cargo fmt to the pinned-lexical test
- Integrate main (parallel eval, content-addressed terms, XSD-1.0 float/double) into the W3C conformance branch
- Strip stale gmeow-ontology issue refs from Rust comments + lint against regression
- **conformance:** Integrate origin/main; fix issue-ref lint to scan only tracked source
- **shacl-af:** Rustfmt wrapping and register new corpus fixtures
- Rustfmt normalization across the SARIF work

### Performance

- **iri:** Const char-class LUT for ASCII validation
- **sparql:** Byte-cursor + memchr tokenizer
- **rdf:** Hex-LUT UCHAR escape, drop write! from the hot path
- **rdf:** Borrow clean input in escape_scan via Cow
- **sparql-eval:** Memoize constant expression atoms per query
- **sparql-eval:** Memoize dataset literal XSD parses per query
- **sparql-eval:** Allocation-free single-column hash-join keys + pre-sized build map
- **sparql-eval:** O(1) visited-set for property-path transitive closure
- **sparql-eval:** Hoist loop-invariant BGP probe permutation selection
- **sparql-eval:** Pre-parse quoted-triple ORDER BY sort keys
- **sparql-eval:** Single-threaded optimization backlog (items 3–7 + ORDER BY triple residual)
- **wasm-pkg:** Add Node parse-throughput benchmark
- **wasm-pkg:** Build the npm artifact with +simd128
- **sparql-eval:** Parallelize BGP inner loop and read-only join probes
- **sparql-eval:** Parallelize FILTER/filtered-left-join with forked per-worker contexts
- **sparql-eval:** Parallelize UNION, BIND, and per-group aggregates with deterministic scratch merge
- **sparql-eval:** Chunk-based parallel collects to cut per-row allocation
- **sparql-eval:** Reintern minted rows by value to drop the per-cell TermValue clone
- **sparql-eval:** Deterministic parallel evaluation (UNION, joins, BGP, FILTER, aggregates)
- **rdf-core:** Add report-only bench for intern-time content-id overhead
- **rdf-core:** Hash predecessor_chain visited set with ahash
- **entail:** Genuine semi-naive delta chase with new-vertex reflexive derivation
- **sparql:** Reuse blank-label set across update-operation iterations
- **shacl-af:** Hoist recursion guard, reuse intersection set, cache sort keys
- **sparql-eval,shapes:** Adopt small-vectors for hot per-row/per-node collections
- **entail:** Reuse frontier buffers in the RDFS chase loop
- **entail:** Reuse frontier buffers in the RIF chase loop
- **shapes:** Pre-resolve rdf:type id once per Class constraint
- **shapes:** Carry id-native value nodes through the constraint layer
- **shapes:** Adopt fixed-key ahash for the remaining membership sets
- **shapes:** Cache report sort key and borrow the sparql dataset
- **rdf:** Validate UTF-8 lazily in the text-format span-tracking arm
- **rdf-core:** Resolve container type once in is_typed_container

### Refactor

- **sparql-eval:** Rc→Arc on SolutionSeq/ExistsInner for Send+Sync
- **sparql-eval:** Make EvalCtx Send+Sync (Arc caches, RwLock order cache, Sync remote)
- **rdf:** Reuse purrdf_gts::wire::hex in the verify bridge
- **shex:** Route datatype checks through parse_xsd10
- **shapes:** Fold double/float lexical check into purrdf-xsd
- **entail:** Split reasoner into vocab/interner/rdfs modules + Regime::Rif scaffolding
- **shapes:** Collapse the non-interned path walker to reflexive inclusion
- **validate:** Hoist shared validate-to-SARIF helper into purrdf-validate
- **rdf:** Centralize native-codec format dispatch behind an RdfCodec trait

### Testing

- **rdf:** Bench the serializer escape boundary path
- **iri:** First parse criterion bench (dev-dep only)
- **sparql-eval:** Forced-parallel byte-identity determinism gate over a query corpus
- **rdf:** Prove content addressing does not perturb serialized bytes
- **shapes:** Cover xsd:float +INF at the SHACL layer; clarify pinned accept-set test
- **shex:** Drop Turtle-parser workaround in validation conformance harness
- **rdf:** Lock leading-empty rejection in nested callers and drain-to-pipe run
- **shex:** Empty the validation trait-skip list and assert zero skips
- **shex:** Lock Import and SemanticAction trait coverage with exact counts
- **sparql-conformance:** Vendor full W3C SPARQL 1.1 QUERY suite with typed non-pass ledger
- **sparql-conformance:** Vendor W3C SPARQL 1.1 UPDATE evaluation suite
- **sparql-conformance:** Vendor W3C SPARQL 1.2 DRAFT suite + classify
- **rdflib-gate:** Ledger test_group_by — purrdf stricter than rdflib on GROUP BY projection
- **sparql:** Cover blank-node reuse inside RDF-1.2 quoted triples
- **shacl-af:** End-to-end goldens for sh:min/max/distinct/offset
- **shapes:** First-party sh:SPARQLFunction conformance corpus cases
- **shacl-af:** Negative-path coverage for sh:SPARQLFunction
- **bench:** Add SHACL pattern-lookup and value-token lexer micro-benches
- **entail:** Lock in deterministic inferred-triple emission order
- **validate:** Cover attribution UnitId -> slice IRI resolution (S0.5)
- **rdf:** Lock parallel line numbering for a newline-less final line
- **validate:** Lock SHACL helpUri anchors against the live spec format
- **validate:** Avoid a literal #N token in the S0.5 test
- **sparql:** Regression-cover FILTER-NOT-EXISTS arithmetic and all-FILTER UNION branch

## [0.2.1] - 2026-07-02

### Benchmarks

- **python:** Published rdflib-vs-shim benchmark harness + docs

### Bug Fixes

- **python/compat:** Reject bare-form xsd duration instead of zeroing it
- **python/compat:** Honor base/initBindings/native kwargs in SPARQL processors
- **python/compat:** Unwrap Resource-typed predicate and index arguments
- **python:** Sample the host wall clock for NOW and RAND/UUID
- **capi:** Sample the host wall clock for NOW and RAND/UUID
- **sparql:** NOW is the wall clock and RAND is real entropy — by default, everywhere
- **sparql:** Thread standpoint + order cache into the UPDATE WHERE context
- **sparql:** NOW/RAND sample the host wall clock, not the epoch

### CI & Build

- **python:** Run the acceptance matrix under the acceptance dep group

### Documentation

- **python/compat:** Strip in-repo tracker references from the compat shim

### Features

- **python:** Python test harness + xfail-ledger gate for the rdflib drop-in
- **python:** Top-level engine exports mirroring the Rust umbrella crate
- **python:** Term-model completeness — value coercion, RDF 1.2 direction, from_n3
- **python:** NamespaceManager + Namespace parity with rdflib
- **python:** Graph/Dataset facade parity with rdflib
- **python:** Rdflib plugin registry + entry-point discovery
- **python:** SPARQL result serialization, native substitutions, property paths
- **python:** Opt-in top-level `rdflib` shadow (import rdflib -> purrdf)
- **build:** Single conformance matrix — native W3C suites + rdflib gate
- **xsd:** Native binary decode + whitespace facets for the compat value map
- **rdf:** Native TriX and HexTuples codecs for the compat plugin registry
- **sparql-eval:** Add wasm-clean QueryEnv seam for NOW/RNG injection
- **11:** Purrdf as an RDF-1.2-first drop-in rdflib replacement

### Other

- **python:** Rustfmt the native SPARQL-results + term-direction bindings
- Release 0.2.1: rdflib drop-in hardening — native xsd coercion + TriX/HexTuples codecs

### Testing

- **python:** Gate — rdflib's own test suite against the compat shim
- **python:** Downstream acceptance matrix (pyshacl / SPARQLWrapper / sssom)

## [0.2.0] - 2026-07-02

### Other

- Release 0.2.0: complete umbrella facade, OntologyProfile, ShExC serializer, drop openEHR OPT

## [0.1.5] - 2026-07-02

### Bug Fixes

- Fix release lanes: wasm-opt post-MVP features, workspace-inherited version

### Documentation

- Add the PurRDF DOI (10.67342/pkg8gpp4no/v1) to CITATION.cff and the README badge row

### Other

- Package README + metadata, js package 0.1.4
- Shex in flight
- Full ShEx 2.1 + complete SHACL Core + de-gmeow the library namespaces
- Purge the invented namespace: purrdf is a toolkit, not an ontology
- Parallel parse + parallel GTS verification (deterministic by construction)
- Python bindings: shex module, engine configuration, GIL release
- Release 0.1.5: full SHACL/ShEx, de-gmeow'd namespaces, SPARQL eval speedups

## [0.1.3] - 2026-07-02

### Bug Fixes

- Include Python sdist toolchain
- Build PyPI manylinux wheels

### Other

- Parameterize jsonld prefix
- Release 0.1.3: brand, first-class docs, strict lints, perf, npm lane
- Stabilize the toolchain: stable-Rust-clean workspace, real MSRV

## [0.1.1] - 2026-07-01

### Bug Fixes

- Set crates.io release user agent
- Pace crates.io bootstrap publishes
- Set crates.io workflow user agent
- Make purrdf the umbrella crate
- Pace only new crate publishes

### Other

- First commit
