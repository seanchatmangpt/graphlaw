// SPDX-FileCopyrightText: 2026 Blackcat Informatics Inc. <paudley@blackcatinformatics.ca>
// SPDX-License-Identifier: MIT OR Apache-2.0 OR MulanPSL-2.0

//! Parse / serialize surface for the `purrdf` Python extension: the
//! `RdfFormat` pyclass, the `parse` / `serialize` module functions, and the
//! pure-Rust `parse_quads` / `serialize_triples` cores plus the `read_input`
//! helper the store seam shares.
//!
//! Native backing: the parse/serialize cores produce and consume the
//! owned model (`RdfQuad` / `RdfTriple`) via the native codecs.

use std::sync::Arc;

use purrdf_core::RdfDiagnostic;

use pyo3::exceptions::{PyTypeError, PyValueError};
use pyo3::prelude::*;
use pyo3::types::{PyBytes, PyString};

use super::query::{PyQueryQuads, PyQueryTriples};
use super::term::PyQuad;
use crate::{
    NativeRdfFormat, ParseOptions, RdfDataset, RdfQuad, RdfTerm, RdfTriple, SerializeGraph,
    SerializeOptions, StatementLayer, TermValue, empty_named_graphs_dropped,
    flat_dataset_from_quads, flat_dataset_from_quads_declaring, flat_rdf_quads_from_dataset,
    parse_dataset, parse_dataset_with, serialize_dataset_to_format, serialize_dataset_with,
};

// ── RDF serialization format enum ───────────────────────────────────────────────

/// The RDF serialization formats the codebase loads/parses/serializes.
///
/// Exposed to Python as `RdfFormat`; the members keep the SCREAMING_SNAKE Python
/// spelling (`RdfFormat.TURTLE`).
#[pyclass(name = "RdfFormat", eq, eq_int)]
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
#[allow(non_camel_case_types)]
#[allow(
    clippy::upper_case_acronyms,
    reason = "the SCREAMING_SNAKE variant spellings ARE the Python-visible enum members (`RdfFormat.TURTLE`), so they must not be renamed"
)]
pub(crate) enum PyRdfFormat {
    TURTLE,
    N_TRIPLES,
    N_QUADS,
    TRIG,
    TRIX,
    HEXTUPLES,
    JSON_LD,
    YAML_LD,
    RDF_XML,
}

impl PyRdfFormat {
    /// The native codec format selector on the parse/serialize path.
    pub(crate) fn to_native(self) -> NativeRdfFormat {
        match self {
            Self::TURTLE => NativeRdfFormat::Turtle,
            Self::N_TRIPLES => NativeRdfFormat::NTriples,
            Self::N_QUADS => NativeRdfFormat::NQuads,
            Self::TRIG => NativeRdfFormat::TriG,
            Self::TRIX => NativeRdfFormat::TriX,
            Self::HEXTUPLES => NativeRdfFormat::HexTuples,
            Self::JSON_LD => NativeRdfFormat::JsonLd,
            Self::YAML_LD => NativeRdfFormat::YamlLd,
            Self::RDF_XML => NativeRdfFormat::RdfXml,
        }
    }

    /// The Python-visible spelling of this member (`RdfFormat.N_QUADS`), for diagnostics.
    ///
    /// A Python caller never sees the native `NativeRdfFormat` name or a media type, so
    /// a message that names either would be asking them to re-derive which argument they
    /// passed. Written out rather than derived from `Debug` so the strings cannot drift
    /// away from the members if the Rust variant spellings ever change.
    pub(crate) fn member_name(self) -> &'static str {
        match self {
            Self::TURTLE => "RdfFormat.TURTLE",
            Self::N_TRIPLES => "RdfFormat.N_TRIPLES",
            Self::N_QUADS => "RdfFormat.N_QUADS",
            Self::TRIG => "RdfFormat.TRIG",
            Self::TRIX => "RdfFormat.TRIX",
            Self::HEXTUPLES => "RdfFormat.HEXTUPLES",
            Self::JSON_LD => "RdfFormat.JSON_LD",
            Self::YAML_LD => "RdfFormat.YAML_LD",
            Self::RDF_XML => "RdfFormat.RDF_XML",
        }
    }
}

// ── The realized serialization loss ─────────────────────────────────────────────

/// One serialized document plus the WHOLE realized loss of producing it, partitioned
/// by CAUSE — the return of `Store.dump_with_loss` / `MutableDataset.dump_with_loss`.
///
/// # Why counts rather than a refusal
///
/// A graph-carrying CONSTRUCT result REFUSES a single-graph syntax (`QueryQuads`),
/// because the graph name is in the query the caller wrote. Dumping a store is the
/// opposite situation: asking a multi-graph store for Turtle is a legitimate "give me
/// the default graph", so the honest answer is not to refuse but to say what was left
/// behind. `dump` answers with bytes alone, exactly as it always has; this is the same
/// serialization with the numbers attached.
///
/// # Why three counts rather than one flag
///
/// The causes are independent, so their sum is the total and no row is charged twice.
/// A star-capable single-graph target (`TURTLE`, `N_TRIPLES`) loses named graphs and no
/// statement rows; a dataset-capable star-incapable one (`TRIX`, `HEXTUPLES`) loses
/// statement rows and base directions and no named graphs. Reading one count alone
/// cannot distinguish "nothing was lost" from "the loss was charged to a cause I am not
/// reading" — which is exactly how a silent drop hides.
///
/// Every count is REALIZED — what this document actually discarded — not the static
/// pair contract `purrdf.loss_matrix_json()` describes.
///
/// # `statement_rows_dropped` on THIS lane
///
/// The Python quad model carries the RDF-1.2 statement layer as ordinary `rdf:reifies`
/// / annotation quads with triple-term objects rather than as a separate layer (see
/// [`dataset_from_quads_verbatim`]), so a star-incapable target does not silently drop
/// them here — it REFUSES the triple term outright. The count is reported anyway, and
/// with the same meaning as on every other host: it is the same
/// `SerializeOutcome` field the C ABI's `out_statement_rows_dropped` and the wasm
/// `statementRowsDropped` read, so a caller comparing hosts is comparing one number,
/// and a future statement-layer ingress on this lane needs no new surface.
#[pyclass(name = "SerializeLoss", frozen)]
#[derive(Debug)]
pub(crate) struct PySerializeLoss {
    bytes: Vec<u8>,
    statement_rows_dropped: usize,
    directional_literals_dropped: usize,
    named_graph_rows_dropped: usize,
    empty_named_graphs_dropped: usize,
}

#[pymethods]
impl PySerializeLoss {
    /// The serialized document, identical to what `dump(format=…)` returns.
    #[getter]
    fn bytes<'py>(&self, py: Python<'py>) -> Bound<'py, PyBytes> {
        PyBytes::new(py, &self.bytes)
    }

    /// RDF-1.2 statement-layer rows (reifier bindings + annotation triples) dropped
    /// because the target cannot represent quoted triples. `0` for star-capable
    /// formats. Rows dropped for being scoped to a named graph are counted by
    /// `named_graph_rows_dropped` instead, never here and never twice.
    #[getter]
    const fn statement_rows_dropped(&self) -> usize {
        self.statement_rows_dropped
    }

    /// Object literals whose RDF-1.2 base direction the target has no surface for
    /// (`TRIX` / `HEXTUPLES` keep the language tag but cannot carry the direction).
    /// `0` for every direction-capable format.
    #[getter]
    const fn directional_literals_dropped(&self) -> usize {
        self.directional_literals_dropped
    }

    /// Rows the single-graph flattening dropped because the target has no named-graph
    /// construct: base quads asserted in a named graph plus the statement-layer rows
    /// scoped to one. `0` for every dataset-capable format. The rows are DROPPED, not
    /// folded into the default graph.
    #[getter]
    const fn named_graph_rows_dropped(&self) -> usize {
        self.named_graph_rows_dropped
    }

    /// Declared named graphs that hold no row and that the target has no spelling for
    /// (`N_QUADS`, `HEXTUPLES` and every single-graph syntax), so the document omits
    /// them. They own no row, so no other count can see them. `0` for `TRIG`, `TRIX`,
    /// `JSON_LD` and `YAML_LD`, which write an empty graph, and for a store that
    /// declares none. The same number as the C ABI's
    /// `purrdf_serialize_empty_named_graphs_dropped` and the wasm
    /// `emptyNamedGraphsDropped`.
    #[getter]
    const fn empty_named_graphs_dropped(&self) -> usize {
        self.empty_named_graphs_dropped
    }

    fn __repr__(&self) -> String {
        format!(
            "SerializeLoss(bytes={}, statement_rows_dropped={}, \
             directional_literals_dropped={}, named_graph_rows_dropped={}, \
             empty_named_graphs_dropped={})",
            self.bytes.len(),
            self.statement_rows_dropped,
            self.directional_literals_dropped,
            self.named_graph_rows_dropped,
            self.empty_named_graphs_dropped
        )
    }
}

/// Serialize the whole quad set to `format` and report every realized loss.
///
/// The pure-Rust core behind both `dump_with_loss` methods, so the store and the
/// mutable dataset can never report the same document differently. `SerializeGraph`
/// is `Dataset` unconditionally — a graph SELECTION would make the named-graph count
/// meaningless, since the caller would already have chosen what to keep — matching the
/// C ABI's `purrdf_serialize`, which has no selection parameter for the same reason.
pub(super) fn dump_quads_with_loss(
    quads: &[RdfQuad],
    declared_graphs: &[RdfTerm],
    format: NativeRdfFormat,
) -> Result<PySerializeLoss, RdfDiagnostic> {
    let dataset = dataset_from_quads_verbatim(quads, declared_graphs)?;
    let outcome = serialize_dataset_to_format(&dataset, format, None)?;
    let empty_named_graphs_dropped =
        empty_named_graphs_dropped(&*dataset, format, SerializeGraph::Dataset)?.len();
    Ok(PySerializeLoss {
        bytes: outcome.bytes,
        statement_rows_dropped: outcome.statement_rows_dropped,
        directional_literals_dropped: outcome.directional_literals_dropped,
        named_graph_rows_dropped: outcome.named_graph_rows_dropped,
        empty_named_graphs_dropped,
    })
}

// ── Module-level functions ──────────────────────────────────────────────────────

/// Parse RDF bytes/str into a list of `Quad`.
///
/// Unlike `Store.load`, blank-node labels are preserved verbatim (no renaming),
/// so canonicalization over the parsed quads is meaningful.
///
/// `base` is the document base relative IRI references resolve against, the same
/// parameter `Store.load` carries and the same one the WebAssembly and C surfaces
/// take. It is genuinely optional but never silently defaulted: PurRDF is handed
/// bytes and has no retrieval IRI, so omitting it means "no base in scope" and a
/// relative reference then hard-fails with `iri-relative-no-base` rather than being
/// resolved against a fabricated one. A document may still establish its own base
/// (Turtle `@base`, `xml:base`, JSON-LD `@context.@base`), which wins over this one.
#[pyfunction]
#[pyo3(signature = (input, format, *, base=None))]
pub(crate) fn parse(
    py: Python<'_>,
    input: &Bound<'_, PyAny>,
    format: PyRdfFormat,
    base: Option<String>,
) -> PyResult<Vec<Py<PyQuad>>> {
    let data = read_input(Some(input), None)?;
    // The native parse runs detached (GIL released); the Quad objects are
    // built after reacquiring.
    let quads = py
        .detach(move || parse_quads(&data, format.to_native(), base.as_deref()))
        .map_err(|e| super::presentation::value_error(format!("parse error: {e}"), &e))?;
    quads
        .into_iter()
        .map(|inner| Py::new(py, PyQuad { inner }))
        .collect()
}

/// Serialize a `QueryTriples` or a `QueryQuads` in `format`. When `output` (a file-like with `.write`) is given the bytes are
/// written to it and `None` is returned; when `output` is omitted the serialized
/// `bytes` are returned directly.
///
/// Both CONSTRUCT result types are accepted, and each delegates to its OWN
/// `serialize` method rather than re-implementing it, so the module function and the
/// method can never disagree — in particular a `QueryQuads` refuses a single-graph
/// syntax here exactly as it does there.
///
/// `base` is the document base the output is written under — the egress mirror of
/// [`parse`]'s. A format that can express a base (Turtle, TriG, JSON-LD, YAML-LD)
/// writes it and relativizes its IRIs against it; one that cannot (N-Triples,
/// N-Quads, TriX, HexTuples) emits absolute IRIs, which is the only spelling those
/// grammars admit. Either way a base that is not an absolute IRI is a hard failure,
/// never silently ignored.
#[pyfunction]
#[pyo3(signature = (input, output=None, format=None, *, base=None))]
pub(crate) fn serialize(
    py: Python<'_>,
    input: &Bound<'_, PyAny>,
    output: Option<&Bound<'_, PyAny>>,
    format: Option<PyRdfFormat>,
    base: Option<String>,
) -> PyResult<Option<Py<PyBytes>>> {
    let format = format.ok_or_else(|| PyValueError::new_err("serialize: format is required"))?;
    let bytes = if let Ok(triples) = input.cast::<PyQueryTriples>() {
        triples.borrow().serialize_bytes(py, format, base)?
    } else if let Ok(quads) = input.cast::<PyQueryQuads>() {
        quads.borrow().serialize_bytes(py, format, base)?
    } else {
        return Err(PyTypeError::new_err(
            "serialize: input must be a QueryTriples or a QueryQuads",
        ));
    };
    match output {
        Some(output) => {
            write_all_to(py, output, &bytes)?;
            Ok(None)
        }
        None => Ok(Some(PyBytes::new(py, &bytes).unbind())),
    }
}

/// Write every byte of `bytes` to a Python file-like `output`, honouring short writes.
///
/// `write` on a Python file object is NOT obliged to consume everything it is given.
/// `io.RawIOBase.write` returns the number of bytes actually written and may return
/// less than it was handed — a raw unbuffered file on a full pipe is the ordinary
/// case — and any object satisfying the file-like protocol may do the same. Calling
/// it once and discarding the count silently truncated the document whenever that
/// happened, and produced a short file with no error: exactly the silent drop this
/// binding exists to avoid on every other seam.
///
/// `None` is accepted as "consumed it all", which is what `io.TextIOBase` and many
/// hand-rolled sinks return. Anything else that is not a non-negative integer is a
/// hard failure rather than a guess, because guessing is how a truncation becomes
/// invisible again.
fn write_all_to(py: Python<'_>, output: &Bound<'_, PyAny>, bytes: &[u8]) -> PyResult<()> {
    let mut written = 0usize;
    while written < bytes.len() {
        let result = output.call_method1("write", (PyBytes::new(py, &bytes[written..]),))?;
        if result.is_none() {
            return Ok(());
        }
        let count: i64 = result.extract().map_err(|_| {
            PyTypeError::new_err(
                "serialize: output.write must return the number of bytes written, or None; \
                 a value of another type cannot be checked for a short write",
            )
        })?;
        let count = usize::try_from(count).map_err(|_| {
            PyValueError::new_err(format!(
                "serialize: output.write reported {count} bytes written, which is negative"
            ))
        })?;
        if count == 0 {
            return Err(PyValueError::new_err(format!(
                "serialize: output.write accepted 0 of {} remaining bytes and would not \
                 make progress; the document was not written in full",
                bytes.len() - written
            )));
        }
        written += count.min(bytes.len() - written);
    }
    Ok(())
}

// ── Pure-Rust cores (PyO3-free, exercised through the pytest suite) ─────────────

/// Parse RDF bytes into owned quads via the native codec with no blank-node
/// renaming. Routes through [`parse_dataset`] → IR → the flat
/// quad un-fold ([`flat_rdf_quads_from_dataset`]) so the `rdf:reifies` / annotation
/// rows of the RDF 1.2 statement layer reappear in the quad stream exactly as a flat
/// parse would yield them. Private-use language tags such as `@x-purrdf-*` are valid
/// BCP-47 `x-…` privateuse tags and survive the native parse.
pub(crate) fn parse_quads(
    data: &[u8],
    format: NativeRdfFormat,
    base: Option<&str>,
) -> Result<Vec<RdfQuad>, RdfDiagnostic> {
    let dataset = parse_dataset(data, format.media_type(), base)?;
    Ok(flat_rdf_quads_from_dataset(&dataset))
}

/// A parsed document's quads, the prefix bindings it declared, and the named graphs it
/// declared without giving them any row (TriG `<g> { }`, an empty TriX `<graph>`,
/// JSON-LD `{"@id": g, "@graph": []}`).
pub(crate) type LoadedDocument = (Vec<RdfQuad>, Vec<(String, String)>, Vec<TermValue>);

/// [`parse_quads`], also returning the document's prefix map from the SAME parse: the
/// `@prefix` / `PREFIX` bindings a Turtle or TriG document left in force at its end,
/// sorted by label, each namespace resolved (`ParseOutcome::document_prefixes`). Empty
/// for every other format. This is the codec's own record, so a `PREFIX` line quoted
/// inside a string literal is never reported.
pub(crate) fn parse_quads_and_prefixes(
    data: &[u8],
    format: NativeRdfFormat,
    base: Option<&str>,
) -> Result<LoadedDocument, RdfDiagnostic> {
    let outcome = parse_dataset_with(data, format.media_type(), base, &ParseOptions::default())?;
    // The graphs a format that names a graph only on a row would drop are exactly the
    // ones the document declared with no row; N-Quads is that format.
    let declared_empty = empty_named_graphs_dropped(
        &*outcome.dataset,
        NativeRdfFormat::NQuads,
        SerializeGraph::Dataset,
    )?;
    Ok((
        flat_rdf_quads_from_dataset(&outcome.dataset),
        outcome.document_prefixes,
        declared_empty,
    ))
}

/// Serialize triples through the native codec under an optional document `base`.
///
/// `base` is the egress mirror of [`parse_quads`]'s: a syntax that can express a base
/// writes it and relativizes against it, one that cannot emits absolute IRIs, and a
/// base that is not an absolute IRI is a hard failure on either. The decision is the
/// core format registry's, never respelled here.
///
/// The selection is `SerializeGraph::Dataset` — which
/// [`serialize_dataset_to_format`] applies — rather than the `DefaultGraph` this used
/// to name, and the two are the SAME output for this input: every triple is built
/// below as a default-graph quad, so there is no named-graph row for the dataset
/// selection to keep. Nor is there a statement layer to drop: the IR is built verbatim
/// (RDF 1.2 triple-term objects stay triple-term objects, no `rdf:reifies` fold), so
/// the reifier and annotation tables are empty and star-incapable targets report zero
/// dropped rows. One entry point carries the base rather than a second `…_with_base`
/// overload beside it, which is how a call site ends up silently not passing one.
pub(crate) fn serialize_triples(
    triples: &[RdfTriple],
    format: NativeRdfFormat,
    base: Option<&str>,
) -> Result<Vec<u8>, RdfDiagnostic> {
    // Build the IR verbatim — every triple is a default-graph quad, RDF 1.2
    // triple-term objects preserved as triple-term objects (no statement-layer fold)
    // — then serialize through the native codec.
    let quads: Vec<RdfQuad> = triples
        .iter()
        .map(|t| RdfQuad::new(t.subject.clone(), t.predicate.clone(), t.object.clone()))
        .collect();
    let dataset = flat_dataset_from_quads(&quads)?;
    serialize_dataset_to_format(&dataset, format, base).map(|outcome| outcome.bytes)
}

/// Serialize a graph-carrying CONSTRUCT result's quads through the native codec,
/// emitting **every** graph.
///
/// The quad twin of [`serialize_triples`]: same verbatim freeze (RDF 1.2 triple-term
/// objects preserved as triple-term objects, no statement-layer fold), but
/// [`SerializeGraph::Dataset`] rather than `DefaultGraph`, because the graph slot is
/// the whole reason this stream is quads. `format` is the caller's, unchecked here: the
/// single-graph syntaxes are refused BEFORE this point (`QueryQuads::serialize`), so a
/// format that reaches this function can carry what it is handed.
///
/// `base` is the document base the output is written under, carrying exactly the meaning
/// it does on [`serialize_triples`]: a graph-carrying result is no less an egress
/// document than a triple-carrying one, so it is written under the same base through the
/// same seam.
pub(crate) fn serialize_quads(
    quads: &[RdfQuad],
    format: NativeRdfFormat,
    base: Option<&str>,
) -> Result<Vec<u8>, RdfDiagnostic> {
    let dataset = flat_dataset_from_quads(quads)?;
    serialize_dataset_with(
        &dataset,
        format,
        base,
        &SerializeOptions {
            selection: SerializeGraph::Dataset,
            // The verbatim freeze this function promises: the RDF 1.2 statement layer is
            // EMITTED, never folded away, and a format with no surface for it fails
            // closed rather than dropping rows behind the caller's back.
            statement_layer: StatementLayer::Emit,
            jsonld_options: None,
        },
    )
    .map(|outcome| outcome.bytes)
}

/// Freeze a flat native quad list into the IR verbatim — RDF 1.2 triple-term objects
/// preserved as triple-term objects (no statement-layer fold), named graphs kept —
/// for native serialization, declaring each of `declared_graphs` so a graph the store
/// holds with no quad is written where the target can spell it. Shared by the
/// `Store`/`MutableDataset` dump paths.
pub(super) fn dataset_from_quads_verbatim(
    quads: &[RdfQuad],
    declared_graphs: &[RdfTerm],
) -> Result<Arc<RdfDataset>, RdfDiagnostic> {
    flat_dataset_from_quads_declaring(quads, declared_graphs)
}

pub(crate) fn read_input(
    input: Option<&Bound<'_, PyAny>>,
    path: Option<String>,
) -> PyResult<Vec<u8>> {
    if let Some(path) = path {
        return std::fs::read(&path)
            .map_err(|e| PyValueError::new_err(format!("cannot read `{path}`: {e}")));
    }
    let Some(input) = input else {
        return Err(PyValueError::new_err(
            "either `input` data or the `path` keyword must be given",
        ));
    };
    if let Ok(bytes) = input.cast::<PyBytes>() {
        return Ok(bytes.as_bytes().to_vec());
    }
    if let Ok(text) = input.cast::<PyString>() {
        return Ok(text.to_str()?.as_bytes().to_vec());
    }
    Err(PyTypeError::new_err("input must be bytes or str"))
}

copy_pyclass_from_py_object!(PyRdfFormat);
