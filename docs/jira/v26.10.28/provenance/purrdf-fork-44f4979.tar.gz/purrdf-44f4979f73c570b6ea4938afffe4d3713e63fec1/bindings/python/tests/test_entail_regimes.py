# SPDX-FileCopyrightText: 2026 Blackcat Informatics® Inc. <paudley@blackcatinformatics.ca>
# SPDX-License-Identifier: MIT OR Apache-2.0 OR MulanPSL-2.0
"""`purrdf.entail` — SPARQL entailment-regime materialization from Python.

This is the surface the originating request asked for: the OWL-RL (and RDFS, RDF,
Simple) materialization the Rust and C-ABI hosts already had, reachable from
Python without reaching into `purrdf_native`.

Not to be confused with `tests/test_entail.py`, which covers SHACL-AF `sh:rule`
entailment — a different mechanism that needs a shapes graph.

What is asserted here, and why:

* **A closure really closes.** OWL-RL derives triples a plain parse does not, and
  every base triple survives.
* **Byte determinism.** Repeated calls produce identical bytes, for both the
  closure and the report. A chase that leaked hash order, a clock or an address
  would diverge here.
* **The honest gap.** `rules(OWL_RL)` is the 78-rule specification table;
  `implemented_rules(OWL_RL)` is the subset this workspace fires. The two are
  asserted to PARTITION the table — fired and missing cover it exactly, without
  overlap, in specification order — and the missing half is asserted to be
  exactly the report's `missing` lines, so the report and the inventory cannot
  drift apart. The gap is legitimately EMPTY for a regime whose table is
  complete, which OWL-RL's and D's now are; an assertion that it is non-empty
  would pin a capability gap that has been closed.
* **One artifact, four hosts.** The committed tri-host golden vector
  (`crates/validate/tests/fixtures/regime-boundary.vectors`) is walked through
  `materialize_nt` here, so Python checks the same bytes the Rust test, the C ABI
  and the WASM module do rather than a fixture of its own.
* **Every regime materializes.** All seven close; none is refused for being the
  regime it is. Two of them need an INPUT rather than permission — `rif` its rule
  document and `owl-direct` a query's class expressions — and `program` is the
  parameter that carries the first. `owl-direct` takes none here because this
  surface closes a dataset rather than answering a query, so what runs is the
  query-independent tableau augmentation.
* **Refusals are typed and legible.** A malformed document, an unknown regime
  spelling, and a `program` that is wrong for the regime all raise `ValueError`,
  and the spelling error names the whole accepted set.
"""

from __future__ import annotations

from pathlib import Path

import pytest

import purrdf
from purrdf import RdfDataset, RdfFormat, entail

# ── Fixtures (example.org, per the repository's vocabulary rule) ────────────────

RDF_TYPE = "http://www.w3.org/1999/02/22-rdf-syntax-ns#type"
RDFS_SUB_CLASS_OF = "http://www.w3.org/2000/01/rdf-schema#subClassOf"
OWL_SYMMETRIC_PROPERTY = "http://www.w3.org/2002/07/owl#SymmetricProperty"

# `A ⊑ B`, one instance of `A`, and a symmetric property with one use of it.
SCHEMA = (
    f"<https://example.org/A> <{RDFS_SUB_CLASS_OF}> <https://example.org/B> .\n"
    f"<https://example.org/x> <{RDF_TYPE}> <https://example.org/A> .\n"
    f"<https://example.org/p> <{RDF_TYPE}> <{OWL_SYMMETRIC_PROPERTY}> .\n"
    "<https://example.org/x> <https://example.org/p> <https://example.org/y> .\n"
)

# cax-sco: the instance of `A` is also an instance of `B`.
SUBCLASS_INFERENCE = f"<https://example.org/x> <{RDF_TYPE}> <https://example.org/B> ."
# prp-symp: a symmetric property's use holds in the other direction too. Purely
# OWL — no RDFS rule licenses it.
SYMMETRY_INFERENCE = (
    "<https://example.org/y> <https://example.org/p> <https://example.org/x> ."
)

# Every member of the Python-visible enum, so a member added without a test is a
# failure rather than an omission.
ALL_REGIMES = [
    entail.Regime.SIMPLE,
    entail.Regime.RDF,
    entail.Regime.RDFS,
    entail.Regime.OWL_RL,
    entail.Regime.OWL_DIRECT,
    entail.Regime.RIF,
    entail.Regime.D,
]
# A normative RIF-in-XML rule document: `?x a ex:A` ⟹ `?x a ex:B`.
#
# `rif` is the one regime whose calculus is the CALLER's rather than a
# specification's, so it is the one spelling whose `program` argument is a document.
RIF_PROGRAM = (
    '<Document xmlns="http://www.w3.org/2007/rif#"><payload><Group><sentence><Forall><declare><Var>x</Var></declare><formula><Implies><if><Frame><object><Var>x</Var></object><slot><Const type="http://www.w3.org/2007/rif#iri">http://www.w3.org/1999/02/22-rdf-syntax-ns#type</Const><Const type="http://www.w3.org/2007/rif#iri">https://example.org/A</Const></slot></Frame></if><then><Frame><object><Var>x</Var></object><slot><Const type="http://www.w3.org/2007/rif#iri">http://www.w3.org/1999/02/22-rdf-syntax-ns#type</Const><Const type="http://www.w3.org/2007/rif#iri">https://example.org/B</Const></slot></Frame></then></Implies></formula></Forall></sentence></Group></payload></Document>'
)
# The conclusion RIF_PROGRAM licenses over SCHEMA, which is also what cax-sco
# licenses under OWL-RL — so the `rif` lane deriving it shows the RULE fired.
RIF_INFERENCE = SUBCLASS_INFERENCE

# Every regime, with the `program` its call takes.
#
# THE POINT OF THIS TABLE is that it has seven rows. It replaces a
# `MATERIALIZABLE`/`NOT_MATERIALIZABLE` split in which two of the seven were
# exempt from every cross-cutting assertion below and covered only by a refusal
# test. `materialize` is total over its parameter now, so they are not exempt.
REGIME_CALLS = [
    (entail.Regime.SIMPLE, ""),
    (entail.Regime.RDF, ""),
    (entail.Regime.RDFS, ""),
    (entail.Regime.OWL_RL, ""),
    (entail.Regime.OWL_DIRECT, ""),
    (entail.Regime.RIF, RIF_PROGRAM),
    (entail.Regime.D, ""),
]
# The regimes whose whole input is a rule table this workspace states — the ones
# `rules()` minus `implemented_rules()` is arithmetic about. The two
# query-directed lanes have no such table (`rules()` is `[]` for both), so the
# inventory assertions below range over these and say why.
RULE_TABLE_REGIMES = [
    entail.Regime.SIMPLE,
    entail.Regime.RDF,
    entail.Regime.RDFS,
    entail.Regime.OWL_RL,
    entail.Regime.D,
]
# The regimes with no rule table of their own.
NO_RULE_TABLE = [
    entail.Regime.OWL_DIRECT,
    entail.Regime.RIF,
]
ACCEPTED_SPELLINGS = [
    "simple",
    "rdf",
    "rdfs",
    "owl-rl",
    "owl-direct",
    "rif",
    "d",
]


def _dataset(text: str = SCHEMA) -> RdfDataset:
    """Freeze `text` (N-Quads) into the native dataset handle."""
    return RdfDataset(text, RdfFormat.N_QUADS)


# ── The closure really closes ───────────────────────────────────────────────────


def test_owl_rl_derives_what_parsing_does_not() -> None:
    """OWL-RL infers triples that are in neither the input nor a Simple closure."""
    closure, _report = entail.materialize(_dataset(), entail.Regime.OWL_RL, "", [], [])
    closed = closure.to_nquads()

    assert SUBCLASS_INFERENCE in closed, closed
    assert SYMMETRY_INFERENCE in closed, closed
    # …and neither is in the input, so the closure is doing the work.
    assert SUBCLASS_INFERENCE not in SCHEMA
    assert SYMMETRY_INFERENCE not in SCHEMA
    # `simple` is the identity closure: the same input yields neither.
    identity, _ = entail.materialize(_dataset(), entail.Regime.SIMPLE, "", [], [])
    assert SUBCLASS_INFERENCE not in identity.to_nquads()
    assert SYMMETRY_INFERENCE not in identity.to_nquads()


def test_symmetry_is_owl_only_not_rdfs() -> None:
    """`prp-symp` is an OWL rule: RDFS must NOT license the symmetric triple."""
    rdfs, _ = entail.materialize(_dataset(), entail.Regime.RDFS, "", [], [])
    assert SUBCLASS_INFERENCE in rdfs.to_nquads(), "rdfs9/cax-sco still fires"
    assert SYMMETRY_INFERENCE not in rdfs.to_nquads()


def test_base_triples_survive_the_closure() -> None:
    """A closure adds; it never drops. Every input triple is still present."""
    closure, _ = entail.materialize(_dataset(), entail.Regime.OWL_RL, "", [], [])
    closed = closure.to_nquads()
    for line in SCHEMA.splitlines():
        assert line in closed, f"input triple dropped by the closure: {line}"
    assert closure.quad_count() > len(SCHEMA.splitlines())


def test_report_names_the_rules_that_fired() -> None:
    """The report is not optional and says what the run actually did."""
    _closure, report = entail.materialize(_dataset(), entail.Regime.OWL_RL, "", [], [])
    assert report.startswith("purrdf-reasoning-report 4\n")
    assert "\nregime owl-rl\n" in report
    # The conclusion counts are the engine's to report, so only the fact that
    # these two rules ran is asserted here — the counts live in the Rust golden
    # vector, where a change to them is a reviewed diff rather than a surprise.
    assert "\nfired cax-sco " in report
    assert "\nfired prp-symp " in report
    assert "\ncontract-hash " in report
    assert report.endswith("inconsistency none\n")


# ── The evaluation limits ───────────────────────────────────────────────────────


def _budget_count(report: str, resource: str) -> int:
    prefix = f"budget {resource} "
    for line in report.splitlines():
        if line.startswith(prefix):
            return int(line.removeprefix(prefix))
    raise AssertionError(f"no {resource} line:\n{report}")


def test_the_evaluation_limits_refuse_naming_this_hosts_keyword() -> None:
    """Each real keyword refuses, preserves its counts and admits its neighbour."""
    def text(value):
        return value if isinstance(value, str) else value.to_nquads()
    for service, data, name in [(entail.materialize, _dataset(), "materialize"),
                                (entail.materialize_nt, SCHEMA, "materialize_nt")]:
        closure, report = service(data, entail.Regime.OWL_RL, "", [], [])
        facts = _budget_count(report, "stored-facts")
        arena = _budget_count(report, "term-arena-bytes")
        for key, short, raised in [("max_stored_facts", facts - 1, facts),
                                    ("max_join_steps", 1, 1048576),
                                    ("max_term_arena_bytes", arena - 1, arena)]:
            with pytest.raises(ValueError) as refused:
                service(data, entail.Regime.OWL_RL, "", [], [], **{key: short})
            message = str(refused.value)
            assert "evaluation exceeded" in message
            assert message.endswith(f"raise it with {name}({key}=...)")
            if key == "max_term_arena_bytes":
                assert f"{arena} observed, {short} permitted" in message
            exact, _ = service(data, entail.Regime.OWL_RL, "", [], [], **{key: raised})
            assert text(exact) == text(closure)


def test_the_limits_in_force_reach_the_contract_hash() -> None:
    """Raising a limit past the default names a different calculus; the closure is the
    same one."""
    def hash_of(report: str) -> str:
        return next(
            line for line in report.splitlines() if line.startswith("contract-hash ")
        )

    closure, report = entail.materialize_nt(SCHEMA, entail.Regime.OWL_RL, "", [], [])
    raised, raised_report = entail.materialize_nt(
        SCHEMA, entail.Regime.OWL_RL, "", [], [], max_stored_facts=1 << 23
    )
    assert raised == closure
    assert hash_of(raised_report) != hash_of(report)


# ── The two entry points are one path ───────────────────────────────────────────


def test_materialize_nt_matches_the_dataset_path_byte_for_byte() -> None:
    """The string wrapper is the same boundary call, not a second engine path."""
    text_closure, text_report = entail.materialize_nt(SCHEMA, entail.Regime.OWL_RL, "", [], [])
    dataset_closure, dataset_report = entail.materialize(
        _dataset(), entail.Regime.OWL_RL, "", [], []
    )
    assert text_closure == dataset_closure.to_nquads()
    assert text_report == dataset_report


def test_to_nquads_round_trips() -> None:
    """A serialized closure re-parses, and re-serializes to the same bytes."""
    closure, _ = entail.materialize(_dataset(), entail.Regime.OWL_RL, "", [], [])
    serialized = closure.to_nquads()
    reparsed = RdfDataset(serialized, RdfFormat.N_QUADS)
    assert reparsed.to_nquads() == serialized
    assert reparsed.quad_count() == closure.quad_count()
    # The same handle type the root surface exposes, not a private twin.
    assert isinstance(reparsed, purrdf.RdfDataset)


# ── Byte determinism ────────────────────────────────────────────────────────────


@pytest.mark.parametrize("regime,program", REGIME_CALLS, ids=lambda r: str(r))
def test_repeated_calls_are_byte_identical(regime: entail.Regime, program: str) -> None:
    """Twelve runs of EVERY regime produce identical bytes.

    A closure that leaked hash iteration order, a clock, a path or an address
    would diverge across these calls; a one-in-two divergence cannot pass by luck
    at this repetition count.
    """
    first_closure, first_report = entail.materialize(_dataset(), regime, program, [], [])
    first = first_closure.to_nquads()
    for _ in range(11):
        closure, report = entail.materialize(_dataset(), regime, program, [], [])
        assert closure.to_nquads() == first
        assert report == first_report
    # …and the text path is stable in the same way.
    text = entail.materialize_nt(SCHEMA, regime, program, [], [])
    assert entail.materialize_nt(SCHEMA, regime, program, [], []) == text


# ── Every regime member is accepted ─────────────────────────────────────────────


@pytest.mark.parametrize("regime,program", REGIME_CALLS, ids=lambda r: str(r))
def test_every_regime_member_materializes(regime: entail.Regime, program: str) -> None:
    """EVERY `Regime` member closes. None is refused for being the regime it is.

    Falsifiable against the behaviour this replaced: `OWL_DIRECT` and `RIF` raised
    `ValueError` here with a message listing the five regimes that "can be
    forward-materialized". `materialize` is total over its parameter now — what
    those two needed was an input, and `program` is where it goes.
    """
    assert isinstance(entail.rules(regime), list)
    assert isinstance(entail.implemented_rules(regime), list)
    closure, report = entail.materialize(_dataset(), regime, program, [], [])
    assert closure.quad_count() >= 4
    assert report.startswith("purrdf-reasoning-report 4\n")
    assert report.endswith("inconsistency none\n")
    # …and the text path agrees, byte for byte, on the same regime and program.
    text_closure, text_report = entail.materialize_nt(SCHEMA, regime, program, [], [])
    assert text_closure == closure.to_nquads()
    assert text_report == report


def test_the_rif_lane_entails_under_the_supplied_rules() -> None:
    """The `rif` lane runs the CALLER's rules, and nothing else's.

    The rule set is the whole calculus for this regime: the conclusion appears
    because the rule fired, and the RDFS axiomatic vocabulary does not, because
    no rule table ran.
    """
    closure, report = entail.materialize(_dataset(), entail.Regime.RIF, RIF_PROGRAM, [], [])
    closed = closure.to_nquads()
    assert RIF_INFERENCE in closed, closed
    assert "\nregime rif\n" in report
    assert "http://www.w3.org/2000/01/rdf-schema#Resource" not in closed


def test_owl_direct_materializes_the_query_independent_augmentation() -> None:
    """`OWL_DIRECT` closes: the tableau states what it decides about named terms."""
    closure, report = entail.materialize(_dataset(), entail.Regime.OWL_DIRECT, "", [], [])
    assert SUBCLASS_INFERENCE in closure.to_nquads(), closure.to_nquads()
    assert "\nregime owl-direct\n" in report


@pytest.mark.parametrize("regime,program", REGIME_CALLS, ids=lambda r: str(r))
def test_a_rule_document_belongs_to_rif_alone(
    regime: entail.Regime, program: str
) -> None:
    """A `program` for a regime that takes none is refused, never discarded."""
    if program:
        return
    for call in (
        lambda: entail.materialize(_dataset(), regime, RIF_PROGRAM, [], []),
        lambda: entail.materialize_nt(SCHEMA, regime, RIF_PROGRAM, [], []),
    ):
        with pytest.raises(ValueError, match="takes no rule document"):
            call()


@pytest.mark.parametrize("spelling", ACCEPTED_SPELLINGS)
def test_cli_spellings_are_accepted_too(spelling: str) -> None:
    """One spelling works from the CLI, the C ABI, WASM and Python."""
    member = getattr(entail.Regime, spelling.upper().replace("-", "_"))
    assert entail.rules(spelling) == entail.rules(member)
    assert entail.implemented_rules(spelling) == entail.implemented_rules(member)


# ── The honest gap ──────────────────────────────────────────────────────────────


def test_owl_rl_rule_inventory_is_the_specification_table() -> None:
    """`rules(OWL_RL)` is all 78 rules of OWL 2 Profiles §4.3, Tables 4–9."""
    spec = entail.rules(entail.Regime.OWL_RL)
    assert len(spec) == 78
    assert len(set(spec)) == 78, "the table has no duplicates"
    assert "cax-sco" in spec
    assert "prp-symp" in spec
    # RDFS is its own 18-rule table; RDF is 3; the rest have none.
    assert len(entail.rules(entail.Regime.RDFS)) == 18
    assert len(entail.rules(entail.Regime.RDF)) == 3
    # D is the datatype table; Simple and the two query-directed lanes state none.
    assert len(entail.rules(entail.Regime.D)) == 5
    for regime in [entail.Regime.SIMPLE, *NO_RULE_TABLE]:
        assert entail.rules(regime) == []
        assert entail.implemented_rules(regime) == []


def test_implemented_rules_are_measurable_against_the_specification_table() -> None:
    """The point of exposing both: a caller can MEASURE coverage, not trust prose.

    The assertions here must survive the table filling up. An earlier version
    demanded a *strict* subset and a *non-empty* gap — which reads as
    count-independent but is not: both encode "the gap never closes", so
    completing the table failed the test that existed to track it. What is
    actually invariant is the partition (fired and missing cover the table
    exactly, without overlap) and the ordering.
    """
    spec = entail.rules(entail.Regime.OWL_RL)
    fired = entail.implemented_rules(entail.Regime.OWL_RL)

    assert fired, "OWL-RL fires at least one rule"
    assert set(fired) <= set(spec), "every implemented rule is a specification rule"
    gap = [rule for rule in spec if rule not in fired]
    assert len(fired) + len(gap) == len(spec), "fired and missing partition the table"
    # Same relative order as the specification table (a subsequence, not a set).
    assert [rule for rule in spec if rule in fired] == fired


def test_extensions_name_what_this_build_adds_beyond_the_table() -> None:
    """A third inventory, disjoint from the other two, answerable without materializing.

    `rules()` and `implemented_rules()` are both statements about the
    specification table. Neither can express "this build also fires a sound rule
    the table omits", and before this was bound the only way to find that out was
    to close a dataset and read the report's `extension` line. Asking is now a
    question in its own right.
    """
    added = entail.extensions(entail.Regime.OWL_RL)
    assert added == ["ext-eq-diff-sym"]

    # Extending a lane is a decision taken per lane; only one has been taken.
    for regime in [entail.Regime.SIMPLE, entail.Regime.RDF, entail.Regime.RDFS,
                   entail.Regime.D, *NO_RULE_TABLE]:
        assert entail.extensions(regime) == [], str(regime)

    # The load-bearing invariant, over EVERY regime: an extension appears in
    # neither normative inventory. The 78 stays 78 because what a sound rule the
    # table omits does to this build does not change what the table says.
    for regime in [*RULE_TABLE_REGIMES, *NO_RULE_TABLE]:
        spec = entail.rules(regime)
        fired = entail.implemented_rules(regime)
        for rule in entail.extensions(regime):
            assert rule not in spec, f"{regime}: {rule} is not a specification rule"
            assert rule not in fired, f"{regime}: {rule} is not an implemented rule"
    assert len(entail.rules(entail.Regime.OWL_RL)) == 78
    assert len(entail.implemented_rules(entail.Regime.OWL_RL)) == 78

    # And the report names the same rules the inventory does, so the two
    # disclosures cannot drift apart.
    _closure, report = entail.materialize(_dataset(), entail.Regime.OWL_RL, "", [], [])
    reported = [
        line.removeprefix("extension ")
        for line in report.splitlines()
        if line.startswith("extension ")
    ]
    assert reported == added


def test_extensions_rejects_an_unknown_regime() -> None:
    """The same hard failure the other two inventories give, naming the accepted set."""
    with pytest.raises(ValueError, match="accepted: simple, rdf, rdfs"):
        entail.extensions("rdfs-plus")


@pytest.mark.parametrize("regime", RULE_TABLE_REGIMES, ids=lambda r: str(r))
def test_the_gap_is_exactly_the_reports_missing_lines(regime: entail.Regime) -> None:
    """The inventory and the report cannot drift apart."""
    spec = entail.rules(regime)
    fired = entail.implemented_rules(regime)
    gap = [rule for rule in spec if rule not in fired]

    _closure, report = entail.materialize(_dataset(), regime, "", [], [])
    missing = [
        line.removeprefix("missing ")
        for line in report.splitlines()
        if line.startswith("missing ")
    ]
    assert missing == gap
    if gap:
        assert f"\ncompleteness sound-incomplete {len(gap)}\n" in report
    else:
        # A complete rule table reports `exact`, or `exact-within-boundaries`
        # when the run still met a construct outside the table — a distinction
        # the report draws precisely so a complete table cannot claim more than
        # it delivered.
        completeness = next(
            line for line in report.splitlines() if line.startswith("completeness ")
        )
        assert completeness in ("completeness exact", "completeness exact-within-boundaries")


# ── Refusals ────────────────────────────────────────────────────────────────────


def test_malformed_input_raises_value_error() -> None:
    """A malformed document is an error, not an empty closure."""
    with pytest.raises(ValueError):
        entail.materialize_nt("this is not n-quads\n", entail.Regime.RDFS, "", [], [])
    with pytest.raises(ValueError):
        RdfDataset("this is not n-quads\n", RdfFormat.N_QUADS)


# `<urn:purrdf:rdfc:reifies>` as a predicate whose OBJECT is a plain IRI (not a
# quoted triple term) is not one of the two exact shapes the canonicalization
# overlay itself lowers (see `crates/rdf-core/src/ir/canon.rs`), so a closure
# carrying it is refused rather than silently canonicalized — accepting it would let
# a structurally different graph canonicalize to the exact bytes a genuine reifier
# binding would.
_RESERVED_PREDICATE_PLAIN_OBJECT = (
    "<https://example.org/r> <urn:purrdf:rdfc:reifies> <https://example.org/o> .\n"
)

# The valid neighbour: an ORDINARY predicate adjacent to the reserved namespace (a
# DIFFERENT `urn:purrdf:` sub-namespace, not `urn:purrdf:rdfc:`) in the exact same
# shape. Over-refusal is the mirror bug of silent acceptance, so this must still
# materialize, with the IRI surviving byte-for-byte into the closure.
_NEIGHBOURING_ORDINARY_PREDICATE = (
    "<https://example.org/r> <urn:purrdf:other:annotation> <https://example.org/o> .\n"
)


def test_a_reserved_vocabulary_closure_raises_value_error_naming_it() -> None:
    """The materialized closure is caller-supplied content too: refuse as a value.

    `materialize_nt` routes the closure through `purrdf_validate::regime`'s typed,
    non-panicking canonicalization entry point rather than the panicking wrapper —
    before that migration this surface aborted the process instead of raising.
    """
    with pytest.raises(ValueError, match="urn:purrdf:rdfc:reifies"):
        entail.materialize_nt(
            _RESERVED_PREDICATE_PLAIN_OBJECT, entail.Regime.SIMPLE, "", [], []
        )


def test_an_ordinary_closure_neighbouring_the_reserved_iri_still_materializes() -> None:
    """The refusal above is not an over-refusal of an ordinary, unrelated IRI."""
    closed_nquads, _report = entail.materialize_nt(
        _NEIGHBOURING_ORDINARY_PREDICATE, entail.Regime.SIMPLE, "", [], []
    )
    assert "urn:purrdf:other:annotation" in closed_nquads, closed_nquads


def test_unknown_regime_spelling_names_the_accepted_set() -> None:
    """The error a caller three language boundaries away has to act on."""
    for call in (
        lambda: entail.materialize(_dataset(), "rdfs-plus", "", [], []),
        lambda: entail.materialize_nt(SCHEMA, "rdfs-plus", "", [], []),
        lambda: entail.rules("rdfs-plus"),
        lambda: entail.implemented_rules("rdfs-plus"),
    ):
        with pytest.raises(ValueError) as raised:
            call()
        message = str(raised.value)
        assert "rdfs-plus" in message
        for spelling in ACCEPTED_SPELLINGS:
            assert spelling in message, f"{message} omits {spelling}"


def test_regime_spellings_are_case_sensitive() -> None:
    """Matching is exact, as the CLI writes the names."""
    with pytest.raises(ValueError, match="OWL-RL"):
        entail.rules("OWL-RL")


def test_a_non_regime_argument_names_the_accepted_set() -> None:
    """An argument that is neither a member nor a spelling is refused legibly."""
    with pytest.raises(ValueError) as raised:
        entail.rules(object())  # type: ignore[arg-type]
    message = str(raised.value)
    assert "purrdf.entail.Regime" in message
    for spelling in ACCEPTED_SPELLINGS:
        assert spelling in message, f"{message} omits {spelling}"


# ── One artifact, four hosts ────────────────────────────────────────────────────

# The COMMITTED tri-host golden vector. The `purrdf-validate` Rust test, the C
# smoke (`crates/rdf-capi/tests/smoke.c`) and the WASM module's
# `entailCheckGoldenVectors` all check these very bytes; this walks them from
# Python, so "one artifact, four hosts" is a claim Python participates in rather
# than one made on its behalf.
GOLDEN_VECTOR = (
    Path(__file__).resolve().parents[3]
    / "crates"
    / "validate"
    / "tests"
    / "fixtures"
    / "regime-boundary.vectors"
)

# The directives that open a body, mapped to the case field they fill. `@program`
# is the regime's own rule document; absent is the empty program, which is what
# every regime but `rif` takes.
_BODY_DIRECTIVES = {
    "@input": "input",
    "@program": "program",
    "@closure": "closure",
    "@report": "report",
}


def _golden_cases() -> list[dict[str, str]]:
    """Parse the committed artifact into its cases.

    The format is line-oriented and deliberately dependency-free (see
    `parse_regime_vectors` in `purrdf-validate`): a line starting with `@` is a
    directive, every other line belongs to the body the last body-directive
    opened, and outside a body only blank lines and `#` comments are legal.
    """
    cases: list[dict[str, str]] = []
    case: dict[str, str] = {}
    section: str | None = None
    for raw in GOLDEN_VECTOR.read_text(encoding="utf-8").splitlines(keepends=True):
        line = raw.rstrip("\n")
        if not line.startswith("@"):
            if section is not None:
                case[section] = case.get(section, "") + raw
            continue
        section = None
        keyword, _, argument = line.partition(" ")
        if keyword == "@case":
            case = {"name": argument.strip()}
        elif keyword == "@regime":
            case["regime"] = argument.strip()
        elif keyword in _BODY_DIRECTIVES:
            section = _BODY_DIRECTIVES[keyword]
            case.setdefault(section, "")
        elif keyword == "@end":
            cases.append(case)
            case = {}
    return cases


def test_the_golden_vector_artifact_is_readable() -> None:
    """The artifact exists, parses, and covers every regime — all seven."""
    cases = _golden_cases()
    assert cases, GOLDEN_VECTOR
    covered = {case["regime"] for case in cases}
    for regime in ALL_REGIMES:
        spelling = str(regime).rsplit(".", 1)[-1].lower().replace("_", "-")
        assert spelling in covered, f"{spelling} is not covered by {GOLDEN_VECTOR}"


@pytest.mark.parametrize(
    "case", _golden_cases(), ids=lambda case: str(case["name"])
)
def test_the_golden_vector_matches_through_python(case: dict[str, str]) -> None:
    """Match shared closure/report bytes under the fixture's explicit capacities."""
    closure, report = entail.materialize_nt(
        case["input"], case["regime"], case.get("program", ""), [], [],
        max_stored_facts=4194304,
        max_join_steps=1048576,
        max_term_arena_bytes=16777216,
    )
    assert closure == case["closure"]
    assert report == case["report"]


# ── The two things the report could not say from Python ─────────────────────────

OWL_DISJOINT_WITH = "http://www.w3.org/2002/07/owl#disjointWith"

# Two disjoint classes and one instance of both: OWL 2 RL's `cax-dw`, whose three
# premises are exactly these three triples, in this order.
INCONSISTENT = (
    f"<https://example.org/A> <{OWL_DISJOINT_WITH}> <https://example.org/B> .\n"
    f"<https://example.org/x> <{RDF_TYPE}> <https://example.org/A> .\n"
    f"<https://example.org/x> <{RDF_TYPE}> <https://example.org/B> .\n"
)


def test_the_withheld_surrogate_count_is_visible_from_python() -> None:
    """`rdfD1`, `rdfD1a`, `rdfs14` and `rdfs14a` have exactly one observable, and it
    reaches Python.

    All four fire, and every conclusion they reach mentions a blank node the chase
    minted — which a SPARQL entailment regime may not answer with, because its
    answers are drawn from the scoping graph. So none of them can ever appear in a
    `fired` line, and this count is the only evidence they ran at all. It used to
    be emitted by the CLI's own renderer alone, so from Python the four rules were
    invisible: the `boundary surrogate` paragraph said its conclusions were
    "counted here" and pointed at a number that was not in the string.
    """
    def withheld(regime: entail.Regime) -> int:
        _closure, report = entail.materialize_nt(SCHEMA, regime, "", [], [])
        for line in report.splitlines():
            if line.startswith("withheld-surrogates "):
                return int(line.removeprefix("withheld-surrogates "))
        raise AssertionError(f"no withheld-surrogates line:\n{report}")

    # RDFS states all four existential rules, and withholds what they conclude.
    assert withheld(entail.Regime.RDFS) > 0
    # OWL 2 RL states none of them, so there is nothing to withhold; the identity
    # closure evaluates nothing at all. Both are facts about the LANE, which is what
    # makes the RDFS number a measurement rather than a constant.
    assert withheld(entail.Regime.OWL_RL) == 0
    assert withheld(entail.Regime.SIMPLE) == 0


def test_an_inconsistent_run_raises_with_its_report_and_witness_triples() -> None:
    """An inconsistent knowledge base has no closure — and still has a run.

    The refusal used to be a `Display` one-liner that read only the premise COUNT,
    so the caller whose data was bad was the only caller who got no report at all
    and `inconsistency` was the constant `none` on every host. The message now
    carries the whole certificate: the rule that refused, the graph whose closure
    refused, and the asserted triples that satisfied the rule in that rule's own
    premise order.
    """
    with pytest.raises(ValueError) as raised:
        entail.materialize_nt(INCONSISTENT, entail.Regime.OWL_RL, "", [], [])
    message = str(raised.value)

    assert "cax-dw was satisfied by 3 asserted triples" in message
    # The certificate begins at the banner, so a caller splits there rather than
    # parsing prose.
    banner = "purrdf-reasoning-report 4\n"
    assert banner in message
    report = message[message.index(banner) :]
    assert report.startswith(f"{banner}regime owl-rl\n")
    assert "\ninconsistency cax-dw premises 3\n" in report
    assert "\ninconsistency-graph default\n" in report
    assert (
        f"\ninconsistency-premise <https://example.org/A> <{OWL_DISJOINT_WITH}> "
        "<https://example.org/B>\n"
    ) in report
    assert report.count("\ninconsistency-premise ") == 3
    # The run is DESCRIBED, not merely refused: it cost a budget and named a calculus.
    assert "\nbudget join-steps " in report
    assert "\ncontract-hash " in report


def test_the_dataset_path_refuses_an_inconsistent_run_the_same_way() -> None:
    """The parsed-dataset entry point carries the same evidence as the text one."""
    dataset = _dataset(INCONSISTENT)
    with pytest.raises(ValueError) as raised:
        entail.materialize(dataset, entail.Regime.OWL_RL, "", [], [])
    message = str(raised.value)
    assert "purrdf-reasoning-report 4\n" in message
    assert message.count("\ninconsistency-premise ") == 3


# ── Conclusion-directed entailment: the chase lane's three services ─────────────


def test_certain_answers_enumerate_entailed_bindings_and_disclose_completeness() -> None:
    """A row is a substitution the knowledge base ENTAILS the pattern under.

    Not "a substitution present in one closure": SPARQL's entailment regimes define
    the answers to a basic graph pattern as the CERTAIN answers, true in every model.
    `?c` therefore ranges over the entailed types of `x`, which is a strict superset
    of the asserted one.
    """
    pattern = f"<https://example.org/x> <{RDF_TYPE}> ?c .\n"
    answer, certificate = entail.certain_answers(entail.Regime.OWL_RL, SCHEMA, pattern, [], [])

    assert answer.startswith("mechanism strict-table\nvar c\n")
    # `A` is asserted; `B` is derived by cax-sco and is a certain answer all the same.
    assert "\nrow <https://example.org/A>\n" in answer
    assert "\nrow <https://example.org/B>\n" in answer
    # No `limit` line IS the claim that the row set is exhaustive. There is
    # deliberately no `complete true` line beside it: that would be a boolean
    # function of lines already rendered.
    assert "\nlimit " not in answer

    # The rows arrive with the run that produced them, on the materialization lane's
    # own banner — an empty row set is the answer a caller is most likely to act on
    # and the one that says least on its own.
    assert certificate.startswith("purrdf-reasoning-report 4\n")
    assert "\nmechanism strict-table " in certificate


def test_a_variable_is_projected_from_every_position_including_the_predicate() -> None:
    """`?name` in ANY position, which is what every host's documentation promises.

    Falsifiable against what this replaced: a variable in PREDICATE position was
    rewritten to a blank node before parsing, RDF forbids one there, and every
    pattern below with a `?p` in it raised `ValueError: the basic graph pattern is
    not N-Triples: ... predicate must be IRI` — a refusal naming a construct the
    caller had not written. `?s <p> ?o` over the same premise answered fine.
    """
    one = "<https://example.org/s> <https://example.org/p> <https://example.org/o> .\n"
    for pattern, expected in [
        (
            "<https://example.org/s> ?p <https://example.org/o> .\n",
            "mechanism strict-table\nvar p\nrow <https://example.org/p>\n",
        ),
        (
            "?s ?p <https://example.org/o> .\n",
            "mechanism strict-table\nvar s\nvar p\n"
            "row <https://example.org/s> <https://example.org/p>\n",
        ),
        (
            "?s ?p ?o .\n",
            "mechanism strict-table\nvar s\nvar p\nvar o\n"
            "row <https://example.org/s> <https://example.org/p> <https://example.org/o>\n",
        ),
        # `$name` is the same variable syntax and reaches the predicate too.
        (
            "$s $p $o .\n",
            "mechanism strict-table\nvar s\nvar p\nvar o\n"
            "row <https://example.org/s> <https://example.org/p> <https://example.org/o>\n",
        ),
    ]:
        answer, _ = entail.certain_answers(entail.Regime.SIMPLE, one, pattern, [], [])
        assert answer == expected, pattern

    # …and the predicate column ranges over what the CHASE entailed. No triple of
    # `SCHEMA` states `x rdf:type B`; `cax-sco` is the only reason the row exists.
    bridge = "<https://example.org/x> ?p <https://example.org/B> .\n"
    answer, _ = entail.certain_answers(entail.Regime.OWL_RL, SCHEMA, bridge, [], [])
    assert answer.startswith("mechanism strict-table\nvar p\n")
    assert f"\nrow <{RDF_TYPE}>\n" in answer
    asserted, _ = entail.certain_answers(entail.Regime.SIMPLE, SCHEMA, bridge, [], [])
    assert asserted == "mechanism strict-table\nvar p\n"


def test_a_question_mark_that_is_not_a_variable_is_not_read_as_one() -> None:
    """A `?` inside an IRI, a literal or a comment is text, not a variable marker.

    The property the whole rewrite is arranged around, asserted with the `?` in
    PREDICATE position: each pattern writes `?zzz` in one of those three places, so
    a scanner that read it would project a `zzz` column — and each answer is
    asserted whole, with none.
    """
    query_string = (
        "<https://example.org/s> <https://example.org/p?zzz=1> <https://example.org/o> .\n"
    )
    answer, _ = entail.certain_answers(
        entail.Regime.SIMPLE,
        query_string,
        "<https://example.org/s> <https://example.org/p?zzz=1> ?o .\n",
        [],
        [],
    )
    assert answer == "mechanism strict-table\nvar o\nrow <https://example.org/o>\n"

    quoted = '<https://example.org/s> <https://example.org/p> "is ?zzz a variable" .\n'
    answer, _ = entail.certain_answers(
        entail.Regime.SIMPLE,
        quoted,
        '<https://example.org/s> ?p "is ?zzz a variable" .\n',
        [],
        [],
    )
    assert answer == "mechanism strict-table\nvar p\nrow <https://example.org/p>\n"

    one = "<https://example.org/s> <https://example.org/p> <https://example.org/o> .\n"
    answer, _ = entail.certain_answers(
        entail.Regime.SIMPLE,
        one,
        "# is ?zzz a variable? it is prose.\n"
        "<https://example.org/s> ?p <https://example.org/o> .\n",
        [],
        [],
    )
    assert answer == "mechanism strict-table\nvar p\nrow <https://example.org/p>\n"


def test_an_open_predicate_is_a_named_limit_rather_than_a_short_answer() -> None:
    """A `?p` ranges over predicates the rule table's closure does not hold.

    `p ∘ p ⊑ p` entails `p rdf:type owl:TransitiveProperty` — `graph_entails` proves
    it, by the freeze mechanism — and no head of OWL 2 RL's Tables 4-9 concludes a
    property characteristic. So `?s ?p ?o` cannot return that row, and the answer
    discloses why instead of rendering an exhaustive-looking relation.
    """
    chain = (
        f"<https://example.org/p> <{RDF_TYPE}> "
        "<http://www.w3.org/2002/07/owl#ObjectProperty> .\n"
        "<https://example.org/p> <http://www.w3.org/2002/07/owl#propertyChainAxiom> "
        "_:l1 .\n"
        "_:l1 <http://www.w3.org/1999/02/22-rdf-syntax-ns#first> "
        "<https://example.org/p> .\n"
        "_:l1 <http://www.w3.org/1999/02/22-rdf-syntax-ns#rest> _:l2 .\n"
        "_:l2 <http://www.w3.org/1999/02/22-rdf-syntax-ns#first> "
        "<https://example.org/p> .\n"
        "_:l2 <http://www.w3.org/1999/02/22-rdf-syntax-ns#rest> "
        "<http://www.w3.org/1999/02/22-rdf-syntax-ns#nil> .\n"
    )
    transitive = (
        f"<https://example.org/p> <{RDF_TYPE}> "
        "<http://www.w3.org/2002/07/owl#TransitiveProperty> .\n"
    )
    verdict, _ = entail.graph_entails(entail.Regime.OWL_RL, chain, transitive, [], [])
    assert verdict == "mechanism freeze\nentailment entailed\n"

    answer, _ = entail.certain_answers(entail.Regime.OWL_RL, chain, "?s ?p ?o .\n", [], [])
    assert "owl#TransitiveProperty" not in answer
    limits = [line for line in answer.splitlines() if line.startswith("limit ")]
    assert len(limits) == 1, answer
    assert limits[0].startswith("limit the question leaves the predicate open in 1 triple")


def test_the_variable_stand_in_never_reaches_a_python_caller() -> None:
    """The name this boundary invents to get a `?p` past the parser stays inside it.

    PurRDF mints no vocabulary, so a stand-in surfacing in a row, a limit or a report
    would be the library's own scaffolding rendered to a caller as a term of their
    data.
    """
    one = "<https://example.org/s> <https://example.org/p> <https://example.org/o> .\n"
    for pattern in [
        "?s ?p ?o .\n",
        "<https://example.org/s> ?p ?o .\n",
        "?s ?p ?o .\n?o ?p2 ?s .\n",
    ]:
        for regime in (entail.Regime.SIMPLE, entail.Regime.RDFS, entail.Regime.OWL_RL):
            answer, certificate = entail.certain_answers(regime, one, pattern, [], [])
            assert "urn:purrdf" not in answer + certificate
            assert "purrdfQvar" not in answer + certificate


def test_a_variable_in_a_literal_datatype_is_refused_rather_than_matched() -> None:
    """`"5"^^?d` is refused by name, and never matches the stand-in namespace.

    The datatype slot is the one position the stand-in's own legality opened up: RDF
    forbids a blank node as a datatype, so the stand-in this replaced was refused
    there by the parser, and an IRI is legal there. This asserts the SEMANTICS rather
    than the rendering, because a diagnostic drops a literal's datatype when it
    prints one — a stand-in that reached that slot is invisible to
    `test_the_variable_stand_in_never_reaches_a_python_caller` above and answers a
    question about the library's own namespace instead of the caller's data.
    """
    probe = "urn:purrdf-query-variable:purrdfQvar1"
    premise = (
        '<https://example.org/caller> <https://example.org/p> "5"^^<https://example.org/dt> .\n'
        f'<https://example.org/probe> <https://example.org/p> "5"^^<{probe}> .\n'
    )
    # THE CONTROL: each half of the premise is reachable by the pattern that names its
    # datatype, so a leak into the datatype slot would show up as a row.
    answer, _ = entail.certain_answers(
        entail.Regime.SIMPLE,
        premise,
        '?s <https://example.org/p> "5"^^<https://example.org/dt> .\n',
        [],
        [],
    )
    assert answer == "mechanism strict-table\nvar s\nrow <https://example.org/caller>\n"
    answer, _ = entail.certain_answers(
        entail.Regime.SIMPLE,
        premise,
        f'?s <https://example.org/p> "5"^^<{probe}> .\n',
        [],
        [],
    )
    assert answer == "mechanism strict-table\nvar s\nrow <https://example.org/probe>\n"

    for pattern in [
        '?s <https://example.org/p> "5"^^?d .\n',
        '?d <https://example.org/p> "5"^^?d .\n',
        '?a <https://example.org/q> '
        '<<( <https://example.org/s> <https://example.org/p> "5"^^?d )>> .\n',
    ]:
        for regime in (entail.Regime.SIMPLE, entail.Regime.RDFS, entail.Regime.OWL_RL):
            with pytest.raises(ValueError) as refused:
                entail.certain_answers(regime, premise, pattern, [], [])
            message = str(refused.value)
            assert "a variable is not a datatype IRI" in message
            assert "`?d`" in message
            assert "urn:purrdf" not in message
            assert "probe" not in message


def test_graph_entails_gives_three_verdicts_and_names_the_mechanism() -> None:
    """THREE verdicts, never two — and the answer says which mechanism reached one.

    `not-entailed` is a PROOF: the procedure was complete for this premise, so the
    absence of a mapping is the absence of an entailment. Collapsing an `undecided`
    into it would turn a limitation of this library into a false statement about the
    caller's data.
    """
    entailed = f"{SUBCLASS_INFERENCE}\n"
    answer, certificate = entail.graph_entails(entail.Regime.OWL_RL, SCHEMA, entailed, [], [])
    assert answer == "mechanism strict-table\nentailment entailed\n"
    assert "\nfired cax-sco " in certificate

    never = f"<https://example.org/x> <{RDF_TYPE}> <https://example.org/Never> .\n"
    answer, _ = entail.graph_entails(entail.Regime.OWL_RL, SCHEMA, never, [], [])
    assert answer.startswith("mechanism strict-table\nentailment not-entailed\n")
    assert "\nmiss " in answer

    # `D` realizes datatype entailment as the five dt-* rules and states no theorem
    # that they are all of it, so it can PROVE an entailment and never refute one.
    answer, _ = entail.graph_entails(entail.Regime.D, SCHEMA, never, [], [])
    assert answer.startswith("mechanism strict-table\nentailment undecided\n")
    assert "\nundecided " in answer


def test_verify_entailment_re_decides_its_own_warrant() -> None:
    """The warrant is re-decided without running a reasoner.

    `warrant absent` / `verified not-applicable` is a not-entailed or an undecided:
    there is no evidence to re-decide, and a `false` there would read as a check that
    ran and failed rather than one that never applied.
    """
    entailed = f"{SUBCLASS_INFERENCE}\n"
    answer, certificate = entail.verify_entailment(
        entail.Regime.OWL_RL, SCHEMA, entailed, [], []
    )
    assert answer.startswith("mechanism strict-table\nentailment entailed\n")
    assert answer.endswith("warrant present\nverified true\n")
    assert certificate.startswith("purrdf-reasoning-report 4\n")

    never = f"<https://example.org/x> <{RDF_TYPE}> <https://example.org/Never> .\n"
    answer, _ = entail.verify_entailment(entail.Regime.OWL_RL, SCHEMA, never, [], [])
    assert answer.endswith("warrant absent\nverified not-applicable\n")


def test_the_regimes_defined_by_a_missing_input_are_refused_by_name() -> None:
    """`OWL_DIRECT` and `RIF` are refused rather than served by a weaker lane.

    Each is defined by an input these signatures do not carry — a query's class
    expressions, and the caller's rule document — so accepting them and quietly doing
    something else would be worse than refusing.
    """
    entailed = f"{SUBCLASS_INFERENCE}\n"
    pattern = f"<https://example.org/x> <{RDF_TYPE}> ?c .\n"
    for regime, spelling in [
        (entail.Regime.OWL_DIRECT, "owl-direct"),
        (entail.Regime.RIF, "rif"),
    ]:
        with pytest.raises(ValueError) as raised:
            entail.graph_entails(regime, SCHEMA, entailed, [], [])
        assert spelling in str(raised.value)
        with pytest.raises(ValueError) as raised:
            entail.certain_answers(regime, SCHEMA, pattern, [], [])
        assert spelling in str(raised.value)


# ── The caller's `owl:imports` table ────────────────────────────────────────────

# The W3C OWL 2 RL entailment corpus, as the Rust conformance harness locates it.
# A path rather than a copy: `scripts/check-corpus-frozen.py` digests those bytes,
# so a fixture transcribing them here would be a second, un-digested corpus free to
# drift from the one the conformance scoreboard grades.
_CORPUS = (
    Path(__file__).resolve().parents[3]
    / "crates"
    / "sparql-conformance"
    / "entailment-suite"
    / "w3c-owl2-rl"
)

# The ontology IRI `support011-A.rdf` DECLARES — the name the premise's `owl:imports`
# object actually is, not the file it happens to live in.
SUPPORT_011_A = "http://www.w3.org/2002/03owlt/imports/support011-A"


def _corpus_nquads(relative: str) -> str:
    """One vendored RDF/XML document as N-Quads text.

    No base IRI is passed and none is needed: every document in the vendored tree
    either declares its own `xml:base` or uses only absolute IRIs, which the Rust
    conformance harness asserts as a standing tripwire.
    """
    return purrdf.from_rdf_xml((_CORPUS / relative).read_text(encoding="utf-8")).decode()


def test_webont_imports_011_answers_from_its_own_premise_imports_intact() -> None:
    """The W3C case the `imports` parameter exists for, on this host.

    Its premise says `Socrates a ont:Man` and `owl:imports <…/support011-A>`;
    `Man ⊑ Mortal` lives only in that support document, so the published answer —
    `Socrates a ont:Mortal` — is reachable only from the imports closure.

    The premise is handed over UNMODIFIED: nothing is merged into it and the
    `owl:imports` triple is left exactly where W3C wrote it. That is the whole
    difference between resolving an import and being given a different premise —
    before this parameter existed, Python could express only the second.
    """
    premise = _corpus_nquads("cases/webont-imports-011/premise.rdf")
    # The premise really does carry the import, so this cannot pass by having been
    # handed a document that needs none.
    assert "<http://www.w3.org/2002/07/owl#imports>" in premise
    conclusion = _corpus_nquads("cases/webont-imports-011/conclusion.rdf")
    support = _corpus_nquads("imports/support011-A.rdf")
    imports = [(SUPPORT_011_A, support)]

    answer, certificate = entail.graph_entails(
        entail.Regime.OWL_RL, premise, conclusion, imports, []
    )
    assert answer.startswith("mechanism strict-table\nentailment entailed\n")
    assert certificate.startswith("purrdf-reasoning-report 4\n")

    # The other two services answer the same question the same way.
    answer, _ = entail.certain_answers(
        entail.Regime.OWL_RL, premise, conclusion, imports, []
    )
    assert answer == "mechanism strict-table\nrow\n"
    answer, _ = entail.verify_entailment(
        entail.Regime.OWL_RL, premise, conclusion, imports, []
    )
    assert answer.endswith("warrant present\nverified true\n")


def test_an_unsupplied_import_refuses_by_name_rather_than_reasoning_without_it() -> None:
    """PurRDF fetches nothing, so an unsupplied import is a refusal that NAMES it.

    Reasoning over the premise alone would answer a different question — the premise
    itself says its axioms are not all of them — and returning that answer as though
    it were this one is exactly what the refusal prevents.
    """
    premise = _corpus_nquads("cases/webont-imports-011/premise.rdf")
    conclusion = _corpus_nquads("cases/webont-imports-011/conclusion.rdf")
    with pytest.raises(ValueError) as raised:
        entail.graph_entails(entail.Regime.OWL_RL, premise, conclusion, [], [])
    assert SUPPORT_011_A in str(raised.value)


def test_a_malformed_import_table_is_refused_by_entry() -> None:
    """Every way of getting the table wrong is a typed refusal naming the entry."""
    premise = _corpus_nquads("cases/webont-imports-011/premise.rdf")
    conclusion = _corpus_nquads("cases/webont-imports-011/conclusion.rdf")
    support = _corpus_nquads("imports/support011-A.rdf")

    with pytest.raises(ValueError) as raised:
        entail.graph_entails(
            entail.Regime.OWL_RL,
            premise,
            conclusion,
            [(SUPPORT_011_A, "this is not n-quads\n")],
            [],
        )
    assert "the import document for" in str(raised.value)

    with pytest.raises(ValueError) as raised:
        entail.graph_entails(
            entail.Regime.OWL_RL,
            premise,
            conclusion,
            [(SUPPORT_011_A, support), (SUPPORT_011_A, "")],
            [],
        )
    assert "twice" in str(raised.value)

    with pytest.raises(ValueError) as raised:
        entail.graph_entails(
            entail.Regime.OWL_RL, premise, conclusion, [("", support)], []
        )
    assert "empty ontology IRI" in str(raised.value)


def test_the_import_table_is_required_rather_than_defaulted() -> None:
    """`[]` is *imports nothing*; a MISSING argument is a TypeError, not a default.

    LOW optionality is the point: a default would let a caller who meant to supply a
    table get an answer computed without one, which is the failure the whole
    parameter exists to make impossible.
    """
    entailed = f"{SUBCLASS_INFERENCE}\n"
    pattern = f"<https://example.org/x> <{RDF_TYPE}> ?c .\n"
    with pytest.raises(TypeError):
        entail.graph_entails(entail.Regime.OWL_RL, SCHEMA, entailed)  # type: ignore[call-arg]
    with pytest.raises(TypeError):
        entail.certain_answers(entail.Regime.OWL_RL, SCHEMA, pattern)  # type: ignore[call-arg]
    with pytest.raises(TypeError):
        entail.verify_entailment(entail.Regime.OWL_RL, SCHEMA, entailed)  # type: ignore[call-arg]


def test_py_entail_premise_iris() -> None:
    """`premise_iris` names the document the premise was read from.

    A premise whose ontology header imports its OWN IRI, with an empty import table, is
    refused when the caller declares no premise IRI and answered when it names that IRI:
    the two calls differ in `premise_iris` alone, so an argument that was silently
    dropped would make both refuse.
    """
    premise_iri = "http://example.org/premise"
    premise = (
        f"<{premise_iri}#ontology> <http://www.w3.org/1999/02/22-rdf-syntax-ns#type> "
        "<http://www.w3.org/2002/07/owl#Ontology> .\n"
        f"<{premise_iri}#ontology> <http://www.w3.org/2002/07/owl#imports> <{premise_iri}> .\n"
        "<https://example.org/x> <https://example.org/p> <https://example.org/y> .\n"
    )
    conclusion = "<https://example.org/x> <https://example.org/p> <https://example.org/y> .\n"
    pattern = "<https://example.org/x> <https://example.org/p> ?o .\n"
    for call, question in (
        (entail.graph_entails, conclusion),
        (entail.verify_entailment, conclusion),
        (entail.certain_answers, pattern),
    ):
        with pytest.raises(ValueError) as raised:
            call(entail.Regime.SIMPLE, premise, question, [], [])
        assert premise_iri in str(raised.value)
        answer, _ = call(entail.Regime.SIMPLE, premise, question, [], [premise_iri])
        assert answer.startswith("mechanism strict-table\n"), answer
    with pytest.raises(TypeError):
        entail.graph_entails(entail.Regime.SIMPLE, premise, conclusion, [])  # type: ignore[call-arg]


def test_every_regime_member_selects_a_distinct_native_regime() -> None:
    """Seven members, seven native regimes, in the order the enum declares them.

    The Rust side of this map is a wildcard-free ``match``, so the compiler forces
    it to be revisited when either enum grows — but the compiler can only check
    the arms it is given, and it cannot see that ``Regime.OWL_DIRECT`` reaches
    ``OwlDirect`` rather than ``Simple``. Two members wired to one native regime
    would produce no error anywhere: both spellings would be accepted, both would
    close a document, and one of them would quietly be reasoning under the wrong
    calculus.

    The reported name is derived from the member's own name here rather than
    written down, so the spelling convention — screaming snake in Python, kebab
    case on the wire — is itself pinned, and a member renamed on one side of it
    fails.
    """
    reported = []
    for regime, program in REGIME_CALLS:
        _, report = entail.materialize_nt(SCHEMA, regime, program, [], [])
        lines = [
            line.removeprefix("regime ")
            for line in report.splitlines()
            if line.startswith("regime ")
        ]
        assert len(lines) == 1, f"{regime}: one regime line per report, got {lines}"
        reported.append(lines[0])

    assert reported == ACCEPTED_SPELLINGS, (
        "each member reaches its own native regime, and the seven arrive in the "
        "order the enum declares them"
    )
    assert len(set(reported)) == len(reported), "no two members share a regime"


def test_the_python_enum_has_exactly_the_seven_members_these_tests_range_over() -> None:
    """An eighth member added without a test is a failure, not an omission.

    ``REGIME_CALLS`` and ``ALL_REGIMES`` are hand-written seven-row tables, and
    every cross-cutting assertion in this file ranges over one of them. Nothing
    otherwise connects those tables to the enum, so a member added to the binding
    would simply never be exercised — the tables would still be seven rows, still
    pass, and still be silent about the new one.
    """
    exported = {name for name in dir(entail.Regime) if name.isupper()}
    ranged_over = {
        spelling.upper().replace("-", "_") for spelling in ACCEPTED_SPELLINGS
    }
    assert exported == ranged_over, (
        "the enum's members and the spellings these tests range over are the same "
        "seven; a member on one side and not the other is untested surface"
    )
    assert len(exported) == len(ALL_REGIMES) == len(REGIME_CALLS) == 7


def test_every_conclusion_directed_service_refuses_an_unreached_import_pair() -> None:
    """A pair the premise's ``owl:imports`` closure never names raises ``ValueError``
    naming it, on all three services; the importing neighbour answers from it."""
    lib = "http://example.org/lib"
    schema = (
        "<http://example.org/A> <http://www.w3.org/2000/01/rdf-schema#subClassOf> "
        "<http://example.org/B> .\n"
    )
    fact = (
        "<http://example.org/x> <http://www.w3.org/1999/02/22-rdf-syntax-ns#type> "
        "<http://example.org/A> .\n"
    )
    importing = (
        "<http://example.org/o> <http://www.w3.org/1999/02/22-rdf-syntax-ns#type> "
        "<http://www.w3.org/2002/07/owl#Ontology> .\n"
        f"<http://example.org/o> <http://www.w3.org/2002/07/owl#imports> <{lib}> .\n" + fact
    )
    conclusion = (
        "<http://example.org/x> <http://www.w3.org/1999/02/22-rdf-syntax-ns#type> "
        "<http://example.org/B> .\n"
    )
    pattern = "<http://example.org/x> <http://www.w3.org/1999/02/22-rdf-syntax-ns#type> ?c .\n"
    table = [(lib, schema)]
    for service, question in (
        (entail.graph_entails, conclusion),
        (entail.verify_entailment, conclusion),
        (entail.certain_answers, pattern),
    ):
        with pytest.raises(ValueError) as refused:
            service("rdfs", fact, question, table, [])
        assert f"<{lib}>" in str(refused.value), str(refused.value)
        assert "would be read and never used" in str(refused.value), str(refused.value)
        answer, _ = service("rdfs", importing, question, table, [])
        assert answer.startswith("mechanism "), answer


# ── The import table: materialize and consistency close over the imports closure ──

_IMPORT_LIB = "http://example.org/lib"
_LIB = (
    "<http://example.org/A> <http://www.w3.org/2000/01/rdf-schema#subClassOf> "
    "<http://example.org/B> .\n"
    "<http://example.org/A> <http://www.w3.org/2002/07/owl#disjointWith> "
    "<http://example.org/C> .\n"
)
_FACTS = (
    "<http://example.org/x> <http://www.w3.org/1999/02/22-rdf-syntax-ns#type> "
    "<http://example.org/A> .\n"
    "<http://example.org/x> <http://www.w3.org/1999/02/22-rdf-syntax-ns#type> "
    "<http://example.org/C> .\n"
)
_IMPORTING_PREMISE = (
    "<http://example.org/o> <http://www.w3.org/1999/02/22-rdf-syntax-ns#type> "
    "<http://www.w3.org/2002/07/owl#Ontology> .\n"
    f"<http://example.org/o> <http://www.w3.org/2002/07/owl#imports> <{_IMPORT_LIB}> .\n"
    + _FACTS
)
_DERIVED_B = (
    "<http://example.org/x> <http://www.w3.org/1999/02/22-rdf-syntax-ns#type> "
    "<http://example.org/B> ."
)


def test_materialize_and_consistency_close_over_the_import_table() -> None:
    """Each answer observes the import: `x : B` joins the closure, and the imported
    disjointness makes the ontology inconsistent, only when the table supplies it."""
    table = [(_IMPORT_LIB, _LIB)]
    importing = RdfDataset(_IMPORTING_PREMISE, RdfFormat.N_QUADS)
    plain = RdfDataset(_FACTS, RdfFormat.N_QUADS)

    with pytest.raises(ValueError, match="example.org/lib"):
        entail.materialize(importing, entail.Regime.RDFS, "", [], [])
    with pytest.raises(ValueError, match="example.org/lib"):
        entail.materialize_nt(_IMPORTING_PREMISE, entail.Regime.RDFS, "", [], [])
    closure, report = entail.materialize(importing, entail.Regime.RDFS, "", table, [])
    assert _DERIVED_B in closure.to_nquads()
    assert "\nboundary ontology-import-resolved " in report
    text, _ = entail.materialize_nt(_IMPORTING_PREMISE, entail.Regime.RDFS, "", table, [])
    assert _DERIVED_B in text
    with pytest.raises(ValueError, match="would be read and never used"):
        entail.materialize(plain, entail.Regime.RDFS, "", table, [])
    unimported, _ = entail.materialize(plain, entail.Regime.RDFS, "", [], [])
    assert _DERIVED_B not in unimported.to_nquads()

    with pytest.raises(ValueError, match="example.org/lib"):
        entail.consistency(_IMPORTING_PREMISE, [], [])
    answer, certificate = entail.consistency(_IMPORTING_PREMISE, table, [])
    assert answer == "consistency false\n"
    assert "\nboundary ontology-import-resolved " in certificate
    with pytest.raises(ValueError, match="example.org/lib"):
        entail.consistency(_FACTS, table, [])
    assert entail.consistency(_FACTS, [], [])[0] == "consistency true\n"


# ── The conclusion-directed services take the evaluation limits ──────────────────


@pytest.mark.parametrize(
    ("service", "name", "question"),
    [
        (entail.certain_answers, "certain_answers", f"{SUBCLASS_INFERENCE}\n"),
        (entail.graph_entails, "graph_entails", f"{SUBCLASS_INFERENCE}\n"),
        (entail.verify_entailment, "verify_entailment", f"{SUBCLASS_INFERENCE}\n"),
    ],
)
def test_a_conclusion_directed_limit_names_this_functions_keyword(service, name, question) -> None:
    """A passed limit raises naming the keyword of the function called; the neighbour with
    the limit raised answers."""
    _, certificate = service(entail.Regime.OWL_RL, SCHEMA, question, [], [])
    arena = _budget_count(certificate, "term-arena-bytes")
    for key, short, raised in [("max_join_steps", 1, 1048576),
                                ("max_stored_facts", 1, 4194304),
                                ("max_term_arena_bytes", arena - 1, arena)]:
        with pytest.raises(ValueError) as refused:
            service(entail.Regime.OWL_RL, SCHEMA, question, [], [], **{key: short})
        message = str(refused.value)
        assert message.endswith(f"raise it with {name}({key}=...)")
        if key == "max_term_arena_bytes":
            assert f"{arena} observed, {short} permitted" in message
        answer, _ = service(entail.Regime.OWL_RL, SCHEMA, question, [], [], **{key: raised})
        assert answer.startswith("mechanism ")
