# SPDX-FileCopyrightText: 2026 Blackcat Informatics® Inc. <paudley@blackcatinformatics.ca>
# SPDX-License-Identifier: MIT OR Apache-2.0 OR MulanPSL-2.0
"""Caller-supplied execution governors on the native query/update surface.

The consumer's admission law is enforced per answer, so it has to be settable from
the language the consumer writes in. These tests hold that surface to two
promises the Rust tier already makes and the binding must not weaken:

* **A tripped governor is an outcome, not an exception.** ``query_governed``
  returns a ``QueryOutcome`` on both paths, carrying the governor that stopped the
  execution, the evidence, and the rows already reached together with the
  certificate that says what they bound. Raising would throw the paid-for rows away
  and blame the engine for a budget the caller set.
* **A ceiling is inclusive.** An answer whose size equals the cap is complete; one
  unit more is a trip.
"""

from __future__ import annotations

import pytest

import purrdf

EX = "http://example.org/"
RDF_REIFIES = "http://www.w3.org/1999/02/22-rdf-syntax-ns#reifies"

# Every dimension the kernel governs, by its stable kebab-case label. The evidence
# maps are keyed by these and a caller may match on them.
CALLER_SETTABLE = (
    "fuel",
    "answer-rows",
    "intermediate-cells",
    "scratch-bytes",
    "remote-requests",
)

# A ceiling a governed call meters but never enforces (`2**64 - 2`), versus one no
# dimension carries at all (`2**64 - 1`).
METERED_CEILING = 2**64 - 2
UNBOUNDED_CEILING = 2**64 - 1

SELECT_ALL = f"SELECT ?s ?o WHERE {{ ?s <{EX}p> ?o }} ORDER BY ?s"


def _store(triples: int = 5) -> purrdf.Store:
    """A store of `triples` statements over ``example.org``."""
    store = purrdf.Store()
    store.load(
        "\n".join(f"<{EX}s{i:03}> <{EX}p> <{EX}o{i:03}> ." for i in range(triples)),
        purrdf.RdfFormat.N_TRIPLES,
    )
    return store


def _rows(solutions: object) -> list[tuple[str, str]]:
    """A SELECT result as `(s, o)` string pairs."""
    return [(str(row[0].value), str(row[1].value)) for row in solutions]  # type: ignore[union-attr]


# ── an ungoverned call is unchanged ───────────────────────────────────────────────


def test_ungoverned_query_is_unchanged() -> None:
    """`Store.query` still returns the results directly, with no outcome wrapper."""
    store = _store()
    solutions = store.query(SELECT_ALL)

    assert isinstance(solutions, purrdf.QuerySolutions)
    assert len(solutions) == 5


def test_governed_query_agrees_with_the_ungoverned_one() -> None:
    """A governor never changes an answer, only an outcome."""
    store = _store()
    governed = store.query_governed(SELECT_ALL)

    assert governed.is_complete
    assert _rows(governed.result) == _rows(store.query(SELECT_ALL))


# ── every governor argument reaches evaluation ────────────────────────────────────


@pytest.mark.parametrize(
    ("keyword", "dimension"),
    [
        ("fuel", "fuel"),
        ("max_answers", "answer-rows"),
        ("max_intermediate_cells", "intermediate-cells"),
        ("max_scratch_bytes", "scratch-bytes"),
        ("max_remote_requests", "remote-requests"),
    ],
)
def test_every_governor_keyword_reaches_evaluation(
    keyword: str, dimension: str
) -> None:
    """Each ceiling arrives at the engine and is echoed by the evidence in force."""
    store = _store()
    outcome = store.query_governed(SELECT_ALL, **{keyword: 9_999})

    assert outcome.evidence.limits[dimension] == 9_999
    assert outcome.evidence.limit_for(dimension) == 9_999


def test_a_governed_call_meters_every_dimension_it_was_not_given() -> None:
    """An unset ceiling is metered, not absent: the evidence has no holes in it."""
    outcome = _store().query_governed(SELECT_ALL)

    assert outcome.is_complete
    for dimension in CALLER_SETTABLE:
        assert outcome.evidence.limits[dimension] == METERED_CEILING
    # The recursion guard is a build ceiling a caller cannot relax, and the paging
    # tier's dimensions are configured elsewhere entirely.
    assert outcome.evidence.limits["udf-depth"] < METERED_CEILING
    assert outcome.evidence.limits["pages"] == UNBOUNDED_CEILING
    assert outcome.evidence.consumed["fuel"] > 0
    assert outcome.evidence.consumed["answer-rows"] == 5
    assert outcome.evidence.consumed_in("answer-rows") == 5


def test_completed_evidence_sizes_the_next_budget() -> None:
    """The measured cost is directly usable as a ceiling — the loop metering exists for."""
    store = _store()
    measured = store.query_governed(SELECT_ALL).evidence.consumed["fuel"]

    assert store.query_governed(SELECT_ALL, fuel=measured).is_complete
    assert not store.query_governed(SELECT_ALL, fuel=measured - 1).is_complete


def test_evidence_rejects_an_unknown_dimension() -> None:
    """A misspelt dimension is a hard error, never a silent zero."""
    evidence = _store().query_governed(SELECT_ALL).evidence

    with pytest.raises(ValueError, match="unknown resource dimension"):
        evidence.consumed_in("fule")
    with pytest.raises(ValueError, match="unknown resource dimension"):
        evidence.limit_for("fule")


def test_governor_arguments_are_keyword_only() -> None:
    """No ceiling can be set by position, where a reordering would silently move it."""
    with pytest.raises(TypeError):
        _store().query_governed(SELECT_ALL, 10)  # type: ignore[misc]


# ── the answer cap, whose boundary is inclusive ───────────────────────────────────


def test_answer_cap_equal_to_the_answer_size_completes() -> None:
    """Consumption equal to the ceiling is admitted: cap == size is a complete answer."""
    outcome = _store().query_governed(SELECT_ALL, max_answers=5)

    assert outcome.is_complete
    assert outcome.tripped is None
    assert outcome.partial is None
    assert len(outcome.result) == 5


def test_answer_cap_one_below_the_answer_size_exhausts() -> None:
    """One unit more than the ceiling trips, and the trip names the answer cap."""
    outcome = _store().query_governed(SELECT_ALL, max_answers=4)

    assert not outcome.is_complete
    assert outcome.result is None
    assert outcome.tripped is not None
    assert outcome.tripped.kind == "budget"
    assert outcome.tripped.label == "answer-cap-exhausted"
    assert outcome.tripped.dimension == "answer-rows"
    assert outcome.tripped.limit == 4
    assert outcome.tripped.consumed == 5
    assert outcome.tripped.estimate is None
    assert outcome.tripped.cause is None


def test_partial_answers_are_a_certified_prefix() -> None:
    """A truncated SELECT hands back its rows plus what they are certified to bound."""
    store = _store()
    complete = _rows(store.query_governed(SELECT_ALL).result)
    outcome = store.query_governed(SELECT_ALL, max_answers=4)

    partial = outcome.partial
    assert partial is not None
    assert partial.certainty == "certain"
    assert partial.is_certain
    assert partial.barrier is None
    assert partial.is_positional_prefix
    # The resumption property, verified rather than asserted: the rows in hand are
    # the true answer's first rows, in order.
    assert _rows(partial.result) == complete[:4]


# ── a trip is an outcome, never an exception ──────────────────────────────────────


@pytest.mark.parametrize(
    "governors",
    [
        {"fuel": 0},
        {"max_answers": 0},
        {"max_intermediate_cells": 0},
        {"deadline_ms": 0},
    ],
    ids=["fuel", "answer-rows", "intermediate-cells", "deadline"],
)
def test_a_tripped_governor_is_returned_not_raised(
    governors: dict[str, int],
) -> None:
    """Every ceiling that can trip returns an outcome object rather than raising."""
    outcome = _store().query_governed(SELECT_ALL, **governors)

    assert isinstance(outcome, purrdf.QueryOutcome)
    assert not outcome.is_complete
    assert outcome.tripped is not None
    assert outcome.evidence.tripped is not None
    assert outcome.evidence.tripped.label == outcome.tripped.label
    assert not outcome.evidence.is_complete


def test_fuel_ceiling_reports_a_budget_governor() -> None:
    """A spent fuel budget reports the dimension, the ceiling, and what was charged."""
    outcome = _store().query_governed(SELECT_ALL, fuel=0)

    assert outcome.tripped is not None
    assert outcome.tripped.label == "fuel-exhausted"
    assert outcome.tripped.dimension == "fuel"
    assert outcome.tripped.limit == 0
    assert outcome.tripped.consumed >= 1
    assert "fuel budget exceeded" in str(outcome.tripped)


def test_deadline_reports_a_stop_cause() -> None:
    """A zero-millisecond deadline expires on the first poll, as a stop signal."""
    outcome = _store().query_governed(SELECT_ALL, deadline_ms=0)

    assert outcome.tripped is not None
    assert outcome.tripped.kind == "stopped"
    assert outcome.tripped.cause == "deadline-exceeded"
    assert outcome.tripped.dimension is None
    assert outcome.tripped.limit is None
    assert outcome.tripped.consumed is None


def test_intermediate_cell_ceiling_is_refused_at_admission() -> None:
    """A ceiling the planner's estimate already exceeds refuses before anything runs.

    The distinct kind is the point: a refusal reports an ESTIMATE, not a
    measurement, because nothing ran to measure.
    """
    outcome = _store().query_governed(SELECT_ALL, max_intermediate_cells=0)

    assert outcome.tripped is not None
    assert outcome.tripped.kind == "refused"
    assert outcome.tripped.label == "cardinality-admission-refused"
    assert outcome.tripped.dimension == "intermediate-cells"
    assert outcome.tripped.limit == 0
    assert outcome.tripped.estimate is not None
    assert outcome.tripped.estimate > 0
    assert outcome.tripped.consumed is None


def test_scratch_byte_ceiling_reports_a_budget_governor() -> None:
    """A value-constructing query is bounded by the arena it mints into."""
    store = _store()
    query = (
        f"SELECT (CONCAT(STR(?s), '{'x' * 64}') AS ?c) WHERE {{ ?s <{EX}p> ?o }}"
    )

    assert store.query_governed(query).is_complete
    outcome = store.query_governed(query, max_scratch_bytes=0)
    assert outcome.tripped is not None
    assert outcome.tripped.dimension == "scratch-bytes"


def test_remote_request_ceiling_reaches_a_query_with_no_remote_call() -> None:
    """A federated ceiling is in force even when the query issues no request."""
    outcome = _store().query_governed(SELECT_ALL, max_remote_requests=0)

    assert outcome.is_complete
    assert outcome.evidence.limits["remote-requests"] == 0
    assert outcome.evidence.consumed["remote-requests"] == 0


# ── the other query forms ─────────────────────────────────────────────────────────


def test_construct_answer_cap_counts_output_statements() -> None:
    """A graph form's cap denominates statements, not solution rows."""
    store = _store()
    query = f"CONSTRUCT {{ ?s <{EX}reaches> ?o }} WHERE {{ ?s <{EX}p> ?o }}"

    complete = store.query_governed(query, max_answers=5)
    assert complete.is_complete
    assert len(complete.result) == 5

    tripped = store.query_governed(query, max_answers=4)
    assert not tripped.is_complete
    assert tripped.tripped is not None
    assert tripped.tripped.label == "answer-cap-exhausted"
    assert tripped.partial is not None
    assert len(tripped.partial.result) == 4


def test_ask_form_has_no_answer_sequence_to_cap() -> None:
    """A boolean has no sequence, so an answer cap of zero does not bound it."""
    outcome = _store().query_governed(f"ASK {{ ?s <{EX}p> ?o }}", max_answers=0)

    assert outcome.is_complete
    assert bool(outcome.result)


def test_governed_query_over_an_rdf12_reifier() -> None:
    """RDF 1.2 triple terms and reifiers are governed like any other statement."""
    store = purrdf.Store()
    store.load(
        f"_:r <{RDF_REIFIES}> <<( <{EX}a> <{EX}p> <{EX}b> )>> .\n"
        f"_:r <{EX}source> <{EX}doc> .\n"
        f"<{EX}a> <{EX}p> <{EX}b> .\n",
        purrdf.RdfFormat.N_TRIPLES,
    )
    query = (
        f"SELECT ?r ?src WHERE {{ ?r <{RDF_REIFIES}> <<( <{EX}a> <{EX}p> <{EX}b> )>> . "
        f"?r <{EX}source> ?src }}"
    )

    complete = store.query_governed(query, max_answers=1)
    assert complete.is_complete
    assert len(complete.result) == 1

    tripped = store.query_governed(query, max_answers=0)
    assert not tripped.is_complete
    assert tripped.tripped is not None
    assert tripped.tripped.label == "answer-cap-exhausted"

    # The triple term survives a governed CONSTRUCT of the annotation shape.
    constructed = store.query_governed(
        f"CONSTRUCT {{ ?r <{EX}claims> ?tt }} "
        f"WHERE {{ ?r <{RDF_REIFIES}> ?tt }}",
        fuel=100_000,
    )
    assert constructed.is_complete
    assert len(constructed.result) == 1


# ── governed entailment query: both phases survive the host boundary ─────────────


def _rdfs_store(kind: type[purrdf.Store] | type[purrdf.MutableDataset] = purrdf.Store):
    store = kind()
    store.load(
        f"<{EX}Cat> <http://www.w3.org/2000/01/rdf-schema#subClassOf> <{EX}Animal> .\n"
        f"<{EX}tom> <http://www.w3.org/1999/02/22-rdf-syntax-ns#type> <{EX}Cat> .\n",
        purrdf.RdfFormat.N_TRIPLES,
    )
    return store


RDFS_QUERY = (
    "SELECT ?x WHERE { ?x "
    "<http://www.w3.org/1999/02/22-rdf-syntax-ns#type> "
    f"<{EX}Animal> }}"
)


def test_entailment_query_carries_answer_and_reasoning_report() -> None:
    outcome = _rdfs_store().query_entailment_governed(RDFS_QUERY, "rdfs")

    assert isinstance(outcome, purrdf.EntailmentQueryOutcome)
    assert outcome.phase == "answered"
    assert outcome.is_complete
    assert outcome.tripped is None
    assert outcome.report is not None
    assert outcome.report.startswith("purrdf-reasoning-report 4\n")
    assert "\nregime rdfs\n" in outcome.report
    assert outcome.outcome is not None and outcome.outcome.is_complete
    assert len(outcome.outcome.result) == 1


def test_entailment_query_keeps_report_when_query_phase_trips() -> None:
    outcome = _rdfs_store().query_entailment_governed(
        RDFS_QUERY, "rdfs", max_answers=0
    )

    assert outcome.phase == "answered"
    assert not outcome.is_complete
    assert outcome.report is not None
    assert outcome.outcome is not None and not outcome.outcome.is_complete
    assert outcome.tripped is not None
    assert outcome.tripped.label == "answer-cap-exhausted"


def test_entailment_query_exposes_a_closure_phase_stop_without_claiming_a_report() -> None:
    outcome = _rdfs_store().query_entailment_governed(
        RDFS_QUERY, "rdfs", deadline_ms=0
    )

    assert outcome.phase == "closure-stopped"
    assert not outcome.is_complete
    assert outcome.outcome is None
    assert outcome.report is None
    assert outcome.tripped is not None
    assert outcome.tripped.cause == "deadline-exceeded"


def test_mutable_dataset_carries_the_same_entailment_outcome() -> None:
    outcome = _rdfs_store(purrdf.MutableDataset).query_entailment_governed(
        RDFS_QUERY, "rdfs"
    )

    assert outcome.is_complete
    assert outcome.outcome is not None
    assert len(outcome.outcome.result) == 1


_IMPORTING = (
    f"<{EX}o> <http://www.w3.org/1999/02/22-rdf-syntax-ns#type> "
    "<http://www.w3.org/2002/07/owl#Ontology> .\n"
    f"<{EX}o> <http://www.w3.org/2002/07/owl#imports> <{EX}schema> .\n"
    f"<{EX}tom> <http://www.w3.org/1999/02/22-rdf-syntax-ns#type> <{EX}Cat> .\n"
)
_IMPORTED_SCHEMA = (
    f"<{EX}Cat> <http://www.w3.org/2000/01/rdf-schema#subClassOf> <{EX}Animal> .\n"
)


@pytest.mark.parametrize("kind", [purrdf.Store, purrdf.MutableDataset])
def test_entailment_query_closes_over_the_import_table(kind) -> None:
    """`tom` is an Animal only through the imported schema, so the row count observes
    whether the import took part; without the table the query is refused by name."""
    store = kind()
    store.load(_IMPORTING, purrdf.RdfFormat.N_TRIPLES)
    with pytest.raises(ValueError, match="example.org/schema"):
        store.query_entailment_governed(RDFS_QUERY, "rdfs")
    table = [(f"{EX}schema", _IMPORTED_SCHEMA)]
    outcome = store.query_entailment_governed(RDFS_QUERY, "rdfs", imports=table)
    assert outcome.outcome is not None and len(outcome.outcome.result) == 1
    assert outcome.report is not None
    assert "\nboundary ontology-import-resolved " in outcome.report
    # An entry a store that imports nothing never reaches is refused; that store with no
    # table answers.
    plain = _rdfs_store(kind)
    with pytest.raises(ValueError, match="would be read and never used"):
        plain.query_entailment_governed(RDFS_QUERY, "rdfs", imports=table)
    answered = plain.query_entailment_governed(RDFS_QUERY, "rdfs", imports=[], premise_iris=[])
    assert answered.outcome is not None and len(answered.outcome.result) == 1


@pytest.mark.parametrize("kind", [purrdf.Store, purrdf.MutableDataset])
def test_entailment_query_takes_the_closures_evaluation_limits(kind) -> None:
    """A passed closure limit raises naming this method's keyword; the neighbour answers."""
    store = _rdfs_store(kind)
    for key, short, raised in [("max_join_steps", 1, 1048576),
                                ("max_term_arena_bytes", 0, 16777216)]:
        with pytest.raises(ValueError) as refused:
            store.query_entailment_governed(RDFS_QUERY, "owl-rl", **{key: short})
        assert str(refused.value).endswith(f"raise it with query_entailment_governed({key}=...)")
        answered = store.query_entailment_governed(RDFS_QUERY, "owl-rl", **{key: raised})
        assert answered.outcome is not None and len(answered.outcome.result) == 1


# ── cancellation token admission and state ──────────────────────────────────────


def test_cancellation_token_reaches_the_evaluator() -> None:
    """A token cancelled before the call stops it on the first poll."""
    token = purrdf.CancellationToken()
    assert not token.cancelled
    token.cancel()
    assert token.cancelled

    outcome = _store().query_governed(SELECT_ALL, cancel=token)

    assert not outcome.is_complete
    assert outcome.tripped is not None
    assert outcome.tripped.kind == "stopped"
    assert outcome.tripped.cause == "cancelled"


def test_cancellation_is_idempotent_and_never_reversible() -> None:
    """Cancelling twice is one cancellation, and nothing clears the bit."""
    token = purrdf.CancellationToken()
    token.cancel()
    token.cancel()

    assert token.cancelled
    assert repr(token) == "<CancellationToken cancelled=True>"


# ── governed UPDATE ───────────────────────────────────────────────────────────────


def test_governed_update_applies_and_reports_evidence() -> None:
    """An applied request reports the cost of applying it."""
    store = _store()
    outcome = store.update_governed(f"INSERT DATA {{ <{EX}a> <{EX}p> <{EX}b> }}")

    assert isinstance(outcome, purrdf.UpdateOutcome)
    assert outcome.is_applied
    assert outcome.tripped is None
    assert outcome.evidence.is_complete
    assert len(store) == 6


def test_a_tripped_update_applies_nothing() -> None:
    """A stopped request leaves the store exactly as it found it — no partial write."""
    store = _store()
    before = len(store)
    outcome = store.update_governed(
        f"INSERT DATA {{ <{EX}a> <{EX}p> <{EX}b> }}", fuel=0
    )

    assert not outcome.is_applied
    assert outcome.tripped is not None
    assert outcome.tripped.label == "fuel-exhausted"
    assert len(store) == before
    assert not list(store.query(f"SELECT ?o WHERE {{ <{EX}a> <{EX}p> ?o }}"))


def test_a_cancelled_update_applies_nothing() -> None:
    """The all-or-nothing guarantee holds for a stop signal, not only for a ceiling."""
    store = _store()
    token = purrdf.CancellationToken()
    token.cancel()

    outcome = store.update_governed(
        f"INSERT DATA {{ <{EX}a> <{EX}p> <{EX}b> }}", cancel=token
    )

    assert not outcome.is_applied
    assert outcome.tripped is not None
    assert outcome.tripped.cause == "cancelled"
    assert len(store) == 5


def test_update_governed_has_no_answer_cap() -> None:
    """`max_answers` is refused on the update path: an UPDATE has no answer sequence."""
    with pytest.raises(TypeError):
        _store().update_governed(  # type: ignore[call-arg]
            f"INSERT DATA {{ <{EX}a> <{EX}p> <{EX}b> }}", max_answers=1
        )


# ── the same surface on MutableDataset ────────────────────────────────────────────


def test_mutable_dataset_governed_query_and_update() -> None:
    """The COW dataset carries the identical governed surface, not a narrower one."""
    dataset = purrdf.MutableDataset()
    dataset.load(
        "\n".join(f"<{EX}s{i:03}> <{EX}p> <{EX}o{i:03}> ." for i in range(5)),
        purrdf.RdfFormat.N_TRIPLES,
    )

    assert dataset.query_governed(SELECT_ALL, max_answers=5).is_complete

    tripped = dataset.query_governed(SELECT_ALL, max_answers=4)
    assert not tripped.is_complete
    assert tripped.tripped is not None
    assert tripped.tripped.label == "answer-cap-exhausted"
    assert tripped.partial is not None
    assert len(tripped.partial.result) == 4

    applied = dataset.update_governed(f"INSERT DATA {{ <{EX}a> <{EX}p> <{EX}b> }}")
    assert applied.is_applied
    assert len(dataset) == 6

    stopped = dataset.update_governed(
        f"INSERT DATA {{ <{EX}c> <{EX}p> <{EX}d> }}", fuel=0
    )
    assert not stopped.is_applied
    assert len(dataset) == 6


@pytest.mark.parametrize("container", [purrdf.Store, purrdf.MutableDataset])
@pytest.mark.parametrize("method", ["query_governed", "query_entailment_governed", "update_governed"])
def test_explicit_no_ceiling_preserves_answers_and_stop_sources(container, method) -> None:
    store = container()
    store.load(f"<{EX}s> <{EX}p> <{EX}o> .", purrdf.RdfFormat.N_TRIPLES)
    args = (SELECT_ALL, "rdf") if method == "query_entailment_governed" else (
        (f"INSERT DATA {{ <{EX}a> <{EX}p> <{EX}b> }}",)
        if method == "update_governed" else (SELECT_ALL,)
    )
    invoke = getattr(store, method)
    result = invoke(*args, no_ceiling=True)
    if method == "query_entailment_governed":
        result = result.outcome
    assert result is not None
    assert result.is_applied if method == "update_governed" else result.is_complete
    for dimension in CALLER_SETTABLE:
        assert result.evidence.limit_for(dimension) == UNBOUNDED_CEILING
        assert result.evidence.consumed_in(dimension) == 0
    stopped = invoke(*args, no_ceiling=True, deadline_ms=0)
    assert stopped.tripped is not None
    assert stopped.tripped.cause == "deadline-exceeded"
    token = purrdf.CancellationToken()
    token.cancel()
    stopped = invoke(*args, no_ceiling=True, cancel=token)
    assert stopped.tripped is not None
    assert stopped.tripped.cause == "cancelled"
    with pytest.raises(TypeError):
        invoke(*args, no_ceiling="true")
    caps = ("fuel", "max_intermediate_cells", "max_scratch_bytes", "max_remote_requests")
    if method != "update_governed":
        caps += ("max_answers",)
    for cap in caps:
        for value in (0, 10):
            with pytest.raises(ValueError, match="no ceiling"):
                invoke(*args, no_ceiling=True, **{cap: value})
    with pytest.raises(TypeError):
        store.query(SELECT_ALL, no_ceiling=True)
