// SPDX-FileCopyrightText: 2026 Blackcat Informatics Inc. <paudley@blackcatinformatics.ca>
// SPDX-License-Identifier: MIT OR Apache-2.0 OR MulanPSL-2.0

//! Native Store / SPARQL / parse / canonicalize surface for the `purrdf` Python
//! extension, backed entirely by the `purrdf-core` IR + the native SPARQL engine.
//!
//! # Why this exists
//!
//! This module exposes the Store + SPARQL (SELECT / ASK / CONSTRUCT, variable substitution) +
//! `parse` / `serialize` + native canonicalization surface our Python layer
//! needs, so `make check` / CI / the build run with **no external RDF runtime**
//! (CONSTITUTION Principle 18).
//!
//! # Kernel-clean separation
//!
//! This module lives in the dedicated Python binding crate. The RDF kernel stays
//! PyO3-free.
//!
//! # Single-responsibility layout
//!
//! This module is the thin facade over five focused submodules, split along the
//! P2 backend-trait seams so the trait extraction is a clean lift:
//!
//! * [`term`] — the term object model (`NamedNode` … `Quad`, `Variable`) and the
//!   Python ⇄ native term converters/extractors (`TermFactory` seam).
//! * [`io`] — `parse` / `serialize` + the pure-Rust `parse_quads` /
//!   `serialize_triples` cores (`RdfParserBackend` / `RdfSerializer` seams).
//! * [`query`] — the materialized SPARQL result model (`SparqlEngine` seam).
//! * [`store`] — the mutable `Store` / `Dataset` / `QuadIter` (`MutableStore` /
//!   `Dataset` seams).
//! * [`canon`] — `CanonicalizationAlgorithm` + the `canonicalize_quads` core.
//!
//! # Design
//!
//! * **Eager materialization** — `Store.query` freezes a snapshot and collects the
//!   native engine's results into owned `Vec`s before returning, so a borrow of the
//!   store never escapes into a `'static` `#[pyclass]`.
//! * **Pure-Rust cores** — [`parse_quads`] and [`canon::canonicalize_quads`] hold the
//!   load-bearing logic and stay PyO3-free; the `#[pymethods]` are thin wrappers
//!   over them. Installed interpreter coverage lives in `bindings/python/tests`.
//!   The native load-ingress control imports its interpreter-free production
//!   module directly; it does not link the PyO3 extension's CPython API.
//! * **Stable object model** — the term/result classes expose the slice of the
//!   Python API the codebase relies on (`NamedNode`, `Literal`, `Store`, …).

mod canon;
mod env;
mod io;
mod load;
mod mutable;
mod prepared;
pub(crate) mod presentation;
mod quad_store;
mod query;
mod results;
mod store;
mod term;
mod xsd;

pub(crate) use io::{PyRdfFormat, parse_quads};
/// The mutable quad store itself, re-exported for the SHACL surface.
///
/// `purrdf.shapes`'s incremental lane takes a `Store` and reads the copy-on-write
/// DELTA out of it (see [`store::PyStore::change_snapshot`]), which it cannot do
/// through the Python object protocol: a delta is a Rust view over this store's own
/// interners, not something expressible as a capsule of a frozen snapshot the way
/// `_store_capsule` is.
pub(crate) use store::PyStore;

use pyo3::prelude::*;

/// Render an IRI failure as the `ValueError` every mutation surface raises.
///
/// One spelling for the whole binding: the message leads with
/// [`purrdf::iri::IriError::diagnostic_code`], the workspace's single owner of those
/// stable strings, so Python callers switch on the same code the CLI, the C ABI and
/// wasm report for the same condition.
pub(crate) fn iri_value_error(err: &purrdf_core::IriError) -> PyErr {
    pyo3::exceptions::PyValueError::new_err(format!("{}: {err}", err.diagnostic_code()))
}

/// Keep physical IRI ingress refusal distinct from invalid lexical input.
pub(crate) fn iri_read_value_error(error: &purrdf::iri::IriReadError) -> PyErr {
    match error {
        purrdf::iri::IriReadError::Lexical(error) => iri_value_error(error),
        purrdf::iri::IriReadError::Storage(error) => storage_value_error(*error),
    }
}

/// Render storage refusal through the shared diagnostic presentation boundary.
pub(crate) fn storage_value_error(error: purrdf_lex::allocation::StorageError) -> PyErr {
    let diagnostic = purrdf_core::RdfDiagnostic::from(error);
    presentation::value_error(diagnostic.to_string(), &diagnostic)
}

fn load_value_error(error: load::LoadError) -> PyErr {
    match error {
        load::LoadError::Insert(error) => iri_read_value_error(&error),
        load::LoadError::Declaration(error) => presentation::value_error(error.to_string(), &error),
    }
}

/// Register the native Store / term / SPARQL surface on the `purrdf` module.
pub(crate) fn register(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<PyRdfFormat>()?;
    m.add_class::<prepared::PyPreparedQuery>()?;
    m.add_class::<canon::PyCanonicalizationAlgorithm>()?;
    m.add_class::<term::PyNamedNode>()?;
    m.add_class::<term::PyBlankNode>()?;
    m.add_class::<term::PyLiteral>()?;
    m.add_class::<term::PyTriple>()?;
    m.add_class::<term::PyQuad>()?;
    m.add_class::<term::PyDefaultGraph>()?;
    m.add_class::<term::PyVariable>()?;
    m.add_class::<query::PyQuerySolutions>()?;
    m.add_class::<query::PyQuerySolution>()?;
    m.add_class::<query::PyQueryTriples>()?;
    m.add_class::<query::PyQueryQuads>()?;
    m.add_class::<io::PySerializeLoss>()?;
    m.add_class::<query::PyQueryBoolean>()?;
    m.add_class::<query::PyCancellationToken>()?;
    m.add_class::<query::PyTrippedGovernor>()?;
    m.add_class::<query::PyGovernorEvidence>()?;
    m.add_class::<query::PyPartialAnswers>()?;
    m.add_class::<query::PyQueryOutcome>()?;
    m.add_class::<query::PyEntailmentQueryOutcome>()?;
    m.add_class::<query::PyUpdateOutcome>()?;
    m.add_class::<PyStore>()?;
    m.add_class::<store::PyDataset>()?;
    m.add_class::<mutable::PyMutableDataset>()?;
    m.add_class::<store::PyQuadIter>()?;
    m.add_function(wrap_pyfunction!(io::parse, m)?)?;
    m.add_function(wrap_pyfunction!(io::serialize, m)?)?;
    m.add_function(wrap_pyfunction!(results::serialize_sparql_solutions, m)?)?;
    m.add_function(wrap_pyfunction!(results::serialize_sparql_boolean, m)?)?;
    m.add_function(wrap_pyfunction!(results::parse_sparql_results, m)?)?;
    m.add_function(wrap_pyfunction!(results::provenance_from_json_py, m)?)?;
    m.add_function(wrap_pyfunction!(results::provenance_from_xml_py, m)?)?;
    m.add_function(wrap_pyfunction!(xsd::xsd_value_compare, m)?)?;
    m.add_function(wrap_pyfunction!(xsd::xsd_canonical_lexical, m)?)?;
    m.add_function(wrap_pyfunction!(xsd::xsd_decode_binary, m)?)?;
    m.add_function(wrap_pyfunction!(xsd::xsd_normalize_whitespace, m)?)?;
    Ok(())
}
