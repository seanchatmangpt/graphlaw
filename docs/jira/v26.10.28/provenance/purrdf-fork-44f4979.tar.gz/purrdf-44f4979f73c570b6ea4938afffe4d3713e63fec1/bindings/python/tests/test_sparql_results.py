# SPDX-FileCopyrightText: 2026 Blackcat Informatics® Inc. <paudley@blackcatinformatics.ca>
# SPDX-License-Identifier: MIT OR Apache-2.0 OR MulanPSL-2.0
"""SPARQL Results serialization / parsing for the compat shim.

Covers the native SELECT/ASK result codecs behind ``Result.serialize`` /
``Result.parse`` (JSON / XML / CSV / TSV): byte-determinism against committed
goldens, round-trips through the native reader, and differential interop with
the *real* rdflib oracle (which can parse a purrdf-emitted SPARQL-JSON/XML
document, and whose emitted document purrdf can parse back).
"""

from __future__ import annotations

import io
from pathlib import Path
from types import ModuleType

import pytest

EX = "http://example.org/"
_GOLDENS = Path(__file__).parent / "goldens" / "sparql_results"


def _fixture_graph(mod: ModuleType) -> object:
    """Build the deterministic three-row graph the goldens were captured from."""
    g = mod.Graph()
    g.add((mod.URIRef(f"{EX}s1"), mod.URIRef(f"{EX}p"), mod.Literal("alpha")))
    g.add((mod.URIRef(f"{EX}s2"), mod.URIRef(f"{EX}p"), mod.Literal(42)))
    g.add((mod.URIRef(f"{EX}s3"), mod.URIRef(f"{EX}p"), mod.Literal("bonjour", lang="fr")))
    return g


def _select(mod: ModuleType) -> object:
    """Run the deterministic (ORDER BY) SELECT the goldens were captured from."""
    return _fixture_graph(mod).query(f"SELECT ?s ?o WHERE {{ ?s <{EX}p> ?o }} ORDER BY ?s")


def _ask(mod: ModuleType) -> object:
    """Run the ASK the goldens were captured from."""
    return _fixture_graph(mod).query(f"ASK {{ ?s <{EX}p> ?o }}")


# ── byte-determinism against committed goldens ────────────────────────────────────


@pytest.mark.parametrize(
    ("fmt", "golden"),
    [
        ("json", "select.srj"),
        ("xml", "select.srx"),
        ("csv", "select.csv"),
        ("tsv", "select.tsv"),
    ],
)
def test_select_serialization_matches_golden(
    compat: ModuleType, fmt: str, golden: str
) -> None:
    """A SELECT serializes to the committed golden bytes, deterministically."""
    result = _select(compat)
    first = result.serialize(format=fmt, encoding="utf-8")
    assert isinstance(first, bytes)
    assert first == (_GOLDENS / golden).read_bytes()
    # Determinism: a second (independent) serialization is byte-identical.
    assert _select(compat).serialize(format=fmt, encoding="utf-8") == first


@pytest.mark.parametrize(("fmt", "golden"), [("json", "ask.srj"), ("xml", "ask.srx")])
def test_ask_serialization_matches_golden(
    compat: ModuleType, fmt: str, golden: str
) -> None:
    """An ASK serializes to the committed golden bytes."""
    assert _ask(compat).serialize(format=fmt, encoding="utf-8") == (
        _GOLDENS / golden
    ).read_bytes()


def test_serialize_str_vs_bytes(compat: ModuleType) -> None:
    """No encoding → ``str``; an encoding → ``bytes`` (RDFLib parity)."""
    result = _select(compat)
    as_str = result.serialize(format="json")
    as_bytes = _select(compat).serialize(format="json", encoding="utf-8")
    assert isinstance(as_str, str)
    assert isinstance(as_bytes, bytes)
    assert as_str.encode("utf-8") == as_bytes


# ── native round-trip (serialize → parse) ─────────────────────────────────────────


@pytest.mark.parametrize("fmt", ["json", "xml"])
def test_select_native_roundtrip(compat: ModuleType, fmt: str) -> None:
    """serialize → parse reconstructs the SELECT variables and rows."""
    data = _select(compat).serialize(format=fmt, encoding="utf-8")
    parsed = compat.Result.parse(io.BytesIO(data), format=fmt)
    assert parsed.type == "SELECT"
    assert list(parsed.vars) == ["s", "o"]
    rows = sorted((str(row[0]), str(row[1])) for row in parsed)
    assert rows == [
        (f"{EX}s1", "alpha"),
        (f"{EX}s2", "42"),
        (f"{EX}s3", "bonjour"),
    ]


@pytest.mark.parametrize("fmt", ["json", "xml"])
def test_ask_native_roundtrip(compat: ModuleType, fmt: str) -> None:
    """serialize → parse reconstructs the ASK boolean."""
    data = _ask(compat).serialize(format=fmt, encoding="utf-8")
    parsed = compat.Result.parse(io.BytesIO(data), format=fmt)
    assert parsed.type == "ASK"
    assert bool(parsed) is True


def test_parse_preserves_datatype_and_language(compat: ModuleType) -> None:
    """A typed / language-tagged literal survives the JSON round-trip."""
    data = _select(compat).serialize(format="json", encoding="utf-8")
    parsed = compat.Result.parse(io.BytesIO(data), format="json")
    by_subject = {str(row[0]): row[1] for row in parsed}
    assert by_subject[f"{EX}s2"].datatype == compat.URIRef(
        "http://www.w3.org/2001/XMLSchema#integer"
    )
    assert by_subject[f"{EX}s3"].language == "fr"


# ── differential interop with the real rdflib oracle ──────────────────────────────


@pytest.mark.parametrize("fmt", ["json", "xml"])
def test_oracle_parses_purrdf_output(
    compat: ModuleType, oracle: ModuleType, fmt: str
) -> None:
    """The real rdflib parses a purrdf-emitted SPARQL Results document."""
    data = _select(compat).serialize(format=fmt, encoding="utf-8")
    oracle_result = oracle.query.Result.parse(io.BytesIO(data), format=fmt)
    rows = sorted((str(row[0]), str(row[1])) for row in oracle_result)
    assert rows == [
        (f"{EX}s1", "alpha"),
        (f"{EX}s2", "42"),
        (f"{EX}s3", "bonjour"),
    ]


@pytest.mark.parametrize("fmt", ["json", "xml"])
def test_purrdf_parses_oracle_output(
    compat: ModuleType, oracle: ModuleType, fmt: str
) -> None:
    """purrdf parses a real-rdflib-emitted SPARQL Results document."""
    oracle_result = _select(oracle)
    data = oracle_result.serialize(format=fmt, encoding="utf-8")
    parsed = compat.Result.parse(io.BytesIO(data), format=fmt)
    rows = sorted((str(row[0]), str(row[1])) for row in parsed)
    assert rows == [
        (f"{EX}s1", "alpha"),
        (f"{EX}s2", "42"),
        (f"{EX}s3", "bonjour"),
    ]


# ── registry wiring (the reserved slots now serve real codecs) ────────────────────


def test_registry_serializer_slots_emit(compat: ModuleType) -> None:
    """``plugin.get(name, ResultSerializer)`` emits a real document (not a stub)."""
    from purrdf.compat.rdflib import plugin
    from purrdf.compat.rdflib.query import ResultParser, ResultSerializer

    result = _select(compat)
    for name, needle in (("json", b'"bindings"'), ("csv", b"s,o"), ("tsv", b"?s")):
        cls = plugin.get(name, ResultSerializer)
        buf = io.BytesIO()
        cls(result).serialize(buf)
        assert needle in buf.getvalue()
    # XML parser slot resolves and parses.
    xml_cls = plugin.get("xml", ResultParser)
    parsed = xml_cls().parse(
        io.BytesIO(_select(compat).serialize(format="xml", encoding="utf-8"))
    )
    assert parsed.type == "SELECT"


# ── registered plugin implementations ─────────────────────────────────────────────


def test_csv_result_parser_variables_and_bindings(compat: ModuleType) -> None:
    """CSV parsing reconstructs variable names, IRIs, literals, and unbound slots."""
    from purrdf.compat.rdflib import plugin
    from purrdf.compat.rdflib.query import ResultParser

    data = (
        "s,o\n"
        "http://example.org/s1,alpha\n"
        "http://example.org/s2,42\n"
        ",unbound\n"
    )
    cls = plugin.get("csv", ResultParser)
    result = cls().parse(io.BytesIO(data.encode("utf-8")))
    assert result.type == "SELECT"
    assert [str(v) for v in result.vars] == ["s", "o"]
    rows = list(result)
    assert len(rows) == 3
    assert rows[0][0] == compat.URIRef("http://example.org/s1")
    assert rows[0][1] == compat.Literal("alpha")
    assert rows[1][0] == compat.URIRef("http://example.org/s2")
    assert rows[1][1] == compat.Literal("42")
    assert rows[1][1].datatype is None
    assert rows[2][0] is None
    assert rows[2][1] == compat.Literal("unbound")


def test_tsv_result_parser_preserves_terms(compat: ModuleType) -> None:
    """TSV parsing preserves IRIs, typed literals, language tags, blank nodes, and unbound."""
    from purrdf.compat.rdflib import plugin
    from purrdf.compat.rdflib.query import ResultParser

    data = (
        "?s\t?o\n"
        "<http://example.org/s1>\t\"alpha\"\n"
        "<http://example.org/s2>\t\"42\"^^<http://www.w3.org/2001/XMLSchema#integer>\n"
        "<http://example.org/s3>\t\"bonjour\"@fr\n"
        "_:b0\t\n"
    )
    cls = plugin.get("tsv", ResultParser)
    result = cls().parse(io.BytesIO(data.encode("utf-8")))
    assert result.type == "SELECT"
    assert [str(v) for v in result.vars] == ["s", "o"]
    rows = {str(row[0]): row[1] for row in result}
    assert rows["http://example.org/s1"] == compat.Literal("alpha")
    assert rows["http://example.org/s2"].datatype == compat.URIRef(
        "http://www.w3.org/2001/XMLSchema#integer"
    )
    assert rows["http://example.org/s3"].language == "fr"
    # The blank-node row has an unbound object.
    blank_row = [row for row in result if isinstance(row[0], compat.BNode)][0]
    assert blank_row[1] is None


def test_txt_result_serializer_emits_table(compat: ModuleType) -> None:
    """The txt serializer emits a non-empty text table with headers and rows."""
    from purrdf.compat.rdflib import plugin
    from purrdf.compat.rdflib.query import ResultSerializer

    result = _select(compat)
    cls = plugin.get("txt", ResultSerializer)
    buf = io.BytesIO()
    cls(result).serialize(buf)
    text = buf.getvalue().decode("utf-8")
    assert "?s" in text
    assert "?o" in text
    assert "alpha" in text
    assert "42" in text
    assert "\n" in text


def test_graph_result_parser_parses_turtle(compat: ModuleType) -> None:
    """A graph parser registered as a ResultParser loads a CONSTRUCT graph."""
    from purrdf.compat.rdflib import plugin
    from purrdf.compat.rdflib.query import ResultParser

    turtle = (
        "@prefix ex: <http://example.org/> .\n"
        "ex:s ex:p ex:o .\n"
    )
    cls = plugin.get("turtle", ResultParser)
    result = cls().parse(
        io.BytesIO(turtle.encode("utf-8")), content_type="turtle"
    )
    assert result.type == "CONSTRUCT"
    assert (
        compat.URIRef("http://example.org/s"),
        compat.URIRef("http://example.org/p"),
        compat.URIRef("http://example.org/o"),
    ) in result


def test_graph_result_parser_accepts_positional_content_type(
    compat: ModuleType,
) -> None:
    """``GraphResultParser.parse`` accepts ``content_type`` positionally (rdflib parity)."""
    from purrdf.compat.rdflib import plugin
    from purrdf.compat.rdflib.query import ResultParser

    nt = "<http://example.org/s> <http://example.org/p> <http://example.org/o> .\n"
    cls = plugin.get("nt", ResultParser)
    result = cls().parse(io.BytesIO(nt.encode("utf-8")), "nt")
    assert result.type == "CONSTRUCT"
    assert len(result) == 1


# ── differential interop for the newly implemented codecs ─────────────────────────


def test_oracle_parses_purrdf_csv_output(
    compat: ModuleType, oracle: ModuleType
) -> None:
    """The real rdflib parses a purrdf-emitted SPARQL Results CSV document."""
    data = _select(compat).serialize(format="csv", encoding="utf-8")
    oracle_result = oracle.query.Result.parse(io.BytesIO(data), format="csv")
    rows = sorted((str(row[0]), str(row[1])) for row in oracle_result)
    assert rows == [
        (f"{EX}s1", "alpha"),
        (f"{EX}s2", "42"),
        (f"{EX}s3", "bonjour"),
    ]


def test_purrdf_parses_oracle_csv_output(
    compat: ModuleType, oracle: ModuleType
) -> None:
    """purrdf's CSV plugin parses a real-rdflib-emitted CSV result document."""
    from purrdf.compat.rdflib import plugin
    from purrdf.compat.rdflib.query import ResultParser

    oracle_result = _select(oracle)
    data = oracle_result.serialize(format="csv", encoding="utf-8")
    cls = plugin.get("csv", ResultParser)
    parsed = cls().parse(io.BytesIO(data))
    rows = sorted((str(row[0]), str(row[1])) for row in parsed)
    assert rows == [
        (f"{EX}s1", "alpha"),
        (f"{EX}s2", "42"),
        (f"{EX}s3", "bonjour"),
    ]


def test_oracle_parses_purrdf_tsv_output(
    compat: ModuleType, oracle: ModuleType
) -> None:
    """The real rdflib parses a purrdf-emitted SPARQL Results TSV document."""
    data = _select(compat).serialize(format="tsv", encoding="utf-8")
    oracle_result = oracle.query.Result.parse(io.BytesIO(data), format="tsv")
    rows = sorted((str(row[0]), str(row[1])) for row in oracle_result)
    assert rows == [
        (f"{EX}s1", "alpha"),
        (f"{EX}s2", "42"),
        (f"{EX}s3", "bonjour"),
    ]


# ── the additive `purrdf` provenance extension, reachable and readable back ───────


@pytest.mark.parametrize("fmt", ["json", "xml"])
def test_provenance_namespace_populates_and_round_trips(
    compat: ModuleType, fmt: str
) -> None:
    """`Result.serialize(provenance_namespace=..., query_hash=...)` anchors a
    populated additive extension, and what purrdf writes, `provenance_from_json`/
    `provenance_from_xml` read back — closing the "writer emits something nothing
    can read back" gap."""
    import purrdf

    data = _select(compat).serialize(
        format=fmt,
        encoding="utf-8",
        provenance_namespace=("prov", "https://example.org/ns/prov#"),
        query_hash="deadbeef",
    )
    reader = purrdf.provenance_from_json if fmt == "json" else purrdf.provenance_from_xml
    decoded = reader(data, "prov", "https://example.org/ns/prov#")
    assert decoded == {"query_hash": "deadbeef", "engine": "purrdf-sparql-eval"}


def test_omitting_provenance_namespace_emits_pure_w3c_output(compat: ModuleType) -> None:
    """No `provenance_namespace`: the output is byte-identical to before the
    parameter existed (the golden-pinned tests above already prove this, this
    test states the contract explicitly for the ASK form too)."""
    data = _ask(compat).serialize(format="json", encoding="utf-8")
    assert b'"prov"' not in data


def test_provenance_without_namespace_but_with_query_hash_is_dropped_and_signalled(
    compat: ModuleType,
) -> None:
    """`query_hash` alone (no `provenance_namespace`) populates `ResultProvenance`
    but has nowhere to go: the extension is dropped, exactly like CSV/TSV drop any
    populated provenance regardless of namespace."""
    data = _ask(compat).serialize(format="json", encoding="utf-8", query_hash="deadbeef")
    assert b"deadbeef" not in data
    assert b'"prov"' not in data


def test_provenance_from_json_on_a_document_with_no_member_decodes_to_none() -> None:
    """A document nothing populated decodes to both fields `None`, not an error."""
    import purrdf

    plain = purrdf.serialize_sparql_boolean("json", True)
    decoded = purrdf.provenance_from_json(plain, "prov", "https://example.org/ns/prov#")
    assert decoded == {"query_hash": None, "engine": None}


def test_invalid_provenance_namespace_is_a_value_error(compat: ModuleType) -> None:
    """An invalid prefix (e.g. containing `:`) is rejected, not silently spliced."""
    with pytest.raises(ValueError):
        _ask(compat).serialize(
            format="json",
            provenance_namespace=("not:a:prefix", "https://example.org/ns/prov#"),
        )


# ── the format id itself ────────────────────────────────────────────────────────


def test_an_unknown_results_format_id_is_refused_and_the_four_known_ones_answer() -> None:
    """Four ids are accepted by name, and a fifth is refused naming the four.

    The goldens above establish what each of the four id*s* produces; nothing
    establishes what a fifth does. An id read as a default — the first format, or
    the last one that matched — would hand a caller a document in a syntax they
    did not ask for and cannot detect, since a SPARQL Results reader is chosen by
    the same name that was ignored.

    ``"txt"`` is deliberately the unknown id under test: rdflib ships its own
    ``txt`` table serializer, so it is the spelling a host is most likely to reach
    for and the one whose silent acceptance would look plausible.
    """
    import purrdf

    for entry in (
        lambda fmt: purrdf.serialize_sparql_boolean(fmt, True),
        lambda fmt: purrdf.serialize_sparql_solutions(fmt, [], []),
        lambda fmt: purrdf.parse_sparql_results(fmt, b'{"head":{},"boolean":true}'),
    ):
        with pytest.raises(ValueError, match="unknown SPARQL results format") as refused:
            entry("txt")
        message = str(refused.value)
        for known in ("json", "xml", "csv", "tsv"):
            assert known in message, f"the refusal names {known}: {message}"

    # The neighbouring valid ids: all four serialize a SELECT, the two that can
    # express an ASK serialize one, and the two the parser reads round-trip.
    # Refusing any of these would be the mirror failure — a format registry that
    # rejects its own registered names.
    row = [purrdf.NamedNode("https://example.org/s")]
    for fmt in ("json", "xml", "csv", "tsv"):
        assert purrdf.serialize_sparql_solutions(fmt, ["s"], [row]), fmt
    # A format is also named by its media type or an alias, in any ASCII case, and
    # each such name produces exactly the document its short id does.
    for alias, fmt in (
        ("JSON", "json"),
        ("srj", "json"),
        (" SPARQL-JSON ", "json"),
        ("application/sparql-results+json", "json"),
        ("sparql-xml", "xml"),
        ("  sPaRqL-XmL\t", "xml"),
        ("Application/SPARQL-Results+XML", "xml"),
        ("text/csv", "csv"),
        ("text/tab-separated-values", "tsv"),
    ):
        assert purrdf.serialize_sparql_solutions(
            alias, ["s"], [row]
        ) == purrdf.serialize_sparql_solutions(fmt, ["s"], [row]), alias
        if fmt in ("json", "xml"):
            encoded = purrdf.serialize_sparql_boolean(alias, True)
            assert purrdf.parse_sparql_results(alias, encoded) == ("ASK", True), alias
    # CSV and TSV are defined for variable bindings only, so an ASK is refused
    # there for a reason of its own — a distinct message, not the unknown-id one.
    for fmt in ("json", "xml"):
        assert purrdf.serialize_sparql_boolean(fmt, True), fmt
        assert purrdf.parse_sparql_results(
            fmt, purrdf.serialize_sparql_boolean(fmt, True)
        ) == ("ASK", True), fmt
    for fmt in ("csv", "tsv"):
        with pytest.raises(ValueError, match="not ASK") as declined:
            purrdf.serialize_sparql_boolean(fmt, True)
        assert "unknown SPARQL results format" not in str(declined.value), (
            f"{fmt}: a registered id that cannot express an ASK says so, and is "
            "never reported as an unregistered id"
        )


@pytest.mark.parametrize(
    ("alias", "canonical"),
    [
        (" JSON ", "json"),
        (" SrJ\t", "json"),
        (" SPARQL-JSON ", "json"),
        (" Application/SPARQL-Results+JSON ", "json"),
        (" XML ", "xml"),
        (" SrX\t", "xml"),
        (" SPARQL-XML ", "xml"),
        (" Application/SPARQL-Results+XML ", "xml"),
        (" CSV ", "csv"),
        (" TEXT/CSV ", "csv"),
        (" TSV ", "tsv"),
        (" TEXT/TAB-SEPARATED-VALUES ", "tsv"),
    ],
)
def test_compat_results_aliases_match_native_formats(
    compat: ModuleType, alias: str, canonical: str
) -> None:
    result = _select(compat)
    encoded = result.serialize(format=alias, encoding="utf-8")
    assert encoded == _select(compat).serialize(format=canonical, encoding="utf-8")
    if canonical in ("json", "xml"):
        parsed = compat.Result.parse(io.BytesIO(encoded), format=alias)
        assert [tuple(str(term) for term in row) for row in parsed] == [
            tuple(str(term) for term in row) for row in _select(compat)
        ]
        ask = _ask(compat).serialize(format=alias, encoding="utf-8")
        assert ask == _ask(compat).serialize(format=canonical, encoding="utf-8")
        assert compat.Result.parse(io.BytesIO(ask), content_type=alias).askAnswer is True
