# SPDX-FileCopyrightText: 2026 Blackcat Informatics® Inc. <paudley@blackcatinformatics.ca>
# SPDX-License-Identifier: MIT OR Apache-2.0 OR MulanPSL-2.0

"""The Python surface's DOCUMENT BASE contract.

The Rust, WebAssembly, and C surfaces all carry a document base on both their parse
and their serialize entry points. These tests pin that the Python one does too, and
that it behaves identically: the base resolves relative references on ingress, is
written and relativized against on egress by the syntaxes that can express one, and
is never fabricated when absent.
"""

from __future__ import annotations

import pytest

import purrdf
from purrdf import RdfFormat

#: A Turtle document whose subject is a relative reference and which declares no
#: `@base` of its own, so the caller's base is the only one that can be in scope.
RELATIVE_TURTLE = "<rel> <https://example.org/p> <https://example.org/o> .\n"

BASE = "https://example.org/base/"

#: The shared `purrdf-iri` diagnostic code for "a relative reference with no base in
#: scope". One identity for every surface — never a per-binding respelling.
NO_BASE_CODE = "iri-relative-no-base"


# ── parse: the ingress base ─────────────────────────────────────────────────────


def test_parse_resolves_a_relative_iri_against_the_supplied_base() -> None:
    quads = purrdf.parse(RELATIVE_TURTLE, RdfFormat.TURTLE, base=BASE)
    assert len(quads) == 1
    assert str(quads[0].subject) == f"<{BASE}rel>"


def test_parse_without_a_base_hard_fails_with_the_shared_code() -> None:
    with pytest.raises(ValueError) as excinfo:
        purrdf.parse(RELATIVE_TURTLE, RdfFormat.TURTLE)
    # No base is invented from a retrieval IRI or the filesystem; the relative
    # reference is refused, and the message carries the shared diagnostic code.
    assert NO_BASE_CODE in str(excinfo.value)


def test_parse_rejects_a_base_that_is_not_absolute() -> None:
    with pytest.raises(ValueError):
        purrdf.parse(RELATIVE_TURTLE, RdfFormat.TURTLE, base="not-absolute/")


def test_an_in_document_base_wins_over_the_supplied_one() -> None:
    doc = (
        "@base <https://example.org/inner/> .\n"
        "<rel> <https://example.org/p> <https://example.org/o> .\n"
    )
    quads = purrdf.parse(doc, RdfFormat.TURTLE, base=BASE)
    assert str(quads[0].subject) == "<https://example.org/inner/rel>"


def test_parse_without_a_base_still_accepts_absolute_documents() -> None:
    # The base is optional, not required: a document with only absolute IRIs needs
    # none and must keep parsing exactly as before.
    doc = "<https://example.org/s> <https://example.org/p> <https://example.org/o> .\n"
    assert len(purrdf.parse(doc, RdfFormat.N_TRIPLES)) == 1


# ── serialize: the egress base ──────────────────────────────────────────────────


def _constructed_triples(base: str | None = None) -> purrdf.QueryTriples:
    """A `QueryTriples` over one triple whose IRIs sit under `BASE`."""
    store = purrdf.Store()
    store.load(
        f"<{BASE}s> <{BASE}p> <{BASE}o> .\n",
        RdfFormat.N_TRIPLES,
        base=base,
    )
    return store.query("CONSTRUCT { ?s ?p ?o } WHERE { ?s ?p ?o }")


def test_serialize_emits_the_base_declaration_for_a_base_capable_format() -> None:
    text = purrdf.serialize(
        _constructed_triples(), format=RdfFormat.TURTLE, base=BASE
    ).decode()
    assert f"@base <{BASE}> ." in text


def test_serialize_relativizes_against_the_base() -> None:
    text = purrdf.serialize(
        _constructed_triples(), format=RdfFormat.TURTLE, base=BASE
    ).decode()
    # The subject is spelled relative to the declared base, not absolutely.
    assert f"<{BASE}s>" not in text
    assert "<s>" in text


def test_serialize_to_a_base_incapable_format_stays_absolute_without_erroring() -> None:
    # N-Triples cannot express a base. The parameter is still read and validated;
    # the answer is the only spelling that grammar admits.
    text = purrdf.serialize(
        _constructed_triples(), format=RdfFormat.N_TRIPLES, base=BASE
    ).decode()
    assert f"<{BASE}s>" in text
    assert "@base" not in text


def test_serialize_rejects_a_base_that_is_not_absolute() -> None:
    with pytest.raises(ValueError):
        purrdf.serialize(
            _constructed_triples(), format=RdfFormat.TURTLE, base="not-absolute/"
        )


def test_serialize_without_a_base_is_unchanged() -> None:
    text = purrdf.serialize(_constructed_triples(), format=RdfFormat.TURTLE).decode()
    assert "@base" not in text
    assert f"<{BASE}s>" in text


def test_query_triples_serialize_carries_the_same_base() -> None:
    # The method on `QueryTriples` and the module-level function share one core, so
    # they must agree byte-for-byte under the same base.
    triples = _constructed_triples()
    direct = triples.serialize(RdfFormat.TURTLE, base=BASE)
    assert direct == purrdf.serialize(
        _constructed_triples(), format=RdfFormat.TURTLE, base=BASE
    )
    assert f"@base <{BASE}> .".encode() in direct


# ── the base reaches the other Python parse surfaces ────────────────────────────


def test_rdf_dataset_constructor_takes_the_base() -> None:
    dataset = purrdf.RdfDataset(RELATIVE_TURTLE, RdfFormat.TURTLE, base=BASE)
    assert dataset.quad_count() == 1
    assert f"<{BASE}rel>" in dataset.to_nquads()

    with pytest.raises(ValueError) as excinfo:
        purrdf.RdfDataset(RELATIVE_TURTLE, RdfFormat.TURTLE)
    assert NO_BASE_CODE in str(excinfo.value)


def test_store_load_and_module_parse_agree_on_the_base() -> None:
    store = purrdf.Store()
    store.load(RELATIVE_TURTLE, RdfFormat.TURTLE, base=BASE)
    loaded = {str(q.subject) for q in store}
    assert loaded == {f"<{BASE}rel>"}


def test_to_json_ld_carries_the_base_on_both_legs() -> None:
    # Ingress: the relative subject resolves. Egress: JSON-LD can express a base, so
    # it reaches the emitted document.
    text = purrdf.to_json_ld(
        RELATIVE_TURTLE.encode(), format=RdfFormat.TURTLE, base=BASE
    )
    assert BASE in text


def test_from_json_ld_takes_a_base() -> None:
    # N-Quads is the output syntax and admits no base, so the emitted IRIs are
    # absolute — which is exactly why the ingress base matters here.
    jsonld = (
        '{"@id": "rel", "https://example.org/p": [{"@id": "https://example.org/o"}]}'
    )
    nquads = purrdf.from_json_ld(jsonld, base=BASE).decode()
    assert f"<{BASE}rel>" in nquads


def test_from_rdf_xml_takes_a_base() -> None:
    xml = (
        '<?xml version="1.0"?>'
        '<rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"'
        ' xmlns:ex="https://example.org/">'
        '<rdf:Description rdf:about="rel">'
        '<ex:p rdf:resource="https://example.org/o"/>'
        "</rdf:Description></rdf:RDF>"
    )
    nquads = purrdf.from_rdf_xml(xml, base=BASE).decode()
    assert f"<{BASE}rel>" in nquads


def test_gts_producer_entry_points_take_a_base() -> None:
    # A relative-IRI source has no other way to say what it is relative to, so the
    # producer surface must accept one; without it the parse is refused.
    data = RELATIVE_TURTLE.encode()
    assert purrdf.gts_from_quads(data, format=RdfFormat.TURTLE, base=BASE)
    assert purrdf.snapshot_content_id_native(
        data, format=RdfFormat.TURTLE, base=BASE
    ).startswith("blake3:")

    with pytest.raises(ValueError) as excinfo:
        purrdf.gts_from_quads(data, format=RdfFormat.TURTLE)
    assert NO_BASE_CODE in str(excinfo.value)


def test_the_base_is_the_same_parameter_across_parse_surfaces() -> None:
    # One base, one meaning: the module parse, the frozen dataset, and the store all
    # resolve the same document to the same subject IRI.
    expected = f"<{BASE}rel>"
    store = purrdf.Store()
    store.load(RELATIVE_TURTLE, RdfFormat.TURTLE, base=BASE)
    assert str(purrdf.parse(RELATIVE_TURTLE, RdfFormat.TURTLE, base=BASE)[0].subject) == (
        expected
    )
    assert expected in purrdf.RdfDataset(
        RELATIVE_TURTLE, RdfFormat.TURTLE, base=BASE
    ).to_nquads()
    assert {str(q.subject) for q in store} == {expected}


# ── dump: the egress mirror `load(base=...)` had no partner for ─────────────────
#
# Every test below pairs the base call with a NO-BASE CONTROL on the same data, so
# the observed `@base` / `xml:base` is attributable to the argument and not to
# something already in the fixture.

#: A store whose IRIs all sit under BASE, so relativizing against it is observable.
ABSOLUTE_NT = f"<{BASE}s> <{BASE}p> <{BASE}o> .\n"


def _store() -> purrdf.Store:
    store = purrdf.Store()
    store.load(ABSOLUTE_NT, RdfFormat.N_TRIPLES)
    return store


def test_store_dump_emits_the_base_declaration_with_a_no_base_control() -> None:
    with_base = _store().dump(format=RdfFormat.TURTLE, base=BASE).decode()
    without = _store().dump(format=RdfFormat.TURTLE).decode()

    assert f"@base <{BASE}> ." in with_base
    assert "@base" not in without, "the control must not already carry a base"
    # And the base is actually applied, not merely declared.
    assert "<s>" in with_base
    assert f"<{BASE}s>" in without


def _mutable() -> purrdf.MutableDataset:
    md = purrdf.MutableDataset()
    md.load(ABSOLUTE_NT, RdfFormat.N_TRIPLES)
    return md


def test_mutable_dataset_dump_emits_the_base_declaration_with_a_control() -> None:
    with_base = _mutable().dump(format=RdfFormat.TURTLE, base=BASE).decode()
    without = _mutable().dump(format=RdfFormat.TURTLE).decode()
    assert f"@base <{BASE}> ." in with_base
    assert "@base" not in without, "the control must not already carry a base"
    assert "<s>" in with_base
    assert f"<{BASE}s>" in without


def test_dump_to_a_base_incapable_format_stays_absolute() -> None:
    # N-Quads cannot express a base: the parameter is still read and validated, and
    # the answer is the only spelling that grammar admits.
    out = _store().dump(format=RdfFormat.N_QUADS, base=BASE).decode()
    assert f"<{BASE}s>" in out
    assert "@base" not in out


def test_dump_rejects_a_base_that_is_not_absolute() -> None:
    with pytest.raises(ValueError):
        _store().dump(format=RdfFormat.TURTLE, base="not-absolute/")


def test_dump_without_a_base_is_unchanged() -> None:
    # The parameter is additive: omitting it reproduces the previous bytes exactly.
    assert _store().dump(format=RdfFormat.TURTLE) == _store().dump(
        format=RdfFormat.TURTLE, base=None
    )


# The combination that had no entry point before: a document base TOGETHER WITH a
# non-default graph selection, over data carrying the RDF 1.2 statement layer.

#: A reifier binding plus its annotation, all under BASE, inside a named graph.
STAR_NQ = (
    f"<{BASE}s> <{BASE}p> <{BASE}o> <{BASE}g> .\n"
    f"<{BASE}r> <http://www.w3.org/1999/02/22-rdf-syntax-ns#reifies> "
    f"<<( <{BASE}s> <{BASE}p> <{BASE}o> )>> <{BASE}g> .\n"
    f"<{BASE}r> <{BASE}confidence> \"0.9\" <{BASE}g> .\n"
)


def _star_store() -> purrdf.Store:
    store = purrdf.Store()
    store.load(STAR_NQ, RdfFormat.N_QUADS)
    return store


def test_dump_applies_a_base_and_a_graph_selection_together() -> None:
    # `from_graph` projects one named graph into the default graph; the base is
    # applied to that projection. Neither axis cancels the other.
    selected = (
        _star_store()
        .dump(
            format=RdfFormat.TURTLE,
            from_graph=purrdf.NamedNode(f"{BASE}g"),
            base=BASE,
        )
        .decode()
    )
    control = (
        _star_store()
        .dump(format=RdfFormat.TURTLE, from_graph=purrdf.NamedNode(f"{BASE}g"))
        .decode()
    )

    assert f"@base <{BASE}> ." in selected
    assert "@base" not in control
    # The graph selection really happened: its quads are present, relativized.
    assert "<s>" in selected
    assert f"{BASE}s" in control


def test_dump_keeps_the_statement_layer_under_a_base_and_a_selection() -> None:
    # The RDF 1.2 statement layer must SURVIVE a based, graph-selected dump. This is
    # the combination that had no entry point, and the one that would regress
    # silently if someone later reached for a projecting spelling.
    dumped = (
        _star_store()
        .dump(format=RdfFormat.TRIG, base=BASE)
        .decode()
    )
    assert f"@base <{BASE}> ." in dumped
    assert "reifies" in dumped, f"the reifier binding must survive: {dumped}"
    assert "confidence" in dumped, f"the annotation must survive: {dumped}"

    # And it round-trips back to the same statement layer.
    back = purrdf.RdfDataset(dumped, RdfFormat.TRIG, base=BASE)
    assert "reifies" in back.to_nquads()
    assert "confidence" in back.to_nquads()


def test_mutable_dump_keeps_the_statement_layer_under_a_base() -> None:
    md = purrdf.MutableDataset()
    md.load(STAR_NQ, RdfFormat.N_QUADS)
    dumped = md.dump(format=RdfFormat.TRIG, base=BASE).decode()
    assert f"@base <{BASE}> ." in dumped
    assert "reifies" in dumped
    assert "confidence" in dumped


# ── to_rdf_xml: xml:base on the egress leg, statement layer intact ──────────────


def test_to_rdf_xml_emits_xml_base_with_a_no_base_control() -> None:
    with_base = purrdf.to_rdf_xml(
        ABSOLUTE_NT.encode(), format=RdfFormat.N_TRIPLES, base=BASE
    )
    without = purrdf.to_rdf_xml(ABSOLUTE_NT.encode(), format=RdfFormat.N_TRIPLES)

    assert f'xml:base="{BASE}"' in with_base
    assert "xml:base" not in without, "the control must not already carry a base"
    assert f'rdf:about="{BASE}s"' in without
    assert 'rdf:about="s"' in with_base


def test_to_rdf_xml_keeps_the_statement_layer_under_a_base() -> None:
    # RDF/XML renders a reifier binding as `rdf:parseType="Triple"`. Gaining the
    # `xml:base` must not cost those rows.
    star_nt = (
        f"<{BASE}r> <http://www.w3.org/1999/02/22-rdf-syntax-ns#reifies> "
        f"<<( <{BASE}s> <{BASE}p> <{BASE}o> )>> .\n"
        f"<{BASE}r> <{BASE}confidence> \"0.9\" .\n"
    )
    xml = purrdf.to_rdf_xml(star_nt.encode(), format=RdfFormat.N_TRIPLES, base=BASE)
    assert f'xml:base="{BASE}"' in xml
    assert "Triple" in xml, f"the reifier binding must survive: {xml}"
    assert "confidence" in xml, f"the annotation must survive: {xml}"


def test_to_rdf_xml_rejects_a_base_that_is_not_absolute() -> None:
    with pytest.raises(ValueError):
        purrdf.to_rdf_xml(
            ABSOLUTE_NT.encode(), format=RdfFormat.N_TRIPLES, base="not-absolute/"
        )


# ── programmatic ingress: no document, so no base can ever be in scope ──────────


def _abs(name: str) -> purrdf.NamedNode:
    return purrdf.NamedNode(f"https://example.org/{name}")


def _quad(subject, predicate, obj) -> purrdf.Quad:
    return purrdf.Quad(subject, predicate, obj)


def test_store_add_refuses_a_relative_iri_at_the_call() -> None:
    """The refusal must arrive at `add`, not at a later freeze.

    A document at least HAS a base to supply. A quad built from Python objects has
    no document and no base, and never will, so the relative IRI can only be a
    mistake. Reporting it here means the traceback names the offending `add`; a
    store may be mutated thousands of times before anything freezes it.
    """
    store = purrdf.Store()
    with pytest.raises(ValueError) as excinfo:
        store.add(_quad(purrdf.NamedNode("rel"), _abs("p"), _abs("o")))
    assert NO_BASE_CODE in str(excinfo.value)
    # The refused quad did not land, and the store is still usable.
    assert len(store) == 0
    store.add(_quad(_abs("s"), _abs("p"), _abs("o")))
    assert len(store) == 1


def test_store_add_checks_every_iri_position() -> None:
    store = purrdf.Store()
    cases = {
        "subject": _quad(purrdf.NamedNode("relSubject"), _abs("p"), _abs("o")),
        "predicate": _quad(_abs("s"), purrdf.NamedNode("relPredicate"), _abs("o")),
        "object": _quad(_abs("s"), _abs("p"), purrdf.NamedNode("relObject")),
        "datatype": _quad(
            _abs("s"),
            _abs("p"),
            purrdf.Literal("42", datatype=purrdf.NamedNode("relDatatype")),
        ),
    }
    for position, quad in cases.items():
        with pytest.raises(ValueError) as excinfo:
            store.add(quad)
        assert NO_BASE_CODE in str(excinfo.value), position
    assert len(store) == 0


def test_store_add_leaves_blank_labels_and_lexical_forms_alone() -> None:
    # Only IRIs are IRIs: a blank label or a literal's lexical form may be any
    # string at all, including one that looks like a relative reference.
    store = purrdf.Store()
    store.add(_quad(purrdf.BlankNode("notAbsolute"), _abs("p"), purrdf.Literal("../x")))
    assert len(store) == 1


def test_the_empty_iri_is_refused_before_it_can_reach_the_store() -> None:
    """`<>` never gets as far as `add`: `NamedNode` itself refuses it.

    The empty IRI is the same-document reference, so it is relative by definition
    and the store would refuse it too. But the term constructor is an even earlier
    boundary, and it already rejects the empty string on its own terms. Pinning
    that here records WHICH layer answers, so a later refactor cannot quietly move
    the check and leave `NamedNode("")` constructible.
    """
    with pytest.raises(ValueError) as excinfo:
        purrdf.NamedNode("")
    assert "must not be empty" in str(excinfo.value)


def test_dataset_add_refuses_a_relative_iri_like_store_add_does() -> None:
    """`Dataset` is not a `Store`, and that was the leak.

    `Store` interns into a term table, and the table is what enforces the
    absoluteness invariant. `Dataset` is a plain quad list with set semantics and no
    term table, so it inherited nothing: `Dataset().add(Quad(NamedNode("rel"), ...))`
    was accepted, and `Dataset.canonicalize` would then hash it and hand back a
    stable RDFC-1.0 label for a term whose identity is unknowable.

    "Nothing invalid escapes, because a Dataset has no serializer" is not the
    invariant the rest of the toolkit states. Unrepresentable from EVERY ingress is.
    """
    dataset = purrdf.Dataset()
    with pytest.raises(ValueError) as excinfo:
        dataset.add(_quad(purrdf.NamedNode("rel"), _abs("p"), _abs("o")))
    assert NO_BASE_CODE in str(excinfo.value)
    # The refused quad did not land, and the dataset is still usable.
    assert len(dataset) == 0
    dataset.add(_quad(_abs("s"), _abs("p"), _abs("o")))
    assert len(dataset) == 1


def test_dataset_checks_every_iri_position_and_the_constructor_too() -> None:
    good = _quad(_abs("s"), _abs("p"), _abs("o"))
    cases = {
        "subject": _quad(purrdf.NamedNode("relSubject"), _abs("p"), _abs("o")),
        "predicate": _quad(_abs("s"), purrdf.NamedNode("relPredicate"), _abs("o")),
        "object": _quad(_abs("s"), _abs("p"), purrdf.NamedNode("relObject")),
        "datatype": _quad(
            _abs("s"),
            _abs("p"),
            purrdf.Literal("42", datatype=purrdf.NamedNode("relDatatype")),
        ),
    }
    for position, quad in cases.items():
        # The seeding constructor is an ingress too, so it gets the same answer.
        with pytest.raises(ValueError) as excinfo:
            purrdf.Dataset([good, quad])
        assert NO_BASE_CODE in str(excinfo.value), position

        dataset = purrdf.Dataset()
        with pytest.raises(ValueError) as excinfo:
            dataset.add(quad)
        assert NO_BASE_CODE in str(excinfo.value), position
        assert len(dataset) == 0

    # The neighbouring VALID cases still pass. Only IRIs are IRIs: a blank label or a
    # literal lexical form may be any string, including one shaped like a reference.
    seeded = purrdf.Dataset([good])
    assert len(seeded) == 1
    seeded.add(_quad(purrdf.BlankNode("notAbsolute"), _abs("p"), purrdf.Literal("../x")))
    assert len(seeded) == 2
    seeded.canonicalize(purrdf.CanonicalizationAlgorithm.UNSTABLE)
    assert len(seeded) == 2
