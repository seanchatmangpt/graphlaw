# SPDX-FileCopyrightText: 2026 Blackcat Informatics® Inc. <paudley@blackcatinformatics.ca>
# SPDX-License-Identifier: MIT OR Apache-2.0 OR MulanPSL-2.0
"""Host-injected property functions on the native query/update surface.

A property function is a RELATION invoked from predicate position: unlike an
extension function it is a row source, so one call may emit zero, one, or many
rows. The Rust tier has carried the seam for a while; these tests hold the Python
surface to what makes it usable and safe from a host that writes Python:

* **A relation is DATA, not a callable.** ``relations`` carries tuples,
  ``relations_from_graph`` carries the head of an ``rdf:List`` of ``rdf:List``s
  written in the store's own default graph, and ``path_relations`` carries a
  TRAVERSAL SPECIFICATION over the store's own edges. Nothing the engine invokes can
  re-enter the interpreter, which is why the whole evaluation still runs with the GIL
  released — the path spelling keeps that property by declaring which edges a hop may
  follow rather than by calling back per hop.
* **A path relation binds the DERIVATION, not the endpoints.** ``?start <iri> ( ?end
  ?pathId ?len ?step ?node ?edge )`` emits one row per hop, and ``?edge`` is the
  traversed statement as a first-class RDF 1.2 term that joins straight back into the
  dataset. ``GROUP BY ?pathId`` with ``ORDER BY ?step`` reassembles a whole walk.
  Every field of the envelope is mandatory: there is no default ``min_hops``, no
  default ``max_hops``, and no default guard, because a zero-hop path has no witness
  and an unbounded depth is a stack-overflow abort.
* **Registration is per call.** A relation named on one call is not in scope on the
  next; the default (no keyword) is exactly the pre-existing evaluation.
* **A registered IRI is reachable EXACTLY**, with no namespace declaration.
  Declaring ``property_fn_namespaces`` asks for the stricter reading instead, in
  which an unregistered IRI under the namespace is a hard error rather than a
  triple pattern that quietly matches nothing.
* **A misconfiguration raises.** A duplicate IRI, a ragged table, a torn list, and
  a head naming nothing are all refused where they are supplied, carrying the
  kernel's own diagnostic text.
"""

from __future__ import annotations

from typing import Any

import pytest

import purrdf

EX = "http://example.org/"
REL = "http://example.org/rel/"

MEMBER_OF = f"{REL}memberOf"
TEAM_SITE = f"{REL}teamSite"
SEEDS = f"{REL}seeds"
DISPLAY_NAME = f"{REL}displayName"

SELECT_MEMBERS = f"SELECT ?person ?team WHERE {{ ?person <{MEMBER_OF}> ?team }}"

# The `rdf:List` of `rdf:List`s encoding `relations_from_graph` reads: one inner
# list per row, holding that row's values in flattened order. The head is an IRI
# rather than a blank node so a caller has a stable name to pass — its cell is
# spelled out and only the tail uses the collection shorthand.
MEMBER_TABLE_TTL = f"""
@prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> .
@prefix ex: <{EX}> .

ex:memberTable
    rdf:first ( ex:ada ex:alpha ) ;
    rdf:rest  ( ( ex:brian ex:alpha ) ( ex:chen ex:beta ) ) .
"""

TORN_TABLE_TTL = f"""
@prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> .
@prefix ex: <{EX}> .

ex:tornTable
    rdf:first ( ex:ada ex:alpha ) ;
    rdf:rest  ex:notACons .
"""

WIDE_TABLE_TTL = f"""
@prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> .
@prefix ex: <{EX}> .

ex:wideTable
    rdf:first ( ex:ada ex:alpha ex:extra ) ;
    rdf:rest  rdf:nil .
"""


def _node(local: str) -> purrdf.NamedNode:
    """An `example.org` IRI term."""
    return purrdf.NamedNode(f"{EX}{local}")


def _member_rows() -> list[list[purrdf.NamedNode]]:
    """The `memberOf` table: two members of one team, one of another."""
    return [
        [_node("ada"), _node("alpha")],
        [_node("brian"), _node("alpha")],
        [_node("chen"), _node("beta")],
    ]


def _member_relations() -> dict[str, Any]:
    """`memberOf` declared as a 1-subject / 1-object tuple relation."""
    return {MEMBER_OF: (1, 1, _member_rows())}


def _pairs(solutions: Any) -> list[tuple[str, str]]:
    """A two-column SELECT result as `(local, local)` pairs, in result order."""
    return [
        (str(row[0].value).removeprefix(EX), str(row[1].value).removeprefix(EX))
        for row in solutions
    ]


def _column(solutions: Any) -> list[str]:
    """A one-column SELECT result as local names, in result order."""
    return [str(row[0].value).removeprefix(EX) for row in solutions]


def _store_with(turtle: str) -> purrdf.Store:
    """A store holding `turtle` in its default graph."""
    store = purrdf.Store()
    store.load(turtle, purrdf.RdfFormat.TURTLE)
    return store


# ── tuple relations ───────────────────────────────────────────────────────────────


def test_a_tuple_relation_answers_a_query() -> None:
    """Rows obtainable ONLY from the relation: the store holds no such triple."""
    store = purrdf.Store()

    solutions = store.query(SELECT_MEMBERS, relations=_member_relations())

    assert _pairs(solutions) == [
        ("ada", "alpha"),
        ("brian", "alpha"),
        ("chen", "beta"),
    ]


def test_the_same_query_without_the_relation_answers_nothing() -> None:
    """Unregistered and undeclared, the call IRI is an ordinary triple pattern."""
    assert len(purrdf.Store().query(SELECT_MEMBERS)) == 0  # type: ignore[arg-type]


def test_a_relation_is_registered_for_one_call_only() -> None:
    """Registration is per call: the next query sees no relation at all."""
    store = purrdf.Store()

    assert len(store.query(SELECT_MEMBERS, relations=_member_relations())) == 3  # type: ignore[arg-type]
    assert len(store.query(SELECT_MEMBERS)) == 0  # type: ignore[arg-type]


def test_a_bound_subject_looks_the_object_side_up() -> None:
    """A `bf` call filters the table on the bound position."""
    store = purrdf.Store()

    solutions = store.query(
        f"SELECT ?team WHERE {{ <{EX}chen> <{MEMBER_OF}> ?team }}",
        relations=_member_relations(),
    )

    assert _column(solutions) == ["beta"]


def test_a_call_joins_against_the_stored_data() -> None:
    """The relation is a row source in a graph pattern, so it joins like any other."""
    store = _store_with(f"<{EX}ada> <{EX}status> <{EX}active> .")

    solutions = store.query(
        f"SELECT ?person ?team WHERE {{ ?person <{EX}status> <{EX}active> . "
        f"?person <{MEMBER_OF}> ?team }}",
        relations=_member_relations(),
    )

    assert _pairs(solutions) == [("ada", "alpha")]


def test_a_relation_may_have_several_object_positions() -> None:
    """A 1/2 relation binds two OUTPUT positions no triple pattern can bind at once."""
    store = purrdf.Store()

    solutions = store.query(
        f"SELECT ?city ?headcount WHERE {{ <{EX}alpha> <{TEAM_SITE}> ( ?city ?headcount ) }}",
        relations={
            TEAM_SITE: (
                1,
                2,
                [
                    [_node("alpha"), purrdf.Literal("Zurich"), purrdf.Literal("2")],
                    [_node("beta"), purrdf.Literal("Osaka"), purrdf.Literal("1")],
                ],
            )
        },
    )

    rows = [(str(row[0].value), str(row[1].value)) for row in solutions]  # type: ignore[union-attr]
    assert rows == [("Zurich", "2")]


def test_a_relation_may_have_an_empty_subject_side() -> None:
    """A 0/1 generator takes no input and enumerates its whole table."""
    store = purrdf.Store()

    solutions = store.query(
        f"SELECT ?team WHERE {{ () <{SEEDS}> ?team }}",
        relations={SEEDS: (0, 1, [[_node("alpha")], [_node("beta")]])},
    )

    assert _column(solutions) == ["alpha", "beta"]


def test_a_relation_cell_converts_exactly_as_a_substitution_value_does() -> None:
    """Literals reach the engine through the one Python→term converter."""
    store = purrdf.Store()

    solutions = store.query(
        f'SELECT ?name WHERE {{ <{EX}ada> <{DISPLAY_NAME}> ?name . FILTER(?name = "Ada") }}',
        relations={
            DISPLAY_NAME: (
                1,
                1,
                [
                    [_node("ada"), purrdf.Literal("Ada")],
                    [_node("brian"), purrdf.Literal("Brian", language="en")],
                ],
            )
        },
    )

    rows = [row[0] for row in solutions]  # type: ignore[union-attr]
    assert [term.value for term in rows] == ["Ada"]
    assert rows[0].datatype.value == "http://www.w3.org/2001/XMLSchema#string"


# ── relations read out of the store's own dataset ────────────────────────────────


def test_a_from_graph_relation_answers_a_query() -> None:
    """The table is data in the store's default graph, read through `from_graph`."""
    store = _store_with(MEMBER_TABLE_TTL)

    solutions = store.query(
        SELECT_MEMBERS,
        relations_from_graph={MEMBER_OF: (_node("memberTable"), 1, 1)},
    )

    assert _pairs(solutions) == [
        ("ada", "alpha"),
        ("brian", "alpha"),
        ("chen", "beta"),
    ]


def test_a_from_graph_relation_agrees_with_the_tuple_spelling() -> None:
    """Two spellings of one table, one answer."""
    from_graph = _store_with(MEMBER_TABLE_TTL).query(
        SELECT_MEMBERS,
        relations_from_graph={MEMBER_OF: (_node("memberTable"), 1, 1)},
    )
    tuples = purrdf.Store().query(SELECT_MEMBERS, relations=_member_relations())

    assert _pairs(from_graph) == _pairs(tuples)


def test_the_two_relation_keywords_compose() -> None:
    """One call may take some relations as data and some out of the dataset."""
    store = _store_with(MEMBER_TABLE_TTL)

    solutions = store.query(
        f"SELECT ?person ?team WHERE {{ ?person <{MEMBER_OF}> ?team . "
        f"() <{SEEDS}> ?team }}",
        relations={SEEDS: (0, 1, [[_node("beta")]])},
        relations_from_graph={MEMBER_OF: (_node("memberTable"), 1, 1)},
    )

    assert _pairs(solutions) == [("chen", "beta")]


# ── namespace declaration and the unregistered call ──────────────────────────────


def test_an_unregistered_iri_under_a_declared_namespace_is_a_hard_error() -> None:
    """The stricter reading: a call that resolves to nothing is refused, not empty."""
    store = purrdf.Store()

    with pytest.raises(ValueError, match="no property function is registered"):
        store.query(
            f"SELECT ?team WHERE {{ <{EX}ada> <{REL}notRegistered> ?team }}",
            property_fn_namespaces=[REL],
            relations=_member_relations(),
        )


def test_an_unregistered_iri_without_a_declared_namespace_is_a_triple_pattern() -> None:
    """Without the declaration only REGISTERED IRIs are calls, so nothing is hijacked."""
    store = _store_with(f"<{EX}ada> <{REL}notRegistered> <{EX}alpha> .")

    solutions = store.query(
        f"SELECT ?team WHERE {{ <{EX}ada> <{REL}notRegistered> ?team }}",
        relations=_member_relations(),
    )

    assert _column(solutions) == ["alpha"]


def test_a_registered_iri_needs_no_namespace_declaration() -> None:
    """Exact-IRI recognition is derived from the registry itself."""
    solutions = purrdf.Store().query(SELECT_MEMBERS, relations=_member_relations())

    assert len(solutions) == 3  # type: ignore[arg-type]


# ── the governed surface ─────────────────────────────────────────────────────────


def test_a_governed_query_over_a_relation_returns_rows_and_a_receipt() -> None:
    """A relation's rows are charged like every other row source."""
    outcome = purrdf.Store().query_governed(
        SELECT_MEMBERS, relations=_member_relations()
    )

    assert outcome.is_complete
    assert outcome.tripped is None
    assert _pairs(outcome.result) == _pairs(
        purrdf.Store().query(SELECT_MEMBERS, relations=_member_relations())
    )
    assert outcome.evidence.consumed["answer-rows"] == 3
    assert outcome.evidence.consumed["fuel"] > 0


def test_a_governed_query_over_a_relation_can_be_stopped_by_a_ceiling() -> None:
    """An answer cap one below the relation's row count trips, and is not raised."""
    outcome = purrdf.Store().query_governed(
        SELECT_MEMBERS, relations=_member_relations(), max_answers=2
    )

    assert not outcome.is_complete
    assert outcome.tripped is not None


def test_a_governed_query_over_a_from_graph_relation_returns_rows() -> None:
    """The dataset-read spelling reaches the governed entry too."""
    outcome = _store_with(MEMBER_TABLE_TTL).query_governed(
        SELECT_MEMBERS,
        relations_from_graph={MEMBER_OF: (_node("memberTable"), 1, 1)},
    )

    assert outcome.is_complete
    assert len(outcome.result) == 3  # type: ignore[arg-type]


# ── what a relation attested about the index behind it ───────────────────────────
#
# Two facts can change a query's answer while every input the engine can see stays
# identical: WHICH version of the host's index answered, and whether that index was
# WHOLE. Neither is in the rows, the query text or the dataset snapshot — only the host
# knows, so a relation declaration may carry one trailing `(generation, incompleteness)`
# attestation, and a governed outcome hands it back on `relation_witness`.
#
# The rule the tests below pin is "witnessed or fatal", and it is decided by the entry
# point's own return type rather than by any keyword: a lane whose outcome has a slot for
# the declaration REPORTS it beside the rows; a lane whose outcome has no such slot
# REFUSES, because a short bag offered as a complete answer is indistinguishable from the
# true complete answer.

#: The host's own name for the index version that produced the rows, verbatim.
INDEX_GENERATION = "members-index-7"

#: The host's own reason its index was not whole, verbatim — a shard name and a phase,
#: because that is what an operator can act on and `True` is not.
REBUILDING = "shard 3 of 4 is still rebuilding"

#: The diagnostic code the kernel raises on a lane with nowhere to carry the
#: declaration. Matched instead of the prose, which is free to be reworded.
INCOMPLETE_CODE = "native-sparql-relation-incomplete"


def _incomplete_relations() -> dict[str, Any]:
    """`memberOf`, attested as served from a named index that was NOT whole."""
    return {MEMBER_OF: (1, 1, _member_rows(), (INDEX_GENERATION, REBUILDING))}


def _whole_relations() -> dict[str, Any]:
    """The neighbour that must keep working: same table, same named index, nothing short.

    Identical to `_incomplete_relations()` except that the incompleteness half is `None`
    — which is silence, not a certificate that the index was whole.
    """
    return {MEMBER_OF: (1, 1, _member_rows(), (INDEX_GENERATION, None))}


def test_an_attested_incompleteness_is_refused_where_nothing_can_carry_it() -> None:
    """`query` and `update` have no witness slot, so they refuse rather than answer short.

    The refusal is the whole justification for the governed lane's witness: the engine
    will not hand back rows from an index the host has declared partial unless the
    outcome it hands them back in can say so.
    """
    store = purrdf.Store()

    with pytest.raises(ValueError, match=INCOMPLETE_CODE):
        store.query(SELECT_MEMBERS, relations=_incomplete_relations())

    with pytest.raises(ValueError, match=INCOMPLETE_CODE):
        store.update(
            f"INSERT {{ ?person <{EX}team> ?team }} WHERE {{ ?person <{MEMBER_OF}> ?team }}",
            relations=_incomplete_relations(),
        )

    # Nothing was applied on the way to the refusal: a partial mutation from a partial
    # index is the silent corruption both halves of this rule exist to prevent.
    assert len(store.query(f"SELECT ?p WHERE {{ ?p <{EX}team> ?t }}")) == 0  # type: ignore[arg-type]


def test_the_governed_lane_answers_and_hands_the_reason_back() -> None:
    """The same relation, on the lane that CAN label the bag: rows plus the reason.

    This is the pairing the refusal above points at. A host with a mid-rebuild index is
    neither refused on both lanes nor answered blind on one: it gets the rows, the
    generation that produced them, and the producer's own words for what was missing.
    """
    outcome = purrdf.Store().query_governed(
        SELECT_MEMBERS, relations=_incomplete_relations()
    )

    assert outcome.is_complete
    assert _pairs(outcome.result) == [
        ("ada", "alpha"),
        ("brian", "alpha"),
        ("chen", "beta"),
    ]
    assert outcome.relation_witness == {
        MEMBER_OF: {
            "invocations": 1,
            "generations": [INDEX_GENERATION],
            "incompleteness": [REBUILDING],
        }
    }


def test_a_relation_declaring_nothing_short_is_unaffected_on_both_lanes() -> None:
    """The valid neighbour, executed on BOTH lanes: a declared generation refuses nothing.

    A refusal is only evidence about the case it excludes if the neighbouring case is
    executed too. A relation that declares which index answered and declares no shortfall
    must answer on the ungoverned lane exactly as an undeclared one does, and its witness
    must carry an EMPTY `incompleteness` — present and empty, which is the true statement
    that nobody declared a shortfall, and never a claim that the index was whole.
    """
    expected = [("ada", "alpha"), ("brian", "alpha"), ("chen", "beta")]

    plain = purrdf.Store().query(SELECT_MEMBERS, relations=_whole_relations())
    assert _pairs(plain) == expected

    outcome = purrdf.Store().query_governed(
        SELECT_MEMBERS, relations=_whole_relations()
    )
    assert outcome.is_complete
    assert _pairs(outcome.result) == expected
    assert outcome.relation_witness == {
        MEMBER_OF: {
            "invocations": 1,
            "generations": [INDEX_GENERATION],
            "incompleteness": [],
        }
    }


def test_a_relation_that_declares_nothing_is_listed_as_having_said_nothing() -> None:
    """Ran-and-said-nothing and never-ran are different facts, and stay different.

    A relation declared without the trailing position — every relation every other test
    in this file declares — still appears in the witness, with its invocation count and a
    single `None` generation. `None` is an ABSENCE: it says those invocations declared no
    version, and a reader must not upgrade it to "the index was current".
    """
    outcome = purrdf.Store().query_governed(
        SELECT_MEMBERS, relations=_member_relations()
    )

    assert outcome.relation_witness == {
        MEMBER_OF: {"invocations": 1, "generations": [None], "incompleteness": []}
    }


def test_a_governed_query_invoking_no_relation_has_a_present_empty_witness() -> None:
    """An empty witness is a fact, and it is reported as one rather than as an absence.

    `{}` says no relation attested anything — here because the query invoked none. It is
    never `None`, never a missing attribute, and specifically NOT a claim that an index
    was whole: there is no seam at which wholeness can be certified at all.
    """
    outcome = purrdf.Store().query_governed("SELECT ?s WHERE { ?s ?p ?o }")

    assert outcome.relation_witness == {}


def test_the_witness_is_keyed_in_iri_order_whatever_order_it_was_declared_in() -> None:
    """Deterministic on every machine and every run, so a logged receipt is comparable.

    The kernel's record is ordered by IRI; a Python `dict` preserves insertion order, so
    writing the entries in the order they are read carries that across. Declared in
    reverse to prove the order is the VALUES' and not the caller's.
    """
    outcome = purrdf.Store().query_governed(
        f"SELECT ?person ?team WHERE {{ ?person <{MEMBER_OF}> ?team . "
        f"() <{SEEDS}> ?team }}",
        relations={
            SEEDS: (0, 1, [[_node("alpha")]], ("seeds-gen-1", None)),
            MEMBER_OF: (1, 1, _member_rows(), (INDEX_GENERATION, REBUILDING)),
        },
    )

    assert list(outcome.relation_witness) == sorted([MEMBER_OF, SEEDS])
    assert outcome.relation_witness[SEEDS]["generations"] == ["seeds-gen-1"]
    assert outcome.relation_witness[MEMBER_OF]["incompleteness"] == [REBUILDING]


def test_the_attestation_position_reaches_all_three_relation_kinds() -> None:
    """One trailing position, admitted on every spelling — and executed on each.

    "All three" is a completeness claim, so all three are driven: the table read out of
    the dataset and the traversal declaration are as likely to have come from a partial
    index as a table handed over as tuples, and a surface wired into one spelling only
    would satisfy a test that drove only that one.
    """
    graph_store = _store_with(MEMBER_TABLE_TTL)
    from_graph = graph_store.query_governed(
        SELECT_MEMBERS,
        relations_from_graph={
            MEMBER_OF: (_node("memberTable"), 1, 1, (INDEX_GENERATION, REBUILDING))
        },
    )
    assert len(from_graph.result) == 3  # type: ignore[arg-type]
    assert from_graph.relation_witness[MEMBER_OF]["incompleteness"] == [REBUILDING]
    assert from_graph.relation_witness[MEMBER_OF]["generations"] == [INDEX_GENERATION]

    chain_store = _store_with(CHAIN_TTL)
    walked = chain_store.query_governed(
        WALK_QUERY,
        path_relations={
            WALK: (
                [(_node("p"), "forward")],
                1,
                4,
                1024,
                100_000,
                "walk",
                (INDEX_GENERATION, REBUILDING),
            )
        },
    )
    assert len(walked.result) == 6  # type: ignore[arg-type]
    assert walked.relation_witness[WALK]["incompleteness"] == [REBUILDING]

    # And both refuse on the lane that cannot carry the declaration, for the same reason
    # the tuple spelling does.
    with pytest.raises(ValueError, match=INCOMPLETE_CODE):
        graph_store.query(
            SELECT_MEMBERS,
            relations_from_graph={
                MEMBER_OF: (_node("memberTable"), 1, 1, (INDEX_GENERATION, REBUILDING))
            },
        )


def test_an_attestation_member_of_the_wrong_type_names_the_field() -> None:
    """Both halves are recorded verbatim, so both must be a `str` or `None`."""
    with pytest.raises(TypeError, match="`incompleteness` must be a str or None"):
        purrdf.Store().query(
            SELECT_MEMBERS,
            relations={MEMBER_OF: (1, 1, _member_rows(), (INDEX_GENERATION, 7))},
        )

    with pytest.raises(TypeError, match="`generation` must be a str or None"):
        purrdf.Store().query(
            SELECT_MEMBERS,
            relations={MEMBER_OF: (1, 1, _member_rows(), (7, REBUILDING))},
        )


def test_a_two_character_string_is_not_an_attestation() -> None:
    """A `str` is a sequence of its own characters, and that must not be read as one.

    `"ab"` extracts as a perfectly well-formed two-member sequence, so accepting any
    two-member sequence would have read a stray trailing string as `generation="a"`,
    `incompleteness="b"` — a misconfiguration accepted in silence and then reported back
    on the receipt as though the host had said it. It is refused as a shape error, exactly
    as any other value in a position this kind does not have.
    """
    with pytest.raises(TypeError, match="must be declared as"):
        purrdf.Store().query(
            SELECT_MEMBERS,
            relations={MEMBER_OF: (1, 1, _member_rows(), "ab")},
        )


def test_an_attestation_of_two_nones_is_silence_and_changes_nothing() -> None:
    """Declaring the position without declaring anything in it attests nothing.

    The witness entry is identical to the one a relation declared with NO trailing
    position gets, which is what makes `None` genuinely silence rather than a third
    declaration with a meaning of its own.
    """
    outcome = purrdf.Store().query_governed(
        SELECT_MEMBERS,
        relations={MEMBER_OF: (1, 1, _member_rows(), (None, None))},
    )

    assert _pairs(outcome.result) == [
        ("ada", "alpha"),
        ("brian", "alpha"),
        ("chen", "beta"),
    ]
    assert (
        outcome.relation_witness
        == purrdf.Store()
        .query_governed(SELECT_MEMBERS, relations=_member_relations())
        .relation_witness
    )


def test_a_tripped_governor_still_reports_what_the_relations_attested() -> None:
    """The witness rides BOTH governed paths, because both need it.

    A truncated execution's relations attested exactly as much as a complete one's did,
    and a caller deciding whether to retry with a larger budget has to know whether the
    rows already in hand came from an index that declared itself short — otherwise raising
    the ceiling just buys more rows from the same partial index.
    """
    outcome = purrdf.Store().query_governed(
        SELECT_MEMBERS, relations=_incomplete_relations(), max_answers=1
    )

    assert not outcome.is_complete
    assert outcome.tripped is not None
    assert outcome.result is None
    assert outcome.relation_witness == {
        MEMBER_OF: {
            "invocations": 1,
            "generations": [INDEX_GENERATION],
            "incompleteness": [REBUILDING],
        }
    }


def test_the_entailment_lane_carries_the_witness_through() -> None:
    """The regime-aware governed lane is a governed lane, so it reports the same receipt.

    Its outcome nests an ordinary `QueryOutcome`, and a relation registered for a closure
    query is as likely to have come from a partial index as one registered for a plain
    query. A witness reachable on one governed entry and not the other would make the
    refusal on the ungoverned lane a dead end for exactly the callers who use this one.
    """
    entailed = purrdf.Store().query_entailment_governed(
        SELECT_MEMBERS, "rdfs", relations=_incomplete_relations()
    )

    assert entailed.phase == "answered"
    assert entailed.outcome is not None
    assert entailed.outcome.relation_witness[MEMBER_OF]["incompleteness"] == [REBUILDING]


def test_mutable_dataset_carries_the_attestation_surface_too() -> None:
    """The compat shim's store must not be the weaker one here either: both lanes."""
    dataset = purrdf.MutableDataset()

    with pytest.raises(ValueError, match=INCOMPLETE_CODE):
        dataset.query(SELECT_MEMBERS, relations=_incomplete_relations())

    outcome = dataset.query_governed(
        SELECT_MEMBERS, relations=_incomplete_relations()
    )
    assert outcome.relation_witness[MEMBER_OF]["incompleteness"] == [REBUILDING]


# ── UPDATE ───────────────────────────────────────────────────────────────────────


def test_an_update_where_over_a_relation_inserts_its_rows() -> None:
    """An UPDATE's WHERE is a triple-pattern context exactly as a query's is."""
    store = purrdf.Store()

    store.update(
        f"INSERT {{ ?person <{EX}team> ?team }} WHERE {{ ?person <{MEMBER_OF}> ?team }}",
        relations=_member_relations(),
    )

    solutions = store.query(
        f"SELECT ?person ?team WHERE {{ ?person <{EX}team> ?team }} ORDER BY ?person"
    )
    assert _pairs(solutions) == [
        ("ada", "alpha"),
        ("brian", "alpha"),
        ("chen", "beta"),
    ]


def test_a_governed_update_over_a_relation_applies_and_reports() -> None:
    """The governed UPDATE entry carries the registry and reports it applied."""
    store = purrdf.Store()

    outcome = store.update_governed(
        f"INSERT {{ ?person <{EX}team> ?team }} WHERE {{ ?person <{MEMBER_OF}> ?team }}",
        relations=_member_relations(),
    )

    assert outcome.is_applied
    assert len(store.query(f"SELECT ?p WHERE {{ ?p <{EX}team> ?t }}")) == 3  # type: ignore[arg-type]


def test_an_update_reads_its_from_graph_table_from_the_pre_update_state() -> None:
    """The table and the WHERE clause see one and the same snapshot."""
    store = _store_with(MEMBER_TABLE_TTL)

    store.update(
        f"INSERT {{ ?person <{EX}team> ?team }} WHERE {{ ?person <{MEMBER_OF}> ?team }}",
        relations_from_graph={MEMBER_OF: (_node("memberTable"), 1, 1)},
    )

    assert len(store.query(f"SELECT ?p WHERE {{ ?p <{EX}team> ?t }}")) == 3  # type: ignore[arg-type]


# ── misconfiguration is refused where it is supplied ─────────────────────────────


def test_a_ragged_tuple_table_is_refused() -> None:
    """A row narrower than the declared arity is a host configuration error."""
    with pytest.raises(ValueError, match="requires 2"):
        purrdf.Store().query(
            SELECT_MEMBERS,
            relations={MEMBER_OF: (1, 1, [[_node("ada")]])},
        )


def test_a_torn_list_is_refused() -> None:
    """An `rdf:rest` pointing at a non-cell is not a table, and says so."""
    store = _store_with(TORN_TABLE_TTL)

    with pytest.raises(ValueError, match="not an rdf:List"):
        store.query(
            SELECT_MEMBERS,
            relations_from_graph={MEMBER_OF: (_node("tornTable"), 1, 1)},
        )


def test_a_from_graph_row_of_the_wrong_width_is_refused() -> None:
    """The arity check applies to the dataset-read spelling identically."""
    store = _store_with(WIDE_TABLE_TTL)

    with pytest.raises(ValueError, match="requires 2"):
        store.query(
            SELECT_MEMBERS,
            relations_from_graph={MEMBER_OF: (_node("wideTable"), 1, 1)},
        )


def test_a_head_that_names_nothing_is_refused() -> None:
    """A head absent from the dataset is configuration pointing at nothing."""
    with pytest.raises(ValueError, match="not present in the dataset"):
        purrdf.Store().query(
            SELECT_MEMBERS,
            relations_from_graph={MEMBER_OF: (_node("noSuchTable"), 1, 1)},
        )


def test_one_iri_declared_twice_is_refused() -> None:
    """A shadowed relation is a wrong-answer channel no query text can reveal."""
    store = _store_with(MEMBER_TABLE_TTL)

    with pytest.raises(ValueError, match="declared twice"):
        store.query(
            SELECT_MEMBERS,
            relations=_member_relations(),
            relations_from_graph={MEMBER_OF: (_node("memberTable"), 1, 1)},
        )


@pytest.mark.parametrize(
    "declaration",
    [
        (1, 1),
        (1, 1, [[_node("ada"), _node("alpha")]], "extra"),
        "not-a-tuple",
    ],
)
def test_a_malformed_declaration_is_a_type_error(declaration: object) -> None:
    """The expected shape is named in the error, not left to an anonymous failure."""
    with pytest.raises(TypeError, match="must be declared as"):
        purrdf.Store().query(SELECT_MEMBERS, relations={MEMBER_OF: declaration})


def test_a_non_term_cell_is_a_type_error() -> None:
    """A row cell goes through the same extractor a substitution value does."""
    with pytest.raises(TypeError, match="expected an RDF term"):
        purrdf.Store().query(
            SELECT_MEMBERS,
            relations={MEMBER_OF: (1, 1, [["ada", "alpha"]])},
        )


def test_a_negative_arity_is_a_type_error() -> None:
    """An arity is a count, so it is read as a non-negative integer."""
    with pytest.raises(TypeError, match="non-negative integer"):
        purrdf.Store().query(
            SELECT_MEMBERS,
            relations={MEMBER_OF: (-1, 1, [])},
        )


def test_a_non_string_relation_key_is_a_type_error() -> None:
    """A relation is keyed by the IRI a query spells in predicate position."""
    with pytest.raises(TypeError, match="must be IRI strings"):
        purrdf.Store().query(
            SELECT_MEMBERS,
            relations={_node("memberOf"): (1, 1, [])},
        )


def test_the_relation_keywords_are_keyword_only() -> None:
    """Every engine-configuration argument is named at the call site."""
    with pytest.raises(TypeError):
        purrdf.Store().query(SELECT_MEMBERS, _member_relations())  # type: ignore[misc]


# ── the same surface on MutableDataset ───────────────────────────────────────────


def test_mutable_dataset_carries_the_same_relation_surface() -> None:
    """`MutableDataset` is the compat shim's store; it must not be the weaker one."""
    dataset = purrdf.MutableDataset()

    solutions = dataset.query(SELECT_MEMBERS, relations=_member_relations())

    assert _pairs(solutions) == _pairs(
        purrdf.Store().query(SELECT_MEMBERS, relations=_member_relations())
    )


def test_mutable_dataset_update_over_a_relation_inserts_its_rows() -> None:
    """The UPDATE lane matches too, including the governed sibling's registry."""
    dataset = purrdf.MutableDataset()

    dataset.update(
        f"INSERT {{ ?person <{EX}team> ?team }} WHERE {{ ?person <{MEMBER_OF}> ?team }}",
        relations=_member_relations(),
    )

    assert len(dataset.query(f"SELECT ?p WHERE {{ ?p <{EX}team> ?t }}")) == 3  # type: ignore[arg-type]


def test_mutable_dataset_refuses_a_declared_unregistered_call() -> None:
    """The namespace declaration reaches the same parser options on both surfaces."""
    with pytest.raises(ValueError, match="no property function is registered"):
        purrdf.MutableDataset().query(
            f"SELECT ?team WHERE {{ <{EX}ada> <{REL}notRegistered> ?team }}",
            property_fn_namespaces=[REL],
        )


# ── path-witness relations ───────────────────────────────────────────────────────
#
# The third relation kind, and the one that is not a table: it declares a TRAVERSAL and
# the relation binds the walks it finds — every hop, in order, with the traversed
# statement as a first-class RDF 1.2 term.

WALK = f"{REL}walk"

#: `ex:a -> ex:b -> ex:c -> ex:d`, one predicate.
CHAIN_TTL = f"""
@prefix ex: <{EX}> .

ex:a ex:p ex:b .
ex:b ex:p ex:c .
ex:c ex:p ex:d .
"""

#: `ex:a -> {{ex:b, ex:c}} -> ex:d`: two distinct two-hop derivations reach `ex:d`,
#: which is exactly where "walk" and "shortest" must disagree.
DIAMOND_TTL = f"""
@prefix ex: <{EX}> .

ex:a ex:p ex:b .
ex:a ex:p ex:c .
ex:b ex:p ex:d .
ex:c ex:p ex:d .
"""

#: A call seeded at `ex:a`, projecting the four columns whose values are exactly
#: pinnable (`?pathId` is a content digest, asserted structurally instead).
WALK_QUERY = (
    f"SELECT ?end ?len ?step ?node WHERE {{ <{EX}a> <{WALK}> "
    "( ?end ?pathId ?len ?step ?node ?edge ) } ORDER BY ?len ?step"
)


def _walk_relation(mode: str = "walk") -> dict[str, Any]:
    """One `ex:p`-forward step, with every envelope field stated explicitly."""
    return {WALK: ([(_node("p"), "forward")], 1, 4, 1024, 100_000, mode)}


def _walk_rows(solutions: Any) -> list[tuple[str, int, int, str]]:
    """`(end, len, step, node)` per row, with the two counts as Python ints."""
    return [
        (
            str(row[0].value).removeprefix(EX),
            int(row[1].value),
            int(row[2].value),
            str(row[3].value).removeprefix(EX),
        )
        for row in solutions
    ]


def test_a_path_relation_binds_every_hop_of_a_multi_hop_chain() -> None:
    """One row per hop of every simple-prefix walk out of `ex:a`, in (len, step) order.

    Three walks leave `ex:a` (`->b`, `->b->c`, `->b->c->d`), so `1 + 2 + 3 = 6` rows.
    `?step` and `?len` are `xsd:integer` literals — read back as Python ints here —
    precisely so `ORDER BY ?step` orders numerically rather than by codepoint.
    """
    store = _store_with(CHAIN_TTL)

    solutions = store.query(WALK_QUERY, path_relations=_walk_relation())

    assert _walk_rows(solutions) == [
        ("b", 1, 1, "b"),
        ("c", 2, 1, "b"),
        ("c", 2, 2, "c"),
        ("d", 3, 1, "b"),
        ("d", 3, 2, "c"),
        ("d", 3, 3, "d"),
    ]


def test_an_inverse_step_traverses_the_same_statements_backwards() -> None:
    """`"inverse"` is the other half of the accepted direction set, executed.

    `test_a_malformed_path_relation_is_refused_by_name` proves `"sideways"` is refused,
    and every other test here spells `"forward"` — so until this test existed, writing
    ``"inverse" => PathDirection::Forward`` in the binding's match arm passed the entire
    Python suite. A refusal is only evidence about the set it excludes if the set it
    ADMITS is executed too, and half of that set was not.

    The same chain, read the other way: seeded at `ex:d`, an inverse `ex:p` step walks
    `d -> c -> b -> a`. The rows are the mirror of the forward test's, which is what
    makes this a direction assertion rather than merely a non-empty one — a step that
    quietly ran forwards from `ex:d` would answer nothing at all.
    """
    store = _store_with(CHAIN_TTL)

    solutions = store.query(
        f"SELECT ?end ?len ?step ?node WHERE {{ <{EX}d> <{WALK}> "
        "( ?end ?pathId ?len ?step ?node ?edge ) } ORDER BY ?len ?step",
        path_relations={WALK: ([(_node("p"), "inverse")], 1, 4, 1024, 100_000, "walk")},
    )

    assert _walk_rows(solutions) == [
        ("c", 1, 1, "c"),
        ("b", 2, 1, "c"),
        ("b", 2, 2, "b"),
        ("a", 3, 1, "c"),
        ("a", 3, 2, "b"),
        ("a", 3, 3, "a"),
    ]


def test_a_forward_step_from_the_far_end_of_the_chain_answers_nothing() -> None:
    """The control for the test above: same seed, same data, direction flipped.

    `ex:d` has no outgoing `ex:p`, so the forward reading answers nothing. Without this
    row the inverse test could be satisfied by a step that ignored the direction and
    happened to enumerate the chain some other way; with it, the two spellings are shown
    to produce genuinely different answers from the same seed.
    """
    store = _store_with(CHAIN_TTL)

    solutions = store.query(
        f"SELECT ?end ?len ?step ?node WHERE {{ <{EX}d> <{WALK}> "
        "( ?end ?pathId ?len ?step ?node ?edge ) } ORDER BY ?len ?step",
        path_relations=_walk_relation(),
    )

    assert _walk_rows(solutions) == []


def test_the_step_and_len_columns_are_xsd_integer_literals() -> None:
    """Typed, never simple: a simple literal would sort `"10"` before `"2"`."""
    store = _store_with(CHAIN_TTL)

    solutions = store.query(WALK_QUERY, path_relations=_walk_relation())
    row = next(iter(solutions))  # type: ignore[call-overload]

    assert row[1].datatype.value == "http://www.w3.org/2001/XMLSchema#integer"
    assert row[2].datatype.value == "http://www.w3.org/2001/XMLSchema#integer"


def test_path_id_groups_the_hops_of_one_walk() -> None:
    """`?pathId` is constant across one walk's rows and distinct between walks.

    That is what makes `GROUP BY ?pathId` the reassembly operator: each group IS one
    walk, so concatenating `?node` in `?step` order recovers the whole route.
    """
    store = _store_with(CHAIN_TTL)

    solutions = store.query(
        f"SELECT ?len (GROUP_CONCAT(?node; separator=\"->\") AS ?route) WHERE {{ "
        f"<{EX}a> <{WALK}> ( ?end ?pathId ?len ?step ?node ?edge ) }} "
        "GROUP BY ?pathId ?len ORDER BY ?len",
        path_relations=_walk_relation(),
    )

    routes = [(int(row[0].value), str(row[1].value)) for row in solutions]  # type: ignore[union-attr]
    assert routes == [
        (1, f"{EX}b"),
        (2, f"{EX}b->{EX}c"),
        (3, f"{EX}b->{EX}c->{EX}d"),
    ]

    # And the identifiers themselves: three walks, three distinct grouping keys, each
    # shared by exactly that walk's hop rows.
    hops = store.query(
        f"SELECT ?pathId ?len WHERE {{ <{EX}a> <{WALK}> "
        "( ?end ?pathId ?len ?step ?node ?edge ) }",
        path_relations=_walk_relation(),
    )
    by_id: dict[str, set[int]] = {}
    for row in hops:  # type: ignore[union-attr]
        by_id.setdefault(str(row[0].value), set()).add(int(row[1].value))
    assert len(by_id) == 3, "one identifier per walk"
    assert all(len(lengths) == 1 for lengths in by_id.values()), (
        "each identifier's rows belong to a single walk length"
    )


def test_two_equal_length_walks_do_not_share_an_identifier() -> None:
    """Distinctness, on the fixture where length cannot stand in for identity.

    `test_path_id_groups_the_hops_of_one_walk` runs on the chain, which has exactly one
    walk per length — so "every identifier's rows agree on `?len`" is satisfied there by
    an implementation that keyed `?pathId` on the LENGTH alone, and the chain can never
    tell the two apart. That is a property of the fixture, not evidence about `?pathId`.

    The diamond is the discriminating case: `a->b->d` and `a->c->d` are two distinct
    walks of the same length to the same endpoint. Grouping must keep them apart, so
    there are four identifiers (`->b`, `->c`, `->b->d`, `->c->d`) and the two two-hop
    routes are both recovered. A length-keyed identifier would fuse the last two into one
    group and lose a derivation silently — which is the whole failure this column exists
    to prevent.
    """
    store = _store_with(DIAMOND_TTL)

    solutions = store.query(
        f"SELECT (GROUP_CONCAT(?node; separator=\"->\") AS ?route) WHERE {{ "
        f"<{EX}a> <{WALK}> ( ?end ?pathId ?len ?step ?node ?edge ) }} "
        "GROUP BY ?pathId ORDER BY ?route",
        path_relations=_walk_relation(),
    )

    routes = sorted(str(row[0].value).replace(EX, "") for row in solutions)  # type: ignore[union-attr]
    assert routes == ["b", "b->d", "c", "c->d"], (
        "four walks, four groups: the two equal-length routes to ex:d stay apart"
    )


def test_shortest_mode_yields_one_witness_per_reachable_pair_on_a_diamond() -> None:
    """`"shortest"` keeps one two-hop derivation of `ex:d`; `"walk"` keeps both.

    Two relation TYPES rather than one with a runtime flag, because the planner reads
    cardinality off the registration: "exponential" and "polynomial" cannot be a
    property of a value it cannot see.
    """
    store = _store_with(DIAMOND_TTL)
    query = (
        f"SELECT ?end ?len ?step ?node WHERE {{ <{EX}a> <{WALK}> "
        "( ?end ?pathId ?len ?step ?node ?edge ) } ORDER BY ?end ?len ?step"
    )

    shortest = store.query(query, path_relations=_walk_relation("shortest"))
    assert _walk_rows(shortest) == [
        ("b", 1, 1, "b"),
        ("c", 1, 1, "c"),
        ("d", 2, 1, "b"),
        ("d", 2, 2, "d"),
    ]

    walk = store.query(query, path_relations=_walk_relation("walk"))
    assert _walk_rows(walk) == [
        ("b", 1, 1, "b"),
        ("c", 1, 1, "c"),
        ("d", 2, 1, "b"),
        ("d", 2, 1, "c"),
        ("d", 2, 2, "d"),
        ("d", 2, 2, "d"),
    ]


def test_the_edge_column_is_an_rdf_12_statement_term_that_joins_back() -> None:
    """`?edge` is a triple TERM, and the dataset is where it came from.

    RDF 1.2 first-classness is a project invariant, so it is pinned from Python and not
    only from Rust: the binding is a `purrdf.Triple`, its parts are the ASSERTED
    subject/predicate/object, and re-binding those three in an ordinary basic graph
    pattern finds the very statement the hop traversed.
    """
    store = _store_with(CHAIN_TTL)

    solutions = store.query(
        f"SELECT ?edge WHERE {{ <{EX}a> <{WALK}> "
        "( ?end ?pathId ?len ?step ?node ?edge ) FILTER(?len = 1) }",
        path_relations=_walk_relation(),
    )
    edges = [row[0] for row in solutions]  # type: ignore[union-attr]

    assert len(edges) == 1
    edge = edges[0]
    assert isinstance(edge, purrdf.Triple), "a hop is a statement term, not a label"
    assert edge.subject == _node("a")
    assert edge.predicate == _node("p")
    assert edge.object == _node("b")

    # The join: the statement the relation handed back is a statement of the dataset.
    joined = store.query(
        f"SELECT ?o WHERE {{ <{EX}a> <{WALK}> ( ?end ?pathId ?len ?step ?node ?edge ) "
        "FILTER(?len = 1) . ?s ?p ?o . FILTER(?edge = TRIPLE(?s, ?p, ?o)) }",
        path_relations=_walk_relation(),
    )
    assert _column(joined) == ["b"], "the hop's statement joins back into the data"


def test_a_path_relation_is_registered_for_one_call_only() -> None:
    """Registration is per call, exactly as for the two table spellings."""
    store = _store_with(CHAIN_TTL)

    assert len(store.query(WALK_QUERY, path_relations=_walk_relation())) == 6  # type: ignore[arg-type]
    assert len(store.query(WALK_QUERY)) == 0  # type: ignore[arg-type]


def test_a_path_relation_reaches_the_governed_and_update_lanes() -> None:
    """Query and update are symmetric: the keyword exists on both, and works on both."""
    store = _store_with(CHAIN_TTL)

    outcome = store.query_governed(WALK_QUERY, path_relations=_walk_relation())
    assert outcome.is_complete
    assert outcome.evidence.consumed["answer-rows"] == 6

    store.update(
        f"INSERT {{ <{EX}a> <{EX}reaches> ?end }} WHERE {{ <{EX}a> <{WALK}> "
        "( ?end ?pathId ?len ?step ?node ?edge ) }",
        path_relations=_walk_relation("shortest"),
    )
    reached = store.query(
        f"SELECT ?end WHERE {{ <{EX}a> <{EX}reaches> ?end }} ORDER BY ?end"
    )
    assert _column(reached) == ["b", "c", "d"]


def test_mutable_dataset_carries_the_path_relation_surface_too() -> None:
    """The compat shim's store must not be the weaker one here either."""
    dataset = purrdf.MutableDataset()
    dataset.load(CHAIN_TTL, purrdf.RdfFormat.TURTLE)

    solutions = dataset.query(WALK_QUERY, path_relations=_walk_relation())

    assert _walk_rows(solutions) == _walk_rows(
        _store_with(CHAIN_TTL).query(WALK_QUERY, path_relations=_walk_relation())
    )


# ── path-relation misconfiguration is refused where it is supplied ───────────────


@pytest.mark.parametrize(
    ("declaration", "message"),
    [
        # An unknown direction string: never coerced to one of the two.
        (
            ([(_node("p"), "sideways")], 1, 4, 8, 64, "walk"),
            "unknown step direction",
        ),
        # An unknown mode string, likewise.
        (
            ([(_node("p"), "forward")], 1, 4, 8, 64, "cheapest"),
            "unknown mode",
        ),
        # An empty alternation: a step that traverses nothing defines no hop.
        (([], 1, 4, 8, 64, "walk"), "at least one"),
        # A repeated (predicate, direction) pair doubles every walk through the hop.
        (
            ([(_node("p"), "forward"), (_node("p"), "forward")], 1, 4, 8, 64, "walk"),
            "repeats",
        ),
        # A predicate must be an IRI; a literal names no statements at all.
        (
            ([(purrdf.Literal("p"), "forward")], 1, 4, 8, 64, "walk"),
            "must be an IRI",
        ),
        # A zero-hop path is the identity and has no witness.
        (([(_node("p"), "forward")], 0, 4, 8, 64, "walk"), "min_hops must be at least 1"),
        # An empty accepted-length interval is a caller who has not finished deciding.
        (([(_node("p"), "forward")], 3, 2, 8, 64, "walk"), "exceeds max_hops"),
        # A guard of zero can only ever produce an error.
        (
            ([(_node("p"), "forward")], 1, 4, 0, 64, "walk"),
            "max_paths_per_seed must be at least 1",
        ),
        (
            ([(_node("p"), "forward")], 1, 4, 8, 0, "walk"),
            "max_expansions_per_invocation must be at least 1",
        ),
    ],
)
def test_a_malformed_path_relation_is_refused_by_name(
    declaration: object, message: str
) -> None:
    """Each rule of the declaration is its own diagnostic, naming what is wrong."""
    store = _store_with(CHAIN_TTL)

    with pytest.raises(ValueError, match=message):
        store.query(WALK_QUERY, path_relations={WALK: declaration})


def test_a_max_hops_past_every_walk_is_accepted_and_answers() -> None:
    """A `max_hops` far past any walk the chain holds is valid configuration.

    The traversal keeps its per-depth state on the heap, so the depth needs no ceiling:
    the relation answers exactly the rows the chain's own walks produce, the same rows a
    `max_hops` sized for the chain answers — the neighbour of the refusals above.
    """
    store = _store_with(CHAIN_TTL)
    deep = {WALK: ([(_node("p"), "forward")], 1, 100_000, 1024, 100_000, "walk")}

    assert _walk_rows(store.query(WALK_QUERY, path_relations=deep)) == _walk_rows(
        store.query(WALK_QUERY, path_relations=_walk_relation())
    )


def test_a_step_the_data_has_no_edges_for_answers_nothing() -> None:
    """An edgeless alternative is valid configuration, not a misconfiguration.

    An alternation is an alternation: ``p|q`` does not fail when ``q`` matches nothing,
    and neither does a step. A host with a fixed step vocabulary querying many stores
    supplies valid configuration every time, and a store carrying none of those edges has
    a correct answer — the empty one.
    """
    store = _store_with(CHAIN_TTL)

    solutions = store.query(
        WALK_QUERY,
        path_relations={
            WALK: ([(_node("noSuchPredicate"), "forward")], 1, 4, 8, 64, "walk")
        },
    )

    assert len(solutions) == 0  # type: ignore[arg-type]


@pytest.mark.parametrize(
    "declaration",
    [
        ([(_node("p"), "forward")], 1, 4, 8, 64),
        ([(_node("p"), "forward")], 1, 4, 8, 64, "walk", "extra"),
        "not-a-tuple",
    ],
)
def test_a_malformed_path_declaration_is_a_type_error(declaration: object) -> None:
    """The expected six-position shape is named in the error."""
    with pytest.raises(TypeError, match="must be declared as"):
        _store_with(CHAIN_TTL).query(WALK_QUERY, path_relations={WALK: declaration})


def test_a_malformed_step_pair_is_a_type_error() -> None:
    """A step is a `(predicate, direction)` PAIR, and the error says so."""
    with pytest.raises(TypeError, match="forward"):
        _store_with(CHAIN_TTL).query(
            WALK_QUERY,
            path_relations={WALK: ([(_node("p"),)], 1, 4, 8, 64, "walk")},
        )


def test_a_non_integer_envelope_field_is_a_type_error() -> None:
    """An envelope field is a count, so it is read as a non-negative integer."""
    with pytest.raises(TypeError, match="`min_hops`"):
        _store_with(CHAIN_TTL).query(
            WALK_QUERY,
            path_relations={WALK: ([(_node("p"), "forward")], "one", 4, 8, 64, "walk")},
        )


def test_one_iri_declared_across_two_relation_kinds_is_refused() -> None:
    """A shadowed relation is refused across ALL THREE dicts, not only two.

    Both pairings that involve `path_relations` are executed, because "all three" is a
    completeness claim and one pairing is not evidence for it: the `relations` +
    `path_relations` collision and the `relations_from_graph` + `path_relations` one are
    separate insertions into the shared name table, and a guard that covered only the
    first would satisfy a test that only ran the first.
    """
    store = _store_with(CHAIN_TTL)

    with pytest.raises(ValueError, match="declared twice"):
        store.query(
            WALK_QUERY,
            relations={WALK: (1, 6, [])},
            path_relations=_walk_relation(),
        )

    with pytest.raises(ValueError, match="declared twice"):
        store.query(
            WALK_QUERY,
            relations_from_graph={WALK: (_node("memberTable"), 1, 1)},
            path_relations=_walk_relation(),
        )


def test_the_path_relation_keyword_is_keyword_only() -> None:
    """Every engine-configuration argument is named at the call site."""
    with pytest.raises(TypeError):
        _store_with(CHAIN_TTL).query(WALK_QUERY, _walk_relation())  # type: ignore[misc]


# ── a path relation under an entailment regime ────────────────────────────────────

#: `ex:sub rdfs:subPropertyOf ex:p` makes `ex:b ex:p ex:c` ENTAILED and never asserted,
#: so the RDFS closure carries an `ex:p` edge the store does not.
SUBPROPERTY_TTL = f"""
@prefix ex: <{EX}> .
@prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#> .

ex:sub rdfs:subPropertyOf ex:p .
ex:a ex:p ex:b .
ex:b ex:sub ex:c .
"""

#: `A ⊑ ∃r.B`, `a : A` — the shape whose combined-approach answer needs a chase-minted
#: existential witness, which is the one closure a path relation may not be built over.
SOME_VALUES_FROM_TTL = f"""
@prefix ex: <{EX}> .
@prefix owl: <http://www.w3.org/2002/07/owl#> .
@prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#> .

ex:A a owl:Class .
ex:B a owl:Class .
ex:A rdfs:subClassOf [ a owl:Restriction ; owl:onProperty ex:r ; owl:someValuesFrom ex:B ] .
ex:a a ex:A .
"""


def test_a_path_relation_under_entailment_walks_the_closure() -> None:
    """The walk reads the CLOSURE, so it agrees with `p+` in the same query.

    It did not always. ``path_relations`` was snapshotted from the store while the query
    was answered over the closure the reasoner materialized, so a regime that DERIVED a
    quad under the step's predicate left the walk answering about a strictly smaller edge
    set than every other pattern beside it — a short bag, returned as a complete result,
    with no diagnostic.

    Three runs settle it rather than one: `p+` and the walk under the same regime must
    agree, and the walk with NO regime must answer the smaller set — otherwise the fix
    could be a relation that was simply widened into always returning more.
    """
    store = _store_with(SUBPROPERTY_TTL)
    grammar = store.query_entailment_governed(
        f"SELECT ?end WHERE {{ <{EX}a> <{EX}p>+ ?end }} ORDER BY ?end",
        "rdfs",
    )
    assert grammar.outcome is not None
    assert _column(grammar.outcome.result) == ["b", "c"]

    entailed = store.query_entailment_governed(
        WALK_QUERY, "rdfs", path_relations=_walk_relation()
    )
    assert entailed.outcome is not None
    # Read once: a solution sequence is an iterator, so a second pass over the same
    # handle would see it already drained and read an empty set as an agreement.
    walked = _walk_rows(entailed.outcome.result)
    assert walked == [
        ("b", 1, 1, "b"),
        ("c", 2, 1, "b"),
        ("c", 2, 2, "c"),
    ]

    # The endpoint sets agree — the invariant, read off the two answers.
    assert sorted({row[0] for row in walked}) == ["b", "c"]

    # Without the regime the derived edge does not exist, so the walk stops at `ex:b`.
    plain = store.query(WALK_QUERY, path_relations=_walk_relation())
    assert _walk_rows(plain) == [("b", 1, 1, "b")]


def test_a_graph_table_under_entailment_reads_the_closure() -> None:
    """`relations_from_graph` follows the same order, for the same reason.

    A table head is read out of the dataset exactly as a traversal's edges are, so a
    regime that completes the list reaches it. `rdfs:subPropertyOf` makes the head's
    `rdf:rest` an entailed triple, which the pre-closure store does not carry: the read
    used to stop at the first cell, and now it reaches the row the entailed cell names.
    """
    turtle = f"""
@prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> .
@prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#> .
@prefix ex: <{EX}> .

ex:tail rdfs:subPropertyOf rdf:rest .

ex:memberTable
    rdf:first ( ex:ada ex:alpha ) ;
    ex:tail   ( ( ex:brian ex:alpha ) ) .
"""
    store = _store_with(turtle)
    entailed = store.query_entailment_governed(
        SELECT_MEMBERS,
        "rdfs",
        relations_from_graph={MEMBER_OF: (_node("memberTable"), 1, 1)},
    )
    assert entailed.outcome is not None
    assert _pairs(entailed.outcome.result) == [("ada", "alpha"), ("brian", "alpha")]

    # Without the regime the head carries no `rdf:rest` at all, so the list ends after
    # its first cell and the table is one row short. That smaller answer is what the
    # pre-closure read gives, and it is what makes the regime — rather than a widened
    # reader — the whole cause of the row above.
    assert _pairs(
        store.query(
            SELECT_MEMBERS,
            relations_from_graph={MEMBER_OF: (_node("memberTable"), 1, 1)},
        )
    ) == [("ada", "alpha")]


def test_a_path_relation_is_refused_only_where_the_chase_minted_a_witness() -> None:
    """The one refused pairing, executed beside the two neighbours it must not refuse.

    An OWL Direct-Semantics closure whose restricted chase minted existential witnesses
    carries blank nodes that are not terms of the scoping graph, and the regime's witness
    filtration cannot reach a property function's output — so a walk over that closure
    could hand one back. That pairing raises. Every other regime, and every `owl-direct`
    run that mints nothing, still answers.
    """
    minting = _store_with(SOME_VALUES_FROM_TTL)
    with pytest.raises(ValueError, match="reasoning-closure-relation-witness"):
        minting.query_entailment_governed(
            WALK_QUERY, "owl-direct", path_relations=_walk_relation()
        )

    # Neighbour one: the same ontology under the same regime, with no relation, still
    # returns the combined approach's certain answer.
    answered = minting.query_entailment_governed(
        f"SELECT ?x WHERE {{ ?x <{EX}r> ?y . ?y a <{EX}B> }}", "owl-direct"
    )
    assert answered.outcome is not None
    assert _column(answered.outcome.result) == ["a"]

    # Neighbour two: `owl:equivalentClass` is outside the Horn fragment the combined
    # approach certifies, so that lane mints nothing and the walk runs.
    mintless = _store_with(
        f"""
@prefix ex: <{EX}> .
@prefix owl: <http://www.w3.org/2002/07/owl#> .

ex:A a owl:Class .
ex:B a owl:Class .
ex:A owl:equivalentClass ex:B .
ex:a a ex:A .
ex:a ex:p ex:b .
"""
    )
    walked = mintless.query_entailment_governed(
        WALK_QUERY, "owl-direct", path_relations=_walk_relation()
    )
    assert walked.outcome is not None
    assert _walk_rows(walked.outcome.result) == [("b", 1, 1, "b")]


def test_every_relation_refusal_names_the_relation_it_is_about() -> None:
    """A ``relations`` map holds several, so the message has to say which to fix.

    The kernel's arity and list diagnostics describe the DEFECT — "row 0 has 1
    value(s)", "not an rdf:List" — and say nothing about which declaration
    produced it. The boundary adds the relation IRI, and that prefix is the only
    thing turning a correct diagnosis into an actionable one when a host declared
    four relations and one of them is wrong. Nothing else asserts the prefix, so
    deleting it would leave every refusal test here green.

    The valid relation declared alongside the broken one is deliberate: it is what
    makes "which one" a real question, and it is the neighbour that must not be
    swept into the refusal.
    """
    with pytest.raises(ValueError) as refused:
        purrdf.Store().query(
            SELECT_MEMBERS,
            relations={
                MEMBER_OF: (1, 1, [[_node("ada")]]),
                f"{REL}wellFormed": (1, 1, [[_node("ada"), _node("blue")]]),
            },
        )
    message = str(refused.value)
    assert f"<{MEMBER_OF}>" in message, (
        f"the refusal names the relation that was misconfigured: {message}"
    )
    assert f"{REL}wellFormed" not in message, (
        f"…and not the one that was fine: {message}"
    )

    # The same prefix on the dataset-read spelling, whose defect text names a
    # table head rather than a row width.
    with pytest.raises(ValueError) as refused:
        purrdf.Store().query(
            SELECT_MEMBERS,
            relations_from_graph={MEMBER_OF: (_node("noSuchTable"), 1, 1)},
        )
    assert f"<{MEMBER_OF}>" in str(refused.value), str(refused.value)

    # …and on the path spelling, whose defect text names an envelope field.
    with pytest.raises(ValueError) as refused:
        purrdf.Store().query(
            WALK_QUERY,
            path_relations={WALK: ([(_node("p"), "forward")], 0, 4, 8, 64, "walk")},
        )
    assert f"<{WALK}>" in str(refused.value), str(refused.value)

    # The neighbouring well-formed declarations still answer, so none of the three
    # refusals above is over-refusal of a valid map.
    assert _pairs(purrdf.Store().query(SELECT_MEMBERS, relations=_member_relations())) == [
        ("ada", "alpha"),
        ("brian", "alpha"),
        ("chen", "beta"),
    ]
    assert _walk_rows(
        _store_with(CHAIN_TTL).query(
            WALK_QUERY,
            path_relations={WALK: ([(_node("p"), "forward")], 1, 4, 8, 64, "walk")},
        )
    )
