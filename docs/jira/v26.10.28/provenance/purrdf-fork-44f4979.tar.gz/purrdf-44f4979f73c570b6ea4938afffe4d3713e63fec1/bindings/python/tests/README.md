<!-- SPDX-FileCopyrightText: 2026 Blackcat Informatics® Inc. <paudley@blackcatinformatics.ca> -->
<!-- SPDX-License-Identifier: CC-BY-4.0 -->

# purrdf Python test suite

Run from `bindings/python/`:

```bash
uv run maturin develop      # (re)build the native module after any Rust change
uv run pytest tests         # or: make pytest   (from the repo root)
```

## Layout

| File / dir | Purpose |
|---|---|
| `conftest.py` | Shared fixtures (`compat`, `oracle`) + the xfail-ledger XPASS hook. |
| `xfail_ledger.toml` | `node_id → reason` for tests expected to fail against the shim. Applied as **strict** xfails; the ledger only shrinks (AGENTS.md §2 discipline). |
| `test_compat_parity.py` | Differential suite: real `rdflib` (oracle) vs `purrdf.compat.rdflib` (shim), locking in current behavior. |
| `test_contextual_mappings.py` | Python receiver dispatch, scope/configuration keyword forwarding, isolated shadow import, PyO3 term extraction and Python result-row accessors. Compiler and evaluator semantics are tested in Rust. |
| `test_rdflib_suite.py` | The **rdflib LSP conformance gate**: drives the subprocess runner and asserts a green result (pass + strict-xfail only). |
| `rdflib_suite/` | The conformance gate's machinery: `runner.py` (subprocess entry that shadows `rdflib` and runs the vendored suite), `xfail_ledger.toml` (its own strict-xfail ledger), and `vendor/` (rdflib 7.6.0's OWN tests, verbatim, with `LICENSE` + `PROVENANCE.md`). Excluded from parent collection via `collect_ignore_glob`. |

## The rdflib LSP conformance gate

`test_rdflib_suite.py` runs rdflib's **own**, verbatim-vendored tests against the
shim. Because the shadow and the oracle share the `rdflib` import name (see rule
below), the whole vendored suite runs in a **subprocess** (`rdflib_suite/runner.py`)
whose `import rdflib` resolves to the top-level rdflib shadow; the parent oracle env is never
mutated. Every gap is a strict xfail in `rdflib_suite/xfail_ledger.toml` with a
concrete reason — an XPASS or a stale ledger key turns the gate RED, so the ledger
only shrinks. Last complete broad-suite snapshot. Scoreboard: **81 passed / 5 xfailed**. See
`rdflib_suite/vendor/PROVENANCE.md` for the exact version, sha, file list, and the
explicit (never silent) exclusions.

## Two rdflib names, one rule: never let the shadow shadow the oracle

- The `dev` dependency group installs the **real** `rdflib` (currently 7.6.x). It
  is the differential *oracle* the parity suite compares against, and the target
  of the "rdflib's own test suite" gate.
- A separate `python-rdflib-shadow` distribution ships a top-level **`rdflib` shadow** package that re-exports
  `purrdf.compat.rdflib`. It claims the same import name.
- These MUST NOT co-inhabit one environment — a differential test whose "reference"
  is secretly the implementation under test proves nothing.
  - The oracle env (this `dev` group) never installs the shadow.
  - The shadow is exercised in isolation: a separate venv, or via explicit
    `sys.modules['rdflib'] = purrdf.compat.rdflib` injection inside a dedicated
    test module — not by installing the top-level package here.

## Gates

`make pytest` (and its CI job) is **separate** from `make check`. `make check` is
the Rust gate (fmt/clippy/build/tests/hygiene) and must stay runnable without a
Python toolchain; the Python suite is its own gate.
